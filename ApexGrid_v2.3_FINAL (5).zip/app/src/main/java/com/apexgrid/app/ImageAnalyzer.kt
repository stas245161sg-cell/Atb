package com.apexgrid.app

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.Closeable
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

enum class RoiZone(val key: String, val title: String) {
    CHART("chart", "График"),
    STOCH("stoch", "Stochastic"),
    AO("ao", "AO"),
    PAYOUT("payout", "Выплата"),
    PAIR("pair", "Пара")
}

data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

object RoiPrefs {
    private const val FILE = "apexgrid_v2_roi_prefs"
    private const val MIN_SIZE = 0.01f

    fun default(zone: RoiZone): NormRect = when (zone) {
        // Зоны по скриншотам интерфейса Pocket Option (HA M5, 1080x2400).
        RoiZone.CHART -> NormRect(0.02f, 0.190f, 0.86f, 0.540f)
        RoiZone.STOCH -> NormRect(0.02f, 0.725f, 0.95f, 0.815f)
        RoiZone.AO -> NormRect(0.02f, 0.815f, 0.95f, 0.905f)
        RoiZone.PAYOUT -> NormRect(0.06f, 0.620f, 0.94f, 0.720f)
        RoiZone.PAIR -> NormRect(0.06f, 0.135f, 0.48f, 0.185f)
    }

    fun load(ctx: Context, zone: RoiZone): NormRect {
        val sp = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = default(zone)
        val p = "roi_${zone.key}_"
        val r = NormRect(
            sp.getFloat(p + "left", d.left),
            sp.getFloat(p + "top", d.top),
            sp.getFloat(p + "right", d.right),
            sp.getFloat(p + "bottom", d.bottom)
        )
        return if (isValid(r)) r else d
    }

    fun save(ctx: Context, zone: RoiZone, r: NormRect) {
        val fixed = if (isValid(r)) r else default(zone)
        val p = "roi_${zone.key}_"
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(p + "left", fixed.left)
            .putFloat(p + "top", fixed.top)
            .putFloat(p + "right", fixed.right)
            .putFloat(p + "bottom", fixed.bottom)
            .apply()
    }

    fun resetAll(ctx: Context) {
        RoiZone.entries.forEach { save(ctx, it, default(it)) }
    }

    private fun isValid(r: NormRect): Boolean =
        r.left >= 0f && r.top >= 0f && r.right <= 1f && r.bottom <= 1f &&
            r.right - r.left >= MIN_SIZE && r.bottom - r.top >= MIN_SIZE
}

object Roi {
    const val POCKET_PACKAGE = "com.pocketoption.broker"
    const val LAST_FRAME_FILE = "apexgrid_v2_last_frame.jpg"
    const val CANDLES_TO_COLLECT = 30
    const val MIN_VALID_CANDLES = 6
    const val LIVE_EDGE_SCROLLED = 0.97f
    const val LIVE_EDGE_LIVE = 0.90f
    const val STOCH_RECENT = 0.04f
    const val STOCH_Y80_ABS = 0.7163f
    const val STOCH_Y20_ABS = 0.7577f
    const val CANDLE_MAX_WIDTH = 0.04f
    const val MAX_ANALYSIS_WIDTH = 1080
}

private object Hsv {
    val GREEN_LO = Scalar(30.0, 80.0, 80.0)
    val GREEN_HI = Scalar(72.0, 255.0, 255.0)
    val RED1_LO = Scalar(0.0, 80.0, 80.0)
    val RED1_HI = Scalar(10.0, 255.0, 255.0)
    val RED2_LO = Scalar(170.0, 80.0, 80.0)
    val RED2_HI = Scalar(180.0, 255.0, 255.0)
    val ST_CYAN_LO = Scalar(72.0, 85.0, 90.0)
    val ST_CYAN_HI = Scalar(112.0, 255.0, 255.0)
    val ST_MAGENTA_LO = Scalar(135.0, 85.0, 90.0)
    val ST_MAGENTA_HI = Scalar(172.0, 255.0, 255.0)
    val PRICE_LINE_LO = Scalar(106.0, 80.0, 80.0)
    val PRICE_LINE_HI = Scalar(125.0, 255.0, 255.0)
    val WHITE_LO = Scalar(0.0, 0.0, 190.0)
    val WHITE_HI = Scalar(180.0, 60.0, 255.0)
    val STOCH_K_LO = Scalar(100.0, 110.0, 110.0)
    val STOCH_K_HI = Scalar(128.0, 255.0, 255.0)
    val STOCH_D_LO = Scalar(5.0, 110.0, 110.0)
    val STOCH_D_HI = Scalar(18.0, 255.0, 255.0)
    val LEVEL80_LO = Scalar(80.0, 100.0, 60.0)
    val LEVEL80_HI = Scalar(92.0, 255.0, 255.0)
    val LEVEL20_LO = Scalar(20.0, 100.0, 60.0)
    val LEVEL20_HI = Scalar(28.0, 255.0, 255.0)
}

private class Mats : Closeable {
    private val list = ArrayList<Mat>()
    fun <T : Mat> keep(m: T): T {
        list.add(m)
        return m
    }
    fun mat(): Mat = keep(Mat())
    override fun close() {
        list.forEach { it.release() }
        list.clear()
    }
}

private class Box(val r0: Int, val r1: Int, val c0: Int, val c1: Int)

private class CandleInfo(
    val topY: Int,
    val bottomY: Int,
    val bodyTopY: Int,
    val bodyBottomY: Int,
    val green: Boolean,
    val body: Float,
    val closeY: Float,
    val rightX: Int,
    val upperWickRatio: Float,
    val lowerWickRatio: Float
)

private class ChartResult(
    val live: Boolean,
    val candles: List<CandleInfo>,
    val note: String = "",
    val endX: Int = -1,
    val pitch: Float = 0f
)

class ImageAnalyzer(context: Context) : Closeable {

    private companion object {
        const val TAG = "ApexGrid_v2.0"
        const val MIN_ST_PIXELS = 3
        const val OCR_INTERVAL_MS = 600L
        const val PAYOUT_TTL_MS = 45_000L
        const val PAYOUT_HARD_TTL_MS = 120_000L
        const val PAIR_OCR_INTERVAL_MS = 450L
        const val PAIR_OCR_ERR_LOG_MS = 10_000L
        const val PAYOUT_STABLE_INTERVAL_MS = 2_500L
        const val PAYOUT_EDGE_INTERVAL_MS = 400L
        const val PAYOUT_STABLE_HOLD_MS = 2_000L
        const val CANDLE_CLOSE_WINDOW_MS = 4_000L
        const val PITCH_CACHE_MS = 2_500L
        const val CANDLE_CACHE_MS = 8_000L
        const val ST_CACHE_MS = 8_000L
        const val INDICATOR_CACHE_MS = 8_000L
        const val LIVE_DEBOUNCE_MS = 1_000L
        const val OCR_UPSCALE = 3
        const val OCR_LOG_HEARTBEAT_MS = 30_000L
        const val OCR_ERR_LOG_MS = 10_000L
        const val ROI_RELOAD_MS = 1_500L

        val PAYOUT_REGEX = Regex("(\\d{2,3})\\s*%")
        val PAIR_REGEX = Regex("\\b([A-Z]{3})\\s*/\\s*([A-Z]{3})(?:\\s+(OTC))?\\b")
        val PAIR_VALID_REGEX = Regex("^[A-Z]{3}/[A-Z]{3}( OTC)?$")
        val PAIR_GLUED_REGEX = Regex("\\b([A-Z]{3})\\s*/\\s*[I1L]([A-Z]{3})\\b")
        val PAIR_NOSLASH_REGEX = Regex("\\b([A-Z]{3})[I1L]([A-Z]{3})\\b")
        val NON_PAIR_CHARS_REGEX = Regex("[^A-Z0-9/ ]")
        val MULTI_SPACE_REGEX = Regex("\\s+")
        const val PAYOUT_MIN = 50
        const val PAYOUT_MAX = 99
    }

    private val appContext: Context = context.applicationContext

    private val cvReady: Boolean = try {
        OpenCVLoader.initDebug()
    } catch (t: Throwable) {
        Log.e(TAG, "OpenCV init failed", t)
        false
    }
    val ready: Boolean get() = cvReady

    @Volatile var lastError: String? = null
        private set

    private var rois: Map<RoiZone, NormRect> = loadRois()
    private var roisLoadedAt = SystemClock.elapsedRealtime()
    private var lastResizeScale = 1f

    @Volatile private var liveState = true
    private var liveChangedAt = 0L

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val ocrBusy = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastOcrLogKey = ""
    private var lastOcrLogAt = 0L
    private var lastOcrErrAt = 0L
    @Volatile private var payout = -1
    @Volatile private var payoutAt = 0L
    private var payoutStableAt = 0L
    private var lastExtractedPayout = -1

    private val pairOcrBusy = AtomicBoolean(false)
    private var lastPairOcrAt = 0L
    private var lastPairErrAt = 0L
    private var lastPairRawLogKey = ""
    private var lastPairRawLogAt = 0L
    @Volatile private var lastDetectedPair: String = ""
    private var candidatePair: String = ""
    private var candidatePairHits = 0
    @Volatile private var pendingPairResetFrom: String? = null
    @Volatile private var pendingPairResetTo: String? = null
    private var onPairChangedCallback: ((String, String) -> Unit)? = null

    @Volatile private var assetName = ""
    @Volatile private var candleClosed = false
    @Volatile private var gridHealthy = false

    private var prevRightEdgeX = -1
    private var prevPitch = 0f
    private var lastValidPitch = 0f
    private var lastValidPitchAt = 0L
    private var lastValidCandles: List<CandleInfo> = emptyList()
    private var lastValidCandlesAt = 0L
    private var lastStTrend: Trend = Trend.UNKNOWN
    private var lastStAt = 0L
    private var lastAo: Trend = Trend.UNKNOWN
    private var lastAoAt = 0L
    private var lastStoch: Cross = Cross.NONE
    private var lastStochValue = Float.NaN
    private var lastStochAt = 0L
    private var candleClosedUntilMs = 0L

    init {
        LogRepository.addLog("ROI: ${describeRois(rois)}")
    }

    fun setOnPairChangedListener(listener: (oldPair: String, newPair: String) -> Unit) {
        onPairChangedCallback = listener
    }

    fun resetChartTracking(clearDetectedPair: Boolean = false, clearPayout: Boolean = true) {
        prevRightEdgeX = -1
        prevPitch = 0f
        lastValidPitch = 0f
        lastValidPitchAt = 0L
        lastValidCandles = emptyList()
        lastValidCandlesAt = 0L
        gridHealthy = false
        lastStTrend = Trend.UNKNOWN
        lastStAt = 0L
        lastAo = Trend.UNKNOWN
        lastAoAt = 0L
        lastStoch = Cross.NONE
        lastStochValue = Float.NaN
        lastStochAt = 0L
        candleClosedUntilMs = 0L
        if (clearPayout) {
            payout = -1
            payoutAt = 0L
            payoutStableAt = 0L
            lastExtractedPayout = -1
            lastOcrAt = 0L
        }
        candleClosed = false
        if (clearDetectedPair) {
            lastDetectedPair = ""
            pendingPairResetFrom = null
            pendingPairResetTo = null
        }
        candidatePair = ""
        candidatePairHits = 0
        LogRepository.addLog("CHART: сброс X-сетки и кэша выплаты")
    }

    fun consumeCandleClosedWindow() {
        candleClosedUntilMs = 0L
    }

    fun reloadRoisNow() {
        rois = loadRois()
        roisLoadedAt = SystemClock.elapsedRealtime()
        LogRepository.addLog("ApexGrid_v2.0 ROI обновлены: ${describeRois(rois)}")
    }

    private fun loadRois(): Map<RoiZone, NormRect> =
        RoiZone.entries.associateWith { RoiPrefs.load(appContext, it) }

    private fun refreshRois(now: Long) {
        if (now - roisLoadedAt < ROI_RELOAD_MS) return
        roisLoadedAt = now
        val fresh = loadRois()
        if (fresh != rois) {
            rois = fresh
            LogRepository.addLog("ROI обновлены: ${describeRois(fresh)}")
        }
    }

    private fun describeRois(map: Map<RoiZone, NormRect>): String =
        map.entries.joinToString(" ") { (zone, r) ->
            "${zone.key}=x${pct(r.left)}-${pct(r.right)} y${pct(r.top)}-${pct(r.bottom)}"
        }

    private fun pct(v: Float): Int = (v * 100).roundToInt()

    fun analyze(bmp: Bitmap): Snapshot? {
        if (!cvReady) return null
        var scaled: Bitmap? = null
        return try {
            val nowMs = SystemClock.elapsedRealtime()
            refreshRois(nowMs)

            val switchedTo = pendingPairResetTo
            if (switchedTo != null) {
                val switchedFrom = pendingPairResetFrom
                pendingPairResetFrom = null
                pendingPairResetTo = null
                // При смене пары сбрасываем сетку, но сохраняем последнюю валидную выплату,
                // чтобы первый кадр новой пары не давал ложный payout=-1.
                resetChartTracking(clearDetectedPair = false, clearPayout = false)
                onPairChangedCallback?.invoke(switchedFrom.orEmpty(), switchedTo)
            }

            requestPairOcr(bmp, nowMs)
            requestPayoutOcr(bmp)

            scaled = downscaleIfNeeded(bmp)
            val work = scaled ?: bmp

            Mats().use { m ->
                val rgba = m.mat()
                Utils.bitmapToMat(work, rgba)
                val rgb = m.mat()
                Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
                val hsv = m.mat()
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
                val frameW = hsv.cols()

                val chart = chart(hsv, frameW, m)
                val otcNow = isOtcNow()
                if (!chart.live) {
                    gridHealthy = false
                    return@use Snapshot(
                        highs = FloatArray(0), lows = FloatArray(0), closes = FloatArray(0),
                        closeY = Float.NaN, isGreen = false, body = Float.NaN,
                        payout = currentPayout(), live = false,
                        assetName = assetName, isOtc = otcNow,
                        pairName = lastDetectedPair.ifEmpty { "—" }
                    )
                }

                val effectivePitch = if (chart.pitch > 0f) {
                    lastValidPitch = chart.pitch
                    lastValidPitchAt = nowMs
                    chart.pitch
                } else if (nowMs - lastValidPitchAt <= PITCH_CACHE_MS && lastValidPitch > 0f) {
                    lastValidPitch
                } else {
                    0f
                }

                val workingCandles: List<CandleInfo>
                val gridStale: Boolean
                if (chart.candles.size >= Roi.MIN_VALID_CANDLES && effectivePitch > 0f) {
                    workingCandles = chart.candles
                    lastValidCandles = chart.candles
                    lastValidCandlesAt = nowMs
                    gridStale = false
                    gridHealthy = true
                } else if (nowMs - lastValidCandlesAt <= CANDLE_CACHE_MS &&
                    lastValidCandles.size >= Roi.MIN_VALID_CANDLES
                ) {
                    workingCandles = lastValidCandles
                    gridStale = true
                    gridHealthy = false
                } else {
                    gridHealthy = false
                    lastError = "grid_invalid(candles=${chart.candles.size}, pitch=${effectivePitch.roundToInt()})"
                    return@use Snapshot(
                        highs = FloatArray(0), lows = FloatArray(0), closes = FloatArray(0),
                        closeY = Float.NaN, isGreen = false, body = Float.NaN,
                        payout = currentPayout(), live = true,
                        chartNote = "grid_invalid", assetName = assetName, isOtc = otcNow,
                        pairName = lastDetectedPair.ifEmpty { "—" }
                    )
                }

                val isClosed = updateClosedCandleState(workingCandles, effectivePitch, nowMs)
                candleClosed = isClosed
                val closed = if (workingCandles.size >= 2) workingCandles.dropLast(1) else emptyList()

                val (stRaw, _) = if (chart.endX >= 0 && closed.isNotEmpty()) {
                    val cb = box(hsv, rois.getValue(RoiZone.CHART))
                    val croi = hsv.crop(cb, m)
                    val newest = closed.last()
                    superTrend(croi, chart.endX + 1, frameW, (newest.topY + newest.bottomY) / 2, m)
                } else Pair(Trend.UNKNOWN, "no_chart")

                val stTrend = if (stRaw != Trend.UNKNOWN) {
                    lastStTrend = stRaw
                    lastStAt = nowMs
                    stRaw
                } else if (nowMs - lastStAt <= ST_CACHE_MS && lastStTrend != Trend.UNKNOWN) {
                    lastStTrend
                } else {
                    Trend.UNKNOWN
                }

                val (rawCross, rawCrossVal) = stochastic(hsv, frameW, m)
                val cross: Cross
                val crossVal: Float
                if (rawCross != Cross.NONE) {
                    lastStoch = rawCross
                    lastStochValue = rawCrossVal
                    lastStochAt = nowMs
                    cross = rawCross
                    crossVal = rawCrossVal
                } else if (nowMs - lastStochAt <= INDICATOR_CACHE_MS) {
                    cross = lastStoch
                    crossVal = lastStochValue
                } else {
                    cross = Cross.NONE
                    crossVal = Float.NaN
                }

                val rawAo = awesome(hsv, m).first
                val aoTrend: Trend
                if (rawAo != Trend.UNKNOWN) {
                    lastAo = rawAo
                    lastAoAt = nowMs
                    aoTrend = rawAo
                } else if (nowMs - lastAoAt <= INDICATOR_CACHE_MS && lastAo != Trend.UNKNOWN) {
                    aoTrend = lastAo
                } else {
                    aoTrend = Trend.UNKNOWN
                }

                val highs = FloatArray(closed.size) { closed[it].topY.toFloat() }
                val lows = FloatArray(closed.size) { closed[it].bottomY.toFloat() }
                val closes = FloatArray(closed.size) { closed[it].closeY.toFloat() }
                val last = closed.lastOrNull()
                Snapshot(
                    highs = highs,
                    lows = lows,
                    closes = closes,
                    closeY = last?.closeY ?: Float.NaN,
                    isGreen = last?.green ?: false,
                    body = last?.body ?: Float.NaN,
                    payout = currentPayout(),
                    chartNote = if (gridStale) "stale_grid" else chart.note,
                    superTrend = stTrend,
                    stochCross = cross,
                    stochValue = crossVal,
                    ao = aoTrend,
                    assetName = assetName,
                    isOtc = otcNow,
                    pairName = lastDetectedPair.ifEmpty { "—" },
                    candleClosed = candleClosed,
                    upperWickRatio = last?.upperWickRatio ?: 0f,
                    lowerWickRatio = last?.lowerWickRatio ?: 0f
                )
            }
        } catch (t: Throwable) {
            Log.e(TAG, "analyze failed", t)
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            null
        } finally {
            scaled?.recycle()
        }
    }

    private fun updateClosedCandleState(candles: List<CandleInfo>, pitch: Float, nowMs: Long): Boolean {
        val lastRightX = candles.lastOrNull()?.rightX ?: return false
        if (prevPitch > 0f && abs(pitch - prevPitch) > prevPitch * 0.45f) {
            candleClosedUntilMs = 0L
        }
        prevPitch = pitch
        if (pitch > 0f && prevRightEdgeX >= 0) {
            val shift = lastRightX - prevRightEdgeX
            if (shift >= (pitch * 0.70f).roundToInt()) {
                candleClosedUntilMs = nowMs + CANDLE_CLOSE_WINDOW_MS
            }
        }
        prevRightEdgeX = lastRightX
        return nowMs <= candleClosedUntilMs
    }

    private fun downscaleIfNeeded(bmp: Bitmap): Bitmap? {
        if (bmp.width <= Roi.MAX_ANALYSIS_WIDTH) {
            lastResizeScale = 1f
            return null
        }
        val scale = Roi.MAX_ANALYSIS_WIDTH.toFloat() / bmp.width
        val height = (bmp.height * scale).roundToInt().coerceAtLeast(1)
        if (abs(scale - lastResizeScale) > 0.001f) {
            lastResizeScale = scale
            LogRepository.addLog("image_resized(scale=${String.format(Locale.US, "%.2f", scale)})")
        }
        return Bitmap.createScaledBitmap(bmp, Roi.MAX_ANALYSIS_WIDTH, height, true)
    }

    private fun box(hsv: Mat, r: NormRect): Box {
        val r0 = (hsv.rows() * r.top).toInt().coerceIn(0, hsv.rows() - 1)
        val r1 = (hsv.rows() * r.bottom).toInt().coerceIn(r0 + 1, hsv.rows())
        val c0 = (hsv.cols() * r.left).toInt().coerceIn(0, hsv.cols() - 1)
        val c1 = (hsv.cols() * r.right).toInt().coerceIn(c0 + 1, hsv.cols())
        return Box(r0, r1, c0, c1)
    }

    private fun Mat.crop(b: Box, m: Mats): Mat = m.keep(submat(b.r0, b.r1, b.c0, b.c1))

    private fun greenMask(src: Mat, m: Mats): Mat {
        val out = m.mat()
        Core.inRange(src, Hsv.GREEN_LO, Hsv.GREEN_HI, out)
        return out
    }

    private fun redMask(src: Mat, m: Mats): Mat {
        val a = m.mat()
        val b = m.mat()
        Core.inRange(src, Hsv.RED1_LO, Hsv.RED1_HI, a)
        Core.inRange(src, Hsv.RED2_LO, Hsv.RED2_HI, b)
        Core.bitwise_or(a, b, a)
        return a
    }

    private fun lastColoredColumn(mask: Mat, m: Mats, minPixels: Int = 2): Int {
        val sums = m.mat()
        Core.reduce(mask, sums, 0, Core.REDUCE_SUM, CvType.CV_32S)
        val arr = IntArray(mask.cols())
        sums.get(0, 0, arr)
        var x = arr.size - 1
        while (x >= 0 && arr[x] < 255 * minPixels) x--
        return x
    }

    private fun removeSpecks(g: Mat, r: Mat, all: Mat, frameW: Int, m: Mats) {
        val s = frameW / 540f
        val minW = maxOf(2, (3f * s).roundToInt())
        val minH = maxOf(3, (6f * s).roundToInt())
        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return
        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        val junk = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            if (st[i * 5 + 2] < minW && st[i * 5 + 3] < minH) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(junk, one, junk)
                found = true
            }
        }
        if (!found) return
        val inverse = m.mat()
        Core.bitwise_not(junk, inverse)
        Core.bitwise_and(g, inverse, g)
        Core.bitwise_and(r, inverse, r)
        Core.bitwise_or(g, r, all)
    }

    private fun chart(hsv: Mat, frameW: Int, m: Mats): ChartResult {
        val b = box(hsv, rois.getValue(RoiZone.CHART))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)
        removeSpecks(g, r, all, frameW, m)
        val end = lastColoredColumn(all, m)
        if (end < 0) return ChartResult(true, emptyList(), "no_colored_pixels_in_chart_roi")
        val roiW = (b.c1 - b.c0).coerceAtLeast(1)
        val edge = end.toFloat() / roiW
        val now = SystemClock.elapsedRealtime()
        if (now - liveChangedAt >= LIVE_DEBOUNCE_MS) {
            when {
                !liveState && edge <= Roi.LIVE_EDGE_LIVE -> {
                    liveState = true
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: на последней свече (edge=${pct(edge)}%)")
                }
                liveState && edge >= Roi.LIVE_EDGE_SCROLLED -> {
                    liveState = false
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: прокручен (edge=${pct(edge)}%)")
                }
            }
        }
        if (!liveState) return ChartResult(false, emptyList(), endX = end)
        val (candles, pitch) = collectCandles(all, g, r, frameW, m)
        val note = when {
            candles.isEmpty() -> "no_candles_found"
            candles.size < Roi.CANDLES_TO_COLLECT -> "candles=${candles.size}/${Roi.CANDLES_TO_COLLECT}"
            else -> ""
        }
        return ChartResult(true, candles, note, end, pitch)
    }

    private fun collectCandles(all: Mat, g: Mat, r: Mat, frameW: Int, m: Mats): Pair<List<CandleInfo>, Float> {
        val lab = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, lab, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return Pair(emptyList(), 0f)
        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        val maxAllowedWidth = (frameW * Roi.CANDLE_MAX_WIDTH).toInt()
        val minH = maxOf(8, (8f * frameW / 540f).roundToInt())
        val candidates = ArrayList<Triple<Int, Float, Int>>()
        for (i in 1 until n) {
            val x = st[i * 5]
            val y = st[i * 5 + 1]
            val w = st[i * 5 + 2]
            val h = st[i * 5 + 3]
            val area = st[i * 5 + 4]
            if (y < 5 || y + h > all.rows() - 5) continue
            if (w !in 3..maxAllowedWidth || h < minH) continue
            if (w > h * 1.35f) continue
            if (area.toFloat() < 0.22f * w * h) continue
            candidates.add(Triple(i, x + w * 0.5f, h))
        }
        if (candidates.isEmpty()) return Pair(emptyList(), 0f)
        candidates.sortBy { it.second }
        var pitch = 0f
        if (candidates.size >= 4) {
            val deltas = ArrayList<Float>()
            for (k in 1 until candidates.size) {
                val dx = candidates[k].second - candidates[k - 1].second
                if (dx >= 2.5f) deltas.add(dx)
            }
            if (deltas.isNotEmpty()) {
                deltas.sort()
                pitch = deltas[(deltas.size * 0.35f).toInt()].coerceAtLeast(3f)
            }
        }
        val pickedIds: List<Int> = if (pitch > 0f && candidates.size >= 4) {
            val chain = ArrayList<Triple<Int, Float, Int>>()
            var anchor = candidates.last()
            chain.add(anchor)
            val tol = maxOf(2.5f, pitch * 0.32f)
            for (k in candidates.size - 2 downTo 0) {
                val cur = candidates[k]
                val gap = anchor.second - cur.second
                if (gap < pitch * 0.55f) {
                    if (cur.third > anchor.third) {
                        chain[chain.lastIndex] = cur
                        anchor = cur
                    }
                    continue
                }
                val steps = (gap / pitch).roundToInt()
                if (steps in 1..3 && abs(gap - steps * pitch) <= tol) {
                    chain.add(cur)
                    anchor = cur
                    if (chain.size >= Roi.CANDLES_TO_COLLECT) break
                }
            }
            chain.reverse()
            chain.map { it.first }
        } else {
            candidates.takeLast(Roi.CANDLES_TO_COLLECT).map { it.first }
        }
        val cols = lab.cols()
        val labArr = IntArray(lab.rows() * cols)
        lab.get(0, 0, labArr)
        val out = ArrayList<CandleInfo>(pickedIds.size)
        for (idx in pickedIds) {
            val c = measureCandle(labArr, cols, g, r, idx, st, m) ?: continue
            out.add(c)
        }
        return Pair(out, pitch)
    }

    private fun measureCandle(labels: IntArray, cols: Int, g: Mat, r: Mat, idx: Int, st: IntArray, m: Mats): CandleInfo? {
        val x = st[idx * 5]
        val y = st[idx * 5 + 1]
        val w = st[idx * 5 + 2]
        val h = st[idx * 5 + 3]
        if (w < 1 || h < 2) return null
        val rowCounts = IntArray(h)
        for (yy in y until y + h) {
            var count = 0
            val base = yy * cols
            for (xx in x until x + w) if (labels[base + xx] == idx) count++
            rowCounts[yy - y] = count
        }
        val maxRow = rowCounts.maxOrNull() ?: 0
        if (maxRow < 4) return null
        val threshold = maxOf(3, (0.5f * maxRow).roundToInt())
        var bodyTop = -1
        var bodyBot = -1
        for (i in rowCounts.indices) {
            if (rowCounts[i] >= threshold) {
                if (bodyTop < 0) bodyTop = i
                bodyBot = i
            }
        }
        if (bodyTop < 0) return null
        val gBody = m.keep(g.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val rBody = m.keep(r.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val green = Core.countNonZero(gBody) > Core.countNonZero(rBody)
        val body = ((bodyBot - bodyTop + 1).toFloat() / h).coerceIn(0f, 1f)
        val upperWick = (bodyTop.toFloat() / h).coerceIn(0f, 1f)
        val lowerWick = ((h - 1 - bodyBot).coerceAtLeast(0).toFloat() / h).coerceIn(0f, 1f)
        val closeY = (if (green) y + bodyTop else y + bodyBot).toFloat()
        return CandleInfo(y, y + h - 1, y + bodyTop, y + bodyBot, green, body, closeY, x + w, upperWick, lowerWick)
    }

    private fun priceLineBand(roi: Mat, m: Mats): IntArray? {
        val blue = m.mat()
        Core.inRange(roi, Hsv.PRICE_LINE_LO, Hsv.PRICE_LINE_HI, blue)
        val sums = m.mat()
        Core.reduce(blue, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = blue.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var best = 0
        for (y in 1 until rows) if (arr[y] > arr[best]) best = y
        if (arr[best] < 255 * 0.25f * blue.cols()) return null
        return intArrayOf((best - 3).coerceAtLeast(0), (best + 4).coerceAtMost(rows), best)
    }

    private fun superTrend(roi: Mat, x1: Int, frameW: Int, candleCenterY: Int, m: Mats): Pair<Trend, String> {
        val cyan = m.mat()
        val magenta = m.mat()
        Core.inRange(roi, Hsv.ST_CYAN_LO, Hsv.ST_CYAN_HI, cyan)
        Core.inRange(roi, Hsv.ST_MAGENTA_LO, Hsv.ST_MAGENTA_HI, magenta)
        val line = m.mat()
        Core.bitwise_or(cyan, magenta, line)

        val white = m.mat()
        Core.inRange(roi, Hsv.WHITE_LO, Hsv.WHITE_HI, white)
        val labels = m.mat()
        val stats = m.mat()
        val cents = m.mat()
        val nLab = Imgproc.connectedComponentsWithStats(white, labels, stats, cents, 8, CvType.CV_32S)
        if (nLab > 1) {
            val st = IntArray(nLab * 5)
            stats.get(0, 0, st)
            val cutMask = m.keep(Mat.zeros(roi.size(), CvType.CV_8UC1))
            val one = m.mat()
            for (i in 1 until nLab) {
                val bw = st[i * 5 + 2]
                val bh = st[i * 5 + 3]
                if (bw > line.cols() * 0.05f && bh > line.rows() * 0.012f) {
                    Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                    Core.bitwise_or(cutMask, one, cutMask)
                }
            }
            val kernel = m.keep(
                Imgproc.getStructuringElement(
                    Imgproc.MORPH_RECT,
                    Size(
                        (3f * frameW / 540f).roundToInt().coerceAtLeast(3).toDouble(),
                        (3f * frameW / 540f).roundToInt().coerceAtLeast(3).toDouble()
                    )
                )
            )
            val grown = m.mat()
            Imgproc.dilate(cutMask, grown, kernel)
            val inv = m.mat()
            Core.bitwise_not(grown, inv)
            Core.bitwise_and(line, inv, line)
        }

        val band = priceLineBand(roi, m)
        if (band != null) {
            val cut = m.keep(line.submat(band[0], band[1], 0, line.cols()))
            cut.setTo(Scalar(0.0))
        }
        val s = frameW / 540f
        val rad = (2f * s).roundToInt().coerceAtLeast(2)
        val c1 = x1.coerceAtMost(line.cols())
        val c0 = (c1 - 6 * rad).coerceAtLeast(0)
        if (c1 - c0 < 2) return Pair(Trend.UNKNOWN, "st_window_small")
        val region = m.keep(line.colRange(c0, c1))
        if (Core.countNonZero(region) < MIN_ST_PIXELS) return Pair(Trend.UNKNOWN, "st_no_px")
        val cols = region.cols()
        val rows = region.rows()
        val bytes = ByteArray(rows * cols)
        region.get(0, 0, bytes)
        val colCount = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) if (bytes[base + x].toInt() != 0) colCount[x]++
        }
        var xe = -1
        for (x in cols - 1 downTo 0) if (colCount[x] >= 2) { xe = x; break }
        if (xe < 0) for (x in cols - 1 downTo 0) if (colCount[x] >= 1) { xe = x; break }
        if (xe < 0) return Pair(Trend.UNKNOWN, "st_no_px")
        val lo = (xe - 2).coerceAtLeast(0)
        var ySum = 0L
        var yCnt = 0
        for (y in 0 until rows) {
            val base = y * cols
            for (x in lo..xe) if (bytes[base + x].toInt() != 0) { ySum += y; yCnt++ }
        }
        val lineY = ySum.toFloat() / yCnt
        val priceY = when {
            band != null -> band[2].toFloat()
            candleCenterY >= 0 -> candleCenterY.toFloat()
            else -> return Pair(Trend.UNKNOWN, "st_no_price")
        }
        val margin = maxOf(2f, 2f * s)
        val trend = when {
            lineY > priceY + margin -> Trend.GREEN
            lineY < priceY - margin -> Trend.RED
            else -> Trend.UNKNOWN
        }
        return Pair(trend, "")
    }

    private fun stochLevels(roi: Mat, roiTop: Int, frameH: Int, m: Mats): Pair<Float, Float> {
        val teal = m.mat()
        val yellow = m.mat()
        Core.inRange(roi, Hsv.LEVEL80_LO, Hsv.LEVEL80_HI, teal)
        Core.inRange(roi, Hsv.LEVEL20_LO, Hsv.LEVEL20_HI, yellow)
        val a = lineCenter(teal, m)
        val b = lineCenter(yellow, m)
        if (a != null && b != null && b - a >= frameH * 0.02f) return Pair(a, b)
        return Pair(Roi.STOCH_Y80_ABS * frameH - roiTop, Roi.STOCH_Y20_ABS * frameH - roiTop)
    }

    private fun lineCenter(mask: Mat, m: Mats): Float? {
        val sums = m.mat()
        Core.reduce(mask, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = mask.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var max = 0
        for (v in arr) if (v > max) max = v
        if (max < 255 * 0.25f * mask.cols()) return null
        var wSum = 0.0
        var ySum = 0.0
        for (y in 0 until rows) {
            if (arr[y] >= max / 2) { wSum += arr[y]; ySum += arr[y].toDouble() * y }
        }
        return (ySum / wSum).toFloat()
    }

    private fun toStochValue(y: Float, y80: Float, y20: Float): Float =
        (80f - (y - y80) * 60f / (y20 - y80)).coerceIn(0f, 100f)

    private fun stochastic(hsv: Mat, frameW: Int, m: Mats): Pair<Cross, Float> {
        val b = box(hsv, rois.getValue(RoiZone.STOCH))
        val roi = hsv.crop(b, m)
        val k = m.mat()
        val d = m.mat()
        Core.inRange(roi, Hsv.STOCH_K_LO, Hsv.STOCH_K_HI, k)
        Core.inRange(roi, Hsv.STOCH_D_LO, Hsv.STOCH_D_HI, d)
        val rows = k.rows()
        val cols = k.cols()
        val kb = ByteArray(rows * cols)
        val db = ByteArray(rows * cols)
        k.get(0, 0, kb)
        d.get(0, 0, db)
        val (y80, y20) = stochLevels(roi, b.r0, hsv.rows(), m)
        val sumK = LongArray(cols); val cntK = IntArray(cols)
        val sumD = LongArray(cols); val cntD = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (kb[base + x].toInt() != 0) { sumK[x] += y.toLong(); cntK[x]++ }
                if (db[base + x].toInt() != 0) { sumD[x] += y.toLong(); cntD[x]++ }
            }
        }
        var lastX = -1
        for (x in cols - 1 downTo 0) if (cntK[x] > 0 && cntD[x] > 0) { lastX = x; break }
        if (lastX < 0) return Pair(Cross.NONE, Float.NaN)
        val deadzone = 0.5f * frameW / 540f
        var prevSign = 0
        var crossX = -1
        var crossDir = Cross.NONE
        var crossVal = Float.NaN
        for (x in 0..lastX) {
            if (cntK[x] == 0 || cntD[x] == 0) continue
            val yK = sumK[x].toFloat() / cntK[x]
            val yD = sumD[x].toFloat() / cntD[x]
            val diff = yD - yK
            val sign = when { diff > deadzone -> 1; diff < -deadzone -> -1; else -> 0 }
            if (sign == 0) continue
            if (prevSign != 0 && sign != prevSign) {
                crossX = x
                crossDir = if (sign > 0) Cross.UP else Cross.DOWN
                crossVal = toStochValue((yK + yD) / 2f, y80, y20)
            }
            prevSign = sign
        }
        val recent = (frameW * Roi.STOCH_RECENT).toInt().coerceAtLeast(4)
        if (crossX < 0 || lastX - crossX > recent) return Pair(Cross.NONE, Float.NaN)
        return Pair(crossDir, crossVal)
    }

    private fun awesome(hsv: Mat, m: Mats): Pair<Trend, Float> {
        val b = box(hsv, rois.getValue(RoiZone.AO))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)
        val x = lastColoredColumn(all, m)
        if (x < 0) return Pair(Trend.UNKNOWN, Float.NaN)
        val x0 = (x - 2).coerceAtLeast(0)
        val gc = Core.countNonZero(m.keep(g.colRange(x0, x + 1)))
        val rc = Core.countNonZero(m.keep(r.colRange(x0, x + 1)))
        val color = when { gc > rc -> Trend.GREEN; rc > gc -> Trend.RED; else -> Trend.UNKNOWN }
        return Pair(color, Float.NaN)
    }

    private fun requestPairOcr(bmp: Bitmap, now: Long) {
        if (now - lastPairOcrAt < PAIR_OCR_INTERVAL_MS) return
        if (!pairOcrBusy.compareAndSet(false, true)) return
        lastPairOcrAt = now
        val scaled = cropScaledBitmap(bmp, rois.getValue(RoiZone.PAIR), OCR_UPSCALE)
        if (scaled == null) {
            pairOcrBusy.set(false)
            return
        }
        try {
            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    if (!gridHealthy) return@addOnSuccessListener
                    val rawPair = text.text.replace('\n', ' ').trim().take(60)
                    val pair = normalizePairName(rawPair)
                    val logAt = SystemClock.elapsedRealtime()
                    if (rawPair != lastPairRawLogKey || logAt - lastPairRawLogAt >= 30_000L) {
                        lastPairRawLogKey = rawPair
                        lastPairRawLogAt = logAt
                        LogRepository.addLog("OCR PAIR RAW: '$rawPair' -> '$pair'")
                    }
                    if (isValidPairName(pair)) {
                        val prev = lastDetectedPair
                        if (prev.isEmpty()) {
                            lastDetectedPair = pair
                            candidatePair = ""
                            candidatePairHits = 0
                            BotState.state.value = BotState.state.value.copy(activePair = pair)
                            LogRepository.addLog("PAIR_INIT: '$pair'")
                        } else if (prev == pair) {
                            candidatePair = ""
                            candidatePairHits = 0
                        } else {
                            if (candidatePair == pair) {
                                candidatePairHits++
                            } else {
                                candidatePair = pair
                                candidatePairHits = 1
                            }
                            if (candidatePairHits >= 3) {
                                lastDetectedPair = pair
                                candidatePair = ""
                                candidatePairHits = 0
                                pendingPairResetFrom = prev
                                pendingPairResetTo = pair
                                BotState.state.value = BotState.state.value.copy(
                                    activePair = pair,
                                    lastSignal = null
                                )
                                LogRepository.addLog("PAIR_SWITCHED: '$prev' -> '$pair' (автосброс)")
                            }
                        }
                    }
                }
                .addOnFailureListener { err ->
                    val t = SystemClock.elapsedRealtime()
                    if (t - lastPairErrAt >= PAIR_OCR_ERR_LOG_MS) {
                        lastPairErrAt = t
                        LogRepository.addLog("PAIR_OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    pairOcrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "pair ocr failed", t)
            scaled.recycle()
            pairOcrBusy.set(false)
        }
    }

    private fun normalizePairName(raw: String): String {
        val cleaned = raw
            .uppercase(Locale.US)
            .replace('\n', ' ')
            .replace(NON_PAIR_CHARS_REGEX, " ")
            .replace(MULTI_SPACE_REGEX, " ")
            .trim()
        PAIR_REGEX.find(cleaned)?.let { m ->
            val base = m.groupValues[1]
            val quote = m.groupValues[2]
            val otc = m.groupValues[3]
            return if (otc.isNotEmpty()) "$base/$quote $otc" else "$base/$quote"
        }
        PAIR_GLUED_REGEX.find(cleaned)?.let { m ->
            return "${m.groupValues[1]}/${m.groupValues[2]}"
        }
        PAIR_NOSLASH_REGEX.find(cleaned)?.let { m ->
            return "${m.groupValues[1]}/${m.groupValues[2]}"
        }
        return ""
    }

    private fun isValidPairName(name: String): Boolean = PAIR_VALID_REGEX.matches(name)

    private fun cropScaledBitmap(bmp: Bitmap, zone: NormRect, upscale: Int): Bitmap? {
        if (bmp.width < 2 || bmp.height < 2) return null
        val x0 = (bmp.width * zone.left).toInt().coerceIn(0, bmp.width - 2)
        val x1 = (bmp.width * zone.right).toInt().coerceIn(x0 + 1, bmp.width)
        val y0 = (bmp.height * zone.top).toInt().coerceIn(0, bmp.height - 2)
        val y1 = (bmp.height * zone.bottom).toInt().coerceIn(y0 + 1, bmp.height)
        val cropW = x1 - x0
        val cropH = y1 - y0
        if (cropW <= 0 || cropH <= 0) return null
        val cropped = Bitmap.createBitmap(bmp, x0, y0, cropW, cropH)
        val scale = upscale.coerceAtLeast(1)
        if (scale == 1) return cropped
        val scaled = Bitmap.createScaledBitmap(cropped, (cropW * scale).coerceAtLeast(1), (cropH * scale).coerceAtLeast(1), true)
        if (scaled !== cropped) cropped.recycle()
        return scaled
    }

    private fun requestPayoutOcr(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        val stableHigh = payout >= 80 && payoutStableAt > 0L &&
            now - payoutStableAt >= PAYOUT_STABLE_HOLD_MS && payout == lastExtractedPayout
        val nearThreshold = payout < 0 || payout in 80..84
        val interval = when {
            stableHigh -> PAYOUT_STABLE_INTERVAL_MS
            nearThreshold -> PAYOUT_EDGE_INTERVAL_MS
            else -> OCR_INTERVAL_MS
        }
        if (now - lastOcrAt < interval) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now
        val scaled = cropScaledBitmap(bmp, rois.getValue(RoiZone.PAYOUT), OCR_UPSCALE)
        if (scaled == null) {
            ocrBusy.set(false)
            return
        }
        try {
            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val raw = text.text.replace('\n', ' ').trim().take(40)
                    val extracted = extractPayout(raw)
                    val nowMs = SystemClock.elapsedRealtime()
                    if (extracted != null) {
                        if (extracted != lastExtractedPayout) {
                            lastExtractedPayout = extracted
                            payoutStableAt = nowMs
                        }
                        payout = extracted
                        payoutAt = nowMs
                    }
                    val key = "$raw|$extracted"
                    if (key != lastOcrLogKey || nowMs - lastOcrLogAt >= OCR_LOG_HEARTBEAT_MS) {
                        lastOcrLogKey = key
                        lastOcrLogAt = nowMs
                        LogRepository.addLog("OCR RAW: '$raw' -> EXTRACTED: ${extracted ?: "null"}")
                    }
                }
                .addOnFailureListener { err ->
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastOcrErrAt >= OCR_ERR_LOG_MS) {
                        lastOcrErrAt = nowMs
                        LogRepository.addLog("OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    ocrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "ocr failed", t)
            try { scaled.recycle() } catch (_: Throwable) {}
            ocrBusy.set(false)
        }
    }

    private fun isOtcNow(): Boolean = true

    private fun extractPayout(raw: String): Int? {
        for (match in PAYOUT_REGEX.findAll(raw)) {
            val run = match.groupValues[1]
            if (run.length == 2) {
                val v = run.toIntOrNull() ?: continue
                if (v in PAYOUT_MIN..PAYOUT_MAX) return v
            } else {
                val first = run.take(2).toIntOrNull()
                val last = run.takeLast(2).toIntOrNull()
                if (first != null && first in PAYOUT_MIN..PAYOUT_MAX) return first
                if (last != null && last in PAYOUT_MIN..PAYOUT_MAX) return last
            }
        }
        return null
    }

    private fun currentPayout(): Int {
        val age = SystemClock.elapsedRealtime() - payoutAt
        // Мягкий TTL 45 с и жёсткий 120 с: одиночный сбой OCR не превращает 92% в -1.
        return when {
            payout <= 0 -> -1
            age <= PAYOUT_HARD_TTL_MS -> payout
            else -> -1
        }
    }

    override fun close() {
        try { recognizer.close() } catch (ignored: Throwable) {}
    }
}
