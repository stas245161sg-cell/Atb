package com.polaris.protocol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.update
import kotlin.random.Random

class TradingAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TradingAccessibilityService? = null
            private set

        private const val JITTER_PX = 4
        private fun isPocketPackage(pkg: String): Boolean =
            pkg.contains("pocket", ignoreCase = true) || pkg.contains("option", ignoreCase = true)

        fun isRunning(): Boolean = instance != null

        fun isPocketOptionForeground(): Boolean {
            if (isPocketPackage(foregroundPackage)) return true
            val root = instance?.rootInActiveWindow ?: return false
            val pkg = root.packageName?.toString().orEmpty()
            if (pkg.isNotEmpty()) foregroundPackage = pkg
            return isPocketPackage(pkg)
        }

        /** Пакет приложения, которое сейчас на переднем плане (по событиям смены окна); пусто, если неизвестно. */
        @Volatile
        var foregroundPackage: String = ""
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var markers: OverlayMarkers? = null

    val markersVisible: Boolean get() = markers?.isShown == true

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        markers = OverlayMarkers(this)
        BotState.state.update { it.copy(accessibility = true) }
        LogRepository.addLog("Служба спец. возможностей подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event != null && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            // Шторка, панель громкости и т.п. не меняют «текущее приложение»
            if (pkg != null && pkg.isNotEmpty() && !pkg.startsWith("com.android.systemui")) {
                foregroundPackage = pkg
            }
        }
    }

    override fun onInterrupt() { /* не используется */ }

    override fun onUnbind(intent: Intent?): Boolean {
        markDisconnected()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        markDisconnected()
        super.onDestroy()
    }

    private fun markDisconnected() {
        markers?.hide()
        markers = null
        instance = null
        foregroundPackage = ""
        BotState.state.update { it.copy(accessibility = false) }
    }

    /** Показать плавающие маркеры CALL/PUT (вызывать из главного потока). */
    fun showMarkers() {
        markers?.show()
    }

    /** Скрыть маркеры; позиции уже сохранены при перетаскивании. */
    fun hideMarkers() {
        markers?.hide()
    }

    /** Тап по точке с рандомизацией ±10px, случайной задержкой и длительностью. */
    fun tap(x: Float, y: Float, onDone: ((Boolean) -> Unit)? = null) {
        if (!isPocketOptionForeground()) { onDone?.invoke(false); return }
        val expectedPackage = foregroundPackage
        val delayMs = Random.nextLong(80, 160)
        handler.postDelayed({ dispatchTap(x, y, expectedPackage, onDone) }, delayMs)
    }

    private fun dispatchTap(x: Float, y: Float, expectedPackage: String, onDone: ((Boolean) -> Unit)?) {
        // Повторная проверка непосредственно перед жестом: пользователь мог переключить приложение.
        if (foregroundPackage != expectedPackage || !isPocketOptionForeground()) {
            LogRepository.addLog("Тап отменён: активное приложение изменилось")
            onDone?.invoke(false)
            return
        }
        if (markersVisible) {
            // Маркер перехватил бы нажатие, поэтому при показанных маркерах не тапаем
            LogRepository.addLog("Маркеры на экране — тап пропущен (нажмите ✓)")
            onDone?.invoke(false)
            return
        }
        val dm = resources.displayMetrics
        val jx = (x + Random.nextInt(-JITTER_PX, JITTER_PX + 1)).coerceIn(1f, dm.widthPixels - 1f)
        val jy = (y + Random.nextInt(-JITTER_PX, JITTER_PX + 1)).coerceIn(1f, dm.heightPixels - 1f)

        val path = Path().apply { moveTo(jx, jy) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, Random.nextLong(35, 95))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    onDone?.invoke(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    onDone?.invoke(false)
                }
            },
            null
        )
        if (!accepted) onDone?.invoke(false)
    }
}
