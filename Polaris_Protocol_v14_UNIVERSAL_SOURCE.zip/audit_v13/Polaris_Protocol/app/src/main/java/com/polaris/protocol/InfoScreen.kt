package com.polaris.protocol

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Инструкция для оператора: что выставить в Pocket Option и какие индикаторы
 * на графике нужны программе. Анализ универсальный: ручной выбор REAL/OTC отсутствует.
 */
@Composable
fun InfoScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    var scalp by remember { mutableStateOf(SignalSettings.scalpEnabled) }
    var trend by remember { mutableStateOf(SignalSettings.trendEnabled) }
    var vol by remember { mutableStateOf(SignalSettings.volEnabled) }
    var tradingMode by remember { mutableStateOf(SignalSettings.tradingMode) }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgTop)
            .padding(16.dp)
    ) {
        Text(
            "Индикаторы и настройки",
            color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Text(
            "POLARIS V14 · UNIVERSAL SIGNAL ENGINE",
            color = FrostBlue, fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                InfoSection("Обязательно выставить в Pocket Option") {
                    InfoLine("Таймфрейм", "любой распознанный; точность зависит от масштаба")
                    InfoLine("Экспирация", "сверяйте с выбранным таймфреймом")
                    InfoLine("Тип графика", "Японские свечи")
                    InfoLine("Выплата", "≥ 80% — жёсткий фильтр в коде")
                    InfoLine("Масштаб", "20–30 свечей в видимой области — предпочтительно")
                }
            }
            item {
                InfoSection("Индикаторы на графике") {
                    InfoLine("SuperTrend", "10 / 3.0 — линия бирюза/пурпур")
                    InfoLine("Stochastic", "5, 3, 3 — уровни 80 и 20 видимы")
                    InfoLine("Awesome Oscillator", "5 / 34 — зелёные/красные столбцы")
                    InfoLine("Остальное", "не добавлять — лишние цвета мешают анализу")
                }
            }
            item {
                InfoSection("Программа считает сама") {
                    InfoLine("EMA", "9 / 21 — из цен закрытия")
                    InfoLine("RSI", "14")
                    InfoLine("ADX", "14, минимум 20")
                    InfoLine("ATR", "14 — сжатие/расширение")
                    InfoLine("Fibonacci", "14.6% от диапазона 30 свечей")
                    InfoLine("На график", "их добавлять НЕ нужно")
                }
            }
            item {
                InfoSection("Важно для захвата") {
                    InfoLine("График", "прокручен до последней свечи (кнопка «>»)")
                    InfoLine("Калибровка", "зоны «График» и «Выплата» по реальным областям")
                    InfoLine("Кнопки", "КУПИТЬ/ПРОДАТЬ и payout не перекрыты панелями")
                    InfoLine("Тема", "тёмная; контраст свечей и индикаторов должен быть сохранён")
                    InfoLine("Банк/ставка", "задаёт оператор в Pocket Option")
                }
            }
            item {
                InfoSection("Режим торговли") {
                    Text("Максимальный винрейт — строгие фильтры, меньше входов. Баланс — средние фильтры. Больше сигналов — мягче пороги, но выше риск ложных входов.", color = TextSecondary, fontSize = 12.sp)
                    ChoiceLine("Максимальный винрейт", tradingMode == TradingMode.MAX_WIN) { tradingMode = TradingMode.MAX_WIN }
                    ChoiceLine("Баланс", tradingMode == TradingMode.BALANCED) { tradingMode = TradingMode.BALANCED }
                    ChoiceLine("Большое количество сигналов", tradingMode == TradingMode.MORE_SIGNALS) { tradingMode = TradingMode.MORE_SIGNALS }
                }
            }
            item {
                InfoSection("Универсальный анализ") {
                    Text("Отдельный выбор REAL / OTC не требуется. Polaris анализирует любой распознанный график Pocket Option единым конвейером. Тип инструмента и доступность индикаторов определяются по текущему изображению; при низком качестве распознавания сигнал блокируется.", color = TextSecondary, fontSize = 11.sp)
                }
            }
            item {
                InfoSection("Стратегии") {
                    SwitchLine("SCALP — фрактал 3 свечи", scalp) { scalp = it }
                    SwitchLine("TREND — EMA/RSI/ADX", trend) { trend = it }
                    SwitchLine("VOL — расширение диапазона и пробой", vol) { vol = it }
                }
            }
        }

        Button(
            onClick = {
                SignalSettings.scalpEnabled = scalp
                SignalSettings.trendEnabled = trend
                SignalSettings.volEnabled = vol
                SignalSettings.tradingMode = tradingMode
                SignalSettings.save(ctx)
                Toast.makeText(ctx, "Настройки сохранены", Toast.LENGTH_SHORT).show()
                onClose()
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = BgTop)
        ) {
            Text("Сохранить и закрыть")
        }
    }
}

@Composable
private fun InfoSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(GlassFill)
            .padding(12.dp)
    ) {
        Text(title, color = IceCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(0.38f))
        Text(value, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(0.62f))
    }
}

@Composable
private fun ChoiceLine(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        androidx.compose.material3.RadioButton(selected = selected, onClick = onClick)
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
