# Build and verification record

Project version: `4.0-build-ready` (versionCode 20)  
Package: `com.traderai.app`

## Included

- Based on the recovered v3.12 source with only the necessary v4.0 modules merged.
- Strict OCR-only M5 timer parsing in the marked region; no device-clock substitution.
- One M5 rollover synchronizer; analysis and entry are gated on an observed `00:01..00:02 → 04:58..05:00` transition.
- Correct signal-candle identity and next-candle entry timestamp.
- Pair-isolated candle histories; pair changes do not cancel open Paper positions.
- Independent Paper ledger with exact pair + expiry timestamp settlement; reconstructed Heikin-Ashi entry prices are tagged `[HA_PROXY]`.
- Persistent DEMO attempt journal, deduplication, state-transition guard, accessibility evidence classifier, and UNKNOWN handling.
- DEMO auto-entry gate requires the configured Pocket Option package and a visible DEMO/Practice label; a gesture is not counted as broker acceptance.
- On-screen CALL/PUT X/Y calibration sliders, timer zone display, logs, Paper panel and DEMO journal view.
- Gradle bootstrap scripts, Android CI workflow, launcher drawable and unit tests.

## Checks performed in this environment

- XML resource/manifest parsing: passed (8 XML files).
- `gradlew` shell syntax: passed.
- Pure Kotlin compile: passed for models, indicators, strategy, timer parser, M5 synchronizer and PaperMath.
- M5 synchronizer runtime smoke test: passed.
- Timer parser runtime smoke test: passed.
- Paper ledger Kotlin syntax compile against temporary Android/JSON API stubs: passed.
- DEMO journal Kotlin syntax compile against temporary Android/JSON API stubs: passed.
- ZIP integrity check: passed.
- Real DG cube PNG launcher icons restored; flat vector cube removed.
- Gradle wrapper JAR restored; standard `gradlew` scripts used.
- Accessibility service granted window-content access so the DEMO/Practice label can be read.
- Ambiguous `context` property renamed to `appContext` in `TraderPipeline`.

## Checks not performed

- Full Android Gradle build and Android unit-test task: **not run**. This environment has no Android SDK or Gradle installation and outbound downloads are blocked.
- Install/run on POCO F3 / HyperOS: **not run**.
- Pocket Option accessibility labels and DEMO marker recognition on the live UI: **not device-verified**.
- Strategy profitability: **not established**; requires independent historical and DEMO sample validation.

A successful GitHub CI build will establish Android compilation and unit-test status. It will not, by itself, establish correct chart reconstruction, broker acceptance, or profitability.
