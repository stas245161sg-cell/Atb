package com.traderai.app.vision

data class HsvRange(
    val hMin: Float, val hMax: Float,
    val sMin: Float, val sMax: Float,
    val vMin: Float, val vMax: Float
) {
    fun contains(h: Float, s: Float, v: Float): Boolean =
        h in hMin..hMax && s in sMin..sMax && v in vMin..vMax
}

object ColorProfile {
    // HSV hue 0..360, S/V 0..1 — под финальную раскраску биржи
    val CANDLE_BULL = HsvRange(75f, 155f, 0.48f, 1f, 0.35f, 1f)
    val CANDLE_BEAR = HsvRange(5f, 32f, 0.55f, 1f, 0.35f, 1f)

    val BB_BLUE = HsvRange(195f, 245f, 0.35f, 1f, 0.35f, 1f)
    val BB_BOTTOM_WHITE = HsvRange(0f, 360f, 0f, 0.20f, 0.72f, 1f)

    val SUPERTREND_UP = HsvRange(65f, 115f, 0.55f, 1f, 0.45f, 1f)
    val SUPERTREND_DOWN = HsvRange(285f, 345f, 0.40f, 1f, 0.30f, 1f)

    val EMA5_YELLOW = HsvRange(42f, 72f, 0.55f, 1f, 0.45f, 1f)

    val STOCH_BLUE = HsvRange(195f, 245f, 0.35f, 1f, 0.35f, 1f)
    val STOCH_ORANGE = HsvRange(15f, 42f, 0.45f, 1f, 0.35f, 1f)
    val RSI_YELLOW_GREEN = HsvRange(55f, 105f, 0.35f, 1f, 0.35f, 1f)
}

data class NormalizedRect(
    val left: Float, val top: Float,
    val right: Float, val bottom: Float
) {
    fun isValid(): Boolean =
        left in 0f..1f && top in 0f..1f &&
        right in 0f..1f && bottom in 0f..1f &&
        right > left && bottom > top

    fun toPixels(width: Int, height: Int): IntRect = IntRect(
        left = (left * width).toInt().coerceIn(0, width - 1),
        top = (top * height).toInt().coerceIn(0, height - 1),
        right = (right * width).toInt().coerceIn(1, width),
        bottom = (bottom * height).toInt().coerceIn(1, height)
    )
}

data class IntRect(
    val left: Int, val top: Int,
    val right: Int, val bottom: Int
) {
    val width: Int get() = right - left
    val height: Int get() = bottom - top
}

object ScreenZones {
    val CHART = NormalizedRect(0.00f, 0.19f, 0.86f, 0.54f)
    val PAIR = NormalizedRect(0.06f, 0.135f, 0.48f, 0.185f)
    val PAYOUT = NormalizedRect(0.06f, 0.62f, 0.94f, 0.72f)
    val STOCH = NormalizedRect(0.02f, 0.70f, 0.95f, 0.78f)
    val RSI = NormalizedRect(0.02f, 0.81f, 0.95f, 0.88f)
    val CALL_BUTTON = NormalizedRect(0.07f, 0.62f, 0.49f, 0.68f)
    val PUT_BUTTON = NormalizedRect(0.51f, 0.62f, 0.93f, 0.68f)

    val LEFT_OCCLUSION = NormalizedRect(0.00f, 0.19f, 0.12f, 0.54f)
    val TRADE_MARKER = NormalizedRect(0.00f, 0.44f, 0.86f, 0.51f)
}

