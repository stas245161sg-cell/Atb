package com.traderai.app.trading

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class RiskStatus(
    val balance: Double? = null,
    val startBalance: Double? = null,
    val riskPercent: Int = 20,
    val drawdownPercent: Double = 0.0,
    val stopBalance: Double? = null,
    val locked: Boolean = false,
    val reason: String = "Ожидание баланса Pocket Option"
)

/**
 * Страховка депозита. При достижении заданного процента убытка
 * новые сделки и автонажатия блокируются до явного разрешения
 * или перезапуска процесса.
 */
object TradeRiskGuard {
    private val _status = MutableStateFlow(RiskStatus())
    val status: StateFlow<RiskStatus> = _status.asStateFlow()

    @Volatile private var startBalance: Double? = null
    @Volatile private var lastBalance: Double? = null
    @Volatile private var locked = false
    @Volatile private var lockReason = "Ожидание баланса Pocket Option"

    @Synchronized
    fun resetForNewSession() {
        startBalance = null
        lastBalance = null
        locked = false
        lockReason = "Ожидание баланса Pocket Option"
        _status.value = RiskStatus()
    }

    @Synchronized
    fun observe(balance: Double?, riskPercent: Int): RiskStatus {
        val safePercent = riskPercent.coerceIn(10, 50)
        if (balance == null || balance <= 0.0) {
            _status.value = _status.value.copy(
                riskPercent = safePercent,
                reason = if (locked) lockReason else "Баланс не распознан"
            )
            return _status.value
        }
        lastBalance = balance
        if (startBalance == null) startBalance = balance
        val start = startBalance!!
        val stop = start * (1.0 - safePercent / 100.0)
        val drawdown = ((start - balance) / start * 100.0).coerceAtLeast(0.0)

        if (!locked && balance <= stop) {
            locked = true
            lockReason = "Достигнут лимит риска $safePercent%. Убыток ${"%.2f".format(drawdown)}%"
        }

        _status.value = RiskStatus(
            balance = balance,
            startBalance = start,
            riskPercent = safePercent,
            drawdownPercent = drawdown,
            stopBalance = stop,
            locked = locked,
            reason = if (locked) lockReason else "Торговля разрешена"
        )
        return _status.value
    }

    @Synchronized
    fun approveResume(): Boolean {
        if (!locked) return false
        // Новый отсчёт от текущего баланса, чтобы тот же лимит работал дальше.
        startBalance = lastBalance
        locked = false
        lockReason = "Торговля возобновлена вручную"
        _status.value = observe(lastBalance, _status.value.riskPercent)
        return true
    }

    @Synchronized
    fun isLocked(): Boolean = locked
}
