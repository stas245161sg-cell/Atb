package com.traderai.app.data

import android.content.Context
import com.traderai.app.vision.Candle
import org.json.JSONArray
import org.json.JSONObject

class CandleHistoryStore(context: Context, pair: String? = null) {
    private val safePair = pair?.uppercase()?.replace(Regex("[^A-Z0-9_]"), "_") ?: "DEFAULT"
    private val prefs = context.getSharedPreferences("traderai_history_$safePair", Context.MODE_PRIVATE)

    @Synchronized
    fun load(): List<Candle> {
        val raw = prefs.getString("candles", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Candle(
                    time = o.getLong("t"),
                    open = o.getDouble("o"), high = o.getDouble("h"),
                    low = o.getDouble("l"), close = o.getDouble("c"),
                    closed = true, confidence = o.getDouble("conf").toFloat(),
                    verified = true
                )
            }.sortedBy { it.time }.takeLast(300)
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized
    fun save(candles: List<Candle>) {
        val arr = JSONArray()
        candles.filter { it.closed && it.verified }
            .distinctBy { it.time }.sortedBy { it.time }.takeLast(300)
            .forEach {
                arr.put(JSONObject().apply {
                    put("t", it.time); put("o", it.open); put("h", it.high)
                    put("l", it.low); put("c", it.close); put("conf", it.confidence.toDouble())
                })
            }
        prefs.edit().putString("candles", arr.toString()).apply()
    }

    @Synchronized
    fun clear() = prefs.edit().remove("candles").apply()
}

