package com.traderai.app.trading

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** One identity per broker pair, direction and closed signal candle. */
data class SignalIdentity(val pair: String, val side: String, val signalCandleTime: Long) {
    val key: String get() = "${pair.trim().uppercase()}_${side.trim().uppercase()}_$signalCandleTime"
}

enum class DemoTradeState { REQUESTED, GESTURE_COMPLETED, BROKER_ACCEPTED, WIN, LOSS, DRAW, REJECTED, UNKNOWN }

data class DemoAttempt(
    val id: String,
    val signal: SignalIdentity,
    val createdAt: Long,
    val updatedAt: Long,
    val state: DemoTradeState,
    val detail: String
)

object DemoExecutionTransitionGuard {
    private val transitions = mapOf(
        DemoTradeState.REQUESTED to setOf(DemoTradeState.GESTURE_COMPLETED, DemoTradeState.REJECTED, DemoTradeState.UNKNOWN),
        DemoTradeState.GESTURE_COMPLETED to setOf(DemoTradeState.BROKER_ACCEPTED, DemoTradeState.REJECTED, DemoTradeState.UNKNOWN),
        DemoTradeState.BROKER_ACCEPTED to setOf(DemoTradeState.WIN, DemoTradeState.LOSS, DemoTradeState.DRAW, DemoTradeState.UNKNOWN),
        DemoTradeState.UNKNOWN to setOf(DemoTradeState.BROKER_ACCEPTED, DemoTradeState.WIN, DemoTradeState.LOSS, DemoTradeState.DRAW),
        DemoTradeState.WIN to emptySet(), DemoTradeState.LOSS to emptySet(),
        DemoTradeState.DRAW to emptySet(), DemoTradeState.REJECTED to emptySet()
    )

    fun allowed(from: DemoTradeState, to: DemoTradeState): Boolean = to in (transitions[from] ?: emptySet())
}

/** Durable, deduplicated DEMO attempt journal. A gesture is never treated as broker acceptance. */
class DemoExecutionEventStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("darkgrid_demo_event_journal_v1", Context.MODE_PRIVATE)
    private val lock = Any()

    fun all(): List<DemoAttempt> = synchronized(lock) {
        val raw = prefs.getString("events", "[]") ?: "[]"
        runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                DemoAttempt(
                    o.getString("id"),
                    SignalIdentity(o.getString("pair"), o.getString("side"), o.getLong("signalTime")),
                    o.getLong("createdAt"), o.getLong("updatedAt"),
                    DemoTradeState.valueOf(o.getString("state")), o.optString("detail")
                )
            }
        }.getOrDefault(emptyList())
    }

    fun appendTransition(attempt: DemoAttempt): Boolean = synchronized(lock) {
        val items = all().toMutableList()
        val index = items.indexOfFirst { it.id == attempt.id }
        if (index < 0) {
            if (attempt.state != DemoTradeState.REQUESTED) return false
            if (items.any { it.signal.key == attempt.signal.key }) return false
            items += attempt
        } else {
            val old = items[index]
            if (!DemoExecutionTransitionGuard.allowed(old.state, attempt.state)) return false
            items[index] = attempt.copy(createdAt = old.createdAt, signal = old.signal)
        }
        val json = JSONArray()
        items.takeLast(1000).forEach { item ->
            json.put(JSONObject().apply {
                put("id", item.id); put("pair", item.signal.pair); put("side", item.signal.side)
                put("signalTime", item.signal.signalCandleTime); put("createdAt", item.createdAt)
                put("updatedAt", item.updatedAt); put("state", item.state.name); put("detail", item.detail)
            })
        }
        prefs.edit().putString("events", json.toString()).commit()
    }
}

class DemoAttemptRegistry(private val store: DemoExecutionEventStore) {
    @Synchronized fun latestUnresolved(): DemoAttempt? = store.all().lastOrNull {
        it.state in setOf(DemoTradeState.REQUESTED, DemoTradeState.GESTURE_COMPLETED, DemoTradeState.BROKER_ACCEPTED, DemoTradeState.UNKNOWN)
    }

    @Synchronized fun create(signal: SignalIdentity, now: Long = System.currentTimeMillis()): DemoAttempt? {
        if (store.all().any { it.signal.key == signal.key }) return null
        val attempt = DemoAttempt(UUID.randomUUID().toString(), signal, now, now, DemoTradeState.REQUESTED, "Accessibility gesture requested")
        return attempt.takeIf { store.appendTransition(it) }
    }

    @Synchronized fun transition(id: String, state: DemoTradeState, detail: String, now: Long = System.currentTimeMillis()): DemoAttempt? {
        val old = store.all().firstOrNull { it.id == id } ?: return null
        val updated = old.copy(updatedAt = now, state = state, detail = detail)
        return updated.takeIf { store.appendTransition(it) }
    }
}

/** Conservative textual evidence classifier; no gesture callback is considered acceptance. */
class BrokerExecutionTracker {
    fun classify(packageName: String?, visibleText: String): DemoTradeState? {
        if (packageName != "com.pocketoption.broker") return null
        val text = visibleText.lowercase()
        return when {
            listOf("trade opened", "deal opened", "сделка открыта", "позиция открыта", "trade placed").any { text.contains(it) } -> DemoTradeState.BROKER_ACCEPTED
            listOf("you won", "вы выиграли", "прибыль", "победа").any { text.contains(it) } || Regex("\\bwin\\b").containsMatchIn(text) -> DemoTradeState.WIN
            listOf("you lost", "вы проиграли", "убыток", "поражение").any { text.contains(it) } || Regex("\\bloss\\b").containsMatchIn(text) -> DemoTradeState.LOSS
            listOf("возврат", "ничья").any { text.contains(it) } || Regex("\\bdraw\\b").containsMatchIn(text) -> DemoTradeState.DRAW
            listOf("не удалось открыть", "ошибка сделки").any { text.contains(it) } || Regex("\\brejected\\b").containsMatchIn(text) -> DemoTradeState.REJECTED
            else -> null
        }
    }
}
