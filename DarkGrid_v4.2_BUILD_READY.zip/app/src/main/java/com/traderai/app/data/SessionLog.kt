package com.traderai.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SessionLog {
    data class Line(val time: String, val tag: String, val message: String)

    private const val MAX = 400
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val _lines = MutableStateFlow<List<Line>>(emptyList())
    val lines = _lines.asStateFlow()

    @Synchronized
    fun add(tag: String, message: String) {
        val line = Line(fmt.format(Date()), tag, message)
        _lines.value = (listOf(line) + _lines.value).take(MAX)
    }

    fun text(): String = _lines.value.joinToString("\n") { "[${it.time}] ${it.tag}: ${it.message}" }

    @Synchronized
    fun clear() { _lines.value = emptyList() }
}

