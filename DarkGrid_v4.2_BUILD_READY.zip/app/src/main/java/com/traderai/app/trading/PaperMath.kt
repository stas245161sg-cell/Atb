package com.traderai.app.trading

import com.traderai.app.vision.Side

object PaperMath {
    const val EXPIRY_MS = 300_000L

    fun result(side: Side, entryPrice: Double, expiryOpenPrice: Double?): PaperResult? {
        if (expiryOpenPrice == null || !expiryOpenPrice.isFinite() || expiryOpenPrice <= 0.0) return null
        if (!entryPrice.isFinite() || entryPrice <= 0.0) return null
        return when {
            expiryOpenPrice == entryPrice -> PaperResult.DRAW
            side == Side.CALL && expiryOpenPrice > entryPrice -> PaperResult.WIN
            side == Side.PUT && expiryOpenPrice < entryPrice -> PaperResult.WIN
            else -> PaperResult.LOSS
        }
    }

    fun signalKey(pair: String, side: Side, signalCandleTime: Long): String =
        "${pair.trim().uppercase()}_${side.name}_${signalCandleTime}"

    fun gridAligned(time: Long): Boolean = time % EXPIRY_MS == 0L
}

