package com.traderai.app.vision

import kotlin.math.abs
import kotlin.math.sqrt

object Indicators {

    fun ema(values: List<Double>, period: Int): List<Double> {
        require(period > 0)
        if (values.isEmpty()) return emptyList()
        val alpha = 2.0 / (period + 1.0)
        val result = MutableList(values.size) { Double.NaN }
        if (values.size < period) return result
        var current = values.take(period).average()
        result[period - 1] = current
        for (i in period until values.size) {
            current = alpha * values[i] + (1.0 - alpha) * current
            result[i] = current
        }
        return result
    }

    fun rsiSeries(values: List<Double>, period: Int = 14): List<Double> {
        val out = MutableList(values.size) { Double.NaN }
        if (period <= 0 || values.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val delta = values[i] - values[i - 1]
            if (delta >= 0) gain += delta else loss -= delta
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        fun value(): Double {
            if (avgLoss == 0.0) return if (avgGain == 0.0) 50.0 else 100.0
            val rs = avgGain / avgLoss
            return 100.0 - 100.0 / (1.0 + rs)
        }
        out[period] = value()
        for (i in period + 1 until values.size) {
            val delta = values[i] - values[i - 1]
            avgGain = (avgGain * (period - 1) + delta.coerceAtLeast(0.0)) / period
            avgLoss = (avgLoss * (period - 1) + (-delta).coerceAtLeast(0.0)) / period
            out[i] = value()
        }
        return out
    }

    fun rsi(values: List<Double>, period: Int = 14): Double? =
        rsiSeries(values, period).lastOrNull()?.takeIf { it.isFinite() }

    data class Bands(
        val middle: Double, val upper: Double,
        val lower: Double, val width: Double
    )

    fun bollingerSeries(
        values: List<Double>,
        period: Int = 20,
        deviations: Double = 2.0
    ): List<Bands?> {
        require(period > 1 && deviations > 0.0)
        return values.indices.map { i ->
            if (i + 1 < period) return@map null
            val window = values.subList(i - period + 1, i + 1)
            val mean = window.average()
            val variance = window.sumOf { (it - mean) * (it - mean) } / period
            val sd = sqrt(variance)
            val upper = mean + deviations * sd
            val lower = mean - deviations * sd
            val width = if (mean != 0.0) (upper - lower) / abs(mean) else 0.0
            Bands(mean, upper, lower, width)
        }
    }

    fun trueRanges(candles: List<Candle>): List<Double> =
        candles.mapIndexed { i, c ->
            if (i == 0) c.high - c.low
            else {
                val previousClose = candles[i - 1].close
                maxOf(
                    c.high - c.low,
                    abs(c.high - previousClose),
                    abs(c.low - previousClose)
                )
            }
        }

    fun atrSeries(candles: List<Candle>, period: Int = 10): List<Double> {
        val out = MutableList(candles.size) { Double.NaN }
        if (period <= 0 || candles.size < period) return out
        val tr = trueRanges(candles)
        var value = tr.take(period).average()
        out[period - 1] = value
        for (i in period until tr.size) {
            value = (value * (period - 1) + tr[i]) / period
            out[i] = value
        }
        return out
    }

    fun superTrendSeries(
        candles: List<Candle>,
        period: Int = 10,
        multiplier: Double = 3.0
    ): List<Int> {
        val out = MutableList(candles.size) { 0 }
        if (period <= 0 || multiplier <= 0.0 || candles.size < period) return out
        val atr = atrSeries(candles, period)
        var finalUpper = Double.NaN
        var finalLower = Double.NaN
        var direction = 1
        for (i in period - 1 until candles.size) {
            val a = atr[i]
            if (!a.isFinite()) continue
            val c = candles[i]
            val midpoint = (c.high + c.low) / 2.0
            val basicUpper = midpoint + multiplier * a
            val basicLower = midpoint - multiplier * a
            if (i == period - 1) {
                finalUpper = basicUpper
                finalLower = basicLower
                out[i] = direction
                continue
            }
            val previousClose = candles[i - 1].close
            val previousUpper = finalUpper
            val previousLower = finalLower
            finalUpper = if (basicUpper < previousUpper || previousClose > previousUpper)
                basicUpper else previousUpper
            finalLower = if (basicLower > previousLower || previousClose < previousLower)
                basicLower else previousLower
            direction = when {
                direction < 0 && c.close > finalUpper -> 1
                direction > 0 && c.close < finalLower -> -1
                else -> direction
            }
            out[i] = direction
        }
        return out
    }

    data class StochPoint(val k: Double, val d: Double)

    fun stochasticSeries(
        candles: List<Candle>,
        kPeriod: Int = 5,
        smoothK: Int = 3,
        dPeriod: Int = 3
    ): List<StochPoint?> {
        require(kPeriod > 0 && smoothK > 0 && dPeriod > 0)
        val raw = MutableList(candles.size) { Double.NaN }
        for (i in kPeriod - 1 until candles.size) {
            val window = candles.subList(i - kPeriod + 1, i + 1)
            val high = window.maxOf { it.high }
            val low = window.minOf { it.low }
            raw[i] = if (high <= low) 50.0
            else ((candles[i].close - low) / (high - low) * 100.0)
        }
        val smooth = MutableList(candles.size) { Double.NaN }
        for (i in candles.indices) {
            if (i + 1 >= kPeriod + smoothK - 1) {
                val values = raw.subList(i - smoothK + 1, i + 1)
                if (values.all { it.isFinite() }) smooth[i] = values.average()
            }
        }
        val result = MutableList<StochPoint?>(candles.size) { null }
        for (i in candles.indices) {
            if (i + 1 >= kPeriod + smoothK + dPeriod - 2) {
                val values = smooth.subList(i - dPeriod + 1, i + 1)
                if (values.all { it.isFinite() }) {
                    result[i] = StochPoint(smooth[i], values.average())
                }
            }
        }
        return result
    }
}

