package com.traderai.app

import android.app.Application

class TraderApplication : Application()

