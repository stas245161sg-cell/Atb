package com.traderai.app.trading

import android.content.Context
import android.graphics.Bitmap
import com.traderai.app.accessibility.DarkGridAccessibilityService
import com.traderai.app.data.AppSettings
import com.traderai.app.data.CandleHistoryStore
import com.traderai.app.data.SessionLog
import com.traderai.app.data.SettingsRepo
import com.traderai.app.vision.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class PipelineResult(
    val confidence: Float,
    val candleCount: Int,
    val pair: String?,
    val payout: Int?,
    val analysis: Analysis?,
    val message: String,
    val warnings: List<String>,
    val calibrationReady: Boolean
)

class TraderPipeline(context: Context) {
    companion object { private const val MIN_HISTORY = 30 }

    private val parser = ScreenParser()
    private val history = mutableListOf<Candle>()
    private var historyStore = CandleHistoryStore(context, null)
    private val appContext = context.applicationContext
    private val m5Synchronizer = M5EntrySynchronizer()
    private var lastM5EntryOpen: Long? = null
    private val paper = PaperTrading(appContext)
    private val settings = SettingsRepo(appContext)
    private val demoEventStore = DemoExecutionEventStore(appContext)
    private val demoRegistry = DemoAttemptRegistry(demoEventStore)
    @Volatile private var activeDemoAttemptId: String? = demoRegistry.latestUnresolved()?.id
    @Volatile private var lastBrokerEvidenceAt: Long = 0L

    @Volatile private var currentSettings = AppSettings()
    @Volatile private var lastClosedTime = Long.MIN_VALUE
    @Volatile private var currentPair = ""
    @Volatile private var lastTapCandle = Long.MIN_VALUE
    @Volatile private var lastTapMs = 0L
    @Volatile private var lastBlockLogMs = 0L
    @Volatile private var lastAnalysis: Analysis? = null

    suspend fun refreshSettings() {
        currentSettings = try { settings.flow.first() } catch (_: Exception) { currentSettings }
    }

    @Synchronized fun setCalibrationApproved(v: Boolean) {
        TradingGate.set(v)
        if (!v) StrategyEngine.reset()
    }

    suspend fun process(bitmap: Bitmap, now: Long = System.currentTimeMillis()): PipelineResult = withContext(Dispatchers.Default) {
        val parsed = parser.parse(bitmap, now)
        val pair = parsed.context.pair

        val unresolvedAttempt = activeDemoAttemptId?.let { id -> demoEventStore.all().firstOrNull { it.id == id } }
        if (unresolvedAttempt != null && unresolvedAttempt.state in setOf(DemoTradeState.REQUESTED, DemoTradeState.GESTURE_COMPLETED) &&
            now - unresolvedAttempt.updatedAt > 20_000L) {
            demoRegistry.transition(unresolvedAttempt.id, DemoTradeState.UNKNOWN, "No visible broker confirmation within 20 seconds", now)
            SessionLog.add("BROKER", "Сделка UNKNOWN: брокер не подтвердил открытие")
        }
        val unresolvedNow = demoRegistry.latestUnresolved()
        val unresolvedExpired = unresolvedNow?.let { now > it.signal.signalCandleTime + 600_000L } == true
        if (unresolvedExpired) activeDemoAttemptId = null

        val brokerEvidenceAt = DarkGridAccessibilityService.latestBrokerEvidenceAt
        if (brokerEvidenceAt > lastBrokerEvidenceAt && brokerEvidenceAt >= now - 30_000L) {
            val attemptId = activeDemoAttemptId
            val state = DarkGridAccessibilityService.latestBrokerEvidenceState?.let { runCatching { DemoTradeState.valueOf(it) }.getOrNull() }
            if (attemptId != null && state != null) {
                val currentAttempt = demoEventStore.all().firstOrNull { it.id == attemptId }
                if (state in setOf(DemoTradeState.WIN, DemoTradeState.LOSS, DemoTradeState.DRAW) &&
                    (currentAttempt?.state == DemoTradeState.REQUESTED || currentAttempt?.state == DemoTradeState.GESTURE_COMPLETED)) {
                    if (currentAttempt?.state == DemoTradeState.REQUESTED) {
                        demoRegistry.transition(attemptId, DemoTradeState.GESTURE_COMPLETED, "Broker outcome screen observed")
                    }
                    demoRegistry.transition(attemptId, DemoTradeState.BROKER_ACCEPTED, "Broker outcome screen is direct evidence of an accepted position")
                }
                demoRegistry.transition(attemptId, state, DarkGridAccessibilityService.latestBrokerEvidenceDetail, brokerEvidenceAt)
                SessionLog.add("BROKER", "Визуальное подтверждение: $state")
            }
            lastBrokerEvidenceAt = brokerEvidenceAt
        }

        if (!pair.isNullOrBlank() && pair != currentPair) {
            if (currentPair.isNotEmpty()) StrategyEngine.reset()
            currentPair = pair
            historyStore = CandleHistoryStore(appContext, pair)
            history.clear()
            history.addAll(historyStore.load())
            lastClosedTime = Long.MIN_VALUE
            lastTapCandle = Long.MIN_VALUE
            lastAnalysis = null
            TradingGate.set(false)
            m5Synchronizer.resetAll()
            lastM5EntryOpen = null
        }

        val closedVerified = parsed.candles.filter { it.closed && it.verified && it.confidence >= 0.80f }
        for (c in closedVerified) {
            val idx = history.indexOfFirst { it.time == c.time }
            if (idx >= 0) { if (c.confidence >= history[idx].confidence) history[idx] = c }
            else history += c
        }
        history.sortBy { it.time }
        while (history.size > 300) history.removeAt(0)
        historyStore.save(history)

        val timer = parsed.timerSecondsRemaining
        val rollover = m5Synchronizer.observe(timer, now)
        if (rollover != null) lastM5EntryOpen = rollover.candleOpenTimeMs
        val contiguous = hasTail(history, MIN_HISTORY)
        val latest = history.lastOrNull()
        // БЫЛО: PaperMath.gridAligned(now) -> now % 300000 == 0,
        // что истинно одну миллисекунду раз в 5 минут и блокировало ВСЕ сигналы.
        // Сетку надо проверять у времени свечи, а не у текущего timestamps.
        val gridOk = latest?.let { PaperMath.gridAligned(it.time) } == true

        val canAnalyze = TradingGate.approved.value && contiguous && parsed.context.valid &&
            parsed.calibrationReady && timer?.let { it in 270..300 } == true && gridOk && latest != null &&
            lastM5EntryOpen == latest.time + PaperMath.EXPIRY_MS && latest.time != lastClosedTime

        val analysis = if (canAnalyze) {
            lastClosedTime = latest!!.time
            StrategyEngine.analyze(
                input = history,
                mode = currentSettings.mode,
                confidence = parsed.confidence,
                context = parsed.context,
                allowCall = currentSettings.call,
                allowPut = currentSettings.put,
                calibrationApproved = true,
                minimumPayout = currentSettings.minPayout,
                now = now
            ).also { lastAnalysis = it }
        } else {
            val pending = lastAnalysis
            val pendingFresh = pending?.entryTime?.let { now - it in 0..30_000L } == true
            if (pendingFresh && pending?.side != Side.NONE) pending!! else Analysis(
                Side.NONE, 0, Regime.UNKNOWN,
                if (!TradingGate.approved.value) "Observer: калибровка не подтверждена; ${parsed.note}"
                else if (!parsed.calibrationReady) "OHLC не подтверждены калибровкой; ${parsed.note}"
                else if (timer == null) "Таймер M5 не прочитан OCR — анализ и вход заблокированы"
                else if (timer !in 270..300 || latest?.let { lastM5EntryOpen != it.time + PaperMath.EXPIRY_MS } == true) "Ожидание подтверждённого перехода M5 00:01 → 05:00"
                else if (!parsed.context.valid) parsed.context.reason
                else if (history.size < MIN_HISTORY) "Истории ${history.size}/$MIN_HISTORY — копим свечи"
                else if (!contiguous) "История не непрерывна (пропуск в $MIN_HISTORY последних)"
                else if (!gridOk) "Временная сетка не выровнена"
                else "Ожидание новой закрытой свечи",
                parsed.confidence, history.size, null, null
            )
        }

        if (analysis.side != Side.NONE && analysis.signalTime != null && pair != null) {
            val current = parsed.candles.lastOrNull { !it.closed && it.verified }
            val key = PaperMath.signalKey(pair, analysis.side, analysis.signalTime)
            if (!riskAllows) {
                SessionLog.add("RISK", "Paper-вход заблокирован: ${risk.reason}")
            } else if (current != null && timer?.let { it in 270..300 } == true &&
                lastM5EntryOpen == current.time && current.time == analysis.signalTime + PaperMath.EXPIRY_MS &&
                analysis.entryTime?.let { now - it in 0..30_000L } == true) {
                val t = paper.open(
                    pair = pair, side = analysis.side, signalTime = analysis.signalTime,
                    signalKey = key, entryPrice = current.open,
                    payout = parsed.context.payout ?: 0, score = analysis.score,
                    reason = analysis.reason, paperEnabled = currentSettings.paper
                )
                if (t == null && currentSettings.paper) {
                    // уже открыта или повтор — логика в warnings не тянем, добавим в note через reasons
                }
            }
        }

        // Автонажатие ПОЛНОСТЬЮ НЕЗАВИСИМО от Paper Trading.
        // Paper — это только контрольный журнал/статистика; он не должен гасить
        // реальный сигнал и не должен блокировать нажатие.
        val currentEntryCandle = parsed.candles.lastOrNull { !it.closed && it.verified }
        val tapWanted = currentSettings.autoTap && analysis.side != Side.NONE &&
            analysis.signalTime != null && pair != null && timer?.let { it in 270..300 } == true &&
            currentEntryCandle != null && lastM5EntryOpen == currentEntryCandle.time &&
            currentEntryCandle.time == analysis.signalTime + PaperMath.EXPIRY_MS
        val tapFresh = analysis.entryTime?.let { now - it in 0..30_000L } == true
        val a11yReady = DarkGridAccessibilityService.isRunning()
        val poForeground = DarkGridAccessibilityService.foregroundPackage == "com.pocketoption.broker"
                val demoLedgerClear = unresolvedNow == null || unresolvedExpired
        val risk = TradeRiskGuard.observe(parsed.balance, currentSettings.riskPercent)
        val riskAllows = !risk.locked
        val tapAllowed = tapWanted && TradingGate.approved.value && tapFresh && a11yReady && poForeground && demoLedgerClear && riskAllows &&
            lastTapCandle != analysis.signalTime && now - lastTapMs >= 60_000L

        if (tapAllowed) {
            val svc = DarkGridAccessibilityService.instance
            if (svc != null) {
                val dm = android.content.res.Resources.getSystem().displayMetrics
                val autoCall = com.traderai.app.vision.ScreenOcr.callButtonCenter
                val autoPut = com.traderai.app.vision.ScreenOcr.putButtonCenter
                val chosen = if (analysis.side == Side.CALL) autoCall ?: (currentSettings.callX to currentSettings.callY)
                             else autoPut ?: (currentSettings.putX to currentSettings.putY)
                val nx = chosen.first
                val ny = chosen.second
                val x = (nx * dm.widthPixels).coerceIn(1f, dm.widthPixels - 1f)
                val y = (ny * dm.heightPixels).coerceIn(1f, dm.heightPixels - 1f)
                val key = PaperMath.signalKey(pair!!, analysis.side, analysis.signalTime!!)
                val attempt = demoRegistry.create(SignalIdentity(pair!!, analysis.side.name, analysis.signalTime!!), now)
                if (attempt != null) {
                    activeDemoAttemptId = attempt.id
                    lastTapCandle = analysis.signalTime
                    lastTapMs = now
                    SessionLog.add("TAP", "Запрос ${analysis.side.name} key=$key ($x,$y)")
                    svc.tap(x, y) { ok ->
                        val next = if (ok) DemoTradeState.GESTURE_COMPLETED else DemoTradeState.REJECTED
                        demoRegistry.transition(attempt.id, next, if (ok) "Accessibility gesture completed; broker acceptance pending" else "Accessibility gesture cancelled")
                        SessionLog.add("TAP", "${analysis.side.name} key=$key gesture=$ok; broker acceptance pending")
                    }
                } else {
                    SessionLog.add("TAP", "Повтор заблокирован реестром DEMO key=$key")
                }
            }
        } else if (tapWanted && now - lastBlockLogMs >= 30_000L) {
            // Логируем, почему предохранитель не пустил тап — это основной материал
            // для разбора расхождений между анализатором и биржей.
            lastBlockLogMs = now
            val why = when {
                !TradingGate.approved.value -> "калибровка не подтверждена"
                !a11yReady -> "спец. возможности не подключены"
                !poForeground -> "Pocket Option не в foreground"
                !demoLedgerClear -> "Предыдущая DEMO-попытка ещё не сверена с брокером"
                !riskAllows -> risk.reason
                !tapFresh -> "сигнал устарел (>30 с)"
                lastTapCandle == analysis.signalTime -> "дубль сигнальной свечи"
                now - lastTapMs < 60_000L -> "кулдаун 60 с"
                else -> "ожидание"
            }
            SessionLog.add("TAP", "БЛОК $why side=${analysis.side.name}")
        }

        // Закрытие строго по цене ОТКРЫТИЯ свечи экспирации.
        history.filter { it.closed }.forEach { c -> paper.settle(pair ?: return@forEach, c.time, c.open) }

        PipelineResult(
            confidence = parsed.confidence,
            candleCount = history.size,
            pair = pair,
            payout = parsed.context.payout,
            analysis = analysis,
            message = analysis.reason,
            warnings = parsed.warnings,
            calibrationReady = parsed.calibrationReady
        )
    }

    private fun hasTail(list: List<Candle>, n: Int): Boolean {
        if (list.size < n) return false
        val tail = list.takeLast(n)
        for (i in 1 until tail.size) if (tail[i].time - tail[i - 1].time != 300_000L) return false
        return tail.all { PaperMath.gridAligned(it.time) }
    }

    fun paperTrading(): PaperTrading = paper
    fun close() { parser.close() }
}

