package com.traderai.app.vision

data class TimerOcrData(val secondsRemaining: Int, val sourceText: String)

object TimerTextParser {
    private val pattern = Regex("""(?<!\d)(\d{1,2})\s*:\s*([0-5]\d)(?!\d)""")

    fun parse(text: String): TimerOcrData? {
        val match = pattern.find(text) ?: return null
        val minutes = match.groupValues[1].toIntOrNull() ?: return null
        val seconds = match.groupValues[2].toIntOrNull() ?: return null
        val total = minutes * 60 + seconds
        return if (total in 1..300) TimerOcrData(total, match.value) else null
    }
}
