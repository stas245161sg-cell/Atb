package com.traderai.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.traderai.app.capture.CaptureState
import com.traderai.app.data.SessionLog
import com.traderai.app.trading.BrokerExecutionTracker

class DarkGridAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: DarkGridAccessibilityService? = null
            private set

        @Volatile var foregroundPackage: String = ""
            private set

        @Volatile var latestBrokerEvidenceState: String? = null
            private set
        @Volatile var latestBrokerEvidenceDetail: String = ""
            private set
        @Volatile var latestBrokerEvidenceAt: Long = 0L
            private set
        @Volatile var demoModeVisible: Boolean = false
            private set
        private val brokerTracker = BrokerExecutionTracker()
        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        CaptureState.accessibility(true)
        SessionLog.add("A11Y", "Служба специальных возможностей подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val pkg = event.packageName?.toString()
            if (!pkg.isNullOrBlank()) foregroundPackage = pkg
        }
        if (foregroundPackage != "com.pocketoption.broker") return
        val root = rootInActiveWindow ?: return
        val visible = buildString {
            fun collect(node: android.view.accessibility.AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 12 || length > 12_000) return
                node.text?.toString()?.takeIf { it.isNotBlank() }?.let { append(it).append(' ') }
                node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let { append(it).append(' ') }
                for (i in 0 until node.childCount) collect(node.getChild(i), depth + 1)
            }
            collect(root, 0)
        }
        demoModeVisible = Regex("\\b(demo|practice)\\b|демо|учебн", RegexOption.IGNORE_CASE).containsMatchIn(visible)
        val evidence = brokerTracker.classify(foregroundPackage, visible) ?: return
        latestBrokerEvidenceState = evidence.name
        latestBrokerEvidenceDetail = visible.take(500)
        latestBrokerEvidenceAt = System.currentTimeMillis()
    }

    override fun onInterrupt() {
        SessionLog.add("A11Y", "Служба прервана")
    }

    override fun onDestroy() {
        instance = null
        CaptureState.accessibility(false)
        SessionLog.add("A11Y", "Служба отключена")
        super.onDestroy()
    }

    fun tap(x: Float, y: Float, onResult: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val desc = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(desc, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onResult(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { onResult(false) }
        }, null)
    }
}

