package com.traderai.app.capture

import com.traderai.app.trading.PaperTrading
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Telemetry(
    val pair: String = "—",
    val payout: Int? = null,
    val candles: Int = 0,
    val fps: Float = 0f,
    val regime: String = "—",
    val cv: Float = 0f,
    val calibrationReady: Boolean = false,
    val ocrOk: Boolean = false,
    val gridOk: Boolean = false
)

object CaptureState {
    private val _capturing = MutableStateFlow(false)
    val capturing = _capturing.asStateFlow()

    private val _status = MutableStateFlow("Ожидание разрешения")
    val status = _status.asStateFlow()

    private val _analysis = MutableStateFlow("Нет анализа")
    val analysis = _analysis.asStateFlow()

    private val _calibrationReady = MutableStateFlow(false)
    val calibrationReady = _calibrationReady.asStateFlow()

    private val _telemetry = MutableStateFlow(Telemetry())
    val telemetry = _telemetry.asStateFlow()

    private val _paper = MutableStateFlow(PaperTrading.Stats(0, 0, 0, 0, 0, 0.0))
    val paper = _paper.asStateFlow()

    private val _paperText = MutableStateFlow("")
    val paperText = _paperText.asStateFlow()

    private val _accessibility = MutableStateFlow(false)
    val accessibility = _accessibility.asStateFlow()

    fun capturing(v: Boolean) { _capturing.value = v }
    fun status(v: String) { _status.value = v }
    fun analysis(v: String) { _analysis.value = v }
    fun calibrationReady(v: Boolean) { _calibrationReady.value = v }
    fun telemetry(v: Telemetry) { _telemetry.value = v }
    fun accessibility(v: Boolean) { _accessibility.value = v }
    fun paper(stats: PaperTrading.Stats, text: String) {
        _paper.value = stats
        _paperText.value = text
    }
}

