package com.traderai.app

import com.traderai.app.trading.DemoExecutionTransitionGuard
import com.traderai.app.trading.DemoTradeState
import org.junit.Assert.*
import org.junit.Test

class DemoExecutionTransitionGuardTest {
    @Test fun gestureIsNotBrokerAcceptance() {
        assertTrue(DemoExecutionTransitionGuard.allowed(DemoTradeState.REQUESTED, DemoTradeState.GESTURE_COMPLETED))
        assertFalse(DemoExecutionTransitionGuard.allowed(DemoTradeState.REQUESTED, DemoTradeState.BROKER_ACCEPTED))
        assertTrue(DemoExecutionTransitionGuard.allowed(DemoTradeState.GESTURE_COMPLETED, DemoTradeState.BROKER_ACCEPTED))
    }

    @Test fun terminalStatesCannotBeRewritten() {
        assertFalse(DemoExecutionTransitionGuard.allowed(DemoTradeState.WIN, DemoTradeState.LOSS))
        assertFalse(DemoExecutionTransitionGuard.allowed(DemoTradeState.REJECTED, DemoTradeState.BROKER_ACCEPTED))
    }
}
