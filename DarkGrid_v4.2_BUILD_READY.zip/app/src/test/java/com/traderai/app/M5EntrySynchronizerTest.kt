package com.traderai.app

import com.traderai.app.trading.M5EntrySynchronizer
import org.junit.Assert.*
import org.junit.Test

class M5EntrySynchronizerTest {
    @Test fun requiresObservedRollover() {
        val sync = M5EntrySynchronizer()
        assertNull(sync.observe(4, 1_199_000L))
        assertNull(sync.observe(2, 1_200_000L))
        val event = sync.observe(299, 1_201_000L)
        assertNotNull(event)
        assertEquals(1_200_000L, event!!.candleOpenTimeMs)
        assertNull(sync.observe(298, 1_202_000L))
    }

    @Test fun missedObservationDoesNotInventEntry() {
        val sync = M5EntrySynchronizer()
        assertNull(sync.observe(1, 1_199_000L))
        assertNull(sync.observe(299, 1_210_000L))
    }

    @Test fun invalidTimerResetsSequence() {
        val sync = M5EntrySynchronizer()
        sync.observe(1, 1_199_000L)
        assertNull(sync.observe(null, 1_200_000L))
        assertNull(sync.observe(299, 1_202_000L))
    }
}
