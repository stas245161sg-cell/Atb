package com.traderai.app

import com.traderai.app.vision.Candle
import com.traderai.app.vision.Indicators
import org.junit.Assert.*
import org.junit.Test

class IndicatorTest {
    @Test fun emaSmaSeed() {
        val r = Indicators.ema(listOf(1.0,2.0,3.0,4.0,5.0,6.0),5)
        assertTrue(r.take(4).all { it.isNaN() })
        assertEquals(3.0, r[4], 1e-6)
        assertEquals(4.0, r[5], 1e-6)
    }
    @Test fun rsiRisingIs100() {
        assertEquals(100.0, Indicators.rsi((1..30).map { it.toDouble() })!!, 1e-6)
    }
    @Test fun bollingerMiddleIsAverage() {
        val b = Indicators.bollingerSeries((1..20).map { it.toDouble() }).last()!!
        assertEquals(10.5, b.middle, 1e-6)
        assertTrue(b.upper > b.middle && b.lower < b.middle)
    }
    @Test fun invalidCandleRejected() {
        val c = Candle(1000,100.0,90.0,95.0,105.0,true,1f,true)
        assertFalse(c.isValid())
    }
}

