package com.traderai.app

import com.traderai.app.vision.TimerTextParser
import org.junit.Assert.*
import org.junit.Test

class TimerTextParserTest {
    @Test fun parsesPocketOptionM5Countdown() {
        assertEquals(278, TimerTextParser.parse("M5 / 04:38")?.secondsRemaining)
        assertEquals(1, TimerTextParser.parse("00 : 01")?.secondsRemaining)
        assertEquals(300, TimerTextParser.parse("05:00")?.secondsRemaining)
    }

    @Test fun rejectsInvalidOrOutOfRangeValues() {
        assertNull(TimerTextParser.parse("05:01"))
        assertNull(TimerTextParser.parse("18:15:22 UTC+3"))
        assertNull(TimerTextParser.parse("00:00"))
        assertNull(TimerTextParser.parse("no timer"))
    }
}
