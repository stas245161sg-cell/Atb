package com.traderai.app

import com.traderai.app.trading.PaperMath
import com.traderai.app.trading.PaperResult
import com.traderai.app.vision.Candle
import com.traderai.app.vision.Indicators
import com.traderai.app.vision.Side
import org.junit.Assert.*
import org.junit.Test

class V31LogicTest {

    @Test fun emaUsesSmaSeed() {
        val r = Indicators.ema(listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0), 5)
        assertTrue(r.take(4).all { it.isNaN() })
        assertEquals(3.0, r[4], 1e-6)
        assertEquals(4.0, r[5], 1e-6)
    }

    @Test fun rsiRisingIs100() {
        assertEquals(100.0, Indicators.rsi((1..30).map { it.toDouble() })!!, 1e-6)
    }

    @Test fun gridAlignedChecksM5() {
        assertTrue(PaperMath.gridAligned(1_700_000_000_000L / 300_000L * 300_000L))
        assertFalse(PaperMath.gridAligned(1_700_000_000_001L))
    }

    @Test fun signalKeyIncludesPairSideAndCandle() {
        val a = PaperMath.signalKey(" aud/nzd otc ", Side.CALL, 1_700_000_100_000L)
        val b = PaperMath.signalKey("AUD/NZD OTC", Side.CALL, 1_700_000_100_000L)
        val c = PaperMath.signalKey("AUD/NZD OTC", Side.PUT, 1_700_000_100_000L)
        assertEquals(a, b)
        assertNotEquals(a, c)
    }

    @Test fun paperResultUsesExpiryOpen() {
        assertEquals(PaperResult.WIN, PaperMath.result(Side.CALL, 1.1000, 1.1010))
        assertEquals(PaperResult.LOSS, PaperMath.result(Side.CALL, 1.1000, 1.0990))
        assertEquals(PaperResult.WIN, PaperMath.result(Side.PUT, 1.1000, 1.0990))
        assertEquals(PaperResult.DRAW, PaperMath.result(Side.PUT, 1.1000, 1.1000))
        assertNull(PaperMath.result(Side.CALL, 1.1000, null))
    }

    @Test fun invalidCandleRejected() {
        val c = Candle(1L, 100.0, 90.0, 95.0, 105.0, true, 1f, true)
        assertFalse(c.isValid())
    }

    @Test fun contiguousTailDetectsGap() {
        val base = 1_700_000_000_000L / 300_000L * 300_000L
        val list = (0 until 50).map { i ->
            Candle(base + i * 300_000L, 1.0, 1.1, 0.9, 1.05, true, 0.95f, true)
        }
        assertTrue(list.zipWithNext().all { (a, b) -> b.time - a.time == 300_000L })
        val broken = list.toMutableList().apply { removeAt(10) }
        assertFalse(broken.zipWithNext().all { (a, b) -> b.time - a.time == 300_000L })
    }
}

