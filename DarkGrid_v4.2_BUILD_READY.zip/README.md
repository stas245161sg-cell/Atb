# DARK GRID — Android trading assistant

Version: **4.2-risk-guard**  
Application ID: `com.traderai.app`  
Minimum Android: 8.0 (API 26)  
Compile / target SDK: 35  
Java / Kotlin bytecode target: 17  

Dark Grid is an on-device chart observer for Pocket Option. It reads the visible M5 chart, reconstructs Heikin-Ashi candles from pixels, computes the configured indicators, generates CALL/PUT candidates, maintains an independent Paper Trading ledger and can dispatch a DEMO accessibility gesture when all safety gates are satisfied.

## Configured analysis

- Chart: Heikin Ashi, M5
- Expiry: 5 minutes
- Bollinger Bands: 20, 2
- SuperTrend: 10, 3
- Stochastic: 5, 3, 3
- RSI: 14
- EMA: 5
- Internal trend confirmation: EMA 13 (not displayed or treated as an enabled chart indicator)
- Modes: Active, Balanced, Sniper
- Minimum payout default: 80%

## Important execution rules

1. Timer is accepted only from OCR in the marked chart region `x=0.69..0.85`, `y=0.16..0.54`. Device-clock fallback is intentionally not used.
2. M5 entry synchronization requires an observed timer rollover from `00:01..00:02` to `04:58..05:00`. A missed rollover is not guessed.
3. Paper Trading is independent of the auto-tap setting. Its entry uses the next M5 candle proxy and is marked `[HA_PROXY]`; settlement requires the exact pair and exact expiry-candle timestamp and uses that candle's opening price.
4. Pair histories are isolated. Switching pairs does not cancel open Paper positions.
5. DEMO tap requires calibration approval, a fresh signal, enabled Accessibility service, `com.pocketoption.broker` in foreground, a visible DEMO/Practice marker, and a one-attempt-per-signal journal.
6. An Accessibility gesture completion is **not** broker acceptance. Broker acceptance/result is recorded only when matching visible broker UI text is observed. If no evidence appears, the attempt remains unconfirmed rather than being counted as a trade.
7. The strategy is not represented as profitable until measured over a sufficiently large, independently verified sample. Heikin-Ashi OHLC reconstructed from pixels is a proxy, not broker-native price data.

## Build on GitHub

1. Create or open a GitHub repository.
2. Upload the contents of this folder to the repository root (not the parent folder).
3. Open **Actions → Dark Grid Android CI** and run the workflow, or push to `main`/`master`.
4. Download the `DarkGrid-debug` artifact from a successful workflow run.

The workflow installs Android SDK platform 35, runs unit tests, assembles the debug APK, and publishes the APK as an artifact.

Local build command (requires Android SDK 35 and JDK 17):

```bash
./gradlew :app:testDebugUnitTest :app:assembleDebug
```

## Device setup

1. Install the generated APK on the POCO F3.
2. Open Dark Grid and grant screen-capture permission when starting observation.
3. Enable the Dark Grid Accessibility service in Android Accessibility settings.
4. Open Pocket Option and select the DEMO/Practice account.
5. Start capture; wait until chart calibration reports ready, visually compare the reconstructed candles with the chart, then explicitly confirm calibration.
6. Test Paper Trading first. Enable DEMO auto-entry only after the tap zones are calibrated and the visible DEMO marker is detected.

HyperOS may restrict background activity. Keep Dark Grid unrestricted from battery optimization while observing, and do not revoke MediaProjection or Accessibility permissions during a session.

## Verification status

The pure Kotlin strategy and M5 synchronizer sources were compiled with the available Kotlin compiler during preparation. Full Android Gradle compilation and on-device validation were **not run in this environment** because Android SDK/Gradle were unavailable and outbound downloads were blocked. The GitHub workflow is included to perform the full Android build and unit-test run. A successful CI build is not proof of broker-side execution or strategy profitability; those require device and DEMO validation.

## Calibration controls

CALL/PUT button centers are detected automatically from OCR text (КУПИТЬ / ПРОДАТЬ) in the trade panel. Manual sliders were removed. The DEMO/Practice label gate was removed; instead the app reads the account balance from the top panel and enforces an adjustable deposit-risk limit (10/20/30/40/50%). When the loss reaches the limit, all new trades are blocked until the user explicitly approves resuming or restarts the app.
