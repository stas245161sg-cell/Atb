package com.polaris.protocol

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Инструкция для оператора: что выставить в Pocket Option и какие индикаторы
 * на графике нужны программе. Анализ универсальный: ручной выбор REAL/OTC отсутствует.
 */
@Composable
fun InfoScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    Column(
        Modifier
            .fillMaxSize()
            .background(BgTop)
            .padding(16.dp)
    ) {
        Text(
            "Индикаторы и настройки",
            color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Text(
            "APEXGRID V17 · UNIFIED REINFORCEMENT",
            color = FrostBlue, fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                InfoSection("Обязательно выставить в Pocket Option") {
                    InfoLine("Таймфрейм", "любой распознанный; точность зависит от масштаба")
                    InfoLine("Экспирация", "сверяйте с выбранным таймфреймом")
                    InfoLine("Тип графика", "Японские свечи")
                    InfoLine("Выплата", "≥ 80% — жёсткий фильтр в коде")
                    InfoLine("Масштаб", "20–30 свечей в видимой области — предпочтительно")
                }
            }
            item {
                InfoSection("Индикаторы на графике") {
                    InfoLine("SuperTrend", "10 / 3.0 — линия бирюза/пурпур")
                    InfoLine("Stochastic", "5, 3, 3 — уровни 80 и 20 видимы")
                    InfoLine("Awesome Oscillator", "5 / 34 — зелёные/красные столбцы")
                    InfoLine("Остальное", "не добавлять — лишние цвета мешают анализу")
                }
            }
            item {
                InfoSection("Программа считает сама") {
                    InfoLine("EMA", "5 / 13 — базовый вектор направления")
                    InfoLine("Свеча", "тело, тени, цвет закрытой свечи")
                    InfoLine("Индикаторы", "только усиление совпадающего направления")
                    InfoLine("Fibonacci", "14.6% от диапазона 30 свечей")
                    InfoLine("На график", "их добавлять НЕ нужно")
                }
            }
            item {
                InfoSection("Важно для захвата") {
                    InfoLine("График", "прокручен до последней свечи (кнопка «>»)")
                    InfoLine("Калибровка", "зоны «График» и «Выплата» по реальным областям")
                    InfoLine("Кнопки", "КУПИТЬ/ПРОДАТЬ и payout не перекрыты панелями")
                    InfoLine("Тема", "тёмная; контраст свечей и индикаторов должен быть сохранён")
                    InfoLine("Банк/ставка", "задаёт оператор в Pocket Option")
                }
            }
            item {
                InfoSection("Единый режим") {
                    Text(
                        "V17 не переключает стратегии: всё, что видно на экране, работает на усиление одного направления. " +
                            "OTC не блокируется. Вход только по закрытой свече, выплата ≥ 80%.",
                        color = TextSecondary, fontSize = 12.sp
                    )
                    Text(
                        "Heikin Ashi допустим и часто стабильнее обычных свечей: меньше рваных теней. " +
                            "Таймфрейм не привязан к логике.",
                        color = TextSecondary, fontSize = 11.sp
                    )
                }
            }
            item {
                InfoSection("Смена графика") {
                    Text(
                        "После переключения пары нажмите кнопку ниже: она сбросит подтверждение, X-сетку и кэш выплаты, " +
                            "чтобы данные старого графика не попали в новый сигнал.",
                        color = TextSecondary, fontSize = 11.sp
                    )
                    Button(
                        onClick = {
                            runCatching {
                                ctx.startService(
                                    Intent(ctx, ScreenCaptureService::class.java).apply {
                                        action = ScreenCaptureService.ACTION_CHART_SWITCHED
                                    }
                                )
                            }
                            Toast.makeText(ctx, "Состояние сброшено", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = BgTop)
                    ) { Text("График переключён — сбросить") }
                }
            }
        }

        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = BgTop)
        ) {
            Text("Понятно")
        }
    }
}

@Composable
private fun InfoSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(GlassFill)
            .padding(12.dp)
    ) {
        Text(title, color = IceCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(0.38f))
        Text(value, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(0.62f))
    }
}

@Composable
private fun ChoiceLine(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        androidx.compose.material3.RadioButton(selected = selected, onClick = onClick)
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
