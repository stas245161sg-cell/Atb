package com.polaris.protocol

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Палитра ApexGrid: ледяной циан и сапфир вместо мятного акцента. */
object ApexGlassColors {
    val VoidBlack = Color(0xFF04060A)
    val DeepObsidian = Color(0xFF090D16)
    val GlassSurface = Color(0xCC101726)
    val GlassElevated = Color(0xD9162033)
    val GlassPill = Color(0xB3131C2E)
    val RimHighlight = Color(0x599EC5FF)
    val RimSubtle = Color(0x24FFFFFF)
    val RimAccent = Color(0x9956CCF2)
    val IceCyan = Color(0xFF5CE1E6)
    val SapphireGlow = Color(0xFF4EA8DE)
    val SignalCrimson = Color(0xFFFF4D6D)
    val AmberHold = Color(0xFFF5B700)
    val TextPrimary = Color(0xFFF3F7FF)
    val TextSecondary = Color(0xFFA3B3CC)
    val TextMuted = Color(0xFF667691)
}

/**
 * Три уровня селективности. Управляют ТОЛЬКО порогом confidence единого движка —
 * стратегии не включаются/выключаются и не спорят друг с другом.
 */
enum class TradingProfile(val title: String, val minConfidence: Float) {
    FLOW("Поток", 0.45f),
    BALANCE("Баланс", 0.55f),
    SNIPER("Снайпер", 0.68f);

    companion object {
        fun fromName(name: String?): TradingProfile =
            entries.firstOrNull { it.name.equals(name, ignoreCase = true) } ?: BALANCE
    }
}

object ProfileSettings {
    private const val FILE = "apexgrid"
    private const val KEY = "profile"

    @Volatile var current: TradingProfile = TradingProfile.BALANCE
        private set

    fun load(ctx: Context) {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, null)
        current = TradingProfile.fromName(raw)
    }

    fun set(ctx: Context, profile: TradingProfile) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString(KEY, profile.name).apply()
        current = profile
    }
}

@Composable
fun ApexHeader(subtitle: String = "LIQUID GLASS · AUTONOMOUS ENGINE", modifier: Modifier = Modifier) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            "APEXGRID",
            style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.4.sp,
                color = ApexGlassColors.TextPrimary
            )
        )
        Text(
            subtitle,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 11.sp,
                color = ApexGlassColors.IceCyan
            )
        )
    }
}

@Composable
fun TradingProfileSelector(
    selected: TradingProfile,
    onSelect: (TradingProfile) -> Unit,
    modifier: Modifier = Modifier
) {
    val containerShape = RoundedCornerShape(20.dp)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(containerShape)
            .background(ApexGlassColors.GlassPill)
            .border(1.dp, ApexGlassColors.RimSubtle, containerShape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TradingProfile.entries.forEach { profile ->
            val isSelected = profile == selected
            val itemShape = RoundedCornerShape(16.dp)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(itemShape)
                    .background(
                        if (isSelected) Brush.horizontalGradient(
                            listOf(Color(0x4D5CE1E6), Color(0x334EA8DE))
                        ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) ApexGlassColors.RimAccent else Color.Transparent,
                        shape = itemShape
                    )
                    .clickable { onSelect(profile) }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    profile.title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) ApexGlassColors.IceCyan else ApexGlassColors.TextSecondary
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

/** Фон с холодной подсветкой жидкого стекла. */
@Composable
fun ApexGlassBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.background(
            brush = Brush.verticalGradient(
                listOf(Color(0xFF0A1120), ApexGlassColors.VoidBlack, Color(0xFF060911))
            )
        )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x265CE1E6), Color(0x124EA8DE), Color.Transparent),
                        radius = 900f
                    )
                )
        )
        content()
    }
}

/** Карточка Liquid Glass с глянцевой гранью и тонкой обводкой. */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    accentBorder: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (accentBorder) ApexGlassColors.RimAccent else ApexGlassColors.RimSubtle
    Surface(
        modifier = modifier
            .shadow(14.dp, shape, ambientColor = Color(0x40000000), spotColor = Color(0x335CE1E6))
            .clip(shape)
            .border(BorderStroke(1.dp, borderColor), shape),
        shape = shape,
        color = Color.Transparent
    ) {
        Box(
            Modifier
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xD9172238), Color(0xB80D1320), Color(0xCC0A0F1A))
                    )
                )
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x24FFFFFF), Color(0x08FFFFFF), Color.Transparent)
                    )
                )
        ) {
            Column(
                Modifier.padding(contentPadding),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    }
}

/** Стеклянная кнопка с холодной подсветкой активного/опасного состояния. */
@Composable
fun LiquidGlassActionButton(
    text: String,
    active: Boolean = false,
    destructive: Boolean = false,
    modifier: Modifier = Modifier,
    height: Dp = 48.dp,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val bg = when {
        destructive -> Brush.horizontalGradient(listOf(Color(0x66FF4D6D), Color(0x339E1B32)))
        active -> Brush.horizontalGradient(listOf(Color(0x4D5CE1E6), Color(0x334EA8DE)))
        else -> Brush.verticalGradient(listOf(Color(0x38FFFFFF), Color(0x14FFFFFF)))
    }
    val stroke = when {
        destructive -> Color(0x99FF4D6D)
        active -> ApexGlassColors.RimAccent
        else -> ApexGlassColors.RimSubtle
    }
    val textColor = when {
        destructive -> Color(0xFFFF8FA3)
        active -> ApexGlassColors.IceCyan
        else -> ApexGlassColors.TextPrimary
    }
    Box(
        modifier
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.dp, stroke), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            ),
            maxLines = 2
        )
    }
}

/** Метрика с моноширинным значением — сетка не «прыгает» при обновлении чисел. */
@Composable
fun GlassMetricRow(
    label: String,
    value: String,
    valueColor: Color = ApexGlassColors.TextPrimary,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = ApexGlassColors.TextSecondary)
        Text(
            value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = valueColor
            )
        )
    }
}
