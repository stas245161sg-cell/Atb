package com.polaris.protocol

enum class Direction { CALL, PUT }
enum class EngineState { SCANNING, CONFIRMING, COOLDOWN }

data class FiboLevels(
    val maxHigh: Float,
    val minLow: Float,
    val range: Float,
    val putLevel: Float,
    val callLevel: Float,
    val anchorY: Float
)

fun priceOf(y: Float, f: FiboLevels): Float = f.anchorY - y

fun fiboLevels(s: Snapshot): FiboLevels? {
    if (s.highs.isEmpty() || s.lows.isEmpty() || s.highs.size != s.lows.size) return null
    if (s.highs.any { !it.isFinite() } || s.lows.any { !it.isFinite() }) return null
    if (s.highs.indices.any { s.highs[it] > s.lows[it] }) return null
    val highY = s.highs.min()
    val lowY = s.lows.max()
    val range = lowY - highY
    if (!range.isFinite() || range <= 0f) return null
    return FiboLevels(
        maxHigh = highY,
        minLow = lowY,
        range = range,
        putLevel = highY + FIBO_RATIO * range,
        callLevel = lowY - FIBO_RATIO * range,
        anchorY = lowY
    )
}

private const val FIBO_RATIO = 0.146f

fun Float.fmt(digits: Int = 0, nan: String = "—"): String =
    if (isNaN()) nan else String.format(java.util.Locale.US, "%.${digits}f", this)

/**
 * Единый бесконфликтный движок: все модули либо усиливают выбранное направление,
 * либо остаются нейтральными. Никаких opposing votes и direction_conflict.
 */
class UnifiedStrategyEngine(
    private val cooldownMs: () -> Long,
    private val minConfidenceProvider: () -> Float = { 0.52f }
) {
    companion object {
        /** Статический порог выплаты (пользовательский фикс: без ставок и без OTC-блокировки). */
        const val MIN_PAYOUT = 80
        const val CONFIRM_FRAMES = 2
        const val CONFIRM_MIN_DURATION_MS = 1_200L
    }

    var state: EngineState = EngineState.SCANNING
        private set

    var lastConfidence: Float = 0f
        private set

    var lastReason: String = ""
        private set

    var lastEffectiveDirection: Direction? = null
        private set

    private var pending: Direction? = null
    private var confirmCount = 0
    private var confirmingSince = 0L
    private var lastKey: String? = null
    private var cooldownUntil = 0L

    /** Сброс при переключении графика/пары (вызывается и сервисом, и анализатором). */
    fun onChartSwitched() {
        resetConfirmation()
        cooldownUntil = 0L
        lastReason = "chart_switched"
    }

    fun evaluate(s: Snapshot, now: Long, allowSignal: Boolean = true): Direction? {
        val minConf = minConfidenceProvider()
        lastEffectiveDirection = null

        when {
            !s.live -> return reject("chart_scrolled")
            s.payout < MIN_PAYOUT -> return reject("low_payout(${s.payout}<$MIN_PAYOUT)")
            !s.candleClosed -> return reject("candle_not_closed")
            s.highs.size < 6 || s.lows.size < 6 -> return reject("not_enough_candles(${s.highs.size})")
        }

        val f = fiboLevels(s) ?: return reject("no_levels")
        val (dir, score, reason) = scoreCoherentSetup(s, f)
        lastConfidence = score
        lastReason = reason

        val candidate = if (allowSignal && dir != null && score >= minConf) dir else null
        if (!allowSignal && dir != null) lastReason = "blocked:$reason"

        when (state) {
            EngineState.COOLDOWN -> {
                if (now >= cooldownUntil && candidate == null) {
                    resetConfirmation()
                    state = EngineState.SCANNING
                }
            }
            EngineState.SCANNING -> {
                if (candidate != null) {
                    pending = candidate
                    confirmCount = 1
                    confirmingSince = now
                    lastKey = stateKey(s, candidate)
                    state = EngineState.CONFIRMING
                    LogRepository.addLog("STATE: SCANNING -> CONFIRMING (${candidate.name} 1/$CONFIRM_FRAMES)")
                }
            }
            EngineState.CONFIRMING -> {
                if (candidate != null && candidate == pending) {
                    val key = stateKey(s, candidate)
                    if (key != lastKey) {
                        lastKey = key
                        confirmCount++
                    }
                    if (confirmCount >= CONFIRM_FRAMES && now - confirmingSince >= CONFIRM_MIN_DURATION_MS) {
                        val fired = pending
                        lastEffectiveDirection = fired
                        state = EngineState.COOLDOWN
                        cooldownUntil = now + cooldownMs().coerceAtLeast(15_000L)
                        resetConfirmation()
                        LogRepository.addLog(
                            "STATE: CONFIRMING -> COOLDOWN (${fired?.name}, pause=${(cooldownUntil - now) / 1000}s)"
                        )
                        return fired
                    }
                } else {
                    LogRepository.addLog("STATE: CONFIRMING -> SCANNING (lost: ${lastReason})")
                    resetConfirmation()
                    state = EngineState.SCANNING
                }
            }
        }
        return null
    }

    private fun reject(reason: String): Direction? {
        lastConfidence = 0f
        lastReason = reason
        return null
    }

    /** Все слои работают на усиление одного выбранного направления. */
    private fun scoreCoherentSetup(s: Snapshot, f: FiboLevels): Triple<Direction?, Float, String> {
        val n = minOf(s.highs.size, s.lows.size)
        val closes = if (s.closes.size == n) s.closes else FloatArray(n) { s.lows[it] }

        val pCloses = FloatArray(n) { priceOf(closes[it], f) }
        val pHighs = FloatArray(n) { priceOf(s.highs[it], f) }
        val pLows = FloatArray(n) { priceOf(s.lows[it], f) }

        val emaFast = emaLast(pCloses, 5)
        val emaSlow = emaLast(pCloses, 13)
        val recentMove = pCloses[n - 1] - pCloses[(n - 4).coerceAtLeast(0)]

        var callSupport = 0f
        var putSupport = 0f
        val notes = ArrayList<String>()

        if (emaFast > emaSlow) callSupport += 0.25f else if (emaFast < emaSlow) putSupport += 0.25f
        if (recentMove > 0f) {
            callSupport += 0.20f
            notes.add("move_up")
        } else if (recentMove < 0f) {
            putSupport += 0.20f
            notes.add("move_dn")
        }
        if (s.isGreen) callSupport += 0.15f else putSupport += 0.15f

        val leadDir = when {
            callSupport > putSupport -> Direction.CALL
            putSupport > callSupport -> Direction.PUT
            else -> return Triple(null, 0f, "flat_tie")
        }

        var total = if (leadDir == Direction.CALL) callSupport else putSupport

        // Форма свечи: чистый impulse/откат усиливает, кульминация режет.
        if (s.body.isFinite()) {
            when {
                s.body in 0.25f..0.82f -> {
                    total += 0.12f
                    notes.add("clean_body")
                }
                s.body >= 0.90f -> {
                    total -= 0.10f
                    notes.add("exhaustion_body")
                }
                else -> total -= 0.05f
            }
        }

        // Тень отскока от края диапазона (усиливает уже выбранное направление).
        if (leadDir == Direction.CALL && s.lowerWickRatio > s.upperWickRatio) {
            total += 0.04f
            notes.add("call_wick")
        } else if (leadDir == Direction.PUT && s.upperWickRatio > s.lowerWickRatio) {
            total += 0.04f
            notes.add("put_wick")
        }

        // Позиция в диапазоне: у края усиливает, в середине просто не мешает.
        val curHigh = s.highs[n - 1]
        val curLow = s.lows[n - 1]
        val tol = f.range * 0.04f
        if (leadDir == Direction.CALL && curLow >= f.callLevel - tol) {
            total += 0.12f
            notes.add("call_zone")
        } else if (leadDir == Direction.PUT && curHigh <= f.putLevel + tol) {
            total += 0.12f
            notes.add("put_zone")
        }

        // Индикаторы: только бонус при совпадении; UNKNOWN/NONE не режут сигнал.
        if (s.superTrend != Trend.UNKNOWN) {
            val stCall = s.superTrend == Trend.GREEN
            if ((leadDir == Direction.CALL && stCall) || (leadDir == Direction.PUT && !stCall)) {
                total += 0.10f
                notes.add("st_ok")
            }
        }
        if (s.ao != Trend.UNKNOWN) {
            val aoCall = s.ao == Trend.GREEN
            if ((leadDir == Direction.CALL && aoCall) || (leadDir == Direction.PUT && !aoCall)) {
                total += 0.06f
                notes.add("ao_ok")
            }
        }
        if (s.stochCross != Cross.NONE) {
            val scCall = s.stochCross == Cross.UP
            if ((leadDir == Direction.CALL && scCall) || (leadDir == Direction.PUT && !scCall)) {
                total += 0.06f
                notes.add("stoch_ok")
            }
        }

        val atrShort = avgRange(pHighs, pLows, 3)
        val atrLong = avgRange(pHighs, pLows, minOf(12, n))
        if (atrLong > 0f && atrShort >= atrLong) {
            total += 0.05f
            notes.add("vol_ok")
        }

        return Triple(leadDir, total.coerceIn(0f, 1f), notes.joinToString("+").ifEmpty { "base" })
    }

    private fun emaLast(src: FloatArray, period: Int): Float {
        if (src.isEmpty()) return 0f
        val p = period.coerceIn(1, src.size)
        val k = 2f / (p + 1)
        var acc = src[0]
        for (i in 1 until src.size) acc = src[i] * k + acc * (1f - k)
        return acc
    }

    private fun avgRange(h: FloatArray, l: FloatArray, len: Int): Float {
        if (h.isEmpty() || len <= 0) return 0f
        val start = (h.size - len).coerceAtLeast(0)
        var sum = 0f
        var cnt = 0
        for (i in start until h.size) {
            val d = h[i] - l[i]
            if (d > 0f) { sum += d; cnt++ }
        }
        return if (cnt == 0) 0f else sum / cnt
    }

    private fun stateKey(s: Snapshot, dir: Direction): String {
        val i = s.highs.lastIndex
        val h = if (i >= 0) (s.highs[i] / 5f).toInt() else 0
        val l = if (i >= 0) (s.lows[i] / 5f).toInt() else 0
        val b = if (s.body.isFinite()) (s.body * 10f).toInt() else 0
        return "${dir.name}:$h:$l:$b:${s.isGreen}:${s.superTrend.ordinal}:${s.stochCross.ordinal}"
    }

    private fun resetConfirmation() {
        pending = null
        confirmCount = 0
        confirmingSince = 0L
        lastKey = null
    }

    fun statsLine(periodSec: Long): String =
        "STATS ${periodSec}s: state=$state conf=${lastConfidence.fmt(2, "?")} reason=$lastReason"
}
