package com.polaris.protocol

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

/** Состояние для UI. Журнал вынесен в LogRepository. */
data class UiState(
    val running: Boolean = false,
    val cvReady: Boolean = true,
    val live: Boolean = true,
    val markers: Boolean = false,
    val accessibility: Boolean = false,
    val fps: Float = 0f,
    val candles: Int = 0,
    val sessionTrades: Int = 0,
    val body: Float = Float.NaN,
    val payout: Int = -1,
    val fiboHigh: Float = Float.NaN,
    val fiboLow: Float = Float.NaN,
    val putLevel: Float = Float.NaN,
    val callLevel: Float = Float.NaN,
    val curHigh: Float = Float.NaN,
    val curLow: Float = Float.NaN,
    val lastGreen: Boolean = false,
    val superTrend: Trend = Trend.UNKNOWN,
    val stochCross: Cross = Cross.NONE,
    val stochValue: Float = Float.NaN,
    val ao: Trend = Trend.UNKNOWN,
    val assetName: String = "",
    val isOtc: Boolean = true,
    val candleClosed: Boolean = false,
    val engine: EngineState = EngineState.SCANNING,
    val lastSignal: Direction? = null
)

object BotState {
    val state = MutableStateFlow(UiState())
}

/** Настройки (SharedPreferences). Координаты кнопок — доли ширины/высоты экрана. */
object BotPrefs {
    const val CALL_X = "call_x"
    const val CALL_Y = "call_y"
    const val PUT_X = "put_x"
    const val PUT_Y = "put_y"
    private const val AUTO = "auto_tap"
    private const val COOLDOWN = "cooldown_s"

    private val defaults = mapOf(
        CALL_X to 0.285f, CALL_Y to 0.647f,
        PUT_X to 0.714f, PUT_Y to 0.647f
    )

    private fun sp(c: Context) = c.getSharedPreferences("polaris_protocol", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float = sp(c).getFloat(key, defaults[key] ?: 0.5f)
    fun put(c: Context, key: String, v: Float) { sp(c).edit().putFloat(key, v).apply() }

    fun autoTap(c: Context): Boolean = sp(c).getBoolean(AUTO, false)
    fun setAutoTap(c: Context, v: Boolean) { sp(c).edit().putBoolean(AUTO, v).apply() }

    fun cooldownSec(c: Context): Int = sp(c).getInt(COOLDOWN, 60)
    fun setCooldownSec(c: Context, v: Int) { sp(c).edit().putInt(COOLDOWN, v).apply() }
    fun cooldownMs(c: Context): Long = cooldownSec(c) * 1000L
}
