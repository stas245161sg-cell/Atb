package com.polaris.protocol

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ======================= APEXGRID / LIQUID GLASS =======================
// Холодная палитра 2026: ледяной циан #5CE1E6, сапфир #4EA8DE,
// глубокий тёмный фон #04060A и коралловый сигнал #FF4D6D.

val TerminalBg = ApexGlassColors.VoidBlack
val TerminalMint = ApexGlassColors.IceCyan
val TerminalMintSoft = Color(0x1A5CE1E6)
val TerminalMintOutline = Color(0x4D5CE1E6)
val TerminalDanger = ApexGlassColors.SignalCrimson
val TerminalDangerSoft = Color(0x1AFF4D6D)

val TextWhite = ApexGlassColors.TextPrimary
val TextSilver = ApexGlassColors.TextSecondary
val TextDim = ApexGlassColors.TextMuted
val TerminalGlassHigh = ApexGlassColors.RimSubtle

/** Сплошная обводка для мест, где нужен Color (Switch, Divider, legacy). */
val GlassBorder = Color.White.copy(alpha = 0.18f)
/** Градиентная обводка — блик на грани стекла. */
val GlassBorderBrush: Brush = Brush.linearGradient(
    colors = listOf(
        Color.White.copy(alpha = 0.40f),
        Color.Transparent,
        Color.White.copy(alpha = 0.10f)
    )
)
/** Фон стеклянной карточки. */
val GlassFill = Color(0xFF141414).copy(alpha = 0.6f)
val GlassBrush: Brush = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.025f), Color.White.copy(alpha = 0.06f))
)
val GlassSpecular: Brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.20f), Color.Transparent))
val AppBackgroundBrush: Brush = Brush.verticalGradient(listOf(TerminalBg, Color(0xFF0C0F0E)))

/** Формы «liquid» — искать форму как у иконки. */
val LiquidShape = RoundedCornerShape(24.dp)
val LiquidButtonShape = RoundedCornerShape(16.dp)
val TerminalMono = FontFamily.Monospace

// --- Алиасы для совместимости с InfoScreen и legacy-компонентами ---
val BgTop = TerminalBg
val BgBottom = Color(0xFF0C0F0E)
val IceCyan = TerminalMint
val DeepCyan = Color(0xFF2B5A85)
val FrostBlue = ApexGlassColors.SapphireGlow
val NeonRed = TerminalDanger
val DeepRed = Color(0xFF5A1727)
val TextPrimary = TextWhite
val TextSecondary = TextSilver
val Positive = TerminalMint
val Negative = TerminalDanger
val SignalRed = TerminalDanger
val LogText = Color(0xFFBAC8DE)

private val PolarisColorScheme = darkColorScheme(
    primary = TerminalMint,
    onPrimary = TerminalBg,
    secondary = TerminalMintSoft,
    background = TerminalBg,
    onBackground = TextWhite,
    surface = TerminalBg,
    onSurface = TextWhite,
    outline = GlassBorder,
    error = TerminalDanger
)

private val PolarisTypography = Typography(
    titleLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        color = TextWhite
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = TextWhite
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 12.sp,
        color = TextSilver,
        lineHeight = 16.sp
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontSize = 11.sp,
        color = TextSilver
    ),
    labelLarge = TextStyle(
        fontFamily = TerminalMono,
        fontWeight = FontWeight.Bold,
        fontSize = 13.sp,
        color = TextWhite
    )
)

@Composable
fun ApexGridTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = PolarisColorScheme, typography = PolarisTypography, content = content)
}

/** Совместимость с прежним именем темы. */
@Composable
fun PolarisTheme(content: @Composable () -> Unit) = ApexGridTheme(content)

/** Фон терминала: чёрный + мятное свечение в левом верхнем углу (как на иконке). */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(AppBackgroundBrush)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(ApexGlassColors.IceCyan.copy(alpha = 0.06f), Color.Transparent),
                        center = Offset(0f, 0f),
                        radius = size.maxDimension * 1.1f
                    )
                )
            },
        content = content
    )
}

/** Карточка Liquid Glass вынесена в ApexGridUI.kt (ColumnScope-контент). */
