# ApexGrid V17.3 — сборка APK

Локальная сборка в текущей среде невозможна: нет JDK, Gradle и Android SDK. APK собирается в GitHub Actions.

## Шаг 1 — репозиторий

1. Создайте **private** репозиторий на GitHub (например `apexgrid`).
2. Загрузите **содержимое** архива `ApexGrid_v17.3_OCR.zip` в корень ветки `main`
   (в корне должны лежать `app/`, `build.gradle`, `settings.gradle`, `.github/`).

   Если используете `ApexGrid_v17.3_OCR_FOLDER.zip`, загрузите содержимое папки `Polaris_V17/`, а не саму папку.

## Шаг 2 — сборка

Workflow `.github/workflows/build.yml` настроен на JDK 17 + Gradle 8.7 + Android SDK:

- при `push` в `main`/`master` сборка запускается сама;
- или вручную: **Actions → Build APK → Run workflow**.

После завершения скачайте артефакт **ApexGrid-debug-apk** (`app/build/outputs/apk/debug/*.apk`).

## Шаг 3 — установка

1. Перенесите APK на Poco F3 и разрешите установку из неизвестных источников.
2. При первом запуске введите код доступа: `ApexGrid_byBoroda13`.
3. Включите службу спец. возможностей ApexGrid в настройках Android.
4. Нажмите START и разрешите захват экрана.
5. В Pocket Option выставьте SuperTrend 10/3, Stochastic 5/3/3, AO 5/34; уберите лишние индикаторы.
6. Откалите зоны «График» и «Выплата» (и Stochastic/AO, если цвета не распознаются).
7. Выплата ≥80%; график должен быть на последней свече (кнопка «>»).

## Что прислать после первого запуска

Первые 30 строк журнала (кнопка LOGS → копировать). Проверяю:

- `START: APEXGRID profile=... conf>=...`
- `OCR RAW: ... -> EXTRACTED: ...`
- `EVAL: ... candle=CLOSED ...` — только в окне после сдвига X-сетки
- `TAP CALL/PUT` — и что `SessionRiskGate` инкрементирует счётчик

## Известное

- Иконка всё ещё `polaris_logo` / старые mipmap — заменим после генерации новой иконки ApexGrid.
- Сборка debug, поэтому `debuggable=true`; доступ не блокируется, пока не задан `APEX_EXPECTED_SHA256`.
