# ApexGrid V17.11.1 — уточнённые границы Stochastic/AO

По вашим координатам с скриншотов подогнаны две зоны (остальные уже совпадали):

- `STOCH` → y 0.70–0.77 (было 0.71–0.78)
- `AO` → y 0.79–0.86 (было 0.80–0.88)

`PAIR` (x 6–44%, y 13–17%), `CHART` (y 20–53%) и `PAYOUT` (x 20–37%, y 65–67%) остались как в V17.11. Отдельный `RoiCalibrationConfig` не добавлен: в проекте уже есть `RoiPrefs` в `ImageAnalyzer.kt` с префами `apexgrid_roi_prefs` и ключами `roi_<zone>_left/top/right/bottom`, enum `RoiZone` и `NormRect` — второй центр хранения зон создал бы рассинхрон.

---

# ApexGrid V17.11 — свежие дефолты зон калибровки

Координаты с экрана калибровки 99494.jpg встроены прямо в существующий `RoiPrefs.default()` (без нового класса и без замены остальных файлов):

- `PAIR` → x 0.06–0.44, y 0.13–0.17 (было x0.14–0.52, y0.18–0.22)
- `CHART` → y 0.20–0.53 (было 0.195)
- `PAYOUT` → x 0.20–0.37, y 0.65–0.67
- `STOCH` → y 0.71–0.78
- `AO` → y 0.80–0.88

В «Калибровке зон» добавлена кнопка **«Сбросить все зоны»**: вызывает `RoiPrefs.resetAll(ctx)` и сразу обновляет карту `rects`, чтобы сброс возвращал именно новые координаты. Сохранённые вручную зоны перекроют дефолты — после установки нажмите эту кнопку один раз.

---

# ApexGrid V17.10.1 — исправление сборки

`ImageAnalyzer.kt:1171`: `isValidPairName()` ссылалась на `PAIR_VALID_REGEX`, но константа не была объявлена в `companion object` (в V17.10 оставил инлайн-`Regex` при правке). Добавил `val PAIR_VALID_REGEX = Regex("^[A-Z]{3}/[A-Z]{3}( OTC)?$")` рядом с другими регулярками. Остальной код V17.10 не менялся.

---

# ApexGrid V17.10 — качество входов по логам 99442–99449

1. `UnifiedStrategyEngine`: убраны PUT по `exhaustion_body` при `Stoch=UP` или `AO=GREEN` (`exhaustion_reversal_block`) — истощение красной свечи теперь не трактуется как продолжение вниз. Штраф за `body>=0.90` усилен с −0.10 до −0.18. При `ST=UNKNOWN` добавляется штраф −0.12 (`st_unknown_penalty`): без подтверждения тренда сигнал должен набрать заметно больше очков.
2. `ImageAnalyzer`: допуск для кандидатов свечей расширен (`w <= h*1.35`, `area >= 0.22*w*h`), чтобы маркеры сделок/пунктиры не выбрасывали свечу. Кэш последней валидной сетки увеличен до 5 с, при использовании кэша выставляется `chartNote=stale_grid` (видно в EVAL как `GRID=stale_grid`).
3. `ImageAnalyzer.normalizePairName()`: если в строке нет валидного `XXX/YYY` — возвращается пустое имя, мусор вроде `OTIMYHas pa...`, `eJTKM`, `He ynycTUTe BO3` больше не может стать парой.
4. `PAYOUT_TTL_MS`: 10 с → 22 с. Единичный null/сбойный кадр OCR больше не обнуляет выплату в `-1` и не блокирует сигналы.

Предупреждения SDK XML v4 и `Unable to strip ... .so` — штатные.

---

# ApexGrid V17.9.1 — исправление ошибки сборки

`ImageAnalyzer.kt:1249`: в `requestPayoutOcr()` переменная `scaled` объявлялась **внутри** `try`, а освобождалась в `catch` → `Unresolved reference: scaled`. Перенёс создание `scaled` (через `cropScaledBitmap`) перед `try` с проверкой на null, как это уже сделано в `requestPairOcr()`. Предупреждения SDK XML v4 и `Unable to strip ... .so` не влияют на сборку.

---

# ApexGrid V17.9 — запрет повторного входа в той же свече

По уточнению: однонаправленные сделки допустимы, если не противоречат стратегии; запрещается только вторая сделка **на той же закрытой свече**.

- Удалён слишком широкий запрет серии из V17.8 (`SAME_DIR_WINDOW_MS`, `sameDirectionStreak`).
- Вместо него в `UnifiedStrategyEngine` добавлен `candleIdentity()` — подпись закрытой свечи (high/low/close/body/color). После сделки сохраняется `lastFiredCandleKey`; повторный вход с такой же подписью блокируется с причиной `same_candle_lock`.
- Подпись сбрасывается при смене пары. `consumeCandleClosedWindow()` в `ImageAnalyzer` и сервисе остаётся как дополнительная защита от повторного срабатывания того же бара.
- Окно закрытой свечи остаётся 4 с, кэши свечей/ST и исправленные ROI — без изменений.

---

# ApexGrid V17.8 — точечные улучшения качества входов

Взято только то, что реально улучшает работу, без регрессов из последнего комплекта:

- `UnifiedStrategyEngine`: запрет серии однонаправленных входов. После **двух подряд** CALL или PUT третий такой же вход блокируется в течение 2 минут (`SAME_DIR_WINDOW_MS`); счётчик сбрасывается при входе в противоположную сторону, по таймауту и при смене пары. В логе причина `same_direction_lock`.
- `ImageAnalyzer`: окно закрытой свечи уменьшено с 8 с до **4 с** — хватает для подтверждения 2 кадрами за 1.2 с, но меньше шанс войти по устаревшему бару.
- `ImageAnalyzer.consumeCandleClosedWindow()` — сервис вызывает его сразу после сигнала, чтобы после cooldown не сработал тот же бар.
- Регулярки `NON_PAIR_CHARS_REGEX` / `MULTI_SPACE_REGEX` вынесены в `companion object` — меньше аллокаций на каждый OCR-кадр.

**Не применено:** регрессивные ROI (0.170/0.693/0.785, пара x0.10), отсутствие нормализации `CAD/IJPY`, кэшей свечей/ST, дубли composable, урезанный `UiBotState`, LOLLIPOP-guard для `windows`.

---

# ApexGrid V17.7 — чистый OCR пары, устойчивость к шумным кадрам, полное имя ApexGrid

Полное переименование: пакет и applicationId → `com.apexgrid.app`, rootProject → `ApexGrid`, все ACTION-константы → `com.apexgrid.app.*`, ключ SharedPreferences ROI → `apexgrid_roi_prefs`, функция экрана терминала переименована в `ApexGridScreen` (замена выполнена во всех исходниках, манифесте, Gradle и документации). Старых вхождений прежнего имени в проекте нет.

Внимание: смена applicationId и ключа ROI означает новый identity приложения и сброс сохранённой калибровки — после установки заново откалибруйте зоны.

---

# ApexGrid V17.7 — чистый OCR пары и устойчивость к шумным кадрам

По свежим логам (`8 CAD/JPY OTC`, `CAD/IJPY OTC`, `not_enough_candles(0)`, `ST=UNKNOWN`):

- `normalizePairName()` теперь вытаскивает пару через `PAIR_REGEX` из любого мусора, плюс два дополнительных шаблона для OCR-искажений разделителя: `PAIR_GLUED_REGEX` (`CAD/IJPY`) и `PAIR_NOSLASH_REGEX` (`NZDIJPY`). Мусорные префиксы `8`, `O`, `CI` больше не меняют пару.
- Подтверждение новой пары по-прежнему требует **2 подряд** совпадения; добавлен троттлинговый лог `OCR PAIR RAW: '<сырое>' -> '<нормализованное>'` для диагностики.
- Добавлен кэш последних валидных свечей `CANDLE_CACHE_MS = 2500` — на шумном кадре с `not_enough_candles` история не обнуляется, детектор закрытия не сбрасывается.
- Добавлен кэш SuperTrend `ST_CACHE_MS = 2500` — `ST=UNKNOWN` на одном кадре больше не затирает последнее надёжное направление.
- HSV SuperTrend уже расширен в V17.6 (cyan H72–112, magenta H135–172) — подтверждено.
- ROI: верх «Графика» подрезан с 17% до **19.5%** (плашка SuperTrend больше не попадает в анализ), зоны Stochastic/AO сдвинуты ниже заголовков (0.705 и 0.800), окно «Пара» сужено слева до x=0.14 (иконка флага в x8–46 больше не попадает в OCR).

**Важно:** если зоны уже откалиброваны вручную, сохранённые значения в `apexgrid_roi_prefs` перекроют новые дефолты — откройте «Калибровка зон» и нажмите «Сброс зоны» для Графика/Stochastic/AO/Пары или подправьте границы.

---

# ApexGrid V17.6 audit — исправления по итогам полной перепроверки

- **Критично:** `SecurityGuard.currentCertSha256()` снова содержал `return null` внутри `return try { ... }` (expression body) — гарантированная ошибка `Returns are not allowed for functions with expression body`. Заменено на ветвление `if (si == null) null else { ... }`.
- `RoiPrefs.default(CHART)` правый край возвращён с `0.86` на `1.0`: `LIVE_EDGE_SCROLLED=0.97` считается от ширины ROI, поэтому при 0.86 живая свеча давала вечный «прокручен».
- `ImageAnalyzer.requestPayoutOcr`: в `catch` добавлен `scaled.recycle()` — утечка Bitmap при исключении.
- `ApexTerminalScreen`: в шапку добавлен `ApexBrandIcon(44.dp)`, версия в подписи обновлена до V17.6.

---

# ApexGrid V17.6 — антидребезг пары и кэш шага сетки

Из присланного комплекта взято только то, что улучшает зрение, без замены рабочего каркаса:

- `ImageAnalyzer`: кэш последнего валидного `pitch` на 2.5 с (`PITCH_CACHE_MS`) — сетка не «ослепляет» на одном кадре; сброс окна закрытия при резком скачке шага >45%.
- `ImageAnalyzer`: фильтрация ложных `PAIR_SWITCHED` — пара меняется только после двух одинаковых OCR-чтений подряд (`candidatePairHits >= 2`).
- `ImageAnalyzer`: строгая нормализация пары через `PAIR_REGEX` и проверка `^[A-Z]{3}/[A-Z]{3}( OTC)?$` (мусор вроде `6R AUD/USD` отсекается).
- `Hsv`: расширены диапазоны SuperTrend — cyan H72–112 / S85+, magenta H135–172 / S85+.
- Журнал увеличен до 500 строк.

**Не применено:** замена `UiState` на урезанный `UiBotState` (теряет FPS/пары/выплату/профиль/движок), новый `MainActivity` без START/STOP и калибровки, дубли `ApexGlassBackdrop`/`LiquidGlassActionButton`/`ApexBrandIcon`, отсутствующие в комплекте `ScreenCaptureService`/`UnifiedStrategyEngine`/`OverlayMarkers`/`SecurityGuard`/`ApexGridAccess`..Complect неполный и сломал бы сборку, поэтому рабочий V17.5 каркас сохранён.

---

# ApexGrid V17.5 — новая иконка

Добавлен исходник `app/src/main/res/drawable-nodpi/apexgrid_icon_raw.jpg` (1024×1024, 161 КБ) — иконка со свечным графиком, восходящей линией и неоновой голубой рамкой из `1795343985610.jpg`. Подключена через `ic_launcher_foreground.xml` с inset 16% (безопасная зона адаптивного значка), фон `#060B12`, монохромный слой тот же. Удалены старые растровые mipmap и `apexgrid_logo.png`, тема переименована в `Theme.ApexGrid`. Добавлен `ApexBrandIcon` для вывода иконки внутри Compose.

---

# ApexGrid V17.4 logui —_compact кнопки экрана логов

- Заголовок экрана логов укорочен до «Журнал», занимает `weight(1f)` и не переносится (`maxLines=1`, `softWrap=false`, ellipsis).
- Кнопки «Копировать / Очистить / Назад» компактные (новый параметр `compact = true` у `LiquidGlassActionButton`: горизонтальный padding 7.dp, шрифт 12.sp, `maxLines = 1`) — помещаются в одной строке без переноса слов.
- Добавлен `BackHandler` — выход системной кнопкой/жестом «Назад» работает так же, как кнопка «Назад».

---

# ApexGrid V17.4 autotap — синхронизация тумблера Автонажатие

- `UiState` получил поле `autoTap`; `BotState` — методы `setAutoTap/setAccessibility/update`.
- `BotPrefs`: добавлены `isAutoTapEnabled`, `setAutoTapEnabled` (сразу обновляет `BotState`) и `syncFromPrefs`. Старые ключи и/file `apexgrid_bot_prefs` сохранены.
- `MainActivity`: при старте и на каждом `ON_RESUME` состояние тумблера и доступности синхронизируется из SharedPreferences и службы; новый `AutoTapControlRow` показывает «Вкл — автоматические тапы по сигналу» / «Вкл — ждёт службу…» / «Выкл — только сигналы и логи».
- `ScreenCaptureService`: перед тапом вызывается `maybeExecuteAutoTap()` — читает актуальный флаг из BotPrefs, проверяет службу и пишет причину отказа в лог.

---

# ApexGrid V17.4 tapfix — диагностика foreground и копирование лога

- `TradingAccessibilityService`: добавлен `currentForegroundPackage()` с опросом `rootInActiveWindow` и резервным `windows.firstOrNull { isActive }` (API 30+), `isPocketOptionForeground()` сравнивает точный пакет.
- `ScreenCaptureService.dispatchTradeTap()`: при блокировке тапа в лог пишется конкретный активный пакет (`'unknown'`, если пусто) и ожидаемый `com.pocketoption.broker`; отдельно диагностируется неактивная служба.
- `ApexLogsScreen`: кнопка «Копировать» — весь журнал в буфер обмена + подтверждение в логе.
- `accessibility_service_config.xml`: добавлены `typeWindowsChanged`, `canRetrieveWindowContent="true"` и `flagRetrieveInteractiveWindows` — нужны для стабильных событий смены окна в HyperOS 4.

---

# ApexGrid V17.4 buildfix — четыре ошибки компиляции

- `Theme.kt`: `DarkColorScheme(...)` → `darkColorScheme(...)` (строчная буква, как в Material 3).
- `ImageAnalyzer.kt`: добавлена недостающая функция `cropScaledBitmap(bmp, zone, upscale)`, используемая OCR пары и выплаты.
- `MainActivity.kt`: жёсткая ссылка `BuildConfig::class.java` заменена на безопасный `Class.forName("$packageName.BuildConfig")` — сборка не зависит от `buildFeatures.buildConfig`.
- `TradingAccessibilityService.kt`: добавлен явный `fun isRunning(): Boolean = instance != null`; в `isPocketOptionForeground()` добавлен резервный опрос `rootInActiveWindow`.

---

# ApexGrid V17.4 final — синхронизация смены пары и освобождение Bitmap

Применён полный обновлённый комплект:

- Смена пары теперь проходит через `pendingPairResetFrom/pendingPairResetTo`: OCR только выставляет флаг, а сброс X-сетки, payout и движка выполняется в начале `ImageAnalyzer.analyze()` на рабочем потоке анализатора. Это убирает гонку с ML Kit-колбэком.
- `CalibrationScreen` получил `DisposableEffect(frameBmp) { onDispose { frameBmp?.recycle() } }` — последний кадр больше не утекает при закрытии калибровки.
- `RoiPrefs.FILE` остался `apexgrid_roi_prefs`; окна `PAYOUT` и `PAIR` сохранены.
- Удалены дубли: `TradingProfile`/`ProfileSettings` (остался один в `BotState.kt`), `ApexGlassColors` (только в `Theme.kt`), `ApexGridTheme` (только в `Theme.kt`), `SessionRiskGate` (только в `BotState.kt`). Удалён старый `ApexInfoSettingsScreen.kt`.
- Лог расширен до 400 записей, добавлен `LogRepository.clear()`.

---

# ApexGrid V17.4 (pair) — автосброс по паре и короткий кулдаун

Добавлено окно OCR `RoiZone.PAIR` («Пара») с интервалом 450 мс и отдельным busy-флагом. При смене распознанной пары `ImageAnalyzer` сам сбрасывает X-сетку и кэш выплаты и через `setOnPairChangedListener` вызывает `UnifiedStrategyEngine.onChartSwitched()` — без 60-секундной заморозки и без ручной кнопки сброса. Ручная кнопка удалена из `ApexInfoSettingsScreen`, вместо неё пояснение.

`BotPrefs.cooldownSec` теперь по умолчанию 20 с и ограничен диапазоном 15–30 с; `SessionRiskGate` tiene страховочный cooldown 15 с вместо 60 с. `RoiPrefs.FILE` остался `apexgrid_roi_prefs` — сохранённая калибровка не теряется. В калибровке через `RoiZone.values()` появилась вкладка «Пара». OpenCV остаётся удалённой зависимостью `com.quickbirdstudios:opencv:4.5.3.0` — локальный AAR в `app/libs/` не требуется.

---

# ApexGrid V17.4 — новый экран «Индикаторы и настройки»

Добавлен `ApexInfoSettingsScreen.kt`: короткие строки вместо плотных абзацев, теги «Логика: / Условия: / График:», контрастные циановые кнопки с тёмным текстом, убраны висячие переносы. Старый `InfoScreen.kt` удалён, вызов в `MainActivity` заменён; кнопка «График переключён — сбросить» отправляет `ACTION_CHART_SWITCHED` (сброс движка, X-сетки и кэша выплаты).

---

# ApexGrid V17.3.1 — исправление ошибки компиляции

`SecurityGuard.kt`: функция `currentCertSha256()` была объявлена с expression body (`= try { ... }`), но внутри использовала `return null`. Это давало `Returns are not allowed for functions with expression body` и роняло `:app:compileDebugKotlin`. Тело заменено на блоковое `{ return try { ... } catch { ... } }`. Остальной код не менялся.

Предупреждения `Unable to strip ... .so` и `SDK XML version 4` на сборку не влияют.

---

# ApexGrid V17.3 — unified Liquid Glass + офлайн-доступ + адаптивный OCR

V17.3:
- Удалён последний мёртвый `SignalSettings.kt` (переключатель MAX_WIN/BALANCED/MORE_SIGNALS) и оба вызова `SignalSettings.load(...)`. Единственный источник режимов — `TradingProfile` (Поток 0.45 / Баланс 0.55 / Снайпер 0.68).
- Payout OCR стал адаптивным: при стабильной выплате ≥80% опрос реже (2500 мс), у порога (80–84) или после `resetChartTracking()` — чаще (400 мс), иначе 600 мс. Поле `apexgrid_prefs` не используется — калибровка остаётся в прежнем хранилище.
- Иконка ApexGrid пока не заменена: ждём генерацию изображения.

---

# ApexGrid V17.2 — unified Liquid Glass + офлайн-доступ

Добавлены `SecurityGuard.kt` и `ApexGridAccess.kt`: офлайн-активация по коду `ApexGrid_byBoroda13` (хеш SHA-256 с солью, состояние в SharedPreferences). Экран активации в холодном Liquid Glass стиле показывается до основного терминала.

Отклонения от присланного «финального» комплекта (причины — конфликты и работоспособность):
- **Не добавлены** `ApexGridTheme.kt` и `ApexTopBarAndModes.kt` дословно: они дублировали `ApexGlassColors`, `ApexGridTheme`, `TradingProfile` и `LiquidGlassCard`. Вместо этого недостающие composable-функции (`ApexGlassBackdrop`, `LiquidGlassCard`, `LiquidGlassActionButton`, `GlassMetricRow`) добавлены в `ApexGridUI.kt`, старая карточка удалена из `Theme.kt`.
- **Не заменён `MainActivity.kt` заглушкой**: присланный вариант удалял весь рабочий интерфейс (START/STOP, логи, калибровка, маркеры). Вместо этого экран активации встроен в существующий `MainActivity` перед `ApexGridScreen`.
- **Не использован присланный `ScreenCaptureService.kt`**: он ссылался на несуществующие `VoteEngine`, `DecisionEngine.MIN_PAYOUT`, `TradingAccessibilityService.isRunning()`, DROP-нул `SessionRiskGate.onExecutedGesture()` и хардкодил профиль `BALANCE`. Сохранён сервис V17 с единым движком и рабочим риск-гейтом.
- **Не использован присланный `ImageAnalyzer.kt` / `UnifiedStrategyEngine.kt`**: в них отсутствовали `dropLast(1)` и требование `candleClosed`, то есть вход шёл по формирующейся свече. Сохранены версии V17 с этими защитами.
- `SecurityGuard.allowed` изменён: `debuggable` блокирует доступ **только если задан `APEX_EXPECTED_SHA256`**.debug-сборка GitHub Actions иначе навсегда оставалась бы на экране активации.

Пороги профилей приведены к присланным: FLOW 0.45 / BALANCE 0.55 / SNIPER 0.68.

---

# ApexGrid V17.1 — unified Liquid Glass (бесконфликтный движок)

Ребрендинг: ApexGrid → **ApexGrid**. Новая палитра: ледяной циан `#5CE1E6`, сапфир `#4EA8DE`, коралловый сигнал `#FF4D6D`, глубокий фон `#04060A`. Мятный `#00FFAA` полностью убран. Моноширинная типографика для заголовка и метрик.

Три переключателя «Поток / Баланс / Снайпер» управляют **только порогом confidence** единого движка (0.44 / 0.52 / 0.62). Конфликтные стратегии не возвращались: `TradingProfile` не включает/не выключает стратегии и не создаёт `direction_conflict`.

Иконка и drawable `apexgrid_logo` пока сохранены — генерация новой иконки ApexGrid отложена.

База: ApexGrid V16. Сборка через GitHub Actions (Gradle 8.7, Kotlin 1.9.22).

## Удалено полностью

- OCR названия пары (`RoiZone.ASSET`, зона калибровки «Название пары`, `requestAssetOcr`, `AssetParser`).
- Конфликтное голосование: `VoteEngine.kt`, `Strategies.kt`, `DecisionEngine.kt` удалены.
- `direction_conflict`, `conflicting_votes`, `weak_vote`, `no_strategy_vote` больше не существуют.

## Ядро: UnifiedStrategyEngine.kt

- Единое направление выбирается один раз по EMA(5/13), наклону последних баров и цвету закрытой свечи.
- Остальные модули только **усиливают** выбранное направление (reinforcement), нейтральные индикаторы не режут сигнал:
  - форма свечи (чистое тело 0.25–0.82 — плюс, кульминация ≥0.90 — минус);
  - тень отскока (upper/lowerWickRatio);
  - зона края диапазона FIBO 14.6% (середина не мешает);
  - SuperTrend 10 3 / Stochastic 5 3 3 / AO 5 34 — только бонус при совпадении;
  - волатильность (сжатие/расширение).
- **Порог выплаты статичен: 80%.** Порог Confidence 0.52. Подтверждение: 2 разных состояния за ≥1.2 с.
- Вход строго по закрытой свече: `s.candleClosed == true` обязателен.
- Cooldown из BotPrefs (минимум 15 с); `SessionRiskGate` (30 жестов, 60 с) сохраняется.
- `onChartSwitched()` сбрасывает подтверждения и cooldown.

## Зрение: ImageAnalyzer.kt

- X-grid фильтрация свечей: берутся только компоненты с равным шагом по X; широкие горизонтальные плашки («Купить»/«Продать», меню) отсекаются.
- `labels.get(0,0,...)` вызывается один раз за кадр вместо 30 раз.
- Добавлены `upperWickRatio` / `lowerWickRatio`.
- Закрытие свечи фиксируется по появлению нового столбца справа (сдвиг правого края ≥0.7 pitch), окно 8 с.
- Защита от открытого меню вместо удалённого OCR: если X-сетка даёт 1–5 свечей или `pitch == 0`, кадр помечается невалидным.
- `resetChartTracking()` сбрасывает X-сетку и кэш выплаты при смене графика.
- SuperTrend / Stochastic / AO остаются по тем же HSV-маскам; новых индикаторов нет.

## Сервис и UI

- `ScreenCaptureService` переведён на `UnifiedStrategyEngine`; VOTE-логирование удалено (спам исчез).
- `ACTION_CHART_SWITCHED` сбрасывает и движок, и анализатор.
- EVAL теперь печатает `conf`, `reason`, `candle=CLOSED/FORMING`, ST/Stoch/AO и RISK-блок.
- Вкладка калибровки «Название пары» удалена из UI и из `RoiZone`.
- `BotState/BotPrefs/UiState` вынесены в отдельный `BotState.kt`.

## Известные ограничения

- Старый переключатель режимов в «Инфо» (Максимальный винрейт/Баланс/Больше сигналов) теперь **не влияет** на движок — удалён из логики, будет убран из UI в следующей версии.
- Payout OCR по-прежнему опрашивает зону каждые 600 мс; экономия достигается только ранним выходом по `!live` и невалидной сетке.
- Порог выплаты не различает CALL/PUT (один процент с экрана).
- Heikin Ashi и обычные свечи обрабатываются одним и тем же детектором; таймфрейм не привязан.
