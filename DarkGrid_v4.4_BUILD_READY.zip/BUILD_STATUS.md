# Build and verification record

Project version: `4.4-pair-fix` (versionCode 24)  
Package: `com.traderai.app`

## What changed in 4.4

- Pair OCR no longer depends on a narrow `x=0.04..0.60, y=0.11..0.20` zone or a strict `AAA/BBB` regex. The search zone is widened to `x=0.02..0.70, y=0.03..0.30`, slash-like characters (`/ \ | · • ∕ ／`) are normalized, and `EURUSD`-style joined codes are accepted when one side is a known asset code.
- Added a **manual pair field** on the main screen. When set, it overrides OCR. This unblocks the whole pipeline on layouts where the pair label cannot be read.
- Added an `OCRDBG` log line (once per minute) with the raw OCR strings and their screen coordinates from the upper 42% of the frame, so a failed pair search can be diagnosed from logs alone.
- Added screen-level broker outcome recognition from the PO chart markers, verified against the supplied screenshots: `+$1,910` (win), `$0` (loss/return), `▼ $1,000 00:29` (open position with countdown). Markers are only accepted when freshly appeared; a gesture callback alone still never counts as broker acceptance. Vision evidence is applied through the existing DEMO transition guard.
- Price-axis calibration now accepts two price labels instead of requiring three, with a negative-slope and plausible-span guard against OCR digit errors. Price regex accepts two or more decimals (indices/crypto).
- All safety gates are unchanged: calibration approval, observed M5 rollover, 30-candle contiguous history, minimum payout, accessibility service, correct foreground package, DEMO journal/dedupe, cooldown, and deposit-risk stop-out.

## Historical context

- `4.1` removed CALL/PUT coordinate sliders and detects button centers from OCR text.
- `4.2` removed the DEMO/Practice label gate and added balance OCR plus `TradeRiskGuard` (10/20/30/40/50%).
- `4.3` widened the M5 rollover observation window to 10 s and cached the OCR pair for 10 minutes. On-device logs showed the timer and payout were read correctly, but the pair stayed `?` for the entire session, so `validContext` was false, no candles were reconstructed, calibration stayed `НЕТ`, and the gate stayed `ЗАКР`.

## Checks performed in this environment

- Kotlin brace/parenthesis balance check: passed for all changed files.
- XML resource/manifest parsing: passed.
- ZIP integrity check: passed.

## Checks not performed

- Full Android Gradle build and Android unit-test task: **not run**. This environment has no Android SDK or Gradle installation.
- Install/run on POCO F3 / HyperOS: **not run**.
- Pocket Option pair-label layout and DEMO journal recognition on the live UI: **not device-verified**.
- Strategy profitability: **not established**; requires independent historical and DEMO sample validation.

A successful GitHub CI build establishes Android compilation and unit-test status only. It does not establish correct chart reconstruction, broker acceptance, or profitability.
