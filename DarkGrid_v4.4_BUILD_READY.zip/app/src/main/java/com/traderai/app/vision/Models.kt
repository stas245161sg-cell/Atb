package com.traderai.app.vision

data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val closed: Boolean,
    val confidence: Float,
    val verified: Boolean = false
) {
    fun isValid(): Boolean =
        time > 0 &&
        open.isFinite() && high.isFinite() &&
        low.isFinite() && close.isFinite() &&
        low > 0.0 && high >= low &&
        high >= maxOf(open, close) &&
        low <= minOf(open, close) &&
        confidence in 0f..1f

    val body: Double get() = kotlin.math.abs(close - open)
    val range: Double get() = high - low
    val bullish: Boolean get() = close > open
    val bearish: Boolean get() = close < open
}

/** Визуальные маркеры сделки на графике Pocket Option. */
enum class BrokerOutcome { PLACED, WIN, LOSS, DRAW }

enum class Side { CALL, PUT, NONE }
enum class Regime { UPTREND, DOWNTREND, RANGE, UNKNOWN }
enum class TradingMode { ACTIVE, BALANCED, SNIPER }

data class ScreenContext(
    val pair: String?,
    val payout: Int?,
    val timeframeMins: Int?,
    val expiryMins: Int?,
    val valid: Boolean,
    val reason: String
)

data class Analysis(
    val side: Side,
    val score: Int,
    val regime: Regime,
    val reason: String,
    val cvConfidence: Float,
    val candleCount: Int,
    val signalTime: Long?,
    val entryTime: Long?
)

data class IndicatorSnapshot(
    val ema5: Double? = null,
    val ema13: Double? = null,
    val rsi: Double? = null,
    val bbUpper: Double? = null,
    val bbLower: Double? = null,
    val superTrendBullish: Boolean? = null,
    val stochK: Double? = null,
    val stochD: Double? = null
)

