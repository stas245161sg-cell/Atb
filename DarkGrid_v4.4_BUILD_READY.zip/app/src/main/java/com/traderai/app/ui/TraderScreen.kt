package com.traderai.app.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.traderai.app.capture.CaptureState
import com.traderai.app.capture.ScreenCaptureService
import com.traderai.app.data.AppSettings
import com.traderai.app.data.SessionLog
import com.traderai.app.data.SettingsRepo
import com.traderai.app.trading.PaperTrading
import com.traderai.app.trading.DemoExecutionEventStore
import com.traderai.app.trading.DemoAttempt
import com.traderai.app.accessibility.DarkGridAccessibilityService
import com.traderai.app.trading.TradingGate
import com.traderai.app.vision.TradingMode
import kotlinx.coroutines.launch

private val CubeCardShape = RoundedCornerShape(22.dp)
private val CubeButtonShape = RoundedCornerShape(14.dp)
private val CubeSegmentShape = RoundedCornerShape(12.dp)
private val CubePillShape = RoundedCornerShape(10.dp)

private enum class Tab { MAIN, LOGS, PAPER, INFO }

@Composable
fun TraderScreen(repo: SettingsRepo) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(Tab.MAIN) }

    val settings by repo.flow.collectAsStateWithLifecycle(initialValue = AppSettings())
    val capturing by CaptureState.capturing.collectAsStateWithLifecycle()
    val status by CaptureState.status.collectAsStateWithLifecycle()
    val analysis by CaptureState.analysis.collectAsStateWithLifecycle()
    val calibrationReady by CaptureState.calibrationReady.collectAsStateWithLifecycle()
    val approved by TradingGate.approved.collectAsStateWithLifecycle()
    val telemetry by CaptureState.telemetry.collectAsStateWithLifecycle()
    val paperStats by CaptureState.paper.collectAsStateWithLifecycle()
    val paperText by CaptureState.paperText.collectAsStateWithLifecycle()
    val logLines by SessionLog.lines.collectAsStateWithLifecycle()
    val demoEvents = remember(logLines) { DemoExecutionEventStore(context).all().takeLast(30).asReversed() }
    val accessibility by CaptureState.accessibility.collectAsStateWithLifecycle()
    val risk by com.traderai.app.trading.TradeRiskGuard.status.collectAsStateWithLifecycle()

    BackHandler(enabled = tab != Tab.MAIN) { tab = Tab.MAIN }

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val i = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, i)
            CaptureState.capturing(true)
            CaptureState.status("Захват запускается…")
        } else {
            CaptureState.capturing(false)
            CaptureState.status("Разрешение не получено")
        }
    }

    fun requestCapture() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }
    fun stopCapture() {
        context.startService(Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        })
        CaptureState.capturing(false)
    }
    fun copy(text: String) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("DarkGrid", text))
    }

    val ambientBg = Brush.radialGradient(
        colors = listOf(Color(0xFF101B24), Color(0xFF070A0E), TraderColors.Void),
        center = Offset(540f, 160f),
        radius = 1350f
    )

    Column(
        Modifier.fillMaxSize().background(ambientBg).statusBarsPadding()
            .navigationBarsPadding().padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("Dark Grid", color = TraderColors.Text, fontSize = 24.sp,
                    fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)
                Text("Observer · Heikin Ashi M5 · 5m", color = TraderColors.Muted,
                    fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
            CubeStatusPill(active = capturing)
        }

        CubeActionRow(
            capturing = capturing,
            onStart = { requestCapture() }, onStop = { stopCapture() },
            onLogs = { tab = Tab.LOGS }, onPaper = { tab = Tab.PAPER },
            onInfo = { tab = Tab.INFO }
        )

        when (tab) {
            Tab.MAIN -> MainConsole(
                repo = repo, scope = scope, settings = settings,
                capturing = capturing, status = status,
                calibrationReady = calibrationReady, approved = approved,
                telemetry = telemetry, analysis = analysis,
                accessibility = accessibility, risk = risk,
                onOpenAccessibility = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            )
            Tab.LOGS -> LogsPane(logLines, onBack = { tab = Tab.MAIN },
                onCopy = { copy(SessionLog.text()) }, onClear = { SessionLog.clear() })
            Tab.PAPER -> PaperPane(paperStats, paperText, onBack = { tab = Tab.MAIN },
                onCopy = { copy(paperText) })
            Tab.INFO -> InfoPane(onBack = { tab = Tab.MAIN }, demoEvents = demoEvents)
        }
    }
}

@Composable
private fun MainConsole(
    repo: SettingsRepo, scope: kotlinx.coroutines.CoroutineScope,
    settings: AppSettings, capturing: Boolean, status: String,
    calibrationReady: Boolean, approved: Boolean,
    telemetry: com.traderai.app.capture.Telemetry, analysis: String,
    accessibility: Boolean, risk: com.traderai.app.trading.RiskStatus,
    onOpenAccessibility: () -> Unit
) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {

        DarkCubeCard(highlighted = capturing) {
            Text("| СТАТУС", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            CubeStatusLine("Захват экрана", if (capturing) "ВКЛ" else "ВЫКЛ", capturing)
            CubeStatusLine("Активная пара", telemetry.pair, true)
            CubeStatusLine("Выплата (OCR)", telemetry.payout?.let { "$it%" } ?: "—", telemetry.ocrOk)
            CubeStatusLine("Свечей", "${telemetry.candles}/300", telemetry.gridOk)
            CubeStatusLine("FPS", "%.1f".format(telemetry.fps), true)
            CubeStatusLine("Режим рынка", telemetry.regime, true)
            CubeStatusLine("CV confidence", "${(telemetry.cv * 100).toInt()}%", telemetry.cv >= 0.8f)
            CubeStatusLine("Калибровка OHLC", if (calibrationReady) "готова" else "нет", calibrationReady)
            CubeStatusLine("Спец. возможности", if (accessibility) "подключены" else "отключены", accessibility)
            CubeStatusLine("Баланс PO", risk.balance?.let { "%.2f".format(it) } ?: "—", risk.balance != null)
            CubeStatusLine("Риск / стоп", "${risk.riskPercent}% / " + (risk.stopBalance?.let { "%.2f".format(it) } ?: "—"), !risk.locked)
            CubeStatusLine("Убыток", "%.2f%%".format(risk.drawdownPercent), risk.drawdownPercent < risk.riskPercent)
            if (risk.locked) {
                Spacer(Modifier.height(4.dp))
                Text(risk.reason, color = TraderColors.Red, fontSize = 11.sp)
                CubeSmallAction("Разрешить торговлю дальше") { com.traderai.app.trading.TradeRiskGuard.approveResume() }
            }
            Spacer(Modifier.height(4.dp))
            CubeSmallAction("Включить спец. возможности", onOpenAccessibility)
            Spacer(Modifier.height(4.dp))
            Text(status, color = if (capturing) TraderColors.IceSteel else TraderColors.Amber,
                fontSize = 13.sp, fontFamily = FontFamily.Monospace)
        }

        DarkCubeCard {
            Text("| УПРАВЛЕНИЕ", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Row(Modifier.fillMaxWidth().clip(CubeSegmentShape)
                .background(Color.White.copy(alpha = 0.03f))
                .border(1.dp, TraderColors.RimSubtle, CubeSegmentShape).padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TradingMode.entries.forEach { mode ->
                    val sel = settings.mode == mode
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                        .then(
                            if (sel) Modifier.background(
                                Brush.verticalGradient(listOf(
                                    TraderColors.IceSteel.copy(alpha = 0.20f),
                                    TraderColors.IceSteelDeep.copy(alpha = 0.70f)
                                ))
                            ) else Modifier.background(Color.Transparent)
                        )
                        .border(1.dp, if (sel) TraderColors.IceSteel.copy(alpha = 0.42f) else Color.Transparent,
                            RoundedCornerShape(9.dp))
                        .clickable { scope.launch { repo.setMode(mode) } }.padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center) {
                        Text(mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            color = if (sel) TraderColors.IceSteel else TraderColors.Muted,
                            fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            CubeDivider()
            CubeToggleRow("Автонажатие CALL/PUT", settings.autoTap) { scope.launch { repo.setAutoTap(it) } }
            Text("Журнал Paper ведётся всегда и не влияет на нажатия. Направление выбирает стратегия.",
                color = TraderColors.Muted, fontSize = 11.sp)
            if (settings.autoTap && !accessibility) {
                Text("Автонажатие не сработает: подключите спец. возможности.",
                    color = TraderColors.Red, fontSize = 11.sp)
            }
            if (settings.autoTap && !approved) {
                Text("Автонажатие не сработает: подтвердите калибровку OHLC.",
                    color = TraderColors.Red, fontSize = 11.sp)
            }
            CubeDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Мин. выплата", color = TraderColors.Text, fontSize = 13.sp)
                Text("${settings.minPayout}%", color = TraderColors.IceSteel, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Slider(
                value = settings.minPayout.toFloat(),
                onValueChange = { scope.launch { repo.setPayout(it.toInt()) } },
                valueRange = 50f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = TraderColors.IceSteel,
                    activeTrackColor = TraderColors.IceSteel.copy(alpha = 0.65f),
                    inactiveTrackColor = Color.White.copy(alpha = 0.08f)
                )
            )
        }

        DarkCubeCard {
            Text("| КНОПКИ CALL / PUT", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Координаты кнопок определяются автоматически по тексту КУПИТЬ / ПРОДАТЬ на экране Pocket Option. Ручных ползунков нет.",
                color = TraderColors.Muted, fontSize = 11.sp)
            val callAuto = com.traderai.app.vision.ScreenOcr.callButtonCenter
            val putAuto = com.traderai.app.vision.ScreenOcr.putButtonCenter
            Text("CALL: " + if (callAuto != null) "${(callAuto.first * 100).toInt()}% / ${(callAuto.second * 100).toInt()}%" else "поиск…",
                color = if (callAuto != null) TraderColors.IceSteel else TraderColors.Amber,
                fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text("PUT: " + if (putAuto != null) "${(putAuto.first * 100).toInt()}% / ${(putAuto.second * 100).toInt()}%" else "поиск…",
                color = if (putAuto != null) TraderColors.IceSteel else TraderColors.Amber,
                fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            Text("Таймер M5: x=69–85%, y=16–54%.",
                color = TraderColors.Amber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            CubeDivider()
            var manualPairText by remember(settings.manualPair) { mutableStateOf(settings.manualPair) }
            OutlinedTextField(
                value = manualPairText,
                onValueChange = { v ->
                    manualPairText = v
                    scope.launch { repo.setManualPair(v) }
                },
                label = { Text("Пара вручную, напр. EUR/USD") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Text("Если OCR не видит пару, укажите её здесь — калибровка, Paper и сигналы смогут запуститься. Пустое поле = только OCR.",
                color = TraderColors.Muted, fontSize = 11.sp)
        }

        DarkCubeCard {
            Text("| ЗОНА РИСКА", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Какую долю депозита вы готовы потерять? При достижении порога торговля-stop.",
                color = TraderColors.Muted, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                listOf(10, 20, 30, 40, 50).forEach { pct ->
                    val sel = settings.riskPercent == pct
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                        .background(if (sel) TraderColors.IceSteel.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.04f))
                        .border(1.dp, if (sel) TraderColors.IceSteel.copy(alpha = 0.45f) else TraderColors.RimSubtle, RoundedCornerShape(9.dp))
                        .clickable { scope.launch { repo.setRiskPercent(pct) } }
                        .padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Text("$pct%", color = if (sel) TraderColors.IceSteel else TraderColors.Muted,
                            fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        DarkCubeCard(highlighted = approved) {
            Text("| КАЛИБРОВКА OHLC", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(if (calibrationReady)
                "Шкала и свечи готовы. Сверьте 10+ свеч с экраном перед подтверждением."
            else "Сигналы заблокированы до получения данных калибровки.",
                color = if (calibrationReady) TraderColors.Text else TraderColors.Muted,
                fontSize = 12.sp, lineHeight = 17.sp)
            Text("Свечей в кадре: ${telemetry.candles} · порог готовности 20",
                color = TraderColors.IceSteel, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            val can = calibrationReady || approved
            val bg = when {
                approved -> Brush.verticalGradient(listOf(TraderColors.IceSteelSoft,
                    TraderColors.IceSteelDeep.copy(alpha = 0.75f)))
                can -> Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.08f),
                    Color.White.copy(alpha = 0.03f)))
                else -> Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.03f), Color.Transparent))
            }
            val bd = when {
                approved -> TraderColors.IceSteel.copy(alpha = 0.48f)
                can -> TraderColors.Amber.copy(alpha = 0.45f)
                else -> TraderColors.RimSubtle
            }
            val tc = when { approved -> TraderColors.IceSteel; can -> TraderColors.Amber; else -> TraderColors.Muted }
            Box(Modifier.fillMaxWidth().clip(CubeButtonShape).background(bg)
                .border(1.dp, bd, CubeButtonShape).clickable(enabled = can) { TradingGate.set(!approved) }
                .padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                Text(if (approved) "Калибровка подтверждена" else "Подтвердить калибровку",
                    color = tc, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }

        DarkCubeCard {
            Text("| ТЕЛЕМЕТРИЯ КАДРА", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text(analysis, color = TraderColors.Text.copy(alpha = 0.90f), fontSize = 12.sp,
                lineHeight = 17.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun PaneHeader(title: String, onBack: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = TraderColors.IceSteel, fontSize = 12.sp,
            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        CubeSmallAction("← ТЕРМИНАЛ", onBack)
    }
}

@Composable
private fun LogsPane(lines: List<SessionLog.Line>, onBack: () -> Unit,
                     onCopy: () -> Unit, onClear: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val filtered = lines.filter { query.isBlank() || it.message.contains(query, true) || it.tag.contains(query, true) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        PaneHeader("| ЛОГ СЕССИИ", onBack)
        OutlinedTextField(query, { query = it }, label = { Text("Поиск") },
            modifier = Modifier.fillMaxWidth(), singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CubeSmallAction("Копировать", onCopy)
            CubeSmallAction("Очистить", onClear)
        }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(filtered) { l ->
                DarkCubeCard {
                    Text("[${l.time}] ${l.tag}: ${l.message}", color = TraderColors.Text,
                        fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
private fun PaperPane(stats: PaperTrading.Stats, text: String, onBack: () -> Unit, onCopy: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PaneHeader("| PAPER TRADING", onBack)
        Text("Сделки появятся после подтверждения калибровки OHLC.",
            color = TraderColors.Amber, fontSize = 11.sp)
        DarkCubeCard {
            CubeStatusLine("Всего сделок", stats.total.toString(), true)
            CubeStatusLine("WIN", stats.wins.toString(), true)
            CubeStatusLine("LOSS", stats.losses.toString(), stats.losses == 0)
            CubeStatusLine("DRAW", stats.draws.toString(), true)
            CubeStatusLine("Открытых", stats.open.toString(), stats.open == 0)
            CubeStatusLine("WinRate", "%.2f%%".format(stats.winRate), stats.winRate >= 55.0)
        }
        CubeSmallAction("Копировать / экспорт TXT", onCopy)
        DarkCubeCard {
            Text(text.ifBlank { "Сделок пока нет" }, color = TraderColors.Text,
                fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
private fun InfoPane(onBack: () -> Unit, demoEvents: List<DemoAttempt>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PaneHeader("| ИНФО", onBack)
        DarkCubeCard {
            Text("DARK GRID / OBSERVER", color = TraderColors.IceSteel, fontSize = 14.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("Heikin Ashi M5, экспирация 5 минут. Сигналы рассчитываются только по закрытой свече.",
                color = TraderColors.Text, fontSize = 12.sp)
            Text("До подтверждения калибровки OHLC заблокированы сигналы и автонажатия. Журнал Paper работает всегда.",
                color = TraderColors.Amber, fontSize = 12.sp)
            Text("DEMO-автонажатие требует: Accessibility, подтверждённую калибровку, Pocket Option в foreground и видимую метку DEMO/Practice. Жест не считается подтверждённой сделкой.",
                color = TraderColors.Red, fontSize = 12.sp)
            Text("Логи SCAN и PAPER пишутся автоматически — проверьте вкладку LOGS.",
                color = TraderColors.Muted, fontSize = 11.sp)
        }
        DarkCubeCard {
            Text("| DEMO EXECUTION JOURNAL", color = TraderColors.IceSteel, fontSize = 12.sp,
                fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            if (demoEvents.isEmpty()) {
                Text("Попыток DEMO пока нет", color = TraderColors.Muted, fontSize = 11.sp)
            } else {
                demoEvents.forEach { attempt ->
                    Text("${attempt.signal.pair} ${attempt.signal.side} · ${attempt.state}",
                        color = when (attempt.state.name) {
                            "WIN" -> TraderColors.IceSteel
                            "LOSS", "REJECTED" -> TraderColors.Red
                            "UNKNOWN" -> TraderColors.Amber
                            else -> TraderColors.Text
                        }, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text(attempt.detail, color = TraderColors.Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun CubeActionRow(capturing: Boolean, onStart: () -> Unit, onStop: () -> Unit,
                          onLogs: () -> Unit, onPaper: () -> Unit, onInfo: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("START" to onStart, "STOP" to onStop, "LOGS" to onLogs,
            "PAPER" to onPaper, "INFO" to onInfo).forEach { (label, action) ->
            val danger = label == "STOP" && capturing
            Box(Modifier.weight(1f).clip(CubePillShape)
                .background(if (danger) TraderColors.RedSoft else Color.White.copy(alpha = 0.04f))
                .border(1.dp, if (danger) TraderColors.Red.copy(alpha = 0.5f) else TraderColors.RimSubtle,
                    CubePillShape)
                .clickable(onClick = action).padding(vertical = 9.dp), contentAlignment = Alignment.Center) {
                Text(label, color = if (danger) TraderColors.Red else TraderColors.IceSteel,
                    fontSize = 10.sp, fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
private fun CubeStatusLine(label: String, value: String, ok: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = TraderColors.Muted, fontSize = 12.sp)
        Text(value, color = if (ok) TraderColors.IceSteel else TraderColors.Amber,
            fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CubeSmallAction(text: String, onClick: () -> Unit) {
    Box(Modifier.clip(CubePillShape).background(Color.White.copy(alpha = 0.04f))
        .border(1.dp, TraderColors.RimSubtle, CubePillShape)
        .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp)) {
        Text(text, color = TraderColors.IceSteel, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun DarkCubeCard(highlighted: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val surface = Brush.verticalGradient(listOf(
        Color.White.copy(alpha = if (highlighted) 0.08f else 0.055f),
        TraderColors.GlassBase.copy(alpha = 0.92f),
        TraderColors.GlassDeep.copy(alpha = 0.96f)
    ))
    val border = Brush.verticalGradient(listOf(
        if (highlighted) TraderColors.RimActive else TraderColors.RimTopLight,
        TraderColors.RimSubtle,
        TraderColors.RimRedAccent.copy(alpha = 0.16f)
    ))
    Column(Modifier.fillMaxWidth().clip(CubeCardShape).background(surface)
        .border(1.dp, border, CubeCardShape).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable private fun CubeDivider() = HorizontalDivider(color = Color.White.copy(alpha = 0.07f))

@Composable
private fun CubeToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TraderColors.Text, fontSize = 13.sp)
        Switch(checked, onChange, colors = SwitchDefaults.colors(
            checkedThumbColor = TraderColors.Void, checkedTrackColor = TraderColors.IceSteel,
            uncheckedThumbColor = TraderColors.Muted,
            uncheckedTrackColor = Color.White.copy(alpha = 0.06f),
            uncheckedBorderColor = TraderColors.RimSubtle))
    }
}

@Composable
private fun CubeStatusPill(active: Boolean) {
    val fg = if (active) TraderColors.IceSteel else TraderColors.Muted
    val bg = if (active) TraderColors.IceSteelSoft else Color.White.copy(alpha = 0.04f)
    val bd = if (active) TraderColors.IceSteel.copy(alpha = 0.45f) else TraderColors.RimSubtle
    Row(Modifier.clip(CircleShape).background(bg).border(1.dp, bd, CircleShape)
        .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(fg))
        Text(if (active) "Active" else "Idle", color = fg, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}

