package com.traderai.app.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.util.Locale

data class OcrItem(val text: String, val bounds: Rect)

data class PriceLabel(
    val price: Double,
    val centerY: Float,
    val centerX: Float
)

data class OcrResult(
    val pair: String?,
    val payout: Int?,
    val secondsRemaining: Int?,
    val timeframeMins: Int?,
    val expiryMins: Int?,
    val priceLabels: List<PriceLabel>,
    val warnings: List<String>,
    val timerOcrData: TimerOcrData? = null,
    val balance: Double? = null,
    val brokerOutcome: BrokerOutcome? = null,
    val brokerOutcomeText: String? = null
)

class ScreenOcr {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    companion object {
        @Volatile var callButtonCenter: Pair<Float, Float>? = null
            private set
        @Volatile var putButtonCenter: Pair<Float, Float>? = null
            private set

        /** Пара, заданная пользователем вручную. Имеет приоритет над OCR. */
        @Volatile var manualPair: String? = null
            private set

        /** Сырые строки OCR верхней зоны для диагностики на устройстве. */
        @Volatile var lastDebugLines: String = ""
            private set

        fun setManualPair(value: String?) {
            manualPair = normalizePair(value) ?: fromJoined(value)
        }

        fun resetAutoCalibration() {
            callButtonCenter = null
            putButtonCenter = null
        }

        private val knownCodes = setOf(
            "EUR", "USD", "GBP", "JPY", "CHF", "AUD", "NZD", "CAD", "CNY",
            "SGD", "SEK", "NOK", "TRY", "ZAR", "PLN", "MXN", "BRL", "INR",
            "BTC", "ETH", "LTC", "XRP", "XAU", "XAG", "DOT", "SOL", "ADA",
            "US30", "NAS100", "SPX500", "GER40", "UK100", "JPY200", "US500"
        )

        /**
         * Приводит распознанный/введённый текст к виду AAA/BBB [OTC].
         * ML Kit иногда читает дробную черту как \, |, ·, ∕, ／ или теряет пробелы,
         * поэтому нормализуем все эти варианты к одному виду.
         */
        fun normalizePair(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            var s = raw.uppercase(Locale.US)
                .replace('\u2215', '/').replace('\u2044', '/').replace('\uFF0F', '/')
                .replace('\\', '/').replace('|', '/').replace('·', '/').replace('•', '/')
            s = Regex("""\s+""").replace(s, " ").trim()
            s = Regex("""\s*/\s*""").replace(s, "/")
            val m = Regex("""([A-Z0-9]{2,6})/([A-Z0-9]{2,6})(?:\s*OTC)?""").find(s)
                ?: return null
            val a = m.groupValues[1]
            val b = m.groupValues[2]
            if (a.length !in 2..6 || b.length !in 2..6) return null
            if (!a.any { it.isLetter() } || !b.any { it.isLetter() }) return null
            val otc = if (m.value.contains("OTC")) " OTC" else ""
            return "$a/$b$otc"
        }

        fun fromJoined(raw: String?): String? {
            if (raw.isNullOrBlank()) return null
            val s = raw.uppercase(Locale.US).replace(Regex("""[^A-Z]"""), "")
            if (s.length == 6) {
                val a = s.substring(0, 3); val b = s.substring(3)
                if (knownCodes.contains(a) || knownCodes.contains(b)) return "$a/$b"
            }
            if (s.length == 9 && s.endsWith("OTC")) {
                val core = s.removeSuffix("OTC")
                if (core.length == 6) {
                    val a = core.substring(0, 3); val b = core.substring(3)
                    if (knownCodes.contains(a) || knownCodes.contains(b)) return "$a/$b OTC"
                }
            }
            return null
        }
    }

    // Кэш последней удачно прочитанной пары: PO иногда на пару секунд
    // закрывает заголовок графиком/результатом сделки. Держим 10 минут.
    @Volatile private var lastPair: String? = null
    @Volatile private var lastPairAt = 0L
    @Volatile private var lastMismatchAt = 0L
    @Volatile private var lastOutcomeText = ""
    @Volatile private var lastOutcomeAt = 0L

    suspend fun read(bitmap: Bitmap, now: Long = System.currentTimeMillis()): OcrResult {
        if (bitmap.isRecycled || bitmap.width < 2 || bitmap.height < 2) {
            return OcrResult(null, null, null, null, null, emptyList(), listOf("Некорректный кадр"))
        }
        val text = try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
        } catch (t: Throwable) {
            return OcrResult(null, null, null, null, null, emptyList(), listOf("Ошибка OCR: ${t.message}"))
        }

        val items = mutableListOf<OcrItem>()
        for (block in text.textBlocks) for (line in block.lines) {
            val box = line.boundingBox ?: continue
            items += OcrItem(line.text.trim(), Rect(box))
        }
        val w = bitmap.width.toFloat(); val h = bitmap.height.toFloat()
        val warnings = mutableListOf<String>()

        // Диагностика: видим ли мы вообще строку с парой и где она расположена.
        lastDebugLines = items.asSequence()
            .map { it to center(it, w, h) }
            .filter { it.second.second < 0.42f }
            .sortedWith(compareBy<Pair<OcrItem, Pair<Float, Float>>> { it.second.second }
                .thenBy { it.second.first })
            .take(28)
            .joinToString(" | ") {
                "${it.first.text.take(28)}@${(it.second.first * 100).toInt()},${(it.second.second * 100).toInt()}"
            }

        // Авто-калибровка центров кнопок по распознанному тексту.
        fun buttonCenter(re: Regex): Pair<Float, Float>? =
            items.firstOrNull { item ->
                val (_, y) = center(item, w, h)
                y in 0.58f..0.75f && re.containsMatchIn(item.text)
            }?.let { item ->
                item.bounds.exactCenterX() / w to item.bounds.exactCenterY() / h
            }

        buttonCenter(Regex("""купить|call|вверх|выше""", RegexOption.IGNORE_CASE))?.let { callButtonCenter = it }
        buttonCenter(Regex("""продать|put|вниз|ниже""", RegexOption.IGNORE_CASE))?.let { putButtonCenter = it }
        val balance = findBalance(items, w, h)

        val ocrPair = findPair(items, w, h)
        val manual = manualPair
        val pair = when {
            manual != null -> manual
            ocrPair != null -> { lastPair = ocrPair; lastPairAt = now; ocrPair }
            lastPair != null && now - lastPairAt < 600_000L -> lastPair
            else -> null
        }
        if (manual != null && ocrPair != null && manual != ocrPair && now - lastMismatchAt >= 60_000L) {
            lastMismatchAt = now
            warnings += "Пара OCR=$ocrPair, ручная=$manual — использована ручная"
        }
        val payout = findPayout(items, w, h)

        // Единственный источник таймера — OCR текущего кадра в размеченной зоне.
        // Системные часы телефона никогда не подменяют таймер Pocket Option.
        val timerData = findTimer(items, w, h)
        val timer = timerData?.secondsRemaining
        warnings += if (timer == null) "Таймер M5 не распознан в зоне x=0.69..0.85, y=0.16..0.54"
                    else "Таймер прочитан OCR: ${timerData?.sourceText ?: "?"} (${timer} с)"

        // Таймфрейм и экспирация зафиксированы стратегией (M5 / 5 мин).
        val timeframeOcr = findTimeframe(items, w, h)
        val timeframe = timeframeOcr ?: 5
        if (timeframeOcr == null) warnings += "M5 не показан на экране — принят фиксированный фрейм"
        val expiryOcr = findExpiry(items, w, h)
        val expiry = expiryOcr ?: 5
        if (expiryOcr == null) warnings += "Экспирация не прочитана — принято 5 мин"

        val prices = findPriceLabels(items, w, h)

        if (pair == null) warnings += "Пара не распознана (укажите её вручную на главном экране)"
        if (payout == null) warnings += "Выплата не распознана"
        if (prices.size < 2) warnings += "Нужно минимум 2 ценовые отметки (${prices.size})"

        // Маркер сделки на графике: '+$1,910' (успех), '$0' (убыток/возврат),
        // '▼ $1,000 00:29' (открытая позиция с обратным отсчётом).
        val rawOutcome = findBrokerOutcome(items, w, h)
        val outcomeKey = rawOutcome?.second ?: ""
        if (outcomeKey.isBlank()) {
            lastOutcomeText = ""; lastOutcomeAt = 0L
        } else if (outcomeKey != lastOutcomeText) {
            lastOutcomeText = outcomeKey; lastOutcomeAt = now
        }
        val freshOutcome = if (outcomeKey.isNotBlank() && now - lastOutcomeAt <= 2_000L) rawOutcome else null

        return OcrResult(pair, payout, timer, timeframe, expiry, prices, warnings, timerData, balance,
            freshOutcome?.first, freshOutcome?.second)
    }

    private fun center(i: OcrItem, w: Float, h: Float) = i.bounds.exactCenterX() / w to i.bounds.exactCenterY() / h

    /**
     * Ищем код пары в расширенной верхней зоне. Раньше зона была
     * x=0.04..0.60, y=0.11..0.20 и жёсткий регекс AAA/BBB — на части
     * устройств/версий PO заголовок расположен выше и/или OCR теряет slash.
     */
    private fun findPair(items: List<OcrItem>, w: Float, h: Float): String? {
        val zone = items.asSequence()
            .map { it to center(it, w, h) }
            .filter { (_, c) -> c.first in 0.02f..0.70f && c.second in 0.03f..0.30f }
            .sortedWith(compareBy<Pair<OcrItem, Pair<Float, Float>>> { it.second.second }
                .thenBy { it.second.first })
        // 1) Строка с дробной чертой (любой вид разделителя).
        val withSlash = zone.mapNotNull { (item, _) -> normalizePair(item.text) }.firstOrNull()
        if (withSlash != null) return withSlash
        // 2) EURUSD / EURUSDOTC без разделителя — только если код известен.
        return zone.mapNotNull { (item, _) -> fromJoined(item.text) }.firstOrNull()
    }

    /**
     * Маркеры результата сделки PO находятся над графиком, правее центра:
     * '+$1,910' — успех, '$0' — возврат/убыток, '▼ $1,000 00:29' — открытая позиция.
     * Зона намеренно узкая, чтобы не принять за маркер цену правой оси или баланс.
     */
    private fun findBrokerOutcome(items: List<OcrItem>, w: Float, h: Float): Pair<BrokerOutcome, String>? {
        val plus = Regex("""\+\s*[\$€₽]?\s*\d[\d\s.,]*""")
        val zero = Regex("""(?<![\d.,])\$?\s*0(?:[.,]0+)?(?!\d)""")
        val down = Regex("""[▼↓]\s*[\$€₽]?\s*\d[\d\s.,]*""")
        val countdown = Regex("""\d{1,2}\s*:\s*[0-5]\d""")
        val candidates = items.asSequence()
            .map { it to center(it, w, h) }
            .filter { (_, c) -> c.first in 0.45f..0.82f && c.second in 0.19f..0.32f }
            .map { (item, _) -> item.text.replace("\u00A0", " ").trim() }
        // Успешная сделка: зелёная плашка с плюсом.
        candidates.firstOrNull { plus.containsMatchIn(it) }
            ?.let { return BrokerOutcome.WIN to it }
        // Открытая позиция: стрелка вниз + сумма + обратный отсчёт.
        candidates.firstOrNull { down.containsMatchIn(it) && countdown.containsMatchIn(it) }
            ?.let { return BrokerOutcome.PLACED to it }
        // Убыточная сделка: PO показывает '$0' как возврат по проигранной ставке.
        candidates.firstOrNull { zero.containsMatchIn(it) && !plus.containsMatchIn(it) && !countdown.containsMatchIn(it) }
            ?.let { return BrokerOutcome.LOSS to it }
        // Проигрыш без обратного отсчёта, но со стрелкой вниз.
        candidates.firstOrNull { down.containsMatchIn(it) }
            ?.let { return BrokerOutcome.LOSS to it }
        return null
    }

    private fun findPayout(items: List<OcrItem>, w: Float, h: Float): Int? {
        return items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.62f..0.72f }
            .mapNotNull { Regex("""(\d{2,3})\s*%""").find(it.text)?.groupValues?.getOrNull(1)?.toIntOrNull() }
            .firstOrNull { it in 50..100 }
    }

    private fun findTimer(items: List<OcrItem>, w: Float, h: Float): TimerOcrData? {
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.69f..0.85f && y in 0.16f..0.54f }
            .mapNotNull { TimerTextParser.parse(it.text) }
            .firstOrNull()
    }

    private fun findTimeframe(items: List<OcrItem>, w: Float, h: Float): Int? {
        val upper = items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.10f..0.58f }
            .joinToString(" ") { it.text.uppercase(Locale.US) }
        return if (Regex("""\bM\s*5\b""").containsMatchIn(upper)) 5 else null
    }

    private fun findExpiry(items: List<OcrItem>, w: Float, h: Float): Int? {
        val lower = items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.45f..0.90f }
            .joinToString(" ") { it.text.uppercase(Locale.US) }
        val five = Regex("""(00\s*:\s*05\s*:\s*00|00\s*:\s*05|5\s*MIN|5\s*M\b)""")
        return if (five.containsMatchIn(lower)) 5 else null
    }

    private fun findPriceLabels(items: List<OcrItem>, w: Float, h: Float): List<PriceLabel> {
        // Раньше требовалось 3+ знака после точки — на индексах/крипте PO
        // показывает цены с двумя знаками и шкала не калибровалась совсем.
        val priceRegex = Regex("""(?<!\d)(\d+\.\d{2,8})(?!\d)""")
        return items.mapNotNull { item ->
            val (x, y) = center(item, w, h)
            if (x !in 0.70f..1.0f || y !in 0.18f..0.56f) return@mapNotNull null
            val v = priceRegex.find(item.text)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: return@mapNotNull null
            if (!v.isFinite() || v <= 0.0) return@mapNotNull null
            PriceLabel(v, item.bounds.exactCenterY(), item.bounds.exactCenterX())
        }.distinctBy { (it.price * 100000.0).toLong() }.sortedBy { it.centerY }
    }

    /** Баланс счёта в верхней панели Pocket Option. */
    private fun findBalance(items: List<OcrItem>, w: Float, h: Float): Double? {
        val amountRegex = Regex("""\d{1,3}(?:[\s,\u00A0]\d{3})+(?:[.,]\d{1,2})?|\d+\.\d{2}""")
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.45f..0.92f && y in 0.02f..0.13f }
            .mapNotNull { amountRegex.find(it.text.replace("\u00A0", " "))?.value }
            .mapNotNull { raw ->
                raw.replace("\u00A0", "").replace(" ", "").replace(",", "").toDoubleOrNull()
            }
            .filter { it > 0.0 }
            .maxOrNull()
    }

    fun close() { recognizer.close() }
}
