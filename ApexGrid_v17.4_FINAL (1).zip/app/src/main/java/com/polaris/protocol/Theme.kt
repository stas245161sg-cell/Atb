package com.polaris.protocol

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DarkColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object ApexGlassColors {
    val VoidBlack = Color(0xFF04060A)
    val DeepObsidian = Color(0xFF090D16)
    val GlassSurface = Color(0xCC101726)
    val GlassElevated = Color(0xD9162033)
    val GlassPill = Color(0xB3131C2E)

    val RimSubtle = Color(0x28FFFFFF)
    val RimAccent = Color(0x995CE1E6)

    val IceCyan = Color(0xFF5CE1E6)
    val SapphireGlow = Color(0xFF4EA8DE)
    val SignalCrimson = Color(0xFFFF4D6D)
    val AmberHold = Color(0xFFF5B700)

    val TextPrimary = Color(0xFFF5F8FF)
    val TextSecondary = Color(0xFFB3C2D9)
    val TextMuted = Color(0xFF7A8BA6)
}

private val ApexDarkColorScheme = DarkColorScheme(
    primary = ApexGlassColors.IceCyan,
    onPrimary = ApexGlassColors.VoidBlack,
    secondary = ApexGlassColors.SapphireGlow,
    onSecondary = ApexGlassColors.TextPrimary,
    background = ApexGlassColors.VoidBlack,
    onBackground = ApexGlassColors.TextPrimary,
    surface = ApexGlassColors.GlassSurface,
    onSurface = ApexGlassColors.TextPrimary,
    surfaceVariant = ApexGlassColors.GlassElevated,
    onSurfaceVariant = ApexGlassColors.TextSecondary,
    error = ApexGlassColors.SignalCrimson,
    onError = ApexGlassColors.VoidBlack,
    outline = ApexGlassColors.RimSubtle
)

val ApexTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        letterSpacing = 0.6.sp,
        color = ApexGlassColors.TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 0.2.sp,
        color = ApexGlassColors.TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        color = ApexGlassColors.TextSecondary
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        letterSpacing = 0.4.sp,
        color = ApexGlassColors.TextSecondary
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 18.sp,
        color = ApexGlassColors.TextPrimary
    )
)

val ApexShapes = Shapes(
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun ApexGridTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ApexDarkColorScheme,
        typography = ApexTypography,
        shapes = ApexShapes,
        content = content
    )
}
