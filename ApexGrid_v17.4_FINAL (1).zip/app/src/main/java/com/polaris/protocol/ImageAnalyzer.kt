package com.polaris.protocol

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.Closeable
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Trend { GREEN, RED, UNKNOWN }
enum class Cross { UP, DOWN, NONE }

/**
 * Результат анализа одного кадра для стратегии Fibonacci 14.6%.
 *
 * highs / lows — Y-координаты экстремумов последних [Roi.CANDLES_TO_COLLECT] закрытых свечей
 * (Y растёт вниз: меньше Y = выше цена). Массивы в хронологическом порядке:
 * последний элемент — самая свежая свеча.
 * closeY / isGreen относятся к последней свече.
 */
data class Snapshot(
    val highs: FloatArray,
    val lows: FloatArray,
    /** Y-закрытия всех собранных свечей — нужны для EMA/RSI/ADX/ATR в v3. */
    val closes: FloatArray = FloatArray(0),
    val closeY: Float,
    val isGreen: Boolean,
    val body: Float,
    val payout: Int,
    val live: Boolean = true,
    val chartNote: String = "",
    /** Подтверждения с графика: SuperTrend по геометрии, Stochastic и AO по цвету. */
    val superTrend: Trend = Trend.UNKNOWN,
    val stochCross: Cross = Cross.NONE,
    val stochValue: Float = Float.NaN,
    val ao: Trend = Trend.UNKNOWN,
    /** Название актива с экрана (например "EUR/JPY OTC") и флаг синтетики. */
    val assetName: String = "",
    val isOtc: Boolean = true,
    /** Название пары с экрана (окно «Пара»), используется для автосброса при смене. */
    val pairName: String = "—",
    /** true = последняя свеча уже закрылась; решение принимается только при true. */
    val candleClosed: Boolean = false,
    /** Доли тени от полной высоты свечи (для фильтра отскока). */
    val upperWickRatio: Float = 0f,
    val lowerWickRatio: Float = 0f
)

// ======================= Зоны интереса (ROI) =======================

/** Зоны, которые пользователь выставляет на экране калибровки. */
enum class RoiZone(val key: String, val title: String) {
    CHART("chart", "График"),
    STOCH("stoch", "Stochastic"),
    AO("ao", "AO"),
    PAYOUT("payout", "Выплата"),
    PAIR("pair", "Пара")
}

/** Прямоугольник в долях экрана: 0.0 = левый/верхний край, 1.0 = правый/нижний. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Хранение зон в SharedPreferences: roi_chart_left, roi_chart_top, roi_chart_right, roi_chart_bottom,
 * roi_payout_*. Значения по умолчанию — раскладка Pocket Option 1080x2400.
 */
object RoiPrefs {
    private const val FILE = "polaris_protocol"
    private const val MIN_SIZE = 0.01f

    fun default(zone: RoiZone): NormRect = when (zone) {
        RoiZone.CHART -> NormRect(0.00f, 0.170f, 0.86f, 0.530f)
        RoiZone.STOCH -> NormRect(0.00f, 0.693f, 0.96f, 0.782f)
        RoiZone.AO -> NormRect(0.00f, 0.785f, 0.96f, 0.878f)
        RoiZone.PAYOUT -> NormRect(0.20f, 0.646f, 0.37f, 0.672f)
        RoiZone.PAIR -> NormRect(0.10f, 0.178f, 0.48f, 0.222f)
    }

    fun load(ctx: Context, zone: RoiZone): NormRect {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = default(zone)
        val p = "roi_${zone.key}_"
        val r = NormRect(
            sp.getFloat(p + "left", d.left),
            sp.getFloat(p + "top", d.top),
            sp.getFloat(p + "right", d.right),
            sp.getFloat(p + "bottom", d.bottom)
        )
        return if (isValid(r)) r else d
    }

    fun save(ctx: Context, zone: RoiZone, r: NormRect) {
        val fixed = if (isValid(r)) r else default(zone)
        val p = "roi_${zone.key}_"
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(p + "left", fixed.left)
            .putFloat(p + "top", fixed.top)
            .putFloat(p + "right", fixed.right)
            .putFloat(p + "bottom", fixed.bottom)
            .apply()
    }

    fun resetAll(ctx: Context) {
        RoiZone.entries.forEach { save(ctx, it, default(it)) }
    }

    private fun isValid(r: NormRect): Boolean =
        r.left >= 0f && r.top >= 0f && r.right <= 1f && r.bottom <= 1f &&
            r.right - r.left >= MIN_SIZE && r.bottom - r.top >= MIN_SIZE
}

/** Константы анализаFibonacci 14.6%. */
object Roi {
    const val POCKET_PACKAGE = "com.pocketoption.broker"
    const val LAST_FRAME_FILE = "last_frame.jpg"   // последний кадр с графиком — фон экрана калибровки

    /** Сколько закрытых свечей собираем: 20 × M5 ≈ 100 минут истории. */
    const val CANDLES_TO_COLLECT = 30
    const val MIN_VALID_CANDLES = 6

    // Гистерезис прокрутки: сравнение идёт с правой границей зоны ROI (а не экрана),
    // причём вход и выход пороги разные — иначе состояние дёргается на границе.
    const val LIVE_EDGE_SCROLLED = 0.97f   // край данных дошёл до 97% зоны → прокручен
    const val LIVE_EDGE_LIVE = 0.90f       // край ушёл левее 90% зоны → снова на последней свече

    // Stochastic: «свежесть» пересечения — доля ширины кадра (~2–3 свечи).
    const val STOCH_RECENT = 0.04f
    // Запасные уровни 80/20, если линии на панели не найдены (доли высоты экрана).
    const val STOCH_Y80_ABS = 0.7163f
    const val STOCH_Y20_ABS = 0.7577f

    // Свеча: максимальная ширина — доля ширины кадра (для 1080 px ≈ 43 px).
    const val CANDLE_MAX_WIDTH = 0.04f
    const val MAX_ANALYSIS_WIDTH = 1080 // кадры шире уменьшаются до этой ширины перед анализом
}

/** Цвета в HSV OpenCV (H 0..179, S/V 0..255), замеры по скриншотам. */
object Hsv {
    // Общие маски свечей. Свеча вверх (70,183,52) H≈56; красная свеча (255,62,31) H≈4.
    val GREEN_LO = Scalar(30.0, 80.0, 80.0)
    // 72, а не 90: зелёная свеча H≈56, бирюзовая линия SuperTrend H≈84–90.
    // Старый порог 90 захватывал линию тренда как «зелёную свечу» и портил High/Low.
    val GREEN_HI = Scalar(72.0, 255.0, 255.0)
    val RED1_LO = Scalar(0.0, 80.0, 80.0)
    val RED1_HI = Scalar(10.0, 255.0, 255.0)
    val RED2_LO = Scalar(170.0, 80.0, 80.0)
    val RED2_HI = Scalar(180.0, 255.0, 255.0)

    // SuperTrend: бирюзовый/пурпурный (H 78–105 / 140–165). Направление — по геометрии.
    val ST_CYAN_LO = Scalar(78.0, 100.0, 100.0)
    val ST_CYAN_HI = Scalar(105.0, 255.0, 255.0)
    val ST_MAGENTA_LO = Scalar(140.0, 100.0, 100.0)
    val ST_MAGENTA_HI = Scalar(165.0, 255.0, 255.0)
    // Синяя линия текущей цены (убираем её строки при поиске SuperTrend).
    val PRICE_LINE_LO = Scalar(106.0, 80.0, 80.0)
    val PRICE_LINE_HI = Scalar(125.0, 255.0, 255.0)
    // Белый текст меток «Купить/Продать» — по нему находим и вырезаем сами метки.
    val WHITE_LO = Scalar(0.0, 0.0, 190.0)
    val WHITE_HI = Scalar(180.0, 60.0, 255.0)

    // Stochastic: %K синяя, %D оранжевая; уровни 80 бирюзовый, 20 жёлтый.
    val STOCH_K_LO = Scalar(100.0, 110.0, 110.0)
    val STOCH_K_HI = Scalar(128.0, 255.0, 255.0)
    val STOCH_D_LO = Scalar(5.0, 110.0, 110.0)
    val STOCH_D_HI = Scalar(18.0, 255.0, 255.0)
    val LEVEL80_LO = Scalar(80.0, 100.0, 60.0)
    val LEVEL80_HI = Scalar(92.0, 255.0, 255.0)
    val LEVEL20_LO = Scalar(20.0, 100.0, 60.0)
    val LEVEL20_HI = Scalar(28.0, 255.0, 255.0)
}

/** Собирает все временные Mat и освобождает их разом (важно на 30 FPS). */
private class Mats : Closeable {
    private val list = ArrayList<Mat>()
    fun <T : Mat> keep(m: T): T {
        list.add(m)
        return m
    }
    fun mat(): Mat = keep(Mat())
    override fun close() {
        list.forEach { it.release() }
        list.clear()
    }
}

/** Пиксельные границы зоны внутри кадра. */
private class Box(val r0: Int, val r1: Int, val c0: Int, val c1: Int)

/** Измеренная свеча: экстремумы, тело, цвет и Y закрытия. */
private class CandleInfo(
    val topY: Int,
    val bottomY: Int,
    val bodyTopY: Int,
    val bodyBottomY: Int,
    val green: Boolean,
    val body: Float,
    val closeY: Float,
    val rightX: Int,
    val upperWickRatio: Float,
    val lowerWickRatio: Float
)

private class ChartResult(
    val live: Boolean,
    val candles: List<CandleInfo>,
    val note: String = "",
    val endX: Int = -1,
    val pitch: Float = 0f
)

class ImageAnalyzer(context: Context) : Closeable {

    private companion object {
        const val TAG = "ImageAnalyzer"
        const val MIN_ST_PIXELS = 3
        const val OCR_INTERVAL_MS = 600L
        const val PAYOUT_TTL_MS = 10_000L
        const val PAIR_OCR_INTERVAL_MS = 450L
        const val PAIR_OCR_ERR_LOG_MS = 10_000L
        /** Интервалы адаптивного опроса выплаты. */
        const val PAYOUT_STABLE_INTERVAL_MS = 2_500L
        const val PAYOUT_EDGE_INTERVAL_MS = 400L
        const val PAYOUT_STABLE_HOLD_MS = 2_000L
        /** Окно, в котором последняя свеча считается закрытой после сдвига X-сетки. */
        const val CANDLE_CLOSE_WINDOW_MS = 8_000L
        const val LIVE_DEBOUNCE_MS = 1_000L
        const val OCR_UPSCALE = 3
        const val OCR_LOG_HEARTBEAT_MS = 30_000L
        const val OCR_ERR_LOG_MS = 10_000L
        const val ROI_RELOAD_MS = 1_500L

        // Только число ПЕРЕД знаком %: деньги ($9,600) и таймеры в строке больше не misinterpreted.
        val PAYOUT_REGEX = Regex("(\\d{2,3})\\s*%")
        const val PAYOUT_MIN = 50
        const val PAYOUT_MAX = 99
    }

    private val appContext: Context = context.applicationContext

    private val cvReady: Boolean = try {
        OpenCVLoader.initDebug()
    } catch (t: Throwable) {
        Log.e(TAG, "OpenCV init failed", t)
        false
    }
    val ready: Boolean get() = cvReady

    /** Причина последней ошибки анализа кадра (для журнала). */
    @Volatile var lastError: String? = null
        private set

    // Зоны читаются из SharedPreferences при создании анализатора (каждый запуск захвата)
    // и затем перечитываются раз в 2 секунды — калибровка действует без перезапуска.
    private var rois: Map<RoiZone, NormRect> = loadRois()
    private var roisLoadedAt = SystemClock.elapsedRealtime()
    private var lastResizeScale = 1f

    // Гистерезис прокрутки: состояние меняется не чаще раза в секунду
    @Volatile private var liveState = true
    private var liveChangedAt = 0L

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val ocrBusy = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastOcrLogKey = ""
    private var lastOcrLogAt = 0L
    private var lastOcrErrAt = 0L
    @Volatile private var payout = -1
    @Volatile private var payoutAt = 0L
    /** Время, с которого выплата стабильна, и последнее распознанное значение. */
    private var payoutStableAt = 0L
    private var lastExtractedPayout = -1

    // Окно «Пара»: отдельный OCR, смена пары вызывает автосброс движка и X-сетки.
    private val pairOcrBusy = AtomicBoolean(false)
    private var lastPairOcrAt = 0L
    private var lastPairErrAt = 0L
    @Volatile private var lastDetectedPair: String = ""
    @Volatile private var pendingPairResetFrom: String? = null
    @Volatile private var pendingPairResetTo: String? = null
    private var onPairChangedCallback: ((String, String) -> Unit)? = null

    /** Название пары больше не распознаётся: поле оставлено только для совместимости UI. */
    @Volatile private var assetName = ""

    /** Признак наличия хотя бы одной ЗАКРЫТОЙ свечи на экране. */
    @Volatile private var candleClosed = false

    /** X-сетка: предыдущий правый край и время, до которого свеча считается закрытой. */
    private var prevRightEdgeX = -1
    private var candleClosedUntilMs = 0L

    init {
        LogRepository.addLog("ROI: ${describeRois(rois)}")
    }

    fun setOnPairChangedListener(listener: (oldPair: String, newPair: String) -> Unit) {
        onPairChangedCallback = listener
    }

    /** Вызывается при переключении графика/пары: старый payout и X-сетка не переносятся. */
    fun resetChartTracking(clearDetectedPair: Boolean = false) {
        prevRightEdgeX = -1
        candleClosedUntilMs = 0L
        payout = -1
        payoutAt = 0L
        payoutStableAt = 0L
        lastExtractedPayout = -1
        lastOcrAt = 0L
        candleClosed = false
        if (clearDetectedPair) {
            lastDetectedPair = ""
            pendingPairResetFrom = null
            pendingPairResetTo = null
        }
        LogRepository.addLog("CHART: сброс X-сетки и кэша выплаты")
    }

    fun reloadRoisNow() {
        rois = loadRois()
        roisLoadedAt = SystemClock.elapsedRealtime()
        LogRepository.addLog("ApexGrid ROI обновлены: ${describeRois(rois)}")
    }

    private fun loadRois(): Map<RoiZone, NormRect> =
        RoiZone.values().associateWith { RoiPrefs.load(appContext, it) }

    private fun refreshRois(now: Long) {
        if (now - roisLoadedAt < ROI_RELOAD_MS) return
        roisLoadedAt = now
        val fresh = loadRois()
        if (fresh != rois) {
            rois = fresh
            LogRepository.addLog("ROI обновлены: ${describeRois(fresh)}")
        }
    }

    private fun describeRois(map: Map<RoiZone, NormRect>): String =
        map.entries.joinToString(" ") { (zone, r) ->
            "${zone.key}=x${pct(r.left)}-${pct(r.right)} y${pct(r.top)}-${pct(r.bottom)}"
        }

    private fun pct(v: Float): Int = (v * 100).roundToInt()

    fun analyze(bmp: Bitmap): Snapshot? {
        if (!cvReady) return null
        var scaled: Bitmap? = null
        return try {
            val nowMs = SystemClock.elapsedRealtime()
            refreshRois(nowMs)

            // Сброс по смене пары выполняется здесь, на рабочем потоке анализатора,
            // а не в OCR-колбэке, чтобы не гонять состояние движка из ML Kit-потока.
            val switchedTo = pendingPairResetTo
            if (switchedTo != null) {
                val switchedFrom = pendingPairResetFrom
                pendingPairResetFrom = null
                pendingPairResetTo = null
                resetChartTracking(clearDetectedPair = false)
                onPairChangedCallback?.invoke(switchedFrom.orEmpty(), switchedTo)
            }

            requestPairOcr(bmp, nowMs)
            requestPayoutOcr(bmp)                 // OCR — по исходному кадру (качество выше)

            // Все вычисления OpenCV — на копии шириной не больше 1080 px.
            scaled = downscaleIfNeeded(bmp)
            val work = scaled ?: bmp

            Mats().use { m ->
                val rgba = m.mat()
                Utils.bitmapToMat(work, rgba)
                val rgb = m.mat()
                Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
                val hsv = m.mat()
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
                val frameW = hsv.cols()
                val frameH = hsv.rows()

                val chart = chart(hsv, frameW, frameH, m)
                val otcNow = isOtcNow()
                if (!chart.live) {
                    return@use Snapshot(
                        highs = FloatArray(0), lows = FloatArray(0), closes = FloatArray(0),
                        closeY = Float.NaN, isGreen = false, body = Float.NaN,
                        payout = currentPayout(), live = false,
                        assetName = assetName, isOtc = otcNow,
                        pairName = lastDetectedPair.ifEmpty { "—" }
                    )
                }

                // Защита от открытого меню/оверлея вместо удалённого OCR названия пары:
                // на настоящем графике X-сетка даёт длинную цепочку с ненулевым шагом.
                if (chart.candles.size < Roi.MIN_VALID_CANDLES || chart.pitch <= 0f) {
                    lastError = "grid_invalid(candles=${chart.candles.size}, pitch=${chart.pitch})"
                    return@use Snapshot(
                        highs = FloatArray(0), lows = FloatArray(0), closes = FloatArray(0),
                        closeY = Float.NaN, isGreen = false, body = Float.NaN,
                        payout = currentPayout(), live = true,
                        chartNote = "grid_invalid", assetName = assetName, isOtc = otcNow,
                        pairName = lastDetectedPair.ifEmpty { "—" }
                    )
                }

                // --- Закрытая свеча ---
                // Флаг выставляется только в окне после появления НОВОГО столбца справа (сдвиг X).
                // Сама светка для решения берётся предпоследняя — она гарантированно закрыта.
                val isClosed = updateClosedCandleState(chart.candles, chart.pitch, nowMs)
                candleClosed = isClosed
                val closed = if (chart.candles.size >= 2) chart.candles.dropLast(1) else emptyList()

                // SuperTrend — по геометрии линии (цена = последняя ЗАКРЫТАЯ свеча)
                val (stTrend, _) = if (chart.endX >= 0 && closed.isNotEmpty()) {
                    val cb = box(hsv, rois.getValue(RoiZone.CHART))
                    val croi = hsv.crop(cb, m)
                    val newest = closed.last()
                    superTrend(croi, chart.endX + 1, frameW, frameH, (newest.topY + newest.bottomY) / 2, m)
                } else Pair(Trend.UNKNOWN, "no_chart")

                // Stochastic 5,3,3 и AO 5,34 — по своим зонам
                val (cross, crossVal) = stochastic(hsv, frameW, m)
                val (aoTrend, _) = awesome(hsv, m)

                val highs = FloatArray(closed.size) { closed[it].topY.toFloat() }
                val lows = FloatArray(closed.size) { closed[it].bottomY.toFloat() }
                val closes = FloatArray(closed.size) { closed[it].closeY.toFloat() }
                val last = closed.lastOrNull()
                Snapshot(
                    highs = highs,
                    lows = lows,
                    closes = closes,
                    closeY = last?.closeY ?: Float.NaN,
                    isGreen = last?.green ?: false,
                    body = last?.body ?: Float.NaN,
                    payout = currentPayout(),
                    chartNote = chart.note,
                    superTrend = stTrend,
                    stochCross = cross,
                    stochValue = crossVal,
                    ao = aoTrend,
                    assetName = assetName,
                    isOtc = otcNow,
                    pairName = lastDetectedPair.ifEmpty { "—" },
                    candleClosed = candleClosed,
                    upperWickRatio = last?.upperWickRatio ?: 0f,
                    lowerWickRatio = last?.lowerWickRatio ?: 0f
                )
            }
        } catch (t: Throwable) {
            Log.e(TAG, "analyze failed", t)
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            null
        } finally {
            scaled?.recycle()
        }
    }

    /** Новый столбец справа = предыдущая свеча закрылась. Держим окно [CANDLE_CLOSE_WINDOW_MS]. */
    private fun updateClosedCandleState(
        candles: List<CandleInfo>,
        pitch: Float,
        nowMs: Long
    ): Boolean {
        val lastRightX = candles.lastOrNull()?.rightX ?: return false
        if (pitch > 0f && prevRightEdgeX >= 0) {
            val shift = lastRightX - prevRightEdgeX
            if (shift >= (pitch * 0.70f).roundToInt()) {
                candleClosedUntilMs = nowMs + CANDLE_CLOSE_WINDOW_MS
            }
        }
        prevRightEdgeX = lastRightX
        return nowMs <= candleClosedUntilMs
    }

    /** Кадр шире 1080 px уменьшается до ровно 1080 px по ширине (высота пропорционально); иначе null. */
    private fun downscaleIfNeeded(bmp: Bitmap): Bitmap? {
        if (bmp.width <= Roi.MAX_ANALYSIS_WIDTH) {
            lastResizeScale = 1f
            return null
        }
        val scale = Roi.MAX_ANALYSIS_WIDTH.toFloat() / bmp.width
        val height = (bmp.height * scale).roundToInt().coerceAtLeast(1)
        if (abs(scale - lastResizeScale) > 0.001f) {
            lastResizeScale = scale
            LogRepository.addLog("image_resized(scale=${String.format(Locale.US, "%.2f", scale)})")
        }
        return Bitmap.createScaledBitmap(bmp, Roi.MAX_ANALYSIS_WIDTH, height, true)
    }

    // ---------- вспомогательные ----------

    /** Пиксельные границы зоны; доли берутся из сохранённой калибровки. */
    private fun box(hsv: Mat, r: NormRect): Box {
        val r0 = (hsv.rows() * r.top).toInt().coerceIn(0, hsv.rows() - 1)
        val r1 = (hsv.rows() * r.bottom).toInt().coerceIn(r0 + 1, hsv.rows())
        val c0 = (hsv.cols() * r.left).toInt().coerceIn(0, hsv.cols() - 1)
        val c1 = (hsv.cols() * r.right).toInt().coerceIn(c0 + 1, hsv.cols())
        return Box(r0, r1, c0, c1)
    }

    /**
     * submat()/colRange()/rowRange() создают новый Mat-хендлер с общими данными.
     * Регистрируем его в пуле кадра: без этого на 30 FPS хендлер живёт до GC.
     */
    private fun Mat.crop(b: Box, m: Mats): Mat = m.keep(submat(b.r0, b.r1, b.c0, b.c1))

    private fun greenMask(src: Mat, m: Mats): Mat {
        val out = m.mat()
        Core.inRange(src, Hsv.GREEN_LO, Hsv.GREEN_HI, out)
        return out
    }

    private fun redMask(src: Mat, m: Mats): Mat {
        val a = m.mat()
        val b = m.mat()
        Core.inRange(src, Hsv.RED1_LO, Hsv.RED1_HI, a)
        Core.inRange(src, Hsv.RED2_LO, Hsv.RED2_HI, b)
        Core.bitwise_or(a, b, a)
        return a
    }

    /** Индекс самой правой колонки, где есть хотя бы [minPixels] пикселей маски; -1 если пусто. */
    private fun lastColoredColumn(mask: Mat, m: Mats, minPixels: Int = 2): Int {
        val sums = m.mat()
        Core.reduce(mask, sums, 0, Core.REDUCE_SUM, CvType.CV_32S)
        val arr = IntArray(mask.cols())
        sums.get(0, 0, arr)
        var x = arr.size - 1
        while (x >= 0 && arr[x] < 255 * minPixels) x--
        return x
    }

    /** Мелкий мусор (остатки краёв): компоненты уже ~3 px и ниже ~6 px в масштабе кадра 540 px. */
    private fun removeSpecks(g: Mat, r: Mat, all: Mat, frameW: Int, m: Mats) {
        val s = frameW / 540f
        val minW = maxOf(2, (3f * s).roundToInt())
        val minH = maxOf(3, (6f * s).roundToInt())

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val junk = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            if (st[i * 5 + 2] < minW && st[i * 5 + 3] < minH) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(junk, one, junk)
                found = true
            }
        }
        if (!found) return
        val inverse = m.mat()
        Core.bitwise_not(junk, inverse)
        Core.bitwise_and(g, inverse, g)
        Core.bitwise_and(r, inverse, r)
        Core.bitwise_or(g, r, all)
    }

    // ---------- График: сбор 20 закрытых свечей ----------

    private fun chart(hsv: Mat, frameW: Int, frameH: Int, m: Mats): ChartResult {
        val b = box(hsv, rois.getValue(RoiZone.CHART))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        removeSpecks(g, r, all, frameW, m)

        // Правый край данных сравнивается с правой границей зоны ROI (а не экрана),
        // с гистерезисом 0.90/0.97 и задержкой 1 с — иначе состояние дёргается каждый кадр.
        val end = lastColoredColumn(all, m)
        if (end < 0) return ChartResult(true, emptyList(), "no_colored_pixels_in_chart_roi")
        val roiW = (b.c1 - b.c0).coerceAtLeast(1)
        val edge = end.toFloat() / roiW
        val now = SystemClock.elapsedRealtime()
        if (now - liveChangedAt >= LIVE_DEBOUNCE_MS) {
            when {
                !liveState && edge <= Roi.LIVE_EDGE_LIVE -> {
                    liveState = true
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: на последней свече (edge=${pct(edge)}%)")
                }
                liveState && edge >= Roi.LIVE_EDGE_SCROLLED -> {
                    liveState = false
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: прокручен (edge=${pct(edge)}%)")
                }
            }
        }
        if (!liveState) return ChartResult(false, emptyList(), endX = end)

        val (candles, pitch) = collectCandles(all, g, r, frameW, m)
        val note = when {
            candles.isEmpty() -> "no_candles_found"
            candles.size < Roi.CANDLES_TO_COLLECT -> "candles=${candles.size}/${Roi.CANDLES_TO_COLLECT}"
            else -> ""
        }
        return ChartResult(true, candles, note, end, pitch)
    }

    /**
     * X-grid: берём только компоненты, выстроенные с равным шагом по оси X.
     * Широкие горизонтальные плашки («Купить»/«Продать», элементы меню) отсекаются.
     */
    private fun collectCandles(
        all: Mat,
        g: Mat,
        r: Mat,
        frameW: Int,
        m: Mats
    ): Pair<List<CandleInfo>, Float> {
        val lab = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, lab, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return Pair(emptyList(), 0f)
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val maxAllowedWidth = (frameW * Roi.CANDLE_MAX_WIDTH).toInt()
        val minH = maxOf(8, (8f * frameW / 540f).roundToInt())
        val candidates = ArrayList<Triple<Int, Float, Int>>() // idx, centerX, h
        for (i in 1 until n) {
            val x = st[i * 5]
            val y = st[i * 5 + 1]
            val w = st[i * 5 + 2]
            val h = st[i * 5 + 3]
            val area = st[i * 5 + 4]
            if (y < 5 || y + h > all.rows() - 5) continue
            if (w !in 3..maxAllowedWidth || h < minH) continue
            if (w > h * 1.15f) continue                       // горизонтальная плашка — не свеча
            if (area.toFloat() < 0.30f * w * h) continue
            candidates.add(Triple(i, x + w * 0.5f, h))
        }
        if (candidates.isEmpty()) return Pair(emptyList(), 0f)

        candidates.sortBy { it.second }
        var pitch = 0f
        if (candidates.size >= 4) {
            val deltas = ArrayList<Float>()
            for (k in 1 until candidates.size) {
                val dx = candidates[k].second - candidates[k - 1].second
                if (dx >= 2.5f) deltas.add(dx)
            }
            if (deltas.isNotEmpty()) {
                deltas.sort()
                pitch = deltas[(deltas.size * 0.35f).toInt()].coerceAtLeast(3f)
            }
        }

        val pickedIds: List<Int> = if (pitch > 0f && candidates.size >= 4) {
            val chain = ArrayList<Triple<Int, Float, Int>>()
            var anchor = candidates.last()
            chain.add(anchor)
            val tol = maxOf(2.5f, pitch * 0.32f)
            for (k in candidates.size - 2 downTo 0) {
                val cur = candidates[k]
                val gap = anchor.second - cur.second
                if (gap < pitch * 0.55f) {
                    if (cur.third > anchor.third) {
                        chain[chain.lastIndex] = cur
                        anchor = cur
                    }
                    continue
                }
                val steps = (gap / pitch).roundToInt()
                if (steps in 1..3 && abs(gap - steps * pitch) <= tol) {
                    chain.add(cur)
                    anchor = cur
                    if (chain.size >= Roi.CANDLES_TO_COLLECT) break
                }
            }
            chain.reverse()
            chain.map { it.first }
        } else {
            candidates.takeLast(Roi.CANDLES_TO_COLLECT).map { it.first }
        }

        // Матрица меток читается ОДИН раз за кадр, а не 30 раз в цикле.
        val cols = lab.cols()
        val labArr = IntArray(lab.rows() * cols)
        lab.get(0, 0, labArr)

        val out = ArrayList<CandleInfo>(pickedIds.size)
        for (idx in pickedIds) {
            val c = measureCandle(labArr, cols, g, r, idx, st, m) ?: continue
            out.add(c)
        }
        return Pair(out, pitch)
    }

    /** Измеряет одну связную компоненту: High/Low, тело, тени, цвет и Y цены закрытия. */
    private fun measureCandle(
        labels: IntArray,
        cols: Int,
        g: Mat,
        r: Mat,
        idx: Int,
        st: IntArray,
        m: Mats
    ): CandleInfo? {
        val x = st[idx * 5]
        val y = st[idx * 5 + 1]
        val w = st[idx * 5 + 2]
        val h = st[idx * 5 + 3]
        if (w < 1 || h < 2) return null

        val rowCounts = IntArray(h)
        for (yy in y until y + h) {
            var count = 0
            val base = yy * cols
            for (xx in x until x + w) if (labels[base + xx] == idx) count++
            rowCounts[yy - y] = count
        }
        val maxRow = rowCounts.maxOrNull() ?: 0
        if (maxRow < 4) return null

        val threshold = maxOf(3, (0.5f * maxRow).roundToInt())
        var bodyTop = -1
        var bodyBot = -1
        for (i in rowCounts.indices) {
            if (rowCounts[i] >= threshold) {
                if (bodyTop < 0) bodyTop = i
                bodyBot = i
            }
        }
        if (bodyTop < 0) return null

        // Цвет свечи считаем по телу: у зелёной тело зелёное, у красной — красное.
        val gBody = m.keep(g.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val rBody = m.keep(r.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val green = Core.countNonZero(gBody) > Core.countNonZero(rBody)

        val body = ((bodyBot - bodyTop + 1).toFloat() / h).coerceIn(0f, 1f)
        val upperWick = (bodyTop.toFloat() / h).coerceIn(0f, 1f)
        val lowerWick = ((h - 1 - bodyBot).coerceAtLeast(0).toFloat() / h).coerceIn(0f, 1f)
        // Закрытие: у зелёной свечи — верх тела (меньший Y), у красной — низ тела (больший Y).
        val closeY = (if (green) y + bodyTop else y + bodyBot).toFloat()
        return CandleInfo(
            y, y + h - 1, y + bodyTop, y + bodyBot, green, body, closeY, x + w,
            upperWick, lowerWick
        )
    }

    // ---------- SuperTrend: направление по геометрии линии ----------

    /** Строки (от, до, центр) синей линии текущей цены; null, если её нет. */
    private fun priceLineBand(roi: Mat, m: Mats): IntArray? {
        val blue = m.mat()
        Core.inRange(roi, Hsv.PRICE_LINE_LO, Hsv.PRICE_LINE_HI, blue)
        val sums = m.mat()
        Core.reduce(blue, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = blue.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var best = 0
        for (y in 1 until rows) if (arr[y] > arr[best]) best = y
        if (arr[best] < 255 * 0.25f * blue.cols()) return null
        return intArrayOf((best - 3).coerceAtLeast(0), (best + 4).coerceAtMost(rows), best)
    }

    /**
     * Линия SuperTrend ищется по бирюзовому/пурпурному; направление определяется положением
     * линии относительно цены: линия ниже цены → GREEN (UP), выше → RED (DOWN).
     */
    private fun superTrend(
        roi: Mat, x1: Int, frameW: Int, frameH: Int, candleCenterY: Int, m: Mats
    ): Pair<Trend, String> {
        val cyan = m.mat()
        val magenta = m.mat()
        Core.inRange(roi, Hsv.ST_CYAN_LO, Hsv.ST_CYAN_HI, cyan)
        Core.inRange(roi, Hsv.ST_MAGENTA_LO, Hsv.ST_MAGENTA_HI, magenta)
        val line = m.mat()
        Core.bitwise_or(cyan, magenta, line)

        // Метки «Купить/Продать» — крупные блоки с белым текстом. Вырезаем их,
        // иначе они попадают в поиск линии и портят геометрию SuperTrend.
        val white = m.mat()
        Core.inRange(roi, Hsv.WHITE_LO, Hsv.WHITE_HI, white)
        val labels = m.mat()
        val stats = m.mat()
        val cents = m.mat()
        val nLab = Imgproc.connectedComponentsWithStats(white, labels, stats, cents, 8, CvType.CV_32S)
        if (nLab > 1) {
            val st = IntArray(nLab * 5)
            stats.get(0, 0, st)
            val cutMask = m.keep(Mat.zeros(roi.size(), CvType.CV_8UC1))
            val one = m.mat()
            for (i in 1 until nLab) {
                val bw = st[i * 5 + 2]
                val bh = st[i * 5 + 3]
                if (bw > line.cols() * 0.05f && bh > line.rows() * 0.012f) {
                    Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                    Core.bitwise_or(cutMask, one, cutMask)
                }
            }
            val kernel = m.keep(Imgproc.getStructuringElement(
                Imgproc.MORPH_RECT, Size((3f * frameW / 540f).roundToInt().coerceAtLeast(3).toDouble(),
                    (3f * frameW / 540f).roundToInt().coerceAtLeast(3).toDouble())))
            val grown = m.mat()
            Imgproc.dilate(cutMask, grown, kernel)
            val inv = m.mat()
            Core.bitwise_not(grown, inv)
            Core.bitwise_and(line, inv, line)
        }

        val band = priceLineBand(roi, m)
        if (band != null) {
            val cut = m.keep(line.submat(band[0], band[1], 0, line.cols()))
            cut.setTo(Scalar(0.0))
        }

        val s = frameW / 540f
        val rad = (2f * s).roundToInt().coerceAtLeast(2)
        val c1 = x1.coerceAtMost(line.cols())
        val c0 = (c1 - 6 * rad).coerceAtLeast(0)
        if (c1 - c0 < 2) return Pair(Trend.UNKNOWN, "st_window_small")

        val region = m.keep(line.colRange(c0, c1))
        if (Core.countNonZero(region) < MIN_ST_PIXELS) return Pair(Trend.UNKNOWN, "st_no_px")

        val cols = region.cols()
        val rows = region.rows()
        val bytes = ByteArray(rows * cols)
        region.get(0, 0, bytes)
        val colCount = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) if (bytes[base + x].toInt() != 0) colCount[x]++
        }
        var xe = -1
        for (x in cols - 1 downTo 0) if (colCount[x] >= 2) { xe = x; break }
        if (xe < 0) for (x in cols - 1 downTo 0) if (colCount[x] >= 1) { xe = x; break }
        if (xe < 0) return Pair(Trend.UNKNOWN, "st_no_px")

        val lo = (xe - 2).coerceAtLeast(0)
        var ySum = 0L
        var yCnt = 0
        for (y in 0 until rows) {
            val base = y * cols
            for (x in lo..xe) if (bytes[base + x].toInt() != 0) { ySum += y; yCnt++ }
        }
        val lineY = ySum.toFloat() / yCnt
        val priceY = when {
            band != null -> band[2].toFloat()
            candleCenterY >= 0 -> candleCenterY.toFloat()
            else -> return Pair(Trend.UNKNOWN, "st_no_price")
        }
        val margin = maxOf(2f, 2f * s)
        val trend = when {
            lineY > priceY + margin -> Trend.GREEN
            lineY < priceY - margin -> Trend.RED
            else -> Trend.UNKNOWN
        }
        return Pair(trend, "")
    }

    // ---------- Stochastic (5,3,3) ----------

    /** Строки линий уровней 80 и 20 внутри зоны; если не найдены — запасные доли экрана. */
    private fun stochLevels(roi: Mat, roiTop: Int, frameH: Int, m: Mats): Pair<Float, Float> {
        val teal = m.mat()
        val yellow = m.mat()
        Core.inRange(roi, Hsv.LEVEL80_LO, Hsv.LEVEL80_HI, teal)
        Core.inRange(roi, Hsv.LEVEL20_LO, Hsv.LEVEL20_HI, yellow)
        val a = lineCenter(teal, m)
        val b = lineCenter(yellow, m)
        if (a != null && b != null && b - a >= frameH * 0.02f) return Pair(a, b)
        return Pair(Roi.STOCH_Y80_ABS * frameH - roiTop, Roi.STOCH_Y20_ABS * frameH - roiTop)
    }

    private fun lineCenter(mask: Mat, m: Mats): Float? {
        val sums = m.mat()
        Core.reduce(mask, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = mask.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var max = 0
        for (v in arr) if (v > max) max = v
        if (max < 255 * 0.25f * mask.cols()) return null
        var wSum = 0.0
        var ySum = 0.0
        for (y in 0 until rows) {
            if (arr[y] >= max / 2) { wSum += arr[y]; ySum += arr[y].toDouble() * y }
        }
        return (ySum / wSum).toFloat()
    }

    private fun toStochValue(y: Float, y80: Float, y20: Float): Float =
        (80f - (y - y80) * 60f / (y20 - y80)).coerceIn(0f, 100f)

    /** Свежее пересечение %K/%D в сторону тренда + значение пересечения. */
    private fun stochastic(hsv: Mat, frameW: Int, m: Mats): Pair<Cross, Float> {
        val b = box(hsv, rois.getValue(RoiZone.STOCH))
        val roi = hsv.crop(b, m)
        val k = m.mat()
        val d = m.mat()
        Core.inRange(roi, Hsv.STOCH_K_LO, Hsv.STOCH_K_HI, k)
        Core.inRange(roi, Hsv.STOCH_D_LO, Hsv.STOCH_D_HI, d)

        val rows = k.rows()
        val cols = k.cols()
        val kb = ByteArray(rows * cols)
        val db = ByteArray(rows * cols)
        k.get(0, 0, kb)
        d.get(0, 0, db)

        val (y80, y20) = stochLevels(roi, b.r0, hsv.rows(), m)
        val sumK = LongArray(cols); val cntK = IntArray(cols)
        val sumD = LongArray(cols); val cntD = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (kb[base + x].toInt() != 0) { sumK[x] += y.toLong(); cntK[x]++ }
                if (db[base + x].toInt() != 0) { sumD[x] += y.toLong(); cntD[x]++ }
            }
        }
        var lastX = -1
        for (x in cols - 1 downTo 0) if (cntK[x] > 0 && cntD[x] > 0) { lastX = x; break }
        if (lastX < 0) return Pair(Cross.NONE, Float.NaN)

        val deadzone = 0.5f * frameW / 540f
        var prevSign = 0
        var crossX = -1
        var crossDir = Cross.NONE
        var crossVal = Float.NaN
        for (x in 0..lastX) {
            if (cntK[x] == 0 || cntD[x] == 0) continue
            val yK = sumK[x].toFloat() / cntK[x]
            val yD = sumD[x].toFloat() / cntD[x]
            val diff = yD - yK
            val sign = when { diff > deadzone -> 1; diff < -deadzone -> -1; else -> 0 }
            if (sign == 0) continue
            if (prevSign != 0 && sign != prevSign) {
                crossX = x
                crossDir = if (sign > 0) Cross.UP else Cross.DOWN
                crossVal = toStochValue((yK + yD) / 2f, y80, y20)
            }
            prevSign = sign
        }
        val recent = (frameW * Roi.STOCH_RECENT).toInt().coerceAtLeast(4)
        if (crossX < 0 || lastX - crossX > recent) return Pair(Cross.NONE, Float.NaN)
        return Pair(crossDir, crossVal)
    }

    // ---------- Awesome Oscillator (5,34) ----------

    private fun awesome(hsv: Mat, m: Mats): Pair<Trend, Float> {
        val b = box(hsv, rois.getValue(RoiZone.AO))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)
        val x = lastColoredColumn(all, m)
        if (x < 0) return Pair(Trend.UNKNOWN, Float.NaN)
        val x0 = (x - 2).coerceAtLeast(0)
        val gc = Core.countNonZero(m.keep(g.colRange(x0, x + 1)))
        val rc = Core.countNonZero(m.keep(r.colRange(x0, x + 1)))
        val color = when { gc > rc -> Trend.GREEN; rc > gc -> Trend.RED; else -> Trend.UNKNOWN }
        return Pair(color, Float.NaN)
    }

    // ---------- Payout через ML Kit OCR + строгая регулярка ----------

    private fun requestPairOcr(bmp: Bitmap, now: Long) {
        if (now - lastPairOcrAt < PAIR_OCR_INTERVAL_MS) return
        if (!pairOcrBusy.compareAndSet(false, true)) return
        lastPairOcrAt = now
        val scaled = cropScaledBitmap(bmp, rois.getValue(RoiZone.PAIR), OCR_UPSCALE)
        if (scaled == null) {
            pairOcrBusy.set(false)
            return
        }
        try {
            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val pair = normalizePairName(text.text)
                    if (isValidPairName(pair)) {
                        val prev = lastDetectedPair
                        if (prev.isEmpty()) {
                            lastDetectedPair = pair
                            BotState.state.value = BotState.state.value.copy(activePair = pair)
                            LogRepository.addLog("PAIR_INIT: '$pair'")
                        } else if (prev != pair) {
                            lastDetectedPair = pair
                            pendingPairResetFrom = prev
                            pendingPairResetTo = pair
                            BotState.state.value = BotState.state.value.copy(
                                activePair = pair,
                                lastSignal = null
                            )
                            LogRepository.addLog("PAIR_SWITCHED: '$prev' -> '$pair' (автосброс)")
                        }
                    }
                }
                .addOnFailureListener { err ->
                    val t = SystemClock.elapsedRealtime()
                    if (t - lastPairErrAt >= PAIR_OCR_ERR_LOG_MS) {
                        lastPairErrAt = t
                        LogRepository.addLog("PAIR_OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    pairOcrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "pair ocr failed", t)
            scaled.recycle()
            pairOcrBusy.set(false)
        }
    }

    private fun normalizePairName(raw: String): String = raw
        .uppercase(Locale.US)
        .replace('\n', ' ')
        .replace(Regex("[^A-Z0-9/ ]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun isValidPairName(name: String): Boolean =
        name.length >= 5 && name.contains('/')

    private fun requestPayoutOcr(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        // Стабильная высокая выплата → реже; у порога или после смены графика → чаще.
        val stableHigh = payout >= 80 && payoutStableAt > 0L &&
            now - payoutStableAt >= PAYOUT_STABLE_HOLD_MS && payout == lastExtractedPayout
        val nearThreshold = payout < 0 || payout in 80..84
        val interval = when {
            stableHigh -> PAYOUT_STABLE_INTERVAL_MS
            nearThreshold -> PAYOUT_EDGE_INTERVAL_MS
            else -> OCR_INTERVAL_MS
        }
        if (now - lastOcrAt < interval) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now
        try {
            val zone = rois.getValue(RoiZone.PAYOUT)
            val x0 = (bmp.width * zone.left).toInt().coerceIn(0, bmp.width - 2)
            val x1 = (bmp.width * zone.right).toInt().coerceIn(x0 + 1, bmp.width)
            val y0 = (bmp.height * zone.top).toInt().coerceIn(0, bmp.height - 2)
            val y1 = (bmp.height * zone.bottom).toInt().coerceIn(y0 + 1, bmp.height)
            val crop = Bitmap.createBitmap(bmp, x0, y0, x1 - x0, y1 - y0)
            val scaled = Bitmap.createScaledBitmap(
                crop, crop.width * OCR_UPSCALE, crop.height * OCR_UPSCALE, true
            )
            if (scaled !== crop) crop.recycle()

            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val raw = text.text.replace('\n', ' ').trim().take(40)
                    val extracted = extractPayout(raw)
                    val nowMs = SystemClock.elapsedRealtime()
                    if (extracted != null) {
                        if (extracted != lastExtractedPayout) {
                            lastExtractedPayout = extracted
                            payoutStableAt = nowMs
                        }
                        payout = extracted
                        payoutAt = nowMs
                    }
                    val key = "$raw|$extracted"
                    if (key != lastOcrLogKey || nowMs - lastOcrLogAt >= OCR_LOG_HEARTBEAT_MS) {
                        lastOcrLogKey = key
                        lastOcrLogAt = nowMs
                        LogRepository.addLog("OCR RAW: '$raw' -> EXTRACTED: ${extracted ?: "null"}")
                    }
                }
                .addOnFailureListener { err ->
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastOcrErrAt >= OCR_ERR_LOG_MS) {
                        lastOcrErrAt = nowMs
                        LogRepository.addLog("OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    ocrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "ocr failed", t)
            ocrBusy.set(false)
        }
    }

    /** Имя пары больше не распознаётся; поле оставлено пустым только для совместимости UI. */
    private fun isOtcNow(): Boolean = true

    /**
     * Строгий разбор: берём только число перед '%' ('KYIVTb 92%', '+929%'),
     * возвращаем первое значение в диапазоне 50..99; деньги и таймеры без '%' игнорируются.
     */
    private fun extractPayout(raw: String): Int? {
        for (match in PAYOUT_REGEX.findAll(raw)) {
            val run = match.groupValues[1]
            if (run.length == 2) {
                val v = run.toIntOrNull() ?: continue
                if (v in PAYOUT_MIN..PAYOUT_MAX) return v
            } else {
                // OCR часто склеивает '92%' в '929%' — пробуем первые и последние 2 цифры
                val first = run.take(2).toIntOrNull()
                val last = run.takeLast(2).toIntOrNull()
                if (first != null && first in PAYOUT_MIN..PAYOUT_MAX) return first
                if (last != null && last in PAYOUT_MIN..PAYOUT_MAX) return last
            }
        }
        return null
    }

    private fun currentPayout(): Int =
        if (SystemClock.elapsedRealtime() - payoutAt > PAYOUT_TTL_MS) -1 else payout

    override fun close() {
        try { recognizer.close() } catch (ignored: Throwable) {}
    }
}
