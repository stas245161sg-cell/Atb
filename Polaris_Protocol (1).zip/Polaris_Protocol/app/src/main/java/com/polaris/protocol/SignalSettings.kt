package com.polaris.protocol

import android.content.Context

/**
 * Только переключатели стратегий.
 * Порог выплаты (80%), порог голосования и параметры индикаторов фиксированы в коде —
 * это параметры алгоритма, а не настройки оператора.
 * Банк и размер ставки задаёт оператор в Pocket Option.
 */
object SignalSettings {
    private const val FILE = "polaris_signals"

    @Volatile var scalpEnabled = true
    @Volatile var trendEnabled = true
    @Volatile var volEnabled = true

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        scalpEnabled = sp.getBoolean("scalp", true)
        trendEnabled = sp.getBoolean("trend", true)
        volEnabled = sp.getBoolean("vol", true)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().apply {
            putBoolean("scalp", scalpEnabled)
            putBoolean("trend", trendEnabled)
            putBoolean("vol", volEnabled)
        }.apply()
        load(ctx)
    }
}
