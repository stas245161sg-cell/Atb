package com.polaris.protocol

import android.os.SystemClock

/**
 * Предохранитель по частоте: лимит сделок и cooldown.
 * Синглтон — доступен и из ScreenCaptureService, и из UI (кнопка сброса).
 *
 * Банк, размер ставки, дневные SL/TP задаёт оператор в Pocket Option — приложение
 * деньги не считает и ставку не меняет (мартингейл исключён полностью).
 *
 * Все времена — только [SystemClock.elapsedRealtime].
 */
object SessionRiskGate {
    const val MAX_TRADES = 100
    private const val COOLDOWN_MS = 60_000L

    @Volatile var trades = 0
        private set
    private var lastTradeAt = 0L

    /** null = торговать можно, иначе kod блокировки. */
    fun allow(@Suppress("UNUSED_PARAMETER") now: Long): String? {
        val t = SystemClock.elapsedRealtime()
        return when {
            trades >= MAX_TRADES -> "max_trades"
            t - lastTradeAt < COOLDOWN_MS -> "cooldown"
            else -> null
        }
    }

    fun onSignal() {
        trades++
        lastTradeAt = SystemClock.elapsedRealtime()
    }

    /** Ручной сброс счётчика оператором (кнопка в UI). */
    fun reset() {
        trades = 0
        lastTradeAt = 0L
        LogRepository.addLog("RISK: счётчик сделок сброшен оператором")
    }

    fun snapshot(): String = "trades=$trades/$MAX_TRADES"
}
