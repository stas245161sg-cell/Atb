package com.traderai.app.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcelable
import androidx.core.app.NotificationCompat
import com.traderai.app.data.SessionLog
import com.traderai.app.trading.TraderPipeline
import com.traderai.app.trading.TradingGate
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.traderai.app.START_CAPTURE"
        const val ACTION_STOP = "com.traderai.app.STOP_CAPTURE"
        const val EXTRA_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL = "traderai_capture_v31"
        private const val NOTIFICATION_ID = 31
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var callback: MediaProjection.Callback? = null

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val pipeline by lazy { TraderPipeline(applicationContext) }
    private val mutex = Mutex()
    private val processing = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var lastFrameAt = 0L
    @Volatile private var fpsFrames = 0
    @Volatile private var fpsAt = 0L
    @Volatile private var currentFps = 0f
    @Volatile private var lastDiagLogAt = 0L
    @Volatile private var lastAnalyzeLogAt = 0L
    @Volatile private var lastCalibState = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopCapture(); stopSelf(startId); return START_NOT_STICKY }
            ACTION_START -> {
                if (projection != null) return START_NOT_STICKY
                val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
                val data = intent.parcelable<Intent>(EXTRA_DATA)
                if (code != Activity.RESULT_OK || data == null) {
                    CaptureState.status("Ошибка: нет токена MediaProjection")
                    stopSelf(startId)
                    return START_NOT_STICKY
                }
                startForegroundCompat()
                try {
                    val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val mp = mgr.getMediaProjection(code, data)
                        ?: throw IllegalStateException("getMediaProjection вернул null")
                    projection = mp
                    val cb = object : MediaProjection.Callback() {
                        override fun onStop() {
                            CaptureState.capturing(false)
                            CaptureState.status("Захват остановлен системой")
                            SessionLog.add("CAPTURE", "Захват остановлен системой")
                            stopCapture(); stopSelf()
                        }
                    }
                    callback = cb
                    mp.registerCallback(cb, mainHandler)
                    startDisplay(mp)
                    CaptureState.capturing(true)
                    CaptureState.status("Захват активен · Observer")
                    SessionLog.add("CAPTURE", "Захват запущен")
                } catch (t: Throwable) {
                    CaptureState.capturing(false)
                    CaptureState.status("Ошибка MediaProjection: ${t.message}")
                    SessionLog.add("ERROR", "MediaProjection: ${t.message}")
                    stopCapture(); stopSelf(startId)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundCompat() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startDisplay(mp: MediaProjection) {
        val m = resources.displayMetrics
        val w = m.widthPixels.coerceAtLeast(1)
        val h = m.heightPixels.coerceAtLeast(1)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            fpsFrames++
            if (fpsAt == 0L) fpsAt = now
            if (now - fpsAt >= 1000L) {
                currentFps = fpsFrames * 1000f / (now - fpsAt).toFloat()
                fpsFrames = 0; fpsAt = now
            }
            if (now - lastFrameAt < 1200L) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            if (!processing.compareAndSet(false, true)) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            lastFrameAt = now
            val image = source.acquireLatestImage()
            if (image == null) { processing.set(false); return@setOnImageAvailableListener }
            val bitmap = try { imageToBitmap(image) } catch (t: Throwable) {
                CaptureState.analysis("Ошибка кадра: ${t.message}"); null
            } finally { image.close() }
            if (bitmap == null) { processing.set(false); return@setOnImageAvailableListener }
            scope.launch {
                try {
                    mutex.withLock {
                        pipeline.refreshSettings()
                        val res = pipeline.process(bitmap)
                        val pt = pipeline.paperTrading()
                        CaptureState.calibrationReady(res.calibrationReady)
                        CaptureState.telemetry(
                            com.traderai.app.capture.Telemetry(
                                pair = res.pair ?: "—",
                                payout = res.payout,
                                candles = res.candleCount,
                                fps = currentFps,
                                regime = res.analysis?.regime?.name ?: "—",
                                cv = res.confidence,
                                calibrationReady = res.calibrationReady,
                                ocrOk = res.pair != null && res.payout != null,
                                gridOk = res.candleCount >= 30
                            )
                        )
                        CaptureState.paper(pt.stats(), pt.exportTxt())

                        // Диагностика: раз в ~6 с пишем, что реально видит OCR/CV.
                        // Без этих строк логи пустуют, пока калибровка не подтверждена.
                        val diagNow = System.currentTimeMillis()
                        if (diagNow - lastDiagLogAt >= 6_000L) {
                            lastDiagLogAt = diagNow
                            SessionLog.add(
                                "SCAN",
                                "${res.pair ?: "?"} ${res.payout?.let { "$it%" } ?: "?"} " +
                                    "свеч=${res.candleCount} калиб=${if (res.calibrationReady) "OK" else "НЕТ"} " +
                                    "шлюз=${if (TradingGate.approved.value) "ОТКР" else "ЗАКР"} :: ${res.message}" +
                                    if (res.warnings.isNotEmpty()) " | ${res.warnings.take(3).joinToString("; ")}" else ""
                            )
                        }
                        if (res.calibrationReady && !lastCalibState) {
                            SessionLog.add("CALIB", "OHLC готовы — сверьте 10+ свеч и подтвердите калибровку")
                        }
                        lastCalibState = res.calibrationReady

                        // Раз в 30 с показываем, что стратегия реально считается —
                        // иначе «Нет сетапа CALL=.. PUT=..» видно только в телеметрии.
                        if (diagNow - lastAnalyzeLogAt >= 30_000L) {
                            lastAnalyzeLogAt = diagNow
                            SessionLog.add(
                                "ANALYZE",
                                "${res.analysis?.side?.name ?: "—"} score=${res.analysis?.score ?: 0} " +
                                    "свеч=${res.candleCount} :: ${res.message}"
                            )
                        }

                        if (res.analysis?.side != com.traderai.app.vision.Side.NONE &&
                            res.analysis?.side != null) {
                            SessionLog.add("SIGNAL", "${res.analysis!!.side} ${res.analysis.reason}")
                        }
                        CaptureState.analysis(buildString {
                            appendLine(res.message)
                            appendLine("Пара: ${res.pair ?: "?"}, выплата: ${res.payout?.let { "$it%" } ?: "?"}")
                            appendLine("Confidence: ${(res.confidence * 100).toInt()}%")
                            appendLine("Закрытых свечей: ${res.candleCount}")
                            appendLine("Калибровка: ${if (res.calibrationReady) "готова" else "нет"}")
                            appendLine("Анализ: ${res.analysis?.reason ?: "—"}")
                            res.warnings.takeLast(8).forEach { appendLine("• $it") }
                        })
                    }
                } catch (t: Throwable) {
                    CaptureState.analysis("Ошибка анализа: ${t.message}")
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                    processing.set(false)
                }
            }
        }, mainHandler)
        virtualDisplay = mp.createVirtualDisplay(
            "DarkGrid-V31", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, mainHandler
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val w = image.width; val h = image.height
        val ps = plane.pixelStride; val rs = plane.rowStride
        if (ps <= 0 || rs <= 0 || w <= 0 || h <= 0) return null
        val paddedWidth = rs / ps
        val padded = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888)
        val buf = plane.buffer; buf.rewind(); padded.copyPixelsFromBuffer(buf)
        return if (paddedWidth == w) padded else try {
            Bitmap.createBitmap(padded, 0, 0, w, h)
        } finally { padded.recycle() }
    }

    private fun stopCapture() {
        // stopCapture вызывается из ACTION_STOP, из callback onStop и из onDestroy —
        // логируем только первый вызов, иначе в журнале три одинаковые строки.
        val wasActive = projection != null
        reader?.setOnImageAvailableListener(null, null)
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        callback?.let { runCatching { projection?.unregisterCallback(it) } }
        callback = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        CaptureState.capturing(false)
        CaptureState.calibrationReady(false)
        CaptureState.status("Захват остановлен")
        if (wasActive) SessionLog.add("CAPTURE", "Захват остановлен")
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Dark Grid", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Dark Grid")
            .setContentText("Observer · реальные сделки отключены")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        stopCapture(); pipeline.close(); scope.cancel(); super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private inline fun <reified T : Parcelable> Intent.parcelable(key: String): T? =
        if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, T::class.java) else getParcelableExtra(key)
}
