package com.traderai.app.trading

import com.traderai.app.vision.*
import kotlin.math.abs

object StrategyEngine {
    private const val M5 = 300_000L
    // 30 закрытых свечей достаточно для Bollinger20 / RSI14 / SuperTrend10 / Stochastic.
    // На экране PO одновременно видно ~38 свеч, требование 50 делало анализ недостижимым.
    private const val REQUIRED_HISTORY = 30
    private const val MIN_CV = 0.80f

    private enum class BreakoutState { NONE, WAIT_CALL, WAIT_PUT }
    private var breakoutState = BreakoutState.NONE
    private var breakoutLevel = 0.0
    private var breakoutAt = 0L

    @Synchronized fun reset() {
        breakoutState = BreakoutState.NONE
        breakoutLevel = 0.0
        breakoutAt = 0L
    }

    @Synchronized
    fun analyze(
        input: List<Candle>,
        mode: TradingMode,
        confidence: Float,
        context: ScreenContext,
        allowCall: Boolean,
        allowPut: Boolean,
        calibrationApproved: Boolean,
        minimumPayout: Int = 80,
        now: Long = System.currentTimeMillis()
    ): Analysis {
        val candles = input.filter { it.closed }.takeLast(100)
        val nextOpen = candles.lastOrNull()?.time?.plus(M5)

        fun reject(reason: String, regime: Regime = Regime.UNKNOWN, score: Int = 0) = Analysis(
            Side.NONE, score, regime, reason, confidence.coerceIn(0f, 1f), candles.size, null, null
        )

        if (!calibrationApproved) return reject("Калибровка OHLC не подтверждена")
        if (!context.valid) return reject("Контекст не подтверждён: ${context.reason}")
        if (context.timeframeMins != 5 || context.expiryMins != 5) return reject("Нужны M5 и экспирация 5 мин")
        val payout = context.payout ?: return reject("Нет выплаты")
        if (payout < minimumPayout) return reject("Выплата $payout < $minimumPayout")
        if (context.pair.isNullOrBlank()) return reject("Нет пары")
        if (!confidence.isFinite() || confidence < MIN_CV) return reject("CV confidence < 0.80")
        if (candles.size < REQUIRED_HISTORY) return reject("Нужно $REQUIRED_HISTORY закрытых свечей")
        if (candles.any { !it.isValid() || !it.verified || it.confidence < MIN_CV }) return reject("Есть непроверенные свечи")
        if (candles.any { it.time % M5 != 0L }) return reject("Метки не выровнены по M5")
        if (candles.zipWithNext().any { (a, b) -> b.time - a.time != M5 }) { reset(); return reject("Пропуск в истории") }

        val last = candles.last()
        val entryTime = nextOpen ?: return reject("Нет времени входа")
        if (now - entryTime > 30_000L) return reject("Сигнал опоздал")

        val closes = candles.map { it.close }
        val ema5 = Indicators.ema(closes, 5)
        val ema13 = Indicators.ema(closes, 13)
        val rsi = Indicators.rsiSeries(closes, 14)
        val bb = Indicators.bollingerSeries(closes, 20, 2.0)
        val st = Indicators.superTrendSeries(candles, 10, 3.0)
        val sto = Indicators.stochasticSeries(candles, 5, 3, 3)
        val atr = Indicators.atrSeries(candles, 10)
        val i = candles.lastIndex
        val p = i - 1
        if (listOf(ema5[i], ema5[p], ema13[i], ema13[p], rsi[i], rsi[p], atr[i]).any { !it.isFinite() } ||
            bb[i] == null || bb[p] == null || sto[i] == null || sto[p] == null || st[i] == 0
        ) return reject("Индикаторы не готовы")

        val e5 = ema5[i]; val e13 = ema13[i]
        val e5p = ema5[p]; val e13p = ema13[p]
        val rsiNow = rsi[i]; val rsiPrev = rsi[p]
        val bands = bb[i]!!; val prevBands = bb[p]!!
        val stoch = sto[i]!!; val stochPrev = sto[p]!!
        val superTrend = st[i]; val currentAtr = atr[i]
        val up = e5 > e13 && e5 > e5p && e13 >= e13p
        val down = e5 < e13 && e5 < e5p && e13 <= e13p
        val regime = when { up && superTrend > 0 -> Regime.UPTREND; down && superTrend < 0 -> Regime.DOWNTREND; else -> Regime.RANGE }

        val range = last.range
        if (range <= 0.0 || range > currentAtr * 2.4) return reject("Аномальный диапазон", regime)
        if (last.body / range > 0.90) return reject("Импульсная свеча", regime)

        val bullish = last.bullish; val bearish = last.bearish
        val crossUp = stochPrev.k <= stochPrev.d && stoch.k > stoch.d
        val crossDown = stochPrev.k >= stochPrev.d && stoch.k < stoch.d
        var callScore = 0; var putScore = 0
        val cr = mutableListOf<String>(); val pr = mutableListOf<String>()
        val prev = candles[p]

        if (up && superTrend > 0) {
            if (prev.low <= maxOf(e5p, prevBands.middle) && bullish && last.close > e5) { callScore += 45; cr += "trend_pullback" }
            if (rsiNow > 50 && rsiNow >= rsiPrev) { callScore += 15; cr += "rsi_bullish" }
            if (crossUp && stoch.k < 80) { callScore += 20; cr += "stoch_cross_up" }
        }
        if (down && superTrend < 0) {
            if (prev.high >= minOf(e5p, prevBands.middle) && bearish && last.close < e5) { putScore += 45; pr += "trend_pullback" }
            if (rsiNow < 50 && rsiNow <= rsiPrev) { putScore += 15; pr += "rsi_bearish" }
            if (crossDown && stoch.k > 20) { putScore += 20; pr += "stoch_cross_down" }
        }

        val flatEma = abs(e5 - e13) <= currentAtr * 0.20
        val bandsCalm = bands.width <= prevBands.width * 1.08
        if (!up && !down && flatEma && bandsCalm) {
            if (last.low <= bands.lower && last.close > bands.lower && bullish && crossUp && stoch.k < 25 && rsiNow > rsiPrev) {
                callScore = maxOf(callScore, 75); cr += "range_reversal"
            }
            if (last.high >= bands.upper && last.close < bands.upper && bearish && crossDown && stoch.k > 75 && rsiNow < rsiPrev) {
                putScore = maxOf(putScore, 75); pr += "range_reversal"
            }
        }

        val prior = candles.dropLast(1).takeLast(20)
        if (prior.size >= 15) {
            val resistance = prior.dropLast(1).maxOf { it.high }
            val support = prior.dropLast(1).minOf { it.low }
            if (breakoutState == BreakoutState.NONE) {
                when {
                    prev.close > resistance && superTrend > 0 && up -> { breakoutState = BreakoutState.WAIT_CALL; breakoutLevel = resistance; breakoutAt = prev.time }
                    prev.close < support && superTrend < 0 && down -> { breakoutState = BreakoutState.WAIT_PUT; breakoutLevel = support; breakoutAt = prev.time }
                }
            }
            if (breakoutState != BreakoutState.NONE && last.time - breakoutAt > 4 * M5) reset()
            if (breakoutState == BreakoutState.WAIT_CALL) {
                if (last.low <= breakoutLevel * 1.0015 && last.close > breakoutLevel && bullish && up && superTrend > 0 && rsiNow > 55) {
                    callScore = maxOf(callScore, 85); cr += "breakout_retest"; reset()
                } else if (last.close < breakoutLevel - currentAtr * 0.25) reset()
            }
            if (breakoutState == BreakoutState.WAIT_PUT) {
                if (last.high >= breakoutLevel * 0.9985 && last.close < breakoutLevel && bearish && down && superTrend < 0 && rsiNow < 45) {
                    putScore = maxOf(putScore, 85); pr += "breakout_retest"; reset()
                } else if (last.close > breakoutLevel + currentAtr * 0.25) reset()
            }
        }

        val threshold = when (mode) { TradingMode.ACTIVE -> 65; TradingMode.BALANCED -> 75; TradingMode.SNIPER -> 85 }
        val side = when {
            allowCall && callScore >= threshold && callScore > putScore + 10 -> Side.CALL
            allowPut && putScore >= threshold && putScore > callScore + 10 -> Side.PUT
            else -> Side.NONE
        }
        val score = maxOf(callScore, putScore).coerceIn(0, 100)
        val reason = when (side) {
            Side.CALL -> "CALL: ${cr.distinct().joinToString(", ")}"
            Side.PUT -> "PUT: ${pr.distinct().joinToString(", ")}"
            Side.NONE -> "Нет сетапа CALL=$callScore PUT=$putScore"
        }
        return Analysis(side, score, regime, reason, confidence, candles.size, last.time + M5, entryTime)
    }
}
