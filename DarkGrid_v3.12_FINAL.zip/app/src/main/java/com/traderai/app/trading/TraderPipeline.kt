package com.traderai.app.trading

import android.content.Context
import android.graphics.Bitmap
import com.traderai.app.accessibility.DarkGridAccessibilityService
import com.traderai.app.data.AppSettings
import com.traderai.app.data.CandleHistoryStore
import com.traderai.app.data.SessionLog
import com.traderai.app.data.SettingsRepo
import com.traderai.app.vision.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class PipelineResult(
    val confidence: Float,
    val candleCount: Int,
    val pair: String?,
    val payout: Int?,
    val analysis: Analysis?,
    val message: String,
    val warnings: List<String>,
    val calibrationReady: Boolean
)

class TraderPipeline(context: Context) {
    companion object { private const val MIN_HISTORY = 30 }

    private val parser = ScreenParser()
    private val historyStore = CandleHistoryStore(context)
    private val history = mutableListOf<Candle>().apply { addAll(historyStore.load()) }
    private val paper = PaperTrading(context)
    private val settings = SettingsRepo(context)

    @Volatile private var currentSettings = AppSettings()
    @Volatile private var lastClosedTime = Long.MIN_VALUE
    @Volatile private var currentPair = ""
    @Volatile private var lastTapCandle = Long.MIN_VALUE
    @Volatile private var lastTapMs = 0L
    @Volatile private var lastBlockLogMs = 0L

    suspend fun refreshSettings() {
        currentSettings = try { settings.flow.first() } catch (_: Exception) { currentSettings }
    }

    @Synchronized fun setCalibrationApproved(v: Boolean) {
        TradingGate.set(v)
        if (!v) StrategyEngine.reset()
    }

    suspend fun process(bitmap: Bitmap, now: Long = System.currentTimeMillis()): PipelineResult = withContext(Dispatchers.Default) {
        val parsed = parser.parse(bitmap, now)
        val pair = parsed.context.pair

        if (!pair.isNullOrBlank() && currentPair.isNotEmpty() && pair != currentPair) {
            StrategyEngine.reset()
            paper.cancelOpen("Смена пары $currentPair → $pair")
            lastClosedTime = Long.MIN_VALUE
            lastTapCandle = Long.MIN_VALUE
        }
        if (!pair.isNullOrBlank()) currentPair = pair

        val closedVerified = parsed.candles.filter { it.closed && it.verified && it.confidence >= 0.80f }
        for (c in closedVerified) {
            val idx = history.indexOfFirst { it.time == c.time }
            if (idx >= 0) { if (c.confidence >= history[idx].confidence) history[idx] = c }
            else history += c
        }
        history.sortBy { it.time }
        while (history.size > 300) history.removeAt(0)
        historyStore.save(history)

        val contiguous = hasTail(history, MIN_HISTORY)
        val latest = history.lastOrNull()
        // БЫЛО: PaperMath.gridAligned(now) -> now % 300000 == 0,
        // что истинно одну миллисекунду раз в 5 минут и блокировало ВСЕ сигналы.
        // Сетку надо проверять у времени свечи, а не у текущего timestamps.
        val gridOk = latest?.let { PaperMath.gridAligned(it.time) } == true

        val canAnalyze = TradingGate.approved.value && contiguous && parsed.context.valid &&
            parsed.calibrationReady && gridOk && latest != null && latest.time != lastClosedTime

        val analysis = if (canAnalyze) {
            lastClosedTime = latest!!.time
            StrategyEngine.analyze(
                input = history,
                mode = currentSettings.mode,
                confidence = parsed.confidence,
                context = parsed.context,
                allowCall = currentSettings.call,
                allowPut = currentSettings.put,
                calibrationApproved = true,
                minimumPayout = currentSettings.minPayout,
                now = now
            )
        } else {
            Analysis(Side.NONE, 0, Regime.UNKNOWN,
                if (!TradingGate.approved.value) "Observer: калибровка не подтверждена; ${parsed.note}"
                else if (!parsed.calibrationReady) "OHLC не подтверждены калибровкой; ${parsed.note}"
                else if (!parsed.context.valid) parsed.context.reason
                else if (history.size < MIN_HISTORY) "Истории ${history.size}/$MIN_HISTORY — копим свечи"
                else if (!contiguous) "История не непрерывна (пропуск в $MIN_HISTORY последних)"
                else if (!gridOk) "Временная сетка не выровнена"
                else "Ожидание новой закрытой свечи",
                parsed.confidence, history.size, null, null)
        }

        if (analysis.side != Side.NONE && analysis.signalTime != null && pair != null) {
            val current = parsed.candles.lastOrNull { !it.closed && it.verified }
            val key = PaperMath.signalKey(pair, analysis.side, analysis.signalTime)
            if (current != null && now - analysis.signalTime <= 30_000L) {
                val t = paper.open(
                    pair = pair, side = analysis.side, signalTime = analysis.signalTime,
                    signalKey = key, entryPrice = current.open,
                    payout = parsed.context.payout ?: 0, score = analysis.score,
                    reason = analysis.reason, paperEnabled = currentSettings.paper
                )
                if (t == null && currentSettings.paper) {
                    // уже открыта или повтор — логика в warnings не тянем, добавим в note через reasons
                }
            }
        }

        // Автонажатие ПОЛНОСТЬЮ НЕЗАВИСИМО от Paper Trading.
        // Paper — это только контрольный журнал/статистика; он не должен гасить
        // реальный сигнал и не должен блокировать нажатие.
        val tapWanted = currentSettings.autoTap && analysis.side != Side.NONE &&
            analysis.signalTime != null && pair != null
        val tapFresh = analysis.signalTime != null && now - analysis.signalTime <= 30_000L
        val a11yReady = DarkGridAccessibilityService.isRunning()
        val poForeground = DarkGridAccessibilityService.foregroundPackage == "com.pocketoption.broker"
        val tapAllowed = tapWanted && TradingGate.approved.value && tapFresh && a11yReady && poForeground &&
            lastTapCandle != analysis.signalTime && now - lastTapMs >= 60_000L

        if (tapAllowed) {
            val svc = DarkGridAccessibilityService.instance
            if (svc != null) {
                val dm = android.content.res.Resources.getSystem().displayMetrics
                val nx = if (analysis.side == Side.CALL) currentSettings.callX else currentSettings.putX
                val ny = if (analysis.side == Side.CALL) currentSettings.callY else currentSettings.putY
                val x = (nx * dm.widthPixels).coerceIn(1f, dm.widthPixels - 1f)
                val y = (ny * dm.heightPixels).coerceIn(1f, dm.heightPixels - 1f)
                val key = PaperMath.signalKey(pair!!, analysis.side, analysis.signalTime!!)
                lastTapCandle = analysis.signalTime
                lastTapMs = now
                // Один и тот же key у PAPER OPEN и у TAP — по нему удобно сравнивать
                // расчётную сделку с реальным нажатием в логах.
                SessionLog.add("TAP", "Запрос ${analysis.side.name} key=$key ($x,$y) paper=${currentSettings.paper}")
                svc.tap(x, y) { ok -> SessionLog.add("TAP", "${analysis.side.name} key=$key ok=$ok") }
            }
        } else if (tapWanted && now - lastBlockLogMs >= 30_000L) {
            // Логируем, почему предохранитель не пустил тап — это основной материал
            // для разбора расхождений между анализатором и биржей.
            lastBlockLogMs = now
            val why = when {
                !TradingGate.approved.value -> "калибровка не подтверждена"
                !a11yReady -> "спец. возможности не подключены"
                !poForeground -> "Pocket Option не в foreground"
                !tapFresh -> "сигнал устарел (>30 с)"
                lastTapCandle == analysis.signalTime -> "дубль сигнальной свечи"
                now - lastTapMs < 60_000L -> "кулдаун 60 с"
                else -> "ожидание"
            }
            SessionLog.add("TAP", "БЛОК $why side=${analysis.side.name}")
        }

        // Закрытие строго по цене ОТКРЫТИЯ свечи экспирации.
        history.filter { it.closed }.forEach { c -> paper.settle(c.time, c.open) }

        PipelineResult(
            confidence = parsed.confidence,
            candleCount = history.size,
            pair = pair,
            payout = parsed.context.payout,
            analysis = analysis,
            message = analysis.reason,
            warnings = parsed.warnings,
            calibrationReady = parsed.calibrationReady
        )
    }

    private fun hasTail(list: List<Candle>, n: Int): Boolean {
        if (list.size < n) return false
        val tail = list.takeLast(n)
        for (i in 1 until tail.size) if (tail[i].time - tail[i - 1].time != 300_000L) return false
        return tail.all { PaperMath.gridAligned(it.time) }
    }

    fun paperTrading(): PaperTrading = paper
    fun close() { parser.close() }
}
