# Dark Grid

Бывший TraderAI. Пакет `com.traderai.app` сохранён для стабильности сборки, но всё пользовательское имя — **Dark Grid**.

Версия: `3.3-darkgrid` (`versionCode 6`).

Визуальный стиль: тёмный оптический куб DG — ледяно-стальные грани, холодное стекло, глубокий фон, сдержанный красный акцент по нижним рёбрам. Без «детского неона».

## Что умеет

- MediaProjection + foreground service (Android 14–17).
- OCR пары, выплаты, таймера, таймфрейма, экспирации и ценовых отметок.
- Реконструкция OHLC с проверкой фитилей, ценовой шкалы и M5-сетки.
- История 300 закрытых свеч.
- Индикаторы: EMA5/13, Bollinger20/2, SuperTrend10/3, RSI14, Stoch5/3/3.
- Стратегии: Trend Pullback / Range Reversal / Breakout+Retest.
- Observer + Paper Trading. Реальные нажатия CALL/PUT отключены.
- Пульт: START/STOP/LOGS/PAPER/INFO, детальный статус, калибровка OHLC.
- Журнал сессии с поиском/копированием, Paper-статистика и экспорт TXT.

## Сборка

GitHub Actions → **Dark Grid Build** → артефакт `DarkGrid-debug`.

Локально: JDK 17 + `./gradlew assembleDebug`.

## Безопасность

Сигналы заблокированы до ручного подтверждения калибровки OHLC. Paper Trading управляется тумблером. Автоклики отсутствуют в коде.
