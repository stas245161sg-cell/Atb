package com.traderai.app.vision

import android.graphics.Bitmap

data class ParsedFrame(
    val candles: List<Candle>,
    val context: ScreenContext,
    val confidence: Float,
    val note: String,
    val warnings: List<String>,
    val calibrationReady: Boolean
)

class ScreenParser(
    private val ocr: ScreenOcr = ScreenOcr(),
    private val reconstructor: CandleReconstructor = CandleReconstructor()
) {
    suspend fun parse(bitmap: Bitmap, now: Long = System.currentTimeMillis()): ParsedFrame {
        if (bitmap.isRecycled || bitmap.width < 2) {
            return ParsedFrame(emptyList(), ScreenContext(null, null, null, null, false, "Некорректный кадр"),
                0f, "Ошибка", listOf("Некорректный кадр"), false)
        }
        val o = ocr.read(bitmap, now)
        val validContext = o.pair != null && o.payout != null &&
            o.timeframeMins == 5 && o.expiryMins == 5 && o.secondsRemaining != null
        val context = ScreenContext(
            pair = o.pair, payout = o.payout,
            timeframeMins = o.timeframeMins, expiryMins = o.expiryMins,
            valid = validContext,
            reason = "Пара=${o.pair ?: "?"}; выплата=${o.payout?.let { "$it%" } ?: "?"}; " +
                "TF=${o.timeframeMins?.let { "M$it" } ?: "?"}; эксп=${o.expiryMins?.let { "${it}m" } ?: "?"}"
        )
        val rec = if (validContext) {
            reconstructor.reconstruct(bitmap, o, now)
        } else {
            ReconstructionResult(emptyList(), 0f, false, false, o.warnings)
        }
        return ParsedFrame(
            candles = rec.candles,
            context = context,
            confidence = rec.confidence,
            note = if (rec.candles.isEmpty()) "OHLC не реконструирован: ${rec.warnings.joinToString("; ")}"
                   else "Свечи реконструированы",
            warnings = o.warnings + rec.warnings,
            calibrationReady = rec.calibrationReady
        )
    }
    fun close() = ocr.close()
}
