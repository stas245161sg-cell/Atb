package com.polaris.protocol

import android.content.Context

/** Универсальные профили отбора сигналов. Тип рынка не выбирается вручную:
 * движок анализирует любой распознанный график Pocket Option одинаковым конвейером.
 */
enum class TradingMode(val title: String, val minVoteScore: Float, val minVotes: Int, val requireFibo: Boolean) {
    MAX_WIN("Максимальный винрейт", 0.62f, 2, true),
    BALANCED("Баланс", 0.50f, 2, false),
    // Даже в режиме высокой частоты один голос не является достаточным подтверждением.
    MORE_SIGNALS("Больше сигналов", 0.42f, 2, false)
}

object SignalSettings {
    private const val FILE = "polaris_signals"

    @Volatile var scalpEnabled = false   // без надёжного определения таймфрейма SCALP выключен по умолчанию
    @Volatile var trendEnabled = true
    @Volatile var volEnabled = true
    @Volatile var tradingMode: TradingMode = TradingMode.BALANCED

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        scalpEnabled = sp.getBoolean("scalp", false)
        trendEnabled = sp.getBoolean("trend", true)
        volEnabled = sp.getBoolean("vol", true)
        tradingMode = runCatching { TradingMode.valueOf(sp.getString("trading_mode", TradingMode.BALANCED.name)!!) }.getOrDefault(TradingMode.BALANCED)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().apply {
            putBoolean("scalp", scalpEnabled)
            putBoolean("trend", trendEnabled)
            putBoolean("vol", volEnabled)
            putString("trading_mode", tradingMode.name)
        }.apply()
        load(ctx)
    }
}
