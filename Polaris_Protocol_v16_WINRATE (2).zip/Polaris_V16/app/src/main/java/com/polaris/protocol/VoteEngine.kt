package com.polaris.protocol

/**
 * Взвешенное голосование: минимум 2 стратегии, суммарный score > порога,
 * плюс фильтр выплаты. Возвращает направление и строку для журнала.
 */
class VoteEngine(
    private val strategies: List<Strategy> = listOf(ScalpStrategy(), TrendStrategy(), VolatilityStrategy())
) {
    companion object {
        /** Фильтр выплаты жёстко задан алгоритмом; единый источник — DecisionEngine. */
        const val MIN_PAYOUT = DecisionEngine.MIN_PAYOUT
    }

    fun decide(s: Snapshot, f: FiboLevels?, payout: Int): Pair<Direction?, String> {
        if (f == null) return null to "no_levels"
        if (payout < MIN_PAYOUT) return null to "payout_filter"

        val votes = strategies.filter { it.enabled }
            .map { strategy -> strategy to strategy.evaluate(s, f) }
            .filter { (_, signal) -> signal.dir != SignalDir.NONE && signal.confidence.isFinite() && signal.confidence > 0f }
        if (votes.isEmpty()) return null to "no_votes"

        val byDir = votes.groupBy { it.second.dir }
        fun sideScore(list: List<Pair<Strategy, Signal>>): Float =
            list.fold(0f) { acc, (st, sig) -> acc + sig.confidence * st.weight }

        val ranked = byDir.entries.sortedByDescending { sideScore(it.value) }
        val bestDir = ranked.first().key
        val group = ranked.first().value
        val score = sideScore(group)
        val opposingScore = ranked.getOrNull(1)?.let { sideScore(it.value) } ?: 0f
        // Сильный голос в противоположную сторону — не усредняем и не игнорируем его.
        if (opposingScore > 0f && opposingScore >= score * 0.35f) {
            return null to "conflicting_votes(best=$bestDir score=${String.format("%.2f", score)} opposite=${String.format("%.2f", opposingScore)})"
        }
        // Индикаторы на одном и том же изображении коррелированы; бонус ограничен,
        // чтобы не выдавать совпадение трёх производных индикаторов за независимые голоса.
        // Индикаторный бонус ограничен и не заменяет второй голос стратегии.
        val bonus = confirmBonus(s, bestDir).coerceAtMost(0.05f)
        val total = (score + bonus).coerceIn(0f, 1f)
        if (!score.isFinite() || !total.isFinite()) return null to "invalid_score"

        val profile = SignalSettings.tradingMode
        if (group.size < maxOf(2, profile.minVotes) || total <= profile.minVoteScore) {
            return null to "weak_vote($bestDir n=${group.size} score=${String.format("%.2f", total)} min=${profile.minVoteScore} bonus=${String.format("%.2f", bonus)})"
        }

        // total — эвристический score, а не калиброванная вероятность победы.
        // Поэтому математическое EV по нему не вычисляем. Фильтр payout остаётся отдельным.

        val dir = if (bestDir == SignalDir.CALL) Direction.CALL else Direction.PUT
        return dir to "vote=$bestDir n=${group.size} score=${String.format("%.2f", total)} bonus=${String.format("%.2f", bonus)} opposing=${String.format("%.2f", opposingScore)} score_not_probability=true"
    }

    /** SuperTrend + Stochastic + AO добавляют уверенности, если согласны с направлением. */
    private fun confirmBonus(s: Snapshot, dir: SignalDir): Float {
        var b = 0f
        if (s.superTrend != Trend.UNKNOWN) {
            val stDir = if (s.superTrend == Trend.GREEN) SignalDir.CALL else SignalDir.PUT
            if (stDir == dir) b += 0.10f
        }
        if (s.stochCross != Cross.NONE) {
            val scDir = if (s.stochCross == Cross.UP) SignalDir.CALL else SignalDir.PUT
            if (scDir == dir) b += 0.08f
        }
        if (s.ao != Trend.UNKNOWN) {
            val aoDir = if (s.ao == Trend.GREEN) SignalDir.CALL else SignalDir.PUT
            if (aoDir == dir) b += 0.07f
        }
        return b
    }
}
