package com.polaris.protocol

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Экран «Информация»: какие индикаторы использует Polaris и как их настроить. */
@Composable
fun InfoScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    var bank by remember { mutableFloatStateOf(SignalSettings.bank) }
    var payout by remember { mutableIntStateOf(SignalSettings.payoutMin) }
    var minScore by remember { mutableFloatStateOf(SignalSettings.minScore) }
    var emaF by remember { mutableIntStateOf(SignalSettings.emaFast) }
    var emaS by remember { mutableIntStateOf(SignalSettings.emaSlow) }
    var rsiP by remember { mutableIntStateOf(SignalSettings.rsiPeriod) }
    var adxP by remember { mutableIntStateOf(SignalSettings.adxPeriod) }
    var adxM by remember { mutableFloatStateOf(SignalSettings.adxMin) }
    var atrP by remember { mutableIntStateOf(SignalSettings.atrPeriod) }
    var atrE by remember { mutableFloatStateOf(SignalSettings.atrExpansion) }
    var fibo by remember { mutableFloatStateOf(SignalSettings.fiboRatio) }
    var scalp by remember { mutableStateOf(SignalSettings.scalpEnabled) }
    var trend by remember { mutableStateOf(SignalSettings.trendEnabled) }
    var vol by remember { mutableStateOf(SignalSettings.volEnabled) }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgTop)
            .padding(16.dp)
    ) {
        Text(
            "Индикаторы и настройки",
            color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold
        )
        Text(
            "Polaris V3 · Adaptive Signal Engine",
            color = FrostBlue, fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                InfoSection("Источники данных (захват экрана)") {
                    InfoLine("Свечи", "High / Low / Close / тело / цвет · 30 баров")
                    InfoLine("SuperTrend", "По положению линии относительно цены, не по цвету")
                    InfoLine("Payout", "OCR зоны выплаты, число перед «%», TTL 10 с")
                    InfoLine("Stochastic / AO", "Опциональные зоны панелей, подтверждение")
                    InfoLine("Стакан", "Недоступен через экран — импульс по свечам вместо order flow")
                }
            }
            item {
                InfoSection("Индикаторы и стратегии") {
                    InfoLine("SCALP (вес 0.30)", "Микрофрактал 3 бара + импульс · M1")
                    InfoLine("TREND (вес 0.45)", "EMA ${emaF}/${emaS} · RSI ${rsiP} · ADX ${adxP} > ${adxM.toInt()} · M5")
                    InfoLine("VOL (вес 0.25)", "ATR ${atrP}, расширение ×${String.format("%.2f", atrE)} · OTC")
                    InfoLine("FIBO ${String.format("%.3f", fibo)}", "Уровни 14.6% от диапазона 30 свечей")
                    InfoLine("Голосование", "≥2 стратегии и score > ${String.format("%.2f", minScore)}")
                    InfoLine("Риск", "Фиксированный 1% банка, без мартингейла")
                }
            }
            item {
                InfoSection("Параметры голосования") {
                    IntSetting("Минимальный payout, %", payout.toFloat(), 75f..95f) {
                        payout = it.toInt()
                    }
                    FloatSetting("Порог score", minScore, 0.50f..0.85f) { minScore = it }
                    IntSetting("Банк для сессии", bank, 100f..100000f) { bank = it.toFloat() }
                }
            }
            item {
                InfoSection("EMA / RSI / ADX") {
                    IntSetting("EMA быстрая", emaF.toFloat(), 5f..20f) { emaF = it.toInt() }
                    IntSetting("EMA медленная", emaS.toFloat(), 15f..40f) { emaS = it.toInt() }
                    IntSetting("RSI период", rsiP.toFloat(), 7f..21f) { rsiP = it.toInt() }
                    IntSetting("ADX период", adxP.toFloat(), 7f..21f) { adxP = it.toInt() }
                    FloatSetting("ADX минимум", adxM, 10f..40f) { adxM = it }
                }
            }
            item {
                InfoSection("ATR / Fibonacci") {
                    IntSetting("ATR период", atrP.toFloat(), 5f..21f) { atrP = it.toInt() }
                    FloatSetting("ATR расширение ×", atrE, 1.05f..1.60f) { atrE = it }
                    FloatSetting("Коэффициент FIBO", fibo, 0.10f..0.30f) { fibo = it }
                }
            }
            item {
                InfoSection("Включить стратегии") {
                    SwitchLine("SCALP", scalp) { scalp = it }
                    SwitchLine("TREND", trend) { trend = it }
                    SwitchLine("VOL (OTC)", vol) { vol = it }
                }
            }
        }

        Button(
            onClick = {
                SignalSettings.bank = bank
                SignalSettings.payoutMin = payout
                SignalSettings.minScore = minScore
                SignalSettings.emaFast = emaF
                SignalSettings.emaSlow = emaS
                SignalSettings.rsiPeriod = rsiP
                SignalSettings.adxPeriod = adxP
                SignalSettings.adxMin = adxM
                SignalSettings.atrPeriod = atrP
                SignalSettings.atrExpansion = atrE
                SignalSettings.fiboRatio = fibo
                SignalSettings.scalpEnabled = scalp
                SignalSettings.trendEnabled = trend
                SignalSettings.volEnabled = vol
                SignalSettings.save(ctx)
                Toast.makeText(ctx, "Настройки сохранены", Toast.LENGTH_SHORT).show()
                onClose()
            },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = IceCyan, contentColor = BgTop)
        ) {
            Text("Сохранить и закрыть")
        }
    }
}

@Composable
private fun InfoSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(GlassFill)
            .padding(12.dp)
    ) {
        Text(title, color = IceCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(0.4f))
        Text(value, color = TextPrimary, fontSize = 12.sp, modifier = Modifier.weight(0.6f))
    }
}

@Composable
private fun IntSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSecondary, fontSize = 12.sp)
            Text(value.toInt().toString(), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = value, onValueChange = { onChange(it.toInt()) }, valueRange = range)
    }
}

@Composable
private fun FloatSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSecondary, fontSize = 12.sp)
            Text(String.format("%.2f", value), color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
