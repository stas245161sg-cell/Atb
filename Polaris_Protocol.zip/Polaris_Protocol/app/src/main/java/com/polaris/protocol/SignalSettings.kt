package com.polaris.protocol

import android.content.Context

/**
 * Настройки сигнального движка и индикаторов.
 * Значения живут в SharedPreferences, но кэшируются в @Volatile-полях —
 * Изменения с экрана «Индикаторы» действуют на следующий кадр без перезапуска захвата.
 */
object SignalSettings {
    private const val FILE = "polaris_signals"

    @Volatile var bank = 1000f
    @Volatile var payoutMin = 85
    @Volatile var minScore = 0.65f
    @Volatile var emaFast = 9
    @Volatile var emaSlow = 21
    @Volatile var rsiPeriod = 14
    @Volatile var adxPeriod = 14
    @Volatile var adxMin = 20f
    @Volatile var atrPeriod = 14
    @Volatile var atrExpansion = 1.2f
    @Volatile var fiboRatio = 0.146f
    @Volatile var scalpEnabled = true
    @Volatile var trendEnabled = true
    @Volatile var volEnabled = true

    fun load(ctx: Context) {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        bank = sp.getFloat("bank", 1000f)
        payoutMin = sp.getInt("payout_min", 85)
        minScore = sp.getFloat("min_score", 0.65f)
        emaFast = sp.getInt("ema_fast", 9)
        emaSlow = sp.getInt("ema_slow", 21)
        rsiPeriod = sp.getInt("rsi_period", 14)
        adxPeriod = sp.getInt("adx_period", 14)
        adxMin = sp.getFloat("adx_min", 20f)
        atrPeriod = sp.getInt("atr_period", 14)
        atrExpansion = sp.getFloat("atr_expansion", 1.2f)
        fiboRatio = sp.getFloat("fibo_ratio", 0.146f)
        scalpEnabled = sp.getBoolean("scalp", true)
        trendEnabled = sp.getBoolean("trend", true)
        volEnabled = sp.getBoolean("vol", true)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().apply {
            putFloat("bank", bank)
            putInt("payout_min", payoutMin)
            putFloat("min_score", minScore)
            putInt("ema_fast", emaFast)
            putInt("ema_slow", emaSlow)
            putInt("rsi_period", rsiPeriod)
            putInt("adx_period", adxPeriod)
            putFloat("adx_min", adxMin)
            putInt("atr_period", atrPeriod)
            putFloat("atr_expansion", atrExpansion)
            putFloat("fibo_ratio", fiboRatio)
            putBoolean("scalp", scalpEnabled)
            putBoolean("trend", trendEnabled)
            putBoolean("vol", volEnabled)
        }.apply()
        load(ctx)
    }
}
