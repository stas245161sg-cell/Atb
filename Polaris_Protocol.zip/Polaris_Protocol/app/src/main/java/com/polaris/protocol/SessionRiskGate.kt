package com.polaris.protocol

/**
 * Защита депозита без мартингейла: фиксированный процент банка на сделку,
 * дневные STOP/TAKE, лимит сделок и cooldown. Ставка НЕ растёт после убытка.
 */
class SessionRiskGate(
    private val startBank: Float,
    private val riskPerTrade: Float = 0.01f,
    private val dayStop: Float = 0.15f,
    private val dayTarget: Float = 0.20f,
    private val maxTrades: Int = 30,
    private val cooldownMs: Long = 60_000L
) {
    private var bank = startBank
    private var trades = 0
    private var lastTradeAt = 0L

    /** null = торговать можно, иначе код блокировки. */
    fun allow(now: Long): String? = when {
        trades >= maxTrades -> "max_trades"
        now - lastTradeAt < cooldownMs -> "cooldown"
        bank - startBank <= -dayStop * startBank -> "day_stop"
        bank - startBank >= dayTarget * startBank -> "day_target"
        else -> null
    }

    fun stake(): Float = bank * riskPerTrade

    /** Учёт факта входа (результат сделки брокер не возвращает через захват экрана). */
    fun onSignal() {
        trades++
        lastTradeAt = System.currentTimeMillis()
    }

    fun onResult(win: Boolean, payout: Int, stake: Float) {
        trades++
        lastTradeAt = System.currentTimeMillis()
        bank += if (win) stake * payout / 100f else -stake
    }

    fun snapshot(): String = "bank=${String.format("%.2f", bank)} trades=$trades pnl=${String.format("%.2f", bank - startBank)}"
}
