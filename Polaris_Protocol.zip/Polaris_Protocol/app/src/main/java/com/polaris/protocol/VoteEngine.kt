package com.polaris.protocol

/**
 * Взвешенное голосование: минимум 2 стратегии, суммарный score > порога,
 * плюс фильтр выплаты. Возвращает направление и строку для журнала.
 */
class VoteEngine(
    private val strategies: List<Strategy> = listOf(ScalpStrategy(), TrendStrategy(), VolatilityStrategy())
) {
    fun decide(s: Snapshot, f: FiboLevels?, payout: Int): Pair<Direction?, String> {
        if (f == null) return null to "no_levels"
        if (payout < SignalSettings.payoutMin) return null to "payout_filter"

        val votes = strategies.filter { it.enabled }
            .map { it to it.evaluate(s, f) }
            .filter { it.second.dir != SignalDir.NONE }
        if (votes.isEmpty()) return null to "no_votes"

        val byDir = votes.groupBy { it.second.dir }
        val bestDir = byDir.maxByOrNull { (_, list) ->
            list.fold(0f) { acc, (st, sig) -> acc + sig.confidence * st.weight }
        }!!.key
        val group = votes.filter { it.second.dir == bestDir }
        val score = group.fold(0f) { acc, (st, sig) -> acc + sig.confidence * st.weight }

        if (group.size < 2 || score <= SignalSettings.minScore) {
            return null to "weak_vote($bestDir n=${group.size} score=${String.format("%.2f", score)})"
        }

        // EV при текущей выплате: p ≈ score, безубыточность 1/(1+payout)
        val p = payout / 100f
        val ev = score * p - (1f - score)
        if (ev <= 0f) return null to "negative_ev(${String.format("%.3f", ev)})"

        val dir = if (bestDir == SignalDir.CALL) Direction.CALL else Direction.PUT
        return dir to "vote=$bestDir n=${group.size} score=${String.format("%.2f", score)} ev=${String.format("%.3f", ev)}"
    }
}
