package com.example.tradebot

import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ======================= Палитра «HyperOS 4 Glassmorphism + киберпанк» =======================

/** Фон приложения: от глубокого чёрного #0A0A0C к тёмно-серому #1A1A20. */
val BgTop = Color(0xFF0A0A0C)
val BgBottom = Color(0xFF1A1A20)

/** Акцент (Primary): неоново-красный из центра иконки; DeepRed — конец градиента кнопок. */
val NeonRed = Color(0xFFFF2A2A)
val DeepRed = Color(0xFF7A0A0A)

/** Вторичный цвет (Secondary): электрик-синий. */
val ElectricBlue = Color(0xFF4A90E2)

/** Текст: белый для заголовков, светло-серый для подписей (для них используется FontWeight.Light). */
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A0A5)

/** Стекло: поверхность и обводка карточек. */
val GlassFill = Color.White.copy(alpha = 0.08f)
val GlassBorder = Color.White.copy(alpha = 0.15f)

/** Смысловые цвета статусов: рост / падение. «Падение» совпадает с акцентом. */
val Positive = Color(0xFF34D399)
val Negative = NeonRed

/** Текст журнала. */
val LogText = Color(0xFFD0D5DD)

val AppBackgroundBrush: Brush = Brush.verticalGradient(listOf(BgTop, BgBottom))

private val TradeBotColorScheme = darkColorScheme(
    primary = NeonRed,
    onPrimary = Color.White,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    background = BgTop,
    onBackground = TextPrimary,
    surface = BgTop,
    onSurface = TextPrimary,
    surfaceVariant = BgBottom,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = NeonRed
)

private val TradeBotTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 14.sp,
        color = TextSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 12.sp,
        color = TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = TextPrimary
    )
)

@Composable
fun TradeBotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TradeBotColorScheme,
        typography = TradeBotTypography,
        content = content
    )
}

/**
 * Фон экрана: вертикальный градиент #0A0A0C → #1A1A20 и два мягких «неоновых» свечения
 * (красное справа сверху, синее слева снизу).
 */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(AppBackgroundBrush)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(NeonRed.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.92f, size.height * 0.04f),
                        radius = size.width * 0.95f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(ElectricBlue.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.05f, size.height * 0.96f),
                        radius = size.width * 1.05f
                    )
                )
            },
        content = content
    )
}
