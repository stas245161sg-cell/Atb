package com.example.tradebot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.tradebot.START"
        const val ACTION_STOP = "com.example.tradebot.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CHANNEL_ID = "tradebot_capture"
        private const val NOTIF_ID = 1001
        private const val CAPTURE_SCALE = 0.5f      // анализ в половинном разрешении
        private const val FRAME_INTERVAL_MS = 33L   // ~30 FPS
        private const val UI_INTERVAL_MS = 250L

        // Журнал: на 30 FPS нельзя писать строку на каждый кадр — буфер из 100 строк перезапишется за секунды
        private const val EVAL_MIN_INTERVAL_MS = 2_000L     // не чаще, когда меняется состояние
        private const val EVAL_HEARTBEAT_MS = 30_000L       // и обязательно раз в 30 с
        private const val STATS_INTERVAL_MS = 300_000L      // сводка причин отказа раз в 5 минут
        private const val ERR_INTERVAL_MS = 10_000L
        private const val FRAME_SAVE_INTERVAL_MS = 5_000L   // как часто обновлять кадр для экрана калибровки
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var analyzer: ImageAnalyzer? = null
    private var engine: DecisionEngine? = null
    private var thread: HandlerThread? = null
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)

    @Volatile private var running = false
    private var stopping = false

    private var screenW = 0
    private var screenH = 0
    private var lastFrameAt = 0L
    private var lastUiAt = 0L
    private var fpsStart = 0L
    private var frames = 0
    private var fps = 0f
    private var wasLive = true
    private var lastEvalSig = ""
    private var lastEvalAt = 0L
    private var lastStatsAt = 0L
    private var lastErrAt = 0L
    private var lastFrameSavedAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> shutdown()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (running) return

        createChannel()
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, notification)
        }

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = readData(intent)
        if (data == null) {
            shutdown()
            return
        }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        val ht = HandlerThread("tradebot-capture").also { it.start() }
        thread = ht
        val handler = Handler(ht.looper)

        // Android 14+: callback нужно зарегистрировать до createVirtualDisplay
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                shutdown()
            }
        }, handler)
        projection = proj

        val (w, h, dpi) = realSize()
        screenW = w
        screenH = h
        val cw = ((w * CAPTURE_SCALE).toInt() and 1.inv()).coerceAtLeast(2)
        val ch = ((h * CAPTURE_SCALE).toInt() and 1.inv()).coerceAtLeast(2)

        val ir = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        reader = ir

        val az = ImageAnalyzer(applicationContext)    // зоны читаются из SharedPreferences
        analyzer = az
        engine = DecisionEngine(
            cooldownMs = { BotPrefs.cooldownMs(this@ScreenCaptureService) },
            modeProvider = { BotPrefs.tradingMode(this@ScreenCaptureService) }
        )

        ir.setOnImageAvailableListener({ r -> onFrame(r) }, handler)
        display = proj.createVirtualDisplay(
            "TradeBotCapture", cw, ch, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            ir.surface, null, handler
        )

        running = true
        TradingAccessibilityService.instance?.hideMarkers()   // маркеры закрыли бы кнопки и OCR payout
        fpsStart = SystemClock.elapsedRealtime()
        BotState.state.update { it.copy(running = true, cvReady = az.ready) }
        lastStatsAt = SystemClock.elapsedRealtime()
        LogRepository.addLog("Захват запущен: ${cw}x$ch (экран ${w}x$h)")
        LogRepository.addLog(
            "START: mode=${BotPrefs.tradingMode(this).title}, autoTap=${if (BotPrefs.autoTap(this)) "ON" else "OFF"}, " +
                "pause=${BotPrefs.cooldownSec(this)}s, " +
                "CALL=${pos(BotPrefs.CALL_X, BotPrefs.CALL_Y)}, PUT=${pos(BotPrefs.PUT_X, BotPrefs.PUT_Y)}"
        )
        if (!az.ready) LogRepository.addLog("ОШИБКА: OpenCV не инициализирован")
    }

    @Suppress("DEPRECATION")
    private fun readData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else i.getParcelableExtra(EXTRA_DATA)

    private fun realSize(): Triple<Int, Int, Int> {
        val (w, h) = realScreenSize(this)
        return Triple(w, h, resources.configuration.densityDpi)
    }

    // ---------- кадры ----------

    private fun onFrame(r: ImageReader) {
        val image: Image = (try { r.acquireLatestImage() } catch (e: Exception) { null }) ?: return
        val now = SystemClock.elapsedRealtime()
        if (now - lastFrameAt < FRAME_INTERVAL_MS || !busy.compareAndSet(false, true)) {
            image.close()
            return
        }
        lastFrameAt = now

        val bmp: Bitmap? = try {
            image.toBitmap()
        } catch (e: Exception) {
            null
        } finally {
            image.close()
        }
        if (bmp == null) {
            busy.set(false)
            return
        }

        try {
            worker.execute {
                try {
                    process(bmp)
                } finally {
                    bmp.recycle()
                    busy.set(false)
                }
            }
        } catch (e: Exception) {
            bmp.recycle()
            busy.set(false)
        }
    }

    private fun process(bmp: Bitmap) {
        val a = analyzer ?: return
        val e = engine ?: return
        val now = SystemClock.elapsedRealtime()
        val snap = a.analyze(bmp)
        if (snap == null) {
            if (now - lastErrAt >= ERR_INTERVAL_MS) {
                lastErrAt = now
                LogRepository.addLog("EVAL: анализ кадра не выполнен (${a.lastError ?: "OpenCV не готов"})")
            }
            return
        }
        val dir = e.evaluate(snap, now)
        logEval(snap, e, now)
        saveFrameIfNeeded(bmp, snap, now)

        frames++
        if (now - fpsStart >= 1000) {
            fps = frames * 1000f / (now - fpsStart)
            frames = 0
            fpsStart = now
        }

        if (snap.live != wasLive) {
            wasLive = snap.live
            LogRepository.addLog(
                if (snap.live) "График снова на последней свече"
                else "График прокручен (нажмите «>» внизу справа) — анализ приостановлен"
            )
        }
        if (dir != null) onSignal(dir, snap)

        if (dir != null || now - lastUiAt >= UI_INTERVAL_MS) {
            lastUiAt = now
            val engineState = e.state
            BotState.state.update {
                it.copy(
                    running = true,
                    live = snap.live,
                    fps = fps,
                    superTrend = snap.superTrend,
                    stochCross = snap.stochCross,
                    stochValue = snap.stochValue,
                    ao = snap.ao,
                    body = snap.body,
                    payout = snap.payout,
                    engine = engineState,
                    lastSignal = dir ?: it.lastSignal
                )
            }
        }
    }

    /** Строка EVAL пишется при смене состояния (не чаще раза в 2 с) и раз в 30 с; плюс сводка STATS раз в 5 минут. */
    private fun logEval(s: Snapshot, e: DecisionEngine, now: Long) {
        val v = e.lastVerdict
        val sig = "${v.mode}|${v.direction}|${v.failures.joinToString(",")}|${s.superTrend}|${s.stochCross}|${s.ao}|${s.live}"
        val changed = sig != lastEvalSig
        if ((changed && now - lastEvalAt >= EVAL_MIN_INTERVAL_MS) || now - lastEvalAt >= EVAL_HEARTBEAT_MS) {
            lastEvalSig = sig
            lastEvalAt = now
            LogRepository.addLog(evalLine(s, v))
        }
        if (now - lastStatsAt >= STATS_INTERVAL_MS) {
            LogRepository.addLog(e.statsLine((now - lastStatsAt) / 1000))
            lastStatsAt = now
        }
    }

    /**
     * Сохраняет последний кадр с графиком в filesDir — он служит фоном на экране калибровки зон.
     * Пишем только пока на экране Pocket Option (по данным службы спец. возможностей); если служба
     * не подключена — только когда на кадре найдена свеча.
     */
    private fun saveFrameIfNeeded(bmp: Bitmap, snap: Snapshot, now: Long) {
        if (now - lastFrameSavedAt < FRAME_SAVE_INTERVAL_MS) return
        val pkg = TradingAccessibilityService.foregroundPackage
        val onPocketOption = if (pkg.isNotEmpty()) pkg == Roi.POCKET_PACKAGE else !snap.body.isNaN()
        if (!onPocketOption) return
        lastFrameSavedAt = now
        try {
            val tmp = File(filesDir, "last_frame.tmp")
            FileOutputStream(tmp).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            tmp.renameTo(File(filesDir, Roi.LAST_FRAME_FILE))
        } catch (e: Exception) {
            // не критично: калибровка просто покажет прежний кадр или заглушку
        }
    }

    private fun pos(kx: String, ky: String): String =
        "${(BotPrefs.get(this, kx) * 100).fmt(0)}%x${(BotPrefs.get(this, ky) * 100).fmt(0)}%"

    private fun onSignal(dir: Direction, s: Snapshot) {
        LogRepository.addLog(
            "TAP ${dir.name}: mode=${BotPrefs.tradingMode(this).name}, st=${s.superTrend}, " +
                "stoch=${s.stochCross}@${s.stochValue.fmt(0, "?")}, ao=${s.ao}, " +
                "body=${s.body.fmt(2, "?")}, payout=${s.payout}%"
        )
        if (!BotPrefs.autoTap(this)) {
            LogRepository.addLog("TAP ${dir.name}: не выполнен — автонажатие выключено")
            return
        }
        val svc = TradingAccessibilityService.instance
        if (svc == null) {
            LogRepository.addLog("TAP ${dir.name}: не выполнен — служба спец. возможностей не активна")
            return
        }
        val x = BotPrefs.get(this, if (dir == Direction.CALL) BotPrefs.CALL_X else BotPrefs.PUT_X) * screenW
        val y = BotPrefs.get(this, if (dir == Direction.CALL) BotPrefs.CALL_Y else BotPrefs.PUT_Y) * screenH
        svc.tap(x, y) { ok -> LogRepository.addLog(if (ok) "TAP ${dir.name}: выполнен" else "TAP ${dir.name}: отменён") }
    }

    // ---------- уведомление и остановка ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Захват экрана", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TradeBot")
            .setContentText("Анализ экрана запущен")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

    private fun shutdown() {
        if (stopping) return
        stopping = true
        running = false

        try { reader?.setOnImageAvailableListener(null, null) } catch (ignored: Throwable) {}
        try { display?.release() } catch (ignored: Throwable) {}
        try { reader?.close() } catch (ignored: Throwable) {}
        try { projection?.stop() } catch (ignored: Throwable) {}
        worker.shutdown()
        analyzer?.close()
        thread?.quitSafely()
        display = null
        reader = null
        projection = null

        BotState.state.update { it.copy(running = false, fps = 0f) }
        LogRepository.addLog("Захват остановлен")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}

private fun Image.toBitmap(): Bitmap {
    val plane = planes[0]
    val pixelStride = plane.pixelStride
    val rowPadding = plane.rowStride - pixelStride * width
    val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(plane.buffer)
    if (rowPadding == 0) return padded
    val exact = Bitmap.createBitmap(padded, 0, 0, width, height)
    padded.recycle()
    return exact
}
