package com.example.tradebot

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

enum class Direction { CALL, PUT }
enum class EngineState { SCANNING, CONFIRMING, COOLDOWN }

/**
 * Режим торговли — набор порогов входа.
 *
 * callZone / putZone: пересечение Stochastic вверх допустимо при значении < callZone,
 * вниз — при значении > putZone (101 / -1 = любая зона).
 * stochConflictAllowed: пересечение против цвета SuperTrend не блокирует вход (нужно в ТЕСТЕ,
 * чтобы проверять нажатия); направление при этом задаёт SuperTrend.
 */
enum class TradingMode(
    val title: String,
    val minPayout: Int,
    val maxBody: Float,
    val requireAo: Boolean,
    val callZone: Float,
    val putZone: Float,
    val stochConflictAllowed: Boolean,
    val aoLenient: Boolean,
    val hint: String
) {
    TEST(
        "ТЕСТ (50%)", 70, 0.85f, false, 101f, -1f, true, false,
        "SuperTrend + свежее пересечение Stoch в любой зоне, AO не учитывается. Payout ≥ 70, тело < 0.85. " +
            "Противоречие Stoch и SuperTrend не блокирует нажатие. Только демо-счёт!"
    ),
    BASE(
        "БАЗОВЫЙ (60%)", 82, 0.85f, true, 30f, 70f, false, true,
        "SuperTrend + AO того же цвета либо AO идёт в нужную сторону последние 2 столбца (одиночный " +
            "«провал» цвета не блокирует) + пересечение Stoch вверх в зоне < 30 / вниз в зоне > 70. " +
            "Payout ≥ 82, тело < 0.85."
    ),
    SAFE(
        "АККУРАТНЫЙ (70%)", 85, 0.6f, true, 20f, 80f, false, false,
        "SuperTrend + AO того же цвета + пересечение Stoch строго в зоне < 20 (вверх) / > 80 (вниз). " +
            "Payout ≥ 85, тело < 0.6."
    );

    fun callZoneOk(v: Float): Boolean = v < callZone
    fun putZoneOk(v: Float): Boolean = v > putZone
}

fun Float.fmt(digits: Int = 0, nan: String = "—"): String =
    if (isNaN()) nan else String.format(Locale.US, "%.${digits}f", this)

/**
 * Итог оценки одного кадра в заданном режиме.
 * direction — не null, только если выполнены ВСЕ условия режима; failures — коды невыполненных условий;
 * notes — пометки (например, проигнорированное противоречие Stoch в режиме ТЕСТ);
 * intended — направление, которое «хочет» SuperTrend (UP / DOWN / NONE).
 */
data class Verdict(
    val direction: Direction?,
    val failures: List<String>,
    val intended: String,
    val mode: TradingMode,
    val notes: List<String> = emptyList()
)

/** EVAL: mode=TEST, dir=DOWN, st=RED, stoch=UP@16, ao=RED, body=0.44, payout=92 -> SIGNAL(PUT) [stoch_opposite_ignored] */
fun evalLine(s: Snapshot, v: Verdict): String {
    val stoch = if (s.stochCross == Cross.NONE) "NONE" else "${s.stochCross.name}@${s.stochValue.fmt(0, "?")}"
    val payout = if (s.payout >= 0) "${s.payout}" else "?"
    val d = v.direction
    val verdict = if (d != null) "SIGNAL(${d.name})" else "NO_TRADE(${v.failures.joinToString(",")})"
    val notes = if (v.notes.isEmpty()) "" else " [${v.notes.joinToString(",")}]"
    val slope = if (s.aoSlope.isNaN()) "" else "(d${if (s.aoSlope > 0f) "+" else ""}${s.aoSlope.toInt()})"
    val chart = if (s.chartNote.isNotEmpty()) {
        ", chart=${s.chartNote}"
    } else {
        ""
    }
    return "EVAL: mode=${v.mode.name}, dir=${v.intended}, st=${s.superTrend.name}, stoch=$stoch, " +
        "ao=${s.ao.name}$slope, body=${s.body.fmt(2, "?")}, payout=$payout$chart -> $verdict$notes"
}

/**
 * State Machine: SCANNING → CONFIRMING (N кадров подряд) → COOLDOWN → SCANNING.
 * Сигнал выдаётся один раз; после паузы бот ждёт, пока сетап исчезнет, и только потом снова готов к входу.
 * Режим читается на каждом кадре через [modeProvider], поэтому переключение в UI действует сразу.
 */
class DecisionEngine(
    private val cooldownMs: () -> Long,
    private val modeProvider: () -> TradingMode = { TradingMode.TEST }
) {

    companion object {
        const val CONFIRM_FRAMES = 3
    }

    var state: EngineState = EngineState.SCANNING
        private set

    /** Результат последней оценки (читается сервисом для строки EVAL). */
    var lastVerdict: Verdict = Verdict(null, emptyList(), "NONE", TradingMode.TEST)
        private set

    private var lastMode: TradingMode? = null
    private var pending: Direction? = null
    private var count = 0
    private var cooldownUntil = 0L

    // Статистика причин отказа за период — показывает, какое условие чаще всего «не пускает» сделку
    private val failCounts = HashMap<String, Int>()
    private var framesTotal = 0
    private var framesLive = 0
    private var signals = 0

    fun evaluate(s: Snapshot, now: Long): Direction? {
        val mode = modeProvider()
        val previous = lastMode
        if (previous != null && previous != mode) {
            LogRepository.addLog("MODE: ${previous.name} -> ${mode.title}")
            if (state == EngineState.CONFIRMING) reset()     // условия другие — подтверждение начинаем заново
        }
        lastMode = mode

        val v = verdict(s, mode)
        lastVerdict = v

        framesTotal++
        if (s.live) framesLive++
        for (f in v.failures) failCounts[f] = (failCounts[f] ?: 0) + 1

        val raw = v.direction
        when (state) {
            EngineState.COOLDOWN -> {
                // После паузы ждём, пока сетап пропадёт — иначе вход повторится по тому же сигналу
                if (now >= cooldownUntil && raw == null) {
                    reset()
                    LogRepository.addLog("STATE: COOLDOWN -> SCANNING")
                }
            }
            EngineState.SCANNING -> {
                if (raw != null) {
                    pending = raw
                    count = 1
                    state = EngineState.CONFIRMING
                    LogRepository.addLog("STATE: SCANNING -> CONFIRMING (${raw.name} 1/$CONFIRM_FRAMES)")
                    if (count >= CONFIRM_FRAMES) return fire(now, mode)
                }
            }
            EngineState.CONFIRMING -> {
                if (raw != null && raw == pending) {
                    count++
                    if (count >= CONFIRM_FRAMES) return fire(now, mode)
                } else {
                    val why = v.failures.joinToString(",").ifEmpty { "direction_changed" }
                    LogRepository.addLog("STATE: CONFIRMING -> SCANNING (setup lost: $why)")
                    reset()
                }
            }
        }
        return null
    }

    /** Проверка всех условий входа выбранного режима с перечислением невыполненных. */
    fun verdict(s: Snapshot, mode: TradingMode): Verdict {
        if (!s.live) return Verdict(null, listOf("chart_scrolled"), "NONE", mode)

        val fails = ArrayList<String>()
        val notes = ArrayList<String>()

        if (s.payout < 0) fails.add("payout_unreadable")
        else if (s.payout < mode.minPayout) fails.add("low_payout(<${mode.minPayout})")

        if (s.body.isNaN()) fails.add("body_unknown")
        else if (s.body >= mode.maxBody) fails.add("big_body(>=${mode.maxBody.fmt(2)})")

        var dir: Direction? = null
        val intended: String
        when (s.superTrend) {
            Trend.GREEN -> {
                intended = "UP"
                dir = Direction.CALL
                stochFailure(s, Cross.UP, mode, notes)?.let { fails.add(it) }
                if (mode.requireAo) aoFailure(s, Trend.GREEN, mode, notes)?.let { fails.add(it) }
            }
            Trend.RED -> {
                intended = "DOWN"
                dir = Direction.PUT
                stochFailure(s, Cross.DOWN, mode, notes)?.let { fails.add(it) }
                if (mode.requireAo) aoFailure(s, Trend.RED, mode, notes)?.let { fails.add(it) }
            }
            Trend.UNKNOWN -> {
                intended = "NONE"
                fails.add("st_unknown")
            }
        }
        return Verdict(if (fails.isEmpty()) dir else null, fails, intended, mode, notes)
    }

    /**
     * Проверка AO. Строго: цвет последнего столбца = нужный. В лояльном режиме (БАЗОВЫЙ) цвет «не того» знака
     * допускается, если AO за последние 2 столбца идёт в нужную сторону (для CALL растёт, для PUT падает).
     * NaN в наклоне (не определён) — не проходит.
     */
    private fun aoFailure(s: Snapshot, want: Trend, mode: TradingMode, notes: MutableList<String>): String? {
        if (s.ao == want) return null
        if (mode.aoLenient && s.ao != Trend.UNKNOWN) {
            val moving = if (want == Trend.GREEN) s.aoSlope > 0f else s.aoSlope < 0f
            if (moving) {
                notes.add(if (want == Trend.GREEN) "ao_red_but_rising" else "ao_green_but_falling")
                return null
            }
        }
        return if (want == Trend.GREEN) "ao_not_green" else "ao_not_red"
    }

    private fun stochFailure(s: Snapshot, want: Cross, mode: TradingMode, notes: MutableList<String>): String? {
        val up = want == Cross.UP
        if (s.stochCross == Cross.NONE) {
            return when {
                mode.stochConflictAllowed -> "no_stoch_cross"
                up -> "no_stoch_cross_up"
                else -> "no_stoch_cross_down"
            }
        }
        if (s.stochCross != want) {
            if (mode.stochConflictAllowed) {
                notes.add("stoch_opposite_ignored")
                return null
            }
            return "stoch_cross_opposite"
        }
        val zoneOk = if (up) mode.callZoneOk(s.stochValue) else mode.putZoneOk(s.stochValue)
        if (zoneOk) return null
        return if (up) "stoch_cross_not_below_${mode.callZone.toInt()}"
        else "stoch_cross_not_above_${mode.putZone.toInt()}"
    }

    /** Итоговая строка статистики за период; счётчики обнуляются. */
    fun statsLine(periodSec: Long): String {
        val fails = failCounts.entries
            .sortedByDescending { it.value }
            .joinToString(" ") { "${it.key}=${it.value}" }
            .ifEmpty { "none" }
        val line = "STATS ${periodSec}s: mode=${lastMode?.name ?: "?"} frames=$framesTotal " +
            "live=$framesLive signals=$signals | $fails"
        failCounts.clear()
        framesTotal = 0
        framesLive = 0
        signals = 0
        return line
    }

    private fun fire(now: Long, mode: TradingMode): Direction? {
        val dir = pending
        val pauseMs = cooldownMs()
        state = EngineState.COOLDOWN
        cooldownUntil = now + pauseMs
        pending = null
        count = 0
        signals++
        LogRepository.addLog(
            "STATE: CONFIRMING -> COOLDOWN (signal ${dir?.name}, mode=${mode.name}, pause ${pauseMs / 1000}s)"
        )
        return dir
    }

    private fun reset() {
        state = EngineState.SCANNING
        pending = null
        count = 0
    }
}

/** Состояние для UI. Журнал вынесен в LogRepository. */
data class UiState(
    val running: Boolean = false,
    val cvReady: Boolean = true,
    val live: Boolean = true,
    val markers: Boolean = false,
    val accessibility: Boolean = false,
    val fps: Float = 0f,
    val superTrend: Trend = Trend.UNKNOWN,
    val stochCross: Cross = Cross.NONE,
    val stochValue: Float = Float.NaN,
    val ao: Trend = Trend.UNKNOWN,
    val body: Float = Float.NaN,
    val payout: Int = -1,
    val engine: EngineState = EngineState.SCANNING,
    val lastSignal: Direction? = null
)

object BotState {
    val state = MutableStateFlow(UiState())
}

/** Настройки (SharedPreferences). Координаты кнопок — доли ширины/высоты экрана. */
object BotPrefs {
    const val CALL_X = "call_x"
    const val CALL_Y = "call_y"
    const val PUT_X = "put_x"
    const val PUT_Y = "put_y"
    private const val AUTO = "auto_tap"
    private const val COOLDOWN = "cooldown_s"
    private const val MODE = "trading_mode"

    // Центры кнопок КУПИТЬ / ПРОДАТЬ на скриншоте 1080x2400: (308,1553) и (771,1553)
    private val defaults = mapOf(
        CALL_X to 0.285f, CALL_Y to 0.647f,
        PUT_X to 0.714f, PUT_Y to 0.647f
    )

    private fun sp(c: Context) = c.getSharedPreferences("tradebot", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float = sp(c).getFloat(key, defaults[key] ?: 0.5f)
    fun put(c: Context, key: String, v: Float) { sp(c).edit().putFloat(key, v).apply() }

    fun autoTap(c: Context): Boolean = sp(c).getBoolean(AUTO, false)
    fun setAutoTap(c: Context, v: Boolean) { sp(c).edit().putBoolean(AUTO, v).apply() }

    fun cooldownSec(c: Context): Int = sp(c).getInt(COOLDOWN, 60)
    fun setCooldownSec(c: Context, v: Int) { sp(c).edit().putInt(COOLDOWN, v).apply() }
    fun cooldownMs(c: Context): Long = cooldownSec(c) * 1000L

    /** Режим торговли; по умолчанию ТЕСТ. */
    fun tradingMode(c: Context): TradingMode {
        val name = sp(c).getString(MODE, null) ?: return TradingMode.TEST
        return try {
            TradingMode.valueOf(name)
        } catch (e: IllegalArgumentException) {
            TradingMode.TEST
        }
    }

    fun setTradingMode(c: Context, m: TradingMode) { sp(c).edit().putString(MODE, m.name).apply() }
}
