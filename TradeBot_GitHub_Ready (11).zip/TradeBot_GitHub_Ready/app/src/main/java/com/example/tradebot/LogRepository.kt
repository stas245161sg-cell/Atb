package com.example.tradebot

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Единый журнал приложения (Singleton). Хранит последние [MAX_LINES] строк в памяти,
 * чтобы не расти бесконечно. Потокобезопасен: addLog можно вызывать из любого потока.
 */
object LogRepository {

    private const val MAX_LINES = 100

    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs.asStateFlow()

    /** Добавляет строку вида `[HH:mm:ss] message`; старые записи сверх лимита удаляются. */
    fun addLog(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "[$time] $message"
        _logs.update { current -> (current + line).takeLast(MAX_LINES) }
    }
}
