package com.example.tradebot

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.flow.update
import kotlin.math.abs
import kotlin.math.roundToInt

/** Реальный размер экрана в пикселях (включая системные панели). */
@Suppress("DEPRECATION")
fun realScreenSize(ctx: Context): Pair<Int, Int> {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    return if (Build.VERSION.SDK_INT >= 30) {
        val b = wm.maximumWindowMetrics.bounds
        Pair(b.width(), b.height())
    } else {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        Pair(dm.widthPixels, dm.heightPixels)
    }
}

private class Marker(val view: TextView, val params: WindowManager.LayoutParams, val sizePx: Int) {
    /** Поправка между координатами окна и экрана (вырез, статус-бар); измеряется после первой отрисовки. */
    var offX = 0
    var offY = 0
}

/**
 * Плавающие маркеры CALL (▲) и PUT (▼): окна поверх других приложений (TYPE_ACCESSIBILITY_OVERLAY —
 * отдельное разрешение «поверх других окон» не нужно, достаточно включённой службы спец. возможностей).
 * Маркер перетаскивается пальцем; центр маркера после отпускания сохраняется как точка нажатия
 * (доли ширины/высоты экрана). Синяя ✓ скрывает маркеры.
 */
class OverlayMarkers(private val service: AccessibilityService) {

    private val wm = service.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = service.resources.displayMetrics.density
    private val slop = ViewConfiguration.get(service).scaledTouchSlop

    private var call: Marker? = null
    private var put: Marker? = null
    private var done: Marker? = null

    val isShown: Boolean get() = call != null

    fun show() {
        if (isShown) return
        val (sw, sh) = realScreenSize(service)
        try {
            call = addMarker(
                "▲", 0xCC22C55E.toInt(), 60,
                BotPrefs.get(service, BotPrefs.CALL_X) * sw,
                BotPrefs.get(service, BotPrefs.CALL_Y) * sh,
                onDropped = { cx, cy -> save(BotPrefs.CALL_X, BotPrefs.CALL_Y, cx, cy, sw, sh) }
            )
            put = addMarker(
                "▼", 0xCCEF4444.toInt(), 60,
                BotPrefs.get(service, BotPrefs.PUT_X) * sw,
                BotPrefs.get(service, BotPrefs.PUT_Y) * sh,
                onDropped = { cx, cy -> save(BotPrefs.PUT_X, BotPrefs.PUT_Y, cx, cy, sw, sh) }
            )
            done = addMarker(
                "✓", 0xCC4C8DFF.toInt(), 44,
                0.5f * sw, 0.70f * sh,
                onDropped = { _, _ -> },
                onTap = { hide() }
            )
        } catch (e: Exception) {
            LogRepository.addLog("Не удалось показать маркеры: ${e.message}")
            removeAll()
            return
        }
        BotState.state.update { it.copy(markers = true) }
        LogRepository.addLog("Маркеры показаны: ▲ на КУПИТЬ, ▼ на ПРОДАТЬ, затем нажмите ✓")
    }

    fun hide() {
        val wasShown = isShown
        removeAll()
        if (wasShown) {
            BotState.state.update { it.copy(markers = false) }
            LogRepository.addLog("Маркеры скрыты, позиции сохранены")
        }
    }

    private fun removeAll() {
        for (m in listOf(call, put, done)) {
            if (m != null) {
                try { wm.removeView(m.view) } catch (e: Exception) { /* уже удалено */ }
            }
        }
        call = null
        put = null
        done = null
    }

    private fun save(kx: String, ky: String, cx: Float, cy: Float, sw: Int, sh: Int) {
        BotPrefs.put(service, kx, (cx / sw).coerceIn(0f, 1f))
        BotPrefs.put(service, ky, (cy / sh).coerceIn(0f, 1f))
        LogRepository.addLog("Позиция сохранена: ${(cx / sw * 100).roundToInt()}% × ${(cy / sh * 100).roundToInt()}%")
    }

    private fun addMarker(
        label: String,
        color: Int,
        sizeDp: Int,
        centerX: Float,
        centerY: Float,
        onDropped: (Float, Float) -> Unit,
        onTap: (() -> Unit)? = null
    ): Marker {
        val size = (sizeDp * density).roundToInt()
        val tv = TextView(service).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
                setStroke((2 * density).roundToInt(), Color.WHITE)
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (centerX - size / 2f).roundToInt()
            y = (centerY - size / 2f).roundToInt()
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        val marker = Marker(tv, lp, size)
        tv.setOnTouchListener(DragListener(marker, onDropped, onTap))
        wm.addView(tv, lp)

        // После первой раскладки сверяем координаты окна с экранными и, если есть сдвиг, выравниваем
        tv.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                tv.viewTreeObserver.removeOnGlobalLayoutListener(this)
                val loc = IntArray(2)
                tv.getLocationOnScreen(loc)
                val dx = loc[0] - lp.x
                val dy = loc[1] - lp.y
                if (abs(dx) <= 200 && abs(dy) <= 200) {
                    marker.offX = dx
                    marker.offY = dy
                    if (dx != 0 || dy != 0) {
                        lp.x -= dx
                        lp.y -= dy
                        try { wm.updateViewLayout(tv, lp) } catch (e: Exception) { /* окно уже убрано */ }
                    }
                }
            }
        })
        return marker
    }

    private inner class DragListener(
        private val m: Marker,
        private val onDropped: (Float, Float) -> Unit,
        private val onTap: (() -> Unit)?
    ) : View.OnTouchListener {

        private var startX = 0
        private var startY = 0
        private var downRawX = 0f
        private var downRawY = 0f
        private var moved = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = m.params.x
                    startY = m.params.y
                    downRawX = e.rawX
                    downRawY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downRawX
                    val dy = e.rawY - downRawY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        m.params.x = startX + dx.roundToInt()
                        m.params.y = startY + dy.roundToInt()
                        try { wm.updateViewLayout(m.view, m.params) } catch (ex: Exception) { /* окно убрано */ }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        onDropped(
                            m.params.x + m.offX + m.sizePx / 2f,
                            m.params.y + m.offY + m.sizePx / 2f
                        )
                    } else {
                        onTap?.invoke()
                    }
                }
            }
            return true
        }
    }
}
