package com.example.tradebot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_CODE, res.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, i)
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0A0A0C.toInt()
        window.navigationBarColor = 0xFF1A1A20.toInt()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            TradeBotTheme {
                TradeBotScreen(
                    onStart = {
                        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        projectionLauncher.launch(mpm.createScreenCaptureIntent())
                    },
                    onStop = {
                        startService(
                            Intent(this, ScreenCaptureService::class.java)
                                .setAction(ScreenCaptureService.ACTION_STOP)
                        )
                    },
                    onOpenAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onToggleMarkers = { toggleMarkers() }
                )
            }
        }
    }

    private fun toggleMarkers() {
        val svc = TradingAccessibilityService.instance
        if (svc == null) {
            Toast.makeText(this, "Сначала включите службу спец. возможностей", Toast.LENGTH_LONG).show()
            return
        }
        if (svc.markersVisible) {
            svc.hideMarkers()
            return
        }
        svc.showMarkers()
        val launch = packageManager.getLaunchIntentForPackage(Roi.POCKET_PACKAGE)
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Pocket Option не найден — откройте его вручную", Toast.LENGTH_LONG).show()
        }
    }
}

// ======================= Модификаторы Glassmorphism =======================

/**
 * Стеклянная карточка: полупрозрачная заливка (белый, alpha 0.08), обводка 1.dp (белый, alpha 0.15),
 * скругление 24.dp, внутренний отступ 16.dp. clip стоит первым, чтобы заливка не выходила за скругление.
 */
fun Modifier.glassCard(): Modifier {
    val shape = RoundedCornerShape(24.dp)
    return this
        .clip(shape)
        .background(GlassFill)
        .border(1.dp, GlassBorder, shape)
        .padding(16.dp)
}

/** Плавное уменьшение до 0.95 при нажатии (пружина) — для всех кнопок и чипов. */
fun Modifier.pressScale(source: InteractionSource, pressedScale: Float = 0.95f): Modifier = composed {
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "pressScale"
    )
    Modifier.scale(s)
}

// ======================= Главный экран =======================

@Composable
private fun TradeBotScreen(
    onStart: () -> Unit,
    onStop: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onToggleMarkers: () -> Unit
) {
    val ctx = LocalContext.current
    val ui by BotState.state.collectAsState()

    var showLogDialog by remember { mutableStateOf(false) }
    var showCalibration by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(BotPrefs.tradingMode(ctx)) }
    var autoTap by remember { mutableStateOf(BotPrefs.autoTap(ctx)) }
    var cooldown by remember { mutableFloatStateOf(BotPrefs.cooldownSec(ctx).toFloat()) }
    val callPos = remember(ui.markers) { posText(ctx, BotPrefs.CALL_X, BotPrefs.CALL_Y) }
    val putPos = remember(ui.markers) { posText(ctx, BotPrefs.PUT_X, BotPrefs.PUT_Y) }

    AppBackground {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Шапка: красный механический глаз + название
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground),
                    contentDescription = null,
                    modifier = Modifier
                        .size(56.dp)
                        .shadow(14.dp, CircleShape, ambientColor = NeonRed, spotColor = NeonRed)
                        .clip(CircleShape)
                )
                Column(Modifier.padding(start = 14.dp)) {
                    Text("TradeBot", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "SuperTrend · Stochastic · AO",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Light
                    )
                }
            }

            GlassCard {
                SectionTitle("Статус")
                InfoRow("Захват экрана", if (ui.running) "ВКЛ" else "ВЫКЛ", if (ui.running) Positive else TextSecondary)
                InfoRow("Режим", mode.title, modeColor(mode))
                InfoRow("Кадров/с", ui.fps.fmt(0), TextPrimary)
                InfoRow(
                    "График",
                    if (ui.live) "на последней свече" else "прокручен — нажмите «>»",
                    if (ui.live) Positive else Negative
                )
                InfoRow("OpenCV", if (ui.cvReady) "готов" else "ошибка", if (ui.cvReady) Positive else Negative)
                InfoRow(
                    "Спец. возможности",
                    if (ui.accessibility) "подключены" else "не подключены",
                    if (ui.accessibility) Positive else Negative
                )
            }

            GlassCard {
                SectionTitle("Индикаторы")
                InfoRow("SuperTrend", trendText(ui.superTrend), trendColor(ui.superTrend))
                InfoRow("Stochastic 5,3,3", crossText(ui.stochCross, ui.stochValue), crossColor(ui.stochCross))
                InfoRow("AO 5,34", trendText(ui.ao), trendColor(ui.ao))
                InfoRow("Тело свечи", ui.body.fmt(2), if (ui.body < mode.maxBody) Positive else Negative)
                InfoRow(
                    "Payout",
                    if (ui.payout >= 0) "${ui.payout}%" else "—",
                    if (ui.payout >= mode.minPayout) Positive else Negative
                )
                InfoRow("Автомат", ui.engine.name, ElectricBlue)
                InfoRow(
                    "Последний сигнал",
                    ui.lastSignal?.name ?: "—",
                    when (ui.lastSignal) {
                        Direction.CALL -> Positive
                        Direction.PUT -> Negative
                        null -> TextSecondary
                    }
                )
            }

            GlassCard {
                SectionTitle("Управление")

                // Режим торговли: стилизованные Glass-кнопки (сохраняется в SharedPreferences, действует сразу)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TradingMode.values().forEach { m ->
                        GlassChip(
                            text = m.title,
                            selected = mode == m,
                            onClick = {
                                mode = m
                                BotPrefs.setTradingMode(ctx, m)
                            },
                            modifier = Modifier.weight(1f),
                            color = modeColor(m)
                        )
                    }
                }
                Text(
                    mode.hint,
                    color = if (mode == TradingMode.TEST) NeonRed else TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (ui.running) {
                        GlassButton(
                            text = "Остановить",
                            onClick = onStop,
                            modifier = Modifier.weight(1f).height(60.dp),
                            fontSize = 12.sp,
                            danger = true
                        )
                    } else {
                        NeonButton(
                            text = "Запросить захват и старт",
                            onClick = onStart,
                            modifier = Modifier.weight(1f).height(60.dp),
                            fontSize = 12.sp
                        )
                    }
                    GlassButton(
                        text = "Показать логи",
                        onClick = { showLogDialog = true },
                        modifier = Modifier.weight(1f).height(60.dp),
                        fontSize = 12.sp
                    )
                    GlassButton(
                        text = "Калибровка зон",
                        onClick = { showCalibration = true },
                        modifier = Modifier.weight(1f).height(60.dp),
                        fontSize = 12.sp
                    )
                }
                Box(Modifier.padding(top = 10.dp))
                GlassButton("Включить службу спец. возможностей", onOpenAccessibility)
                Row(
                    Modifier.fillMaxWidth().padding(top = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Автонажатие", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(
                            "Только демо-счёт. Выкл — только сигналы.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Light
                        )
                    }
                    HyperSwitch(
                        checked = autoTap,
                        onCheckedChange = { autoTap = it; BotPrefs.setAutoTap(ctx, it) }
                    )
                }
            }

            GlassCard {
                SectionTitle("Маркеры нажатия")
                Text(
                    "Перетащите зелёный ▲ на кнопку КУПИТЬ, красный ▼ — на ПРОДАТЬ, затем нажмите синюю ✓. " +
                        "Бот будет нажимать в точках, где вы оставили маркеры.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                InfoRow("CALL (КУПИТЬ)", callPos, Positive)
                InfoRow("PUT (ПРОДАТЬ)", putPos, Negative)
                Box(Modifier.padding(top = 10.dp))
                if (ui.markers) {
                    GlassButton(
                        text = "Скрыть маркеры и сохранить",
                        onClick = onToggleMarkers,
                        danger = true
                    )
                } else {
                    NeonButton(
                        text = "Показать маркеры и открыть Pocket Option",
                        onClick = onToggleMarkers
                    )
                }
            }

            GlassCard {
                SectionTitle("Параметры")
                LabeledSlider("Пауза после сигнала", cooldown, 10f..300f, "${cooldown.toInt()} с") {
                    cooldown = it; BotPrefs.setCooldownSec(ctx, it.toInt())
                }
            }
        }

        // Полноэкранный оверлей калибровки зон поверх всего интерфейса
        if (showCalibration) {
            CalibrationScreen(onClose = { showCalibration = false })
        }
    }

    if (showLogDialog) {
        LogDialog(onDismiss = { showLogDialog = false })
    }
}

// ======================= Окно журнала =======================

@Composable
private fun LogDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val logs by LogRepository.logs.collectAsState()
    val listState = rememberLazyListState()

    // Авто-скролл вниз при каждом обновлении (размер списка упирается в лимит, поэтому следим и за последней строкой)
    LaunchedEffect(logs.size, logs.lastOrNull()) {
        if (logs.isNotEmpty()) listState.scrollToItem(logs.lastIndex)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.82f)
                .shadow(16.dp, shape, ambientColor = NeonRed.copy(alpha = 0.5f), spotColor = NeonRed.copy(alpha = 0.5f))
                .clip(shape)
                .background(BgTop.copy(alpha = 0.9f))
                .border(1.dp, GlassBorder, shape)
                .padding(16.dp)
        ) {
            SectionTitle("Журнал анализа", fontSize = 20.sp)

            if (logs.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Text(
                        "Журнал пуст",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(logs) { line ->
                        Text(
                            text = line,
                            color = LogText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Light,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                NeonButton(
                    text = "Скопировать",
                    onClick = {
                        clipboardManager.setText(AnnotatedString(LogRepository.logs.value.joinToString("\n")))
                        Toast.makeText(ctx, "Логи скопированы", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f)
                )
                GlassButton(
                    text = "Закрыть",
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

// ======================= Компоненты Glassmorphism =======================

/** Карточка: glassCard() + плавное изменение размера при смене содержимого (animateContentSize). */
@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .glassCard(),
        content = content
    )
}

@Composable
private fun SectionTitle(text: String, fontSize: TextUnit = 16.sp) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(bottom = 8.dp)
    ) {
        Box(
            Modifier
                .width(3.dp)
                .height(16.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(NeonRed)
        )
        Text(
            text,
            color = TextPrimary,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Light)
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

/**
 * Главная кнопка: градиент от неоново-красного #FF2A2A к тёмно-красному, скругление 24.dp,
 * красное свечение (shadow) и пружинное уменьшение до 0.95 при нажатии.
 */
@Composable
private fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(),
    fontSize: TextUnit = 14.sp
) {
    val shape = RoundedCornerShape(24.dp)
    val source = remember { MutableInteractionSource() }
    Box(
        modifier = modifier
            .pressScale(source)
            .defaultMinSize(minHeight = 52.dp)
            .shadow(12.dp, shape = shape, ambientColor = NeonRed, spotColor = NeonRed)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(NeonRed, DeepRed)))
            .border(1.dp, Color.White.copy(alpha = 0.25f), shape)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Стеклянная кнопка (24.dp). danger = true — тёмное стекло с красной обводкой и слабым красным свечением
 * (используется для «Остановить» и «Скрыть маркеры»).
 */
@Composable
private fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(),
    fontSize: TextUnit = 14.sp,
    danger: Boolean = false
) {
    val shape = RoundedCornerShape(24.dp)
    val source = remember { MutableInteractionSource() }
    val fill = if (danger) Color.Black.copy(alpha = 0.45f) else GlassFill
    val stroke = if (danger) NeonRed else GlassBorder
    val glow = if (danger) Modifier.shadow(
        8.dp, shape, ambientColor = NeonRed.copy(alpha = 0.6f), spotColor = NeonRed.copy(alpha = 0.6f)
    ) else Modifier
    Box(
        modifier = modifier
            .pressScale(source)
            .defaultMinSize(minHeight = 52.dp)
            .then(glow)
            .clip(shape)
            .background(fill)
            .border(if (danger) 1.5.dp else 1.dp, stroke, shape)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = Color.White,
            fontSize = fontSize,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * Полупрозрачная «таблетка» (16.dp): режимы торговли и вкладки калибровки.
 * selected — заливка и обводка цвета [color] с плавной анимацией; floating — парящая (с мягкой тенью цвета).
 */
@Composable
private fun GlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = NeonRed,
    floating: Boolean = false
) {
    val shape = RoundedCornerShape(16.dp)
    val source = remember { MutableInteractionSource() }
    val bg by animateColorAsState(
        targetValue = if (selected) color.copy(alpha = 0.55f) else GlassFill,
        animationSpec = tween(220),
        label = "chipBg"
    )
    val stroke by animateColorAsState(
        targetValue = if (selected) color else GlassBorder,
        animationSpec = tween(220),
        label = "chipStroke"
    )
    val glow = if (floating) Modifier.shadow(
        10.dp, shape, ambientColor = color.copy(alpha = 0.45f), spotColor = color.copy(alpha = 0.45f)
    ) else Modifier
    Box(
        modifier = modifier
            .height(52.dp)
            .pressScale(source)
            .then(glow)
            .clip(shape)
            .background(bg)
            .border(1.dp, stroke, shape)
            .clickable(interactionSource = source, indication = null, onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) Color.White else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Light,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

/** Переключатель в стиле HyperOS: круглый бегунок, плавная анимация цвета и положения, активный цвет — неоново-красный. */
@Composable
private fun HyperSwitch(checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val track by animateColorAsState(
        targetValue = if (checked) NeonRed else Color.White.copy(alpha = 0.18f),
        animationSpec = tween(250),
        label = "switchTrack"
    )
    val thumbX by animateDpAsState(
        targetValue = if (checked) 25.dp else 3.dp,
        animationSpec = tween(250),
        label = "switchThumb"
    )
    Box(
        modifier = Modifier
            .width(52.dp)
            .height(30.dp)
            .clip(CircleShape)
            .background(track)
            .border(1.dp, GlassBorder, CircleShape)
            .toggleable(
                value = checked,
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                role = Role.Switch,
                onValueChange = onCheckedChange
            )
    ) {
        Box(
            Modifier
                .offset(x = thumbX, y = 3.dp)
                .size(24.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}

/** Ползунок в парящей полупрозрачной «таблетке» (16.dp): белый бегунок, неоново-красная активная дорожка. */
@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color.White.copy(alpha = 0.06f))
            .border(1.dp, GlassBorder, shape)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Light)
            Text(valueText, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = NeonRed,
                inactiveTrackColor = Color.White.copy(alpha = 0.18f)
            )
        )
    }
}

private fun modeColor(m: TradingMode): Color = when (m) {
    TradingMode.TEST -> NeonRed
    TradingMode.BASE -> ElectricBlue
    TradingMode.SAFE -> Positive
}

private fun trendText(t: Trend) = when (t) {
    Trend.GREEN -> "ЗЕЛЁНЫЙ"
    Trend.RED -> "КРАСНЫЙ"
    Trend.UNKNOWN -> "—"
}

private fun trendColor(t: Trend) = when (t) {
    Trend.GREEN -> Positive
    Trend.RED -> Negative
    Trend.UNKNOWN -> TextSecondary
}

private fun crossText(c: Cross, v: Float) = when (c) {
    Cross.UP -> "вверх (${v.fmt()})"
    Cross.DOWN -> "вниз (${v.fmt()})"
    Cross.NONE -> "нет"
}

private fun crossColor(c: Cross) = when (c) {
    Cross.UP -> Positive
    Cross.DOWN -> Negative
    Cross.NONE -> TextSecondary
}

private fun posText(ctx: Context, kx: String, ky: String): String =
    "${(BotPrefs.get(ctx, kx) * 100).roundToInt()}% × ${(BotPrefs.get(ctx, ky) * 100).roundToInt()}%"

// ======================= Калибровка зон (ROI) =======================

private enum class DragMode { NONE, MOVE, CORNER, DRAW }

private fun zoneColor(z: RoiZone): Color = when (z) {
    RoiZone.CHART -> ElectricBlue
    RoiZone.STOCH -> Color(0xFFF5A524)
    RoiZone.AO -> Positive
    RoiZone.PAYOUT -> NeonRed
}

/** Последний кадр, сохранённый сервисом захвата, пока на экране был Pocket Option. */
private fun loadLastFrame(ctx: Context): Pair<ImageBitmap?, Long> {
    val f = File(ctx.filesDir, Roi.LAST_FRAME_FILE)
    if (!f.exists()) return Pair(null, 0L)
    return try {
        Pair(BitmapFactory.decodeFile(f.path)?.asImageBitmap(), f.lastModified())
    } catch (e: Exception) {
        Pair(null, 0L)
    }
}

private fun pct(v: Float): Int = (v * 100).roundToInt()

@Composable
private fun CalibrationScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    // Рамки хранятся в долях экрана (0.0–1.0): пиксели касаний пересчитываются при каждом жесте,
    // поэтому «Сохранить» просто записывает готовые проценты в SharedPreferences
    val rects = remember {
        mutableStateMapOf<RoiZone, NormRect>().apply {
            RoiZone.values().forEach { put(it, RoiPrefs.load(ctx, it)) }
        }
    }
    var active by remember { mutableStateOf(RoiZone.CHART) }
    val (frame, frameTime) = remember { loadLastFrame(ctx) }
    val (screenW, screenH) = remember { realScreenSize(ctx) }
    val ratio = screenW.toFloat() / screenH.toFloat()

    AppBackground {
        Column(
            Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 8.dp)
        ) {
            // Вкладки зон — парящие полупрозрачные таблетки 16.dp
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                RoiZone.values().forEach { z ->
                    GlassChip(
                        text = z.title,
                        selected = active == z,
                        onClick = { active = z },
                        modifier = Modifier.weight(1f),
                        color = zoneColor(z),
                        floating = true
                    )
                }
            }

            val r = rects.getValue(active)
            Text(
                "${active.title}: x ${pct(r.left)}–${pct(r.right)}%, y ${pct(r.top)}–${pct(r.bottom)}%. " +
                    "Тяните за углы, двигайте рамку или обведите зону пальцем заново.",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Light,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            // Картинка размером с экран телефона (с сохранением пропорций) и рамки поверх неё
            BoxWithConstraints(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                val wDp = minOf(maxWidth, maxHeight * ratio)
                val hDp = wDp / ratio
                ZoneCanvas(
                    widthDp = wDp,
                    heightDp = hDp,
                    frame = frame,
                    rects = rects,
                    active = active
                )
            }

            if (frame == null) {
                Text(
                    "Скриншота пока нет: запустите захват, откройте Pocket Option на несколько секунд " +
                        "и вернитесь сюда — на фоне появится последний кадр.",
                    color = NeonRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(top = 8.dp)
                )
            } else if (frameTime > 0L) {
                val time = remember(frameTime) {
                    java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault())
                        .format(java.util.Date(frameTime))
                }
                Text(
                    "Скриншот от $time",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                GlassButton(
                    text = "Сбросить зону",
                    onClick = { rects[active] = RoiPrefs.default(active) },
                    modifier = Modifier.weight(1f).height(52.dp),
                    fontSize = 12.sp
                )
                GlassButton(
                    text = "Отмена",
                    onClick = onClose,
                    modifier = Modifier.weight(1f).height(52.dp),
                    fontSize = 12.sp
                )
                NeonButton(
                    text = "Сохранить",
                    onClick = {
                        RoiZone.values().forEach { z -> RoiPrefs.save(ctx, z, rects.getValue(z)) }
                        LogRepository.addLog("ROI сохранены (калибровка)")
                        Toast.makeText(ctx, "Зоны сохранены", Toast.LENGTH_SHORT).show()
                        onClose()
                    },
                    modifier = Modifier.weight(1f).height(52.dp),
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun ZoneCanvas(
    widthDp: Dp,
    heightDp: Dp,
    frame: ImageBitmap?,
    rects: MutableMap<RoiZone, NormRect>,
    active: RoiZone
) {
    val density = LocalDensity.current
    val widthPx = with(density) { widthDp.toPx() }
    val heightPx = with(density) { heightDp.toPx() }
    val hitRadius = with(density) { 32.dp.toPx() }
    val handleRadius = with(density) { 10.dp.toPx() }
    val minSize = 0.02f

    Box(
        Modifier
            .size(widthDp, heightDp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, GlassBorder, RoundedCornerShape(12.dp))
            .background(Color(0xFF14171D))
    ) {
        if (frame != null) {
            Image(
                bitmap = frame,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Заглушка: сетка через каждые 10% экрана
            Canvas(Modifier.fillMaxSize()) {
                for (i in 1..9) {
                    val x = size.width * i / 10f
                    val y = size.height * i / 10f
                    drawLine(Color.White.copy(alpha = 0.07f), Offset(x, 0f), Offset(x, size.height))
                    drawLine(Color.White.copy(alpha = 0.07f), Offset(0f, y), Offset(size.width, y))
                }
            }
        }

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(active) {
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    var mode = DragMode.NONE
                    var corner = 0
                    var anchorX = 0f
                    var anchorY = 0f

                    detectDragGestures(
                        onDragStart = { p ->
                            val r = rects.getValue(active)
                            val corners = arrayOf(
                                Offset(r.left * w, r.top * h),
                                Offset(r.right * w, r.top * h),
                                Offset(r.left * w, r.bottom * h),
                                Offset(r.right * w, r.bottom * h)
                            )
                            var best = -1
                            var bestDist = hitRadius
                            for (i in 0..3) {
                                val dist = (corners[i] - p).getDistance()
                                if (dist <= bestDist) {
                                    bestDist = dist
                                    best = i
                                }
                            }
                            if (best >= 0) {
                                mode = DragMode.CORNER
                                corner = best
                            } else if (p.x in (r.left * w)..(r.right * w) && p.y in (r.top * h)..(r.bottom * h)) {
                                mode = DragMode.MOVE
                            } else {
                                mode = DragMode.DRAW
                                anchorX = (p.x / w).coerceIn(0f, 1f)
                                anchorY = (p.y / h).coerceIn(0f, 1f)
                            }
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            val r = rects.getValue(active)
                            val fx = (change.position.x / w).coerceIn(0f, 1f)
                            val fy = (change.position.y / h).coerceIn(0f, 1f)
                            when (mode) {
                                DragMode.CORNER -> {
                                    var l = r.left
                                    var t = r.top
                                    var rr = r.right
                                    var b = r.bottom
                                    // углы: 0 = левый верхний, 1 = правый верхний, 2 = левый нижний, 3 = правый нижний
                                    if (corner == 0 || corner == 2) l = fx.coerceAtMost(rr - minSize)
                                    else rr = fx.coerceAtLeast(l + minSize)
                                    if (corner == 0 || corner == 1) t = fy.coerceAtMost(b - minSize)
                                    else b = fy.coerceAtLeast(t + minSize)
                                    rects[active] = NormRect(l, t, rr, b)
                                }
                                DragMode.MOVE -> {
                                    val wd = r.right - r.left
                                    val ht = r.bottom - r.top
                                    val nl = (r.left + drag.x / w).coerceIn(0f, 1f - wd)
                                    val nt = (r.top + drag.y / h).coerceIn(0f, 1f - ht)
                                    rects[active] = NormRect(nl, nt, nl + wd, nt + ht)
                                }
                                DragMode.DRAW -> {
                                    var l = minOf(anchorX, fx)
                                    var rr = maxOf(anchorX, fx)
                                    var t = minOf(anchorY, fy)
                                    var b = maxOf(anchorY, fy)
                                    if (rr - l < minSize) { rr = (l + minSize).coerceAtMost(1f); l = rr - minSize }
                                    if (b - t < minSize) { b = (t + minSize).coerceAtMost(1f); t = b - minSize }
                                    rects[active] = NormRect(l, t, rr, b)
                                }
                                DragMode.NONE -> Unit
                            }
                        },
                        onDragEnd = { mode = DragMode.NONE },
                        onDragCancel = { mode = DragMode.NONE }
                    )
                }
        ) {
            // Сначала неактивные зоны, активная — сверху
            RoiZone.values().sortedBy { it == active }.forEach { z ->
                val r = rects.getValue(z)
                val color = zoneColor(z)
                val isActive = z == active
                val topLeft = Offset(r.left * size.width, r.top * size.height)
                val rectSize = Size((r.right - r.left) * size.width, (r.bottom - r.top) * size.height)
                drawRect(color.copy(alpha = if (isActive) 0.28f else 0.10f), topLeft, rectSize)
                drawRect(
                    color.copy(alpha = if (isActive) 1f else 0.6f),
                    topLeft,
                    rectSize,
                    style = Stroke(width = (if (isActive) 3.dp else 1.5.dp).toPx())
                )
                if (isActive) {
                    listOf(
                        topLeft,
                        Offset(topLeft.x + rectSize.width, topLeft.y),
                        Offset(topLeft.x, topLeft.y + rectSize.height),
                        Offset(topLeft.x + rectSize.width, topLeft.y + rectSize.height)
                    ).forEach { c ->
                        drawCircle(Color.White, handleRadius, c)
                        drawCircle(color, handleRadius * 0.6f, c)
                    }
                }
            }
        }

        // Подписи зон
        RoiZone.values().forEach { z ->
            val r = rects.getValue(z)
            Text(
                z.title,
                color = zoneColor(z),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.offset {
                    IntOffset((r.left * widthPx).roundToInt() + 6, (r.top * heightPx).roundToInt() + 4)
                }
            )
        }
    }
}
