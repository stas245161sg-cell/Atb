package com.apex.protocol

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.imgproc.Imgproc
import java.io.Closeable
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Результат анализа одного кадра для стратегии Fibonacci 14.6%.
 *
 * highs / lows — Y-координаты экстремумов последних [Roi.CANDLES_TO_COLLECT] закрытых свечей
 * (Y растёт вниз: меньше Y = выше цена). Массивы в хронологическом порядке:
 * последний элемент — самая свежая свеча.
 * closeY / isGreen относятся к последней свече.
 */
data class Snapshot(
    val highs: FloatArray,
    val lows: FloatArray,
    val closeY: Float,
    val isGreen: Boolean,
    val body: Float,
    val payout: Int,
    val live: Boolean = true,
    val chartNote: String = ""
)

// ======================= Зоны интереса (ROI) =======================

/** Зоны, которые пользователь выставляет на экране калибровки. */
enum class RoiZone(val key: String, val title: String) {
    CHART("chart", "График"),
    PAYOUT("payout", "Выплата")
}

/** Прямоугольник в долях экрана: 0.0 = левый/верхний край, 1.0 = правый/нижний. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Хранение зон в SharedPreferences: roi_chart_left, roi_chart_top, roi_chart_right, roi_chart_bottom,
 * roi_payout_*. Значения по умолчанию — раскладка Pocket Option 1080x2400.
 */
object RoiPrefs {
    private const val FILE = "apex_protocol"
    private const val MIN_SIZE = 0.01f

    fun default(zone: RoiZone): NormRect = when (zone) {
        RoiZone.CHART -> NormRect(0.00f, 0.110f, 1.00f, 0.530f)
        RoiZone.PAYOUT -> NormRect(0.20f, 0.646f, 0.37f, 0.672f)
    }

    fun load(ctx: Context, zone: RoiZone): NormRect {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = default(zone)
        val p = "roi_${zone.key}_"
        val r = NormRect(
            sp.getFloat(p + "left", d.left),
            sp.getFloat(p + "top", d.top),
            sp.getFloat(p + "right", d.right),
            sp.getFloat(p + "bottom", d.bottom)
        )
        return if (isValid(r)) r else d
    }

    fun save(ctx: Context, zone: RoiZone, r: NormRect) {
        val fixed = if (isValid(r)) r else default(zone)
        val p = "roi_${zone.key}_"
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(p + "left", fixed.left)
            .putFloat(p + "top", fixed.top)
            .putFloat(p + "right", fixed.right)
            .putFloat(p + "bottom", fixed.bottom)
            .apply()
    }

    private fun isValid(r: NormRect): Boolean =
        r.left >= 0f && r.top >= 0f && r.right <= 1f && r.bottom <= 1f &&
            r.right - r.left >= MIN_SIZE && r.bottom - r.top >= MIN_SIZE
}

/** Константы анализаFibonacci 14.6%. */
object Roi {
    const val POCKET_PACKAGE = "com.pocketoption.broker"
    const val LAST_FRAME_FILE = "last_frame.jpg"   // последний кадр с графиком — фон экрана калибровки

    /** Сколько закрытых свечей собираем: 20 × M5 ≈ 100 минут истории. */
    const val CANDLES_TO_COLLECT = 20

    // Гистерезис прокрутки: сравнение идёт с правой границей зоны ROI (а не экрана),
    // причём вход и выход пороги разные — иначе состояние дёргается на границе.
    const val LIVE_EDGE_SCROLLED = 0.97f   // край данных дошёл до 97% зоны → прокручен
    const val LIVE_EDGE_LIVE = 0.90f       // край ушёл левее 90% зоны → снова на последней свече

    // Свеча: максимальная ширина — доля ширины кадра (для 1080 px ≈ 43 px).
    const val CANDLE_MAX_WIDTH = 0.04f
    const val MAX_ANALYSIS_WIDTH = 1080 // кадры шире уменьшаются до этой ширины перед анализом
}

/** Цвета в HSV OpenCV (H 0..179, S/V 0..255), замеры по скриншотам. */
object Hsv {
    // Общие маски свечей. Свеча вверх (70,183,52) H≈56; красная свеча (255,62,31) H≈4.
    val GREEN_LO = Scalar(30.0, 80.0, 80.0)
    // 72, а не 90: зелёная свеча H≈56, бирюзовая линия SuperTrend H≈84–90.
    // Старый порог 90 захватывал линию тренда как «зелёную свечу» и портил High/Low.
    val GREEN_HI = Scalar(72.0, 255.0, 255.0)
    val RED1_LO = Scalar(0.0, 80.0, 80.0)
    val RED1_HI = Scalar(10.0, 255.0, 255.0)
    val RED2_LO = Scalar(170.0, 80.0, 80.0)
    val RED2_HI = Scalar(180.0, 255.0, 255.0)
}

/** Собирает все временные Mat и освобождает их разом (важно на 30 FPS). */
private class Mats : Closeable {
    private val list = ArrayList<Mat>()
    fun <T : Mat> keep(m: T): T {
        list.add(m)
        return m
    }
    fun mat(): Mat = keep(Mat())
    override fun close() {
        list.forEach { it.release() }
        list.clear()
    }
}

/** Пиксельные границы зоны внутри кадра. */
private class Box(val r0: Int, val r1: Int, val c0: Int, val c1: Int)

/** Измеренная свеча: экстремумы, тело, цвет и Y закрытия. */
private class CandleInfo(
    val topY: Int,
    val bottomY: Int,
    val bodyTopY: Int,
    val bodyBottomY: Int,
    val green: Boolean,
    val body: Float,
    val closeY: Float,
    val rightX: Int
)

private class ChartResult(val live: Boolean, val candles: List<CandleInfo>, val note: String = "")

class ImageAnalyzer(context: Context) : Closeable {

    private companion object {
        const val TAG = "ImageAnalyzer"
        const val OCR_INTERVAL_MS = 600L
        const val PAYOUT_TTL_MS = 10_000L
        const val LIVE_DEBOUNCE_MS = 1_000L
        const val OCR_UPSCALE = 3
        const val OCR_LOG_HEARTBEAT_MS = 30_000L
        const val OCR_ERR_LOG_MS = 10_000L
        const val ROI_RELOAD_MS = 2_000L

        // Только число ПЕРЕД знаком %: деньги ($9,600) и таймеры в строке больше не misinterpreted.
        val PAYOUT_REGEX = Regex("(\\d{2,3})\\s*%")
        const val PAYOUT_MIN = 50
        const val PAYOUT_MAX = 99
    }

    private val appContext: Context = context.applicationContext

    private val cvReady: Boolean = try {
        OpenCVLoader.initDebug()
    } catch (t: Throwable) {
        Log.e(TAG, "OpenCV init failed", t)
        false
    }
    val ready: Boolean get() = cvReady

    /** Причина последней ошибки анализа кадра (для журнала). */
    @Volatile var lastError: String? = null
        private set

    // Зоны читаются из SharedPreferences при создании анализатора (каждый запуск захвата)
    // и затем перечитываются раз в 2 секунды — калибровка действует без перезапуска.
    private var rois: Map<RoiZone, NormRect> = loadRois()
    private var roisLoadedAt = SystemClock.elapsedRealtime()
    private var lastResizeScale = 1f

    // Гистерезис прокрутки: состояние меняется не чаще раза в секунду
    @Volatile private var liveState = true
    private var liveChangedAt = 0L

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val ocrBusy = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastOcrLogKey = ""
    private var lastOcrLogAt = 0L
    private var lastOcrErrAt = 0L
    @Volatile private var payout = -1
    @Volatile private var payoutAt = 0L

    init {
        LogRepository.addLog("ROI: ${describeRois(rois)}")
    }

    private fun loadRois(): Map<RoiZone, NormRect> =
        RoiZone.values().associateWith { RoiPrefs.load(appContext, it) }

    private fun refreshRois(now: Long) {
        if (now - roisLoadedAt < ROI_RELOAD_MS) return
        roisLoadedAt = now
        val fresh = loadRois()
        if (fresh != rois) {
            rois = fresh
            LogRepository.addLog("ROI обновлены: ${describeRois(fresh)}")
        }
    }

    private fun describeRois(map: Map<RoiZone, NormRect>): String =
        map.entries.joinToString(" ") { (zone, r) ->
            "${zone.key}=x${pct(r.left)}-${pct(r.right)} y${pct(r.top)}-${pct(r.bottom)}"
        }

    private fun pct(v: Float): Int = (v * 100).roundToInt()

    fun analyze(bmp: Bitmap): Snapshot? {
        if (!cvReady) return null
        var scaled: Bitmap? = null
        return try {
            refreshRois(SystemClock.elapsedRealtime())
            requestPayoutOcr(bmp)                 // OCR — по исходному кадру (качество выше)

            // Все вычисления OpenCV — на копии шириной не больше 1080 px.
            scaled = downscaleIfNeeded(bmp)
            val work = scaled ?: bmp

            Mats().use { m ->
                val rgba = m.mat()
                Utils.bitmapToMat(work, rgba)
                val rgb = m.mat()
                Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
                val hsv = m.mat()
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
                val frameW = hsv.cols()
                val frameH = hsv.rows()

                val chart = chart(hsv, frameW, frameH, m)
                if (!chart.live) {
                    return@use Snapshot(
                        FloatArray(0), FloatArray(0), Float.NaN, false,
                        Float.NaN, currentPayout(), live = false
                    )
                }

                val highs = FloatArray(chart.candles.size) { chart.candles[it].topY.toFloat() }
                val lows = FloatArray(chart.candles.size) { chart.candles[it].bottomY.toFloat() }
                val last = chart.candles.lastOrNull()
                Snapshot(
                    highs = highs,
                    lows = lows,
                    closeY = last?.closeY ?: Float.NaN,
                    isGreen = last?.green ?: false,
                    body = last?.body ?: Float.NaN,
                    payout = currentPayout(),
                    chartNote = chart.note
                )
            }
        } catch (t: Throwable) {
            Log.e(TAG, "analyze failed", t)
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            null
        } finally {
            scaled?.recycle()
        }
    }

    /** Кадр шире 1080 px уменьшается до ровно 1080 px по ширине (высота пропорционально); иначе null. */
    private fun downscaleIfNeeded(bmp: Bitmap): Bitmap? {
        if (bmp.width <= Roi.MAX_ANALYSIS_WIDTH) {
            lastResizeScale = 1f
            return null
        }
        val scale = Roi.MAX_ANALYSIS_WIDTH.toFloat() / bmp.width
        val height = (bmp.height * scale).roundToInt().coerceAtLeast(1)
        if (abs(scale - lastResizeScale) > 0.001f) {
            lastResizeScale = scale
            LogRepository.addLog("image_resized(scale=${String.format(Locale.US, "%.2f", scale)})")
        }
        return Bitmap.createScaledBitmap(bmp, Roi.MAX_ANALYSIS_WIDTH, height, true)
    }

    // ---------- вспомогательные ----------

    /** Пиксельные границы зоны; доли берутся из сохранённой калибровки. */
    private fun box(hsv: Mat, r: NormRect): Box {
        val r0 = (hsv.rows() * r.top).toInt().coerceIn(0, hsv.rows() - 1)
        val r1 = (hsv.rows() * r.bottom).toInt().coerceIn(r0 + 1, hsv.rows())
        val c0 = (hsv.cols() * r.left).toInt().coerceIn(0, hsv.cols() - 1)
        val c1 = (hsv.cols() * r.right).toInt().coerceIn(c0 + 1, hsv.cols())
        return Box(r0, r1, c0, c1)
    }

    /**
     * submat()/colRange()/rowRange() создают новый Mat-хендлер с общими данными.
     * Регистрируем его в пуле кадра: без этого на 30 FPS хендлер живёт до GC.
     */
    private fun Mat.crop(b: Box, m: Mats): Mat = m.keep(submat(b.r0, b.r1, b.c0, b.c1))

    private fun greenMask(src: Mat, m: Mats): Mat {
        val out = m.mat()
        Core.inRange(src, Hsv.GREEN_LO, Hsv.GREEN_HI, out)
        return out
    }

    private fun redMask(src: Mat, m: Mats): Mat {
        val a = m.mat()
        val b = m.mat()
        Core.inRange(src, Hsv.RED1_LO, Hsv.RED1_HI, a)
        Core.inRange(src, Hsv.RED2_LO, Hsv.RED2_HI, b)
        Core.bitwise_or(a, b, a)
        return a
    }

    /** Индекс самой правой колонки, где есть хотя бы [minPixels] пикселей маски; -1 если пусто. */
    private fun lastColoredColumn(mask: Mat, m: Mats, minPixels: Int = 2): Int {
        val sums = m.mat()
        Core.reduce(mask, sums, 0, Core.REDUCE_SUM, CvType.CV_32S)
        val arr = IntArray(mask.cols())
        sums.get(0, 0, arr)
        var x = arr.size - 1
        while (x >= 0 && arr[x] < 255 * minPixels) x--
        return x
    }

    /** Мелкий мусор (остатки краёв): компоненты уже ~3 px и ниже ~6 px в масштабе кадра 540 px. */
    private fun removeSpecks(g: Mat, r: Mat, all: Mat, frameW: Int, m: Mats) {
        val s = frameW / 540f
        val minW = maxOf(2, (3f * s).roundToInt())
        val minH = maxOf(3, (6f * s).roundToInt())

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val junk = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            if (st[i * 5 + 2] < minW && st[i * 5 + 3] < minH) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(junk, one, junk)
                found = true
            }
        }
        if (!found) return
        val inverse = m.mat()
        Core.bitwise_not(junk, inverse)
        Core.bitwise_and(g, inverse, g)
        Core.bitwise_and(r, inverse, r)
        Core.bitwise_or(g, r, all)
    }

    // ---------- График: сбор 20 закрытых свечей ----------

    private fun chart(hsv: Mat, frameW: Int, frameH: Int, m: Mats): ChartResult {
        val b = box(hsv, rois.getValue(RoiZone.CHART))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        removeSpecks(g, r, all, frameW, m)

        // Правый край данных сравнивается с правой границей зоны ROI (а не экрана),
        // с гистерезисом 0.90/0.97 и задержкой 1 с — иначе состояние дёргается каждый кадр.
        val end = lastColoredColumn(all, m)
        if (end < 0) return ChartResult(true, emptyList(), "no_colored_pixels_in_chart_roi")
        val roiW = (b.c1 - b.c0).coerceAtLeast(1)
        val edge = end.toFloat() / roiW
        val now = SystemClock.elapsedRealtime()
        if (now - liveChangedAt >= LIVE_DEBOUNCE_MS) {
            when {
                !liveState && edge <= Roi.LIVE_EDGE_LIVE -> {
                    liveState = true
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: на последней свече (edge=${pct(edge)}%)")
                }
                liveState && edge >= Roi.LIVE_EDGE_SCROLLED -> {
                    liveState = false
                    liveChangedAt = now
                    LogRepository.addLog("LIVE: прокручен (edge=${pct(edge)}%)")
                }
            }
        }
        if (!liveState) return ChartResult(false, emptyList())

        val candles = collectCandles(all, g, r, null, frameW, m)
        val note = when {
            candles.isEmpty() -> "no_candles_found"
            candles.size < Roi.CANDLES_TO_COLLECT -> "candles=${candles.size}/${Roi.CANDLES_TO_COLLECT}"
            else -> ""
        }
        return ChartResult(true, candles, note)
    }

    /**
     * Собирает до [Roi.CANDLES_TO_COLLECT] правых связных компонент (свечей) из общей маски.
     * Для каждой свечи находим экстремумы (верхний/нижний пиксель), тело и цвет по зелёной/красной маске.
     */
    private fun collectCandles(
        all: Mat,
        g: Mat,
        r: Mat,
        labels: Mat?,
        frameW: Int,
        m: Mats
    ): List<CandleInfo> {
        val lab = labels ?: m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, lab, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return emptyList()
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val maxAllowedWidth = (frameW * Roi.CANDLE_MAX_WIDTH).toInt()
        val minH = maxOf(8, (8f * frameW / 540f).roundToInt())

        // Отсекаем кляксы и вертикальные ступеньки линии тренда:
        // высота ≥ 8px, ширина 3..maxAllowedWidth, заполненность ≥ 30%.
        val picked = (1 until n)
            .filter {
                val w = st[it * 5 + 2]
                val h = st[it * 5 + 3]
                val area = st[it * 5 + 4]
                w in 3..maxAllowedWidth && h >= minH && area.toFloat() >= 0.3f * w * h
            }
            .sortedByDescending { st[it * 5] + st[it * 5 + 2] }
            .take(Roi.CANDLES_TO_COLLECT)

        val out = ArrayList<CandleInfo>(picked.size)
        for (i in picked) {
            val c = measureCandle(lab, g, r, i, st, m) ?: continue
            out.add(c)
        }
        // Переворачиваем: массив должен идти от старой свечи к новой
        return out.asReversed()
    }

    /** Измеряет одну связную компоненту: High/Low, тело, цвет и Y цены закрытия. */
    private fun measureCandle(
        labels: Mat,
        g: Mat,
        r: Mat,
        idx: Int,
        st: IntArray,
        m: Mats
    ): CandleInfo? {
        val x = st[idx * 5]
        val y = st[idx * 5 + 1]
        val w = st[idx * 5 + 2]
        val h = st[idx * 5 + 3]
        if (w < 1 || h < 2) return null

        val cols = labels.cols()
        val lab = IntArray(labels.rows() * cols)
        labels.get(0, 0, lab)

        val rowCounts = IntArray(h)
        for (yy in y until y + h) {
            var count = 0
            val base = yy * cols
            for (xx in x until x + w) if (lab[base + xx] == idx) count++
            rowCounts[yy - y] = count
        }
        val maxRow = rowCounts.maxOrNull() ?: 0
        if (maxRow < 4) return null

        val threshold = maxOf(3, (0.5f * maxRow).roundToInt())
        var bodyTop = -1
        var bodyBot = -1
        for (i in rowCounts.indices) {
            if (rowCounts[i] >= threshold) {
                if (bodyTop < 0) bodyTop = i
                bodyBot = i
            }
        }
        if (bodyTop < 0) return null

        // Цвет свечи считаем по телу: у зелёной тело зелёное, у красной — красное.
        val gBody = m.keep(g.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val rBody = m.keep(r.submat(y + bodyTop, y + bodyBot + 1, x, x + w))
        val green = Core.countNonZero(gBody) > Core.countNonZero(rBody)

        val body = ((bodyBot - bodyTop + 1).toFloat() / h).coerceIn(0f, 1f)
        // Закрытие: у зелёной свечи — верх тела (меньший Y), у красной — низ тела (больший Y).
        val closeY = (if (green) y + bodyTop else y + bodyBot).toFloat()
        return CandleInfo(y, y + h - 1, y + bodyTop, y + bodyBot, green, body, closeY, x + w)
    }

    // ---------- Payout через ML Kit OCR + строгая регулярка ----------

    private fun requestPayoutOcr(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOcrAt < OCR_INTERVAL_MS) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now
        try {
            val zone = rois.getValue(RoiZone.PAYOUT)
            val x0 = (bmp.width * zone.left).toInt().coerceIn(0, bmp.width - 2)
            val x1 = (bmp.width * zone.right).toInt().coerceIn(x0 + 1, bmp.width)
            val y0 = (bmp.height * zone.top).toInt().coerceIn(0, bmp.height - 2)
            val y1 = (bmp.height * zone.bottom).toInt().coerceIn(y0 + 1, bmp.height)
            val crop = Bitmap.createBitmap(bmp, x0, y0, x1 - x0, y1 - y0)
            val scaled = Bitmap.createScaledBitmap(
                crop, crop.width * OCR_UPSCALE, crop.height * OCR_UPSCALE, true
            )
            if (scaled !== crop) crop.recycle()

            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val raw = text.text.replace('\n', ' ').trim().take(40)
                    val extracted = extractPayout(raw)
                    val nowMs = SystemClock.elapsedRealtime()
                    if (extracted != null) {
                        payout = extracted
                        payoutAt = nowMs
                    }
                    val key = "$raw|$extracted"
                    if (key != lastOcrLogKey || nowMs - lastOcrLogAt >= OCR_LOG_HEARTBEAT_MS) {
                        lastOcrLogKey = key
                        lastOcrLogAt = nowMs
                        LogRepository.addLog("OCR RAW: '$raw' -> EXTRACTED: ${extracted ?: "null"}")
                    }
                }
                .addOnFailureListener { err ->
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastOcrErrAt >= OCR_ERR_LOG_MS) {
                        lastOcrErrAt = nowMs
                        LogRepository.addLog("OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    ocrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "ocr failed", t)
            ocrBusy.set(false)
        }
    }

    /**
     * Строгий разбор: берём только число перед '%' ('KYIVTb 92%', '+929%'),
     * возвращаем первое значение в диапазоне 50..99; деньги и таймеры без '%' игнорируются.
     */
    private fun extractPayout(raw: String): Int? {
        for (match in PAYOUT_REGEX.findAll(raw)) {
            val run = match.groupValues[1]
            if (run.length == 2) {
                val v = run.toIntOrNull() ?: continue
                if (v in PAYOUT_MIN..PAYOUT_MAX) return v
            } else {
                // OCR часто склеивает '92%' в '929%' — пробуем первые и последние 2 цифры
                val first = run.take(2).toIntOrNull()
                val last = run.takeLast(2).toIntOrNull()
                if (first != null && first in PAYOUT_MIN..PAYOUT_MAX) return first
                if (last != null && last in PAYOUT_MIN..PAYOUT_MAX) return last
            }
        }
        return null
    }

    private fun currentPayout(): Int =
        if (SystemClock.elapsedRealtime() - payoutAt > PAYOUT_TTL_MS) -1 else payout

    override fun close() {
        try { recognizer.close() } catch (ignored: Throwable) {}
    }
}
