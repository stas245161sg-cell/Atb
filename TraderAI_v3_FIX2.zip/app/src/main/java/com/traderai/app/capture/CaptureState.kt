package com.traderai.app.capture

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object CaptureState {
    private val _status = MutableStateFlow("Ожидание разрешения")
    val status = _status.asStateFlow()
    private val _analysis = MutableStateFlow("Нет анализа")
    val analysis = _analysis.asStateFlow()
    fun status(v: String) { _status.value = v }
    fun analysis(v: String) { _analysis.value = v }
}
