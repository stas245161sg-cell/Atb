package com.traderai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object TraderColors {
    val Background = Color(0xFF070A10)
    val Surface = Color(0xFF111824)
    val Border = Color(0xFF29384B)
    val Text = Color(0xFFF2F5FA)
    val Muted = Color(0xFF8997AA)
    val Cyan = Color(0xFF55DDE0)
    val Green = Color(0xFF9BEA45)
    val Red = Color(0xFFFF6B5E)
    val Yellow = Color(0xFFFFD34E)
}

private val Dark = darkColorScheme(
    primary = TraderColors.Cyan,
    secondary = TraderColors.Green,
    background = TraderColors.Background,
    surface = TraderColors.Surface,
    onPrimary = TraderColors.Background,
    onBackground = TraderColors.Text,
    onSurface = TraderColors.Text
)

@Composable
fun TraderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Dark, content = content)
}
