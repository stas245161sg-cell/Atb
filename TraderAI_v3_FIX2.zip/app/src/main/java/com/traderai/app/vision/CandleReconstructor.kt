package com.traderai.app.vision

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class ReconstructionResult(
    val candles: List<Candle>,
    val confidence: Float,
    val priceScaleValid: Boolean,
    val warnings: List<String>
)

class CandleReconstructor {

    private data class Hsv(val h: Float, val s: Float, val v: Float)

    private data class ColumnBody(
        val x: Int, val top: Int, val bottom: Int, val bullish: Boolean
    )

    private data class Group(
        val columns: List<ColumnBody>
    ) {
        val left get() = columns.minOf { it.x }
        val right get() = columns.maxOf { it.x }
        val centerX get() = (left + right) / 2f
        val top get() = columns.minOf { it.top }
        val bottom get() = columns.maxOf { it.bottom }
        val bullish get() = columns.count { it.bullish } >= columns.size / 2
    }

    private data class Scale(
        val intercept: Double, val slope: Double, val r2: Double
    ) {
        fun priceAt(y: Double): Double = intercept + slope * y
    }

    private fun hsv(color: Int): Hsv {
        val r = Color.red(color) / 255f
        val g = Color.green(color) / 255f
        val b = Color.blue(color) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        var h = 0f
        if (d != 0f) {
            h = when (mx) {
                r -> 60f * (((g - b) / d) % 6f)
                g -> 60f * (((b - r) / d) + 2f)
                else -> 60f * (((r - g) / d) + 4f)
            }
        }
        if (h < 0f) h += 360f
        return Hsv(h, if (mx == 0f) 0f else d / mx, mx)
    }

    private fun isBull(c: Int): Boolean {
        val v = hsv(c)
        return ColorProfile.CANDLE_BULL.contains(v.h, v.s, v.v)
    }

    private fun isBear(c: Int): Boolean {
        val v = hsv(c)
        return ColorProfile.CANDLE_BEAR.contains(v.h, v.s, v.v)
    }

    private fun calibrate(labels: List<PriceLabel>): Scale? {
        if (labels.size < 2) return null
        val pts = labels.distinctBy { (it.centerY / 10).toInt() }
            .sortedBy { it.centerY }
        if (pts.size < 2) return null
        val ys = pts.map { it.centerY.toDouble() }
        val ps = pts.map { it.price }
        val my = ys.average()
        val mp = ps.average()
        val den = ys.sumOf { (it - my) * (it - my) }
        if (den <= 0.0) return null
        val slope = ys.indices.sumOf { (ys[it] - my) * (ps[it] - mp) } / den
        if (!slope.isFinite() || abs(slope) < 1e-12) return null
        val intercept = mp - slope * my
        val total = ps.sumOf { (it - mp) * (it - mp) }
        val residual = pts.indices.sumOf {
            val diff = ps[it] - (intercept + slope * ys[it])
            diff * diff
        }
        val r2 = if (total <= 1e-18) 0.0 else 1.0 - residual / total
        if (!r2.isFinite() || r2 < 0.90) return null
        if (pts.last().centerY - pts.first().centerY < 25f) return null
        return Scale(intercept, slope, r2)
    }

    private fun columns(bitmap: Bitmap, rect: IntRect): List<ColumnBody> {
        val result = mutableListOf<ColumnBody>()
        for (x in rect.left until rect.right) {
            var best: ColumnBody? = null
            var start = -1
            var color: Boolean? = null
            for (y in rect.top until rect.bottom) {
                val px = bitmap.getPixel(x, y)
                val bull = isBull(px)
                val bear = isBear(px)
                val cur = when { bull && !bear -> true; bear && !bull -> false; else -> null }
                if (cur == null) {
                    if (start >= 0 && color != null && y - start >= 3) {
                        val candidate = ColumnBody(x, start, y - 1, color)
                        if (best == null || candidate.bottom - candidate.top > best.bottom - best.top) best = candidate
                    }
                    start = -1; color = null; continue
                }
                if (color == null) { start = y; color = cur }
            }
            if (start >= 0 && color != null && rect.bottom - start >= 3) {
                val candidate = ColumnBody(x, start, rect.bottom - 1, color)
                if (best == null || candidate.bottom - candidate.top > best.bottom - best.top) best = candidate
            }
            best?.let { result += it }
        }
        return result
    }

    private fun groups(list: List<ColumnBody>, width: Int): List<Group> {
        if (list.isEmpty()) return emptyList()
        val maxGap = max(2, width / 180)
        val sorted = list.sortedBy { it.x }
        val out = mutableListOf<Group>()
        var current = mutableListOf<ColumnBody>()
        for (c in sorted) {
            if (current.isEmpty()) { current += c; continue }
            val prev = current.last()
            if (c.x - prev.x <= maxGap + 1 && c.bullish == prev.bullish) {
                current += c
            } else {
                out += Group(current)
                current = mutableListOf(c)
            }
        }
        if (current.isNotEmpty()) out += Group(current)
        return out.filter {
            val w = it.right - it.left + 1
            w in 3..32 && it.bottom - it.top >= 3
        }
    }

    fun reconstruct(bitmap: Bitmap, ocr: OcrResult, now: Long = System.currentTimeMillis()): ReconstructionResult {
        val warnings = mutableListOf<String>()
        val scale = calibrate(ocr.priceLabels)
        if (scale == null) {
            return ReconstructionResult(emptyList(), 0f, false, listOf("Ценовая шкала не откалибрована"))
        }
        val timer = ocr.secondsRemaining ?: return ReconstructionResult(
            emptyList(), 0f, true, listOf("Нет достоверного таймера M5")
        )

        val chart = ScreenZones.CHART.toPixels(bitmap.width, bitmap.height)
        val occlusion = ScreenZones.LEFT_OCCLUSION.toPixels(bitmap.width, bitmap.height)
        val marker = ScreenZones.TRADE_MARKER.toPixels(bitmap.width, bitmap.height)

        val scan = IntRect(max(chart.left, occlusion.right), chart.top, chart.right, chart.bottom)
        val found = groups(columns(bitmap, scan), scan.width)
            .filter { !(it.centerX >= marker.left && it.centerX <= marker.right &&
                    it.top >= marker.top && it.bottom <= marker.bottom) }

        if (found.size < 10) warnings += "Мало тел свечей: ${found.size}"
        if (found.size > 80) warnings += "Слишком много групп: возможны помехи"

        val estimated = now - ((300 - timer).coerceIn(0, 300) * 1000L)
        val currentOpen = (estimated / 300_000L) * 300_000L
        val ordered = found.sortedBy { it.centerX }
        val candles = mutableListOf<Candle>()

        ordered.forEachIndexed { index, g ->
            val openY = if (g.bullish) g.bottom else g.top
            val closeY = if (g.bullish) g.top else g.bottom
            val open = scale.priceAt(openY.toDouble())
            val close = scale.priceAt(closeY.toDouble())
            val high = max(open, close)
            val low = min(open, close)
            if (!open.isFinite() || !close.isFinite() || open <= 0.0 || close <= 0.0) return@forEachIndexed
            val quality = if (g.columns.size >= 5) 0.92f else if (g.columns.size >= 3) 0.82f else 0.65f
            candles += Candle(
                time = currentOpen - (ordered.lastIndex - index) * 300_000L,
                open = open, high = high, low = low, close = close,
                closed = index != ordered.lastIndex,
                confidence = minOf(quality, scale.r2.toFloat()),
                verified = quality >= 0.80f && scale.r2 >= 0.90
            )
        }

        val countConf = when { candles.size >= 50 -> 1f; candles.size >= 30 -> 0.85f; candles.size >= 20 -> 0.65f; else -> 0.25f }
        val avgQuality = candles.map { it.confidence }.average().takeIf { it.isFinite() }?.toFloat() ?: 0f
        val confidence = (countConf * 0.25f + scale.r2.toFloat() * 0.35f + avgQuality * 0.40f).coerceIn(0f, 1f)
        if (candles.size < 50) warnings += "История короче 50 свечей"
        return ReconstructionResult(candles, confidence, true, warnings)
    }
}
