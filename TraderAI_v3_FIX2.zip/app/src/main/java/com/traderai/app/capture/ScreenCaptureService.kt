package com.traderai.app.capture

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcelable
import androidx.core.app.NotificationCompat
import com.traderai.app.trading.TraderPipeline
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.traderai.app.START_CAPTURE"
        const val ACTION_STOP = "com.traderai.app.STOP_CAPTURE"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "traderai_capture"
        private const val NOTIFICATION_ID = 7
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var callback: MediaProjection.Callback? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val pipeline by lazy { TraderPipeline(applicationContext) }
    private val mutex = Mutex()
    private val processing = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopCapture(); stopSelf(startId); return START_NOT_STICKY }
            ACTION_START -> {
                if (projection != null) return START_NOT_STICKY
                startForeground(NOTIFICATION_ID, notification())
                val code = intent.getIntExtra(EXTRA_CODE, Activity.RESULT_CANCELED)
                val data = intent.parcelable<Intent>(EXTRA_DATA)
                if (code != Activity.RESULT_OK || data == null) {
                    CaptureState.status("Нет разрешения MediaProjection")
                    stopSelf(startId); return START_NOT_STICKY
                }
                try {
                    val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = mgr.getMediaProjection(code, data)
                    val projectionCallback = object : MediaProjection.Callback() {
                        override fun onStop() { CaptureState.status("Захват остановлен системой"); stopCapture(); stopSelf() }
                    }
                    callback = projectionCallback
                    projection?.registerCallback(projectionCallback, mainHandler)
                    startDisplay()
                } catch (t: Throwable) {
                    CaptureState.status("Ошибка захвата: ${t.message}")
                    stopCapture(); stopSelf(startId)
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun startDisplay() {
        val m = resources.displayMetrics
        val w = m.widthPixels.coerceAtLeast(1)
        val h = m.heightPixels.coerceAtLeast(1)
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader = r
        r.setOnImageAvailableListener({ source ->
            val now = System.currentTimeMillis()
            if (now - lastFrameAt < 1200L) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            if (!processing.compareAndSet(false, true)) { source.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            lastFrameAt = now
            val image = source.acquireLatestImage()
            if (image == null) { processing.set(false); return@setOnImageAvailableListener }
            val bitmap = try { toBitmap(image) } catch (t: Throwable) { CaptureState.analysis("Ошибка кадра: ${t.message}"); null } finally { image.close() }
            if (bitmap == null) { processing.set(false); return@setOnImageAvailableListener }
            scope.launch {
                try {
                    mutex.withLock {
                        pipeline.refreshSettings()
                        val res = pipeline.process(bitmap)
                        CaptureState.analysis(buildString {
                            appendLine(res.message)
                            appendLine("Пара: ${res.pair ?: "?"}, выплата: ${res.payout?.let { "$it%" } ?: "?"}")
                            appendLine("Confidence: ${(res.confidence * 100).toInt()}%")
                            appendLine("Закрытых свечей: ${res.candleCount}")
                            appendLine("Анализ: ${res.analysis?.reason ?: "—"}")
                            res.warnings.takeLast(8).forEach { appendLine("• $it") }
                            appendLine("ОНЛАЙН: реальные нажатия отключены")
                        })
                    }
                } catch (t: Throwable) {
                    CaptureState.analysis("Ошибка анализа: ${t.message}")
                } finally {
                    if (!bitmap.isRecycled) bitmap.recycle()
                    processing.set(false)
                }
            }
        }, mainHandler)
        virtualDisplay = projection?.createVirtualDisplay("TraderAI", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, mainHandler)
        CaptureState.status("Захват активен · Observer")
    }

    private fun toBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val w = image.width; val h = image.height
        val ps = plane.pixelStride; val rs = plane.rowStride
        if (ps <= 0 || rs <= 0) return null
        val paddedWidth = rs / ps
        val padded = Bitmap.createBitmap(paddedWidth, h, Bitmap.Config.ARGB_8888)
        val buf = plane.buffer; buf.rewind(); padded.copyPixelsFromBuffer(buf)
        return if (paddedWidth == w) padded else try {
            Bitmap.createBitmap(padded, 0, 0, w, h)
        } finally { padded.recycle() }
    }

    private fun stopCapture() {
        reader?.setOnImageAvailableListener(null, null)
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { reader?.close() } catch (_: Throwable) {}
        reader = null
        callback?.let { runCatching { projection?.unregisterCallback(it) } }
        callback = null
        try { projection?.stop() } catch (_: Throwable) {}
        projection = null
        CaptureState.status("Захват остановлен")
    }

    private fun notification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "TraderAI", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("TraderAI")
            .setContentText("Observer · без реальных сделок")
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        stopCapture(); pipeline.close(); scope.cancel(); super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private inline fun <reified T : Parcelable> Intent.parcelable(key: String): T? =
        if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, T::class.java) else getParcelableExtra(key)
}
