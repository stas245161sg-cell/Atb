package com.traderai.app.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.util.Locale

data class OcrItem(val text: String, val bounds: Rect)

data class PriceLabel(
    val price: Double,
    val centerY: Float,
    val centerX: Float
)

data class OcrResult(
    val pair: String?,
    val payout: Int?,
    val secondsRemaining: Int?,
    val priceLabels: List<PriceLabel>,
    val warnings: List<String>
)

class ScreenOcr {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun read(bitmap: Bitmap): OcrResult {
        val warnings = mutableListOf<String>()
        if (bitmap.isRecycled || bitmap.width < 2 || bitmap.height < 2) {
            return OcrResult(null, null, null, emptyList(), listOf("Некорректный кадр"))
        }

        val text = try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
        } catch (t: Throwable) {
            return OcrResult(null, null, null, emptyList(), listOf("Ошибка OCR: ${t.message}"))
        }

        val items = mutableListOf<OcrItem>()
        for (block in text.textBlocks) {
            for (line in block.lines) {
                val box = line.boundingBox ?: continue
                items += OcrItem(line.text.trim(), Rect(box))
            }
        }
        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()

        val pair = findPair(items, w, h)
        val payout = findPayout(items, w, h)
        val timer = findTimer(items, w, h)
        val prices = findPriceLabels(items, w, h)

        if (pair == null) warnings += "Пара не распознана"
        if (payout == null) warnings += "Выплата не распознана"
        if (timer == null) warnings += "Таймер M5 не распознан"
        if (prices.size < 2) warnings += "Мало ценовых отметок для шкалы"

        return OcrResult(pair, payout, timer, prices, warnings)
    }

    private fun center(item: OcrItem, w: Float, h: Float): Pair<Float, Float> =
        item.bounds.exactCenterX() / w to item.bounds.exactCenterY() / h

    private fun findPair(items: List<OcrItem>, w: Float, h: Float): String? {
        val regex = Regex("""\b([A-Z]{3})\s*/\s*([A-Z]{3})(?:\s+OTC)?\b""", RegexOption.IGNORE_CASE)
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.05f..0.55f && y in 0.12f..0.20f }
            .mapNotNull { regex.find(it.text.uppercase(Locale.US)) }
            .map { "${it.groupValues[1]}/${it.groupValues[2]}" }
            .firstOrNull()
    }

    private fun findPayout(items: List<OcrItem>, w: Float, h: Float): Int? {
        val regex = Regex("""(\d{2,3})\s*%""")
        return items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.62f..0.72f }
            .mapNotNull { regex.find(it.text)?.groupValues?.getOrNull(1)?.toIntOrNull() }
            .firstOrNull { it in 50..100 }
    }

    private fun findTimer(items: List<OcrItem>, w: Float, h: Float): Int? {
        val regex = Regex("""(?<!\d)(\d{1,2}):([0-5]\d)(?!\d)""")
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.25f..0.95f && y in 0.18f..0.42f }
            .mapNotNull { regex.find(it.text) }
            .mapNotNull {
                val m = it.groupValues[1].toIntOrNull() ?: return@mapNotNull null
                val s = it.groupValues[2].toIntOrNull() ?: return@mapNotNull null
                m * 60 + s
            }
            .firstOrNull { it in 0..300 }
    }

    private fun findPriceLabels(items: List<OcrItem>, w: Float, h: Float): List<PriceLabel> {
        val priceRegex = Regex("""(?<!\d)(\d+\.\d{3,8})(?!\d)""")
        return items.mapNotNull { item ->
            val (x, y) = center(item, w, h)
            if (x !in 0.70f..1.0f || y !in 0.18f..0.56f) return@mapNotNull null
            val value = priceRegex.find(item.text)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
                ?: return@mapNotNull null
            if (!value.isFinite() || value <= 0.0) return@mapNotNull null
            PriceLabel(value, item.bounds.exactCenterY(), item.bounds.exactCenterX())
        }.distinctBy { (it.price * 100000.0).toLong() }
            .sortedBy { it.centerY }
    }

    fun close() { recognizer.close() }
}
