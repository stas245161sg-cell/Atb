package com.traderai.app.trading

import android.content.Context
import android.graphics.Bitmap
import com.traderai.app.data.CandleHistoryStore
import com.traderai.app.data.SettingsRepo
import com.traderai.app.data.AppSettings
import com.traderai.app.vision.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

data class PipelineResult(
    val confidence: Float,
    val candleCount: Int,
    val pair: String?,
    val payout: Int?,
    val analysis: Analysis?,
    val message: String,
    val warnings: List<String>
)

class TraderPipeline(context: Context) {
    private val parser = ScreenParser()
    private val historyStore = CandleHistoryStore(context)
    private val history = mutableListOf<Candle>().apply { addAll(historyStore.load()) }
    private val paper = PaperTrading(context)
    private val settings = SettingsRepo(context)

    @Volatile private var currentSettings = AppSettings()
    @Volatile private var lastClosedTime = Long.MIN_VALUE

    suspend fun refreshSettings() { currentSettings = settings.flow.firstOrNullSafe() ?: currentSettings }

    @Synchronized fun setCalibrationApproved(v: Boolean) { TradingGate.set(v); if (!v) StrategyEngine.reset() }

    suspend fun process(bitmap: Bitmap, now: Long = System.currentTimeMillis()): PipelineResult = withContext(Dispatchers.Default) {
        val parsed = parser.parse(bitmap, now)
        val closed = parsed.candles.filter { it.closed && it.verified && it.confidence >= 0.80f }
        for (c in closed) {
            val idx = history.indexOfFirst { it.time == c.time }
            if (idx >= 0) { if (c.confidence >= history[idx].confidence) history[idx] = c }
            else history += c
        }
        history.sortBy { it.time }
        while (history.size > 300) history.removeAt(0)
        historyStore.save(history)

        contiguous = hasTail(history, 50)
        val latest = history.lastOrNull()

        val analysis = if (TradingGate.approved.value && contiguous && parsed.context.valid && latest != null && latest.time != lastClosedTime) {
            lastClosedTime = latest.time
            StrategyEngine.analyze(
                input = history,
                mode = currentSettings.mode,
                confidence = parsed.confidence,
                context = parsed.context,
                allowCall = currentSettings.call,
                allowPut = currentSettings.put,
                calibrationApproved = true,
                minimumPayout = currentSettings.minPayout,
                now = now
            )
        } else {
            Analysis(Side.NONE, 0, Regime.UNKNOWN, if (!TradingGate.approved.value) "Observer: калибровка не подтверждена"
                else if (!parsed.context.valid) parsed.context.reason
                else if (!contiguous) "История не непрерывна"
                else "Ожидание новой закрытой свечи", parsed.confidence, history.size, null, null)
        }

        // Paper trading: открытие по цене открытия текущей свечи если доступно
        if (analysis.side != Side.NONE && analysis.entryTime != null) {
            val cur = parsed.candles.lastOrNull { !it.closed }
            if (cur != null && now - analysis.entryTime <= 30_000L) {
                paper.open(parsed.context.pair ?: "—", analysis.side, analysis.signalTime ?: latest!!.time,
                    analysis.entryTime, cur.open, parsed.context.payout ?: 0, analysis.score, analysis.reason)
            }
        }
        // расчёт по закрытой свече экспирации
        history.filter { it.closed }.forEach { c -> paper.settle(c.time, c.close) }

        PipelineResult(
            confidence = parsed.confidence,
            candleCount = history.size,
            pair = parsed.context.pair,
            payout = parsed.context.payout,
            analysis = analysis,
            message = analysis.reason,
            warnings = parsed.warnings
        )
    }

    private var contiguous = false

    private fun hasTail(list: List<Candle>, n: Int): Boolean {
        if (list.size < n) return false
        val tail = list.takeLast(n)
        for (i in 1 until tail.size) if (tail[i].time - tail[i - 1].time != 300_000L) return false
        return true
    }

    fun paperTrading(): PaperTrading = paper

    fun close() { parser.close() }
}

private suspend fun <T> kotlinx.coroutines.flow.Flow<T>.firstOrNullSafe(): T? =
    try { first() } catch (_: Exception) { null }
