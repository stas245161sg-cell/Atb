package com.traderai.app.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.traderai.app.capture.CaptureState
import com.traderai.app.capture.ScreenCaptureService
import com.traderai.app.data.SettingsRepo
import com.traderai.app.trading.TradingGate
import com.traderai.app.vision.TradingMode
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TraderScreen(repo: SettingsRepo) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by repo.flow.collectAsStateWithLifecycle(initialValue = com.traderai.app.data.AppSettings())
    val status by CaptureState.status.collectAsStateWithLifecycle()
    val analysis by CaptureState.analysis.collectAsStateWithLifecycle()
    var approved by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(TraderColors.Background)
            .verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("TRADER AI", color = TraderColors.Text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Observer · Heikin Ashi M5 · экспирация 5 мин", color = TraderColors.Muted, fontSize = 12.sp)

        CardBox {
            Text("СОСТОЯНИЕ", color = TraderColors.Muted, fontWeight = FontWeight.Bold)
            Text(status, color = TraderColors.Cyan)
            Spacer(Modifier.height(10.dp))
            Button(onClick = {
                if (status.contains("активен")) stop(context) else start(context)
            }, modifier = Modifier.fillMaxWidth()) {
                Text(if (status.contains("активен")) "ОСТАНОВИТЬ АНАЛИЗ" else "ЗАПУСТИТЬ АНАЛИЗ")
            }
        }

        CardBox {
            Text("НАСТРОЙКИ", color = TraderColors.Muted, fontWeight = FontWeight.Bold)
            TradingMode.values().forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    RadioButton(selected = settings.mode == m, onClick = { scope.launch { repo.setMode(m) } })
                    Text(m.name, color = TraderColors.Text)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("CALL", color = TraderColors.Green)
                Switch(checked = settings.call, onCheckedChange = { scope.launch { repo.setCall(it) } })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("PUT", color = TraderColors.Red)
                Switch(checked = settings.put, onCheckedChange = { scope.launch { repo.setPut(it) } })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Мин. выплата: ${settings.minPayout}%", color = TraderColors.Yellow)
                Switch(checked = settings.paper, onCheckedChange = { scope.launch { repo.setPaper(it) } })
            }
        }

        CardBox {
            Text("КАЛИБРОВКА OHLC", color = TraderColors.Yellow, fontWeight = FontWeight.Bold)
            Text("По умолчанию сигналы заблокированы. Подтвердите калибровку только после сверки 10+ распознанных свеч с экраном.", color = TraderColors.Muted, fontSize = 12.sp)
            Button(onClick = { approved = !approved; TradingGate.set(approved) }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (approved) TraderColors.Green else TraderColors.Border)) {
                Text(if (approved) "КАЛИБРОВКА ПОДТВЕРЖДЕНА" else "ПОДТВЕРДИТЬ КАЛИБРОВКУ")
            }
        }

        CardBox {
            Text("АНАЛИЗ КАДРА", color = TraderColors.Muted, fontWeight = FontWeight.Bold)
            Text(analysis, color = TraderColors.Text, fontSize = 12.sp)
        }
    }
}

@Composable
private fun CardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(TraderColors.Surface, RoundedCornerShape(16.dp))
            .border(1.dp, TraderColors.Border, RoundedCornerShape(16.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content
    )
}

private fun start(context: Context) {
    val i = Intent(context, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_START }
    androidx.core.content.ContextCompat.startForegroundService(context, i)
}

private fun stop(context: Context) {
    val i = Intent(context, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP }
    context.startService(i)
}
