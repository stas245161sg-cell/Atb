package com.traderai.app.trading

import android.content.Context
import com.traderai.app.vision.Side
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class PaperResult { OPEN, WIN, LOSS, DRAW, CANCELLED }

data class PaperTrade(
    val id: String, val pair: String, val side: Side,
    val signalTime: Long, val entryTime: Long, val expiryTime: Long,
    val entryPrice: Double?, val exitPrice: Double?,
    val payout: Int, val result: PaperResult,
    val score: Int, val reason: String
)

class PaperTrading(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("traderai_paper", Context.MODE_PRIVATE)
    private val trades = mutableListOf<PaperTrade>()

    init { load() }

    @Synchronized fun all(): List<PaperTrade> = trades.toList().asReversed()

    @Synchronized
    fun open(pair: String, side: Side, signalTime: Long, entryTime: Long,
             entryPrice: Double, payout: Int, score: Int, reason: String): PaperTrade? {
        if (side == Side.NONE || pair.isBlank()) return null
        if (!entryPrice.isFinite() || entryPrice <= 0.0 || payout !in 1..100 || entryTime <= signalTime) return null
        if (trades.any { it.result == PaperResult.OPEN }) return null
        val t = PaperTrade(UUID.randomUUID().toString(), pair, side, signalTime, entryTime,
            entryTime + 300_000L, entryPrice, null, payout, PaperResult.OPEN, score, reason)
        trades += t; persist(); return t
    }

    @Synchronized
    fun settle(candleOpenTime: Long, exitPrice: Double): PaperTrade? {
        if (!exitPrice.isFinite() || exitPrice <= 0.0) return null
        val idx = trades.indexOfLast { it.result == PaperResult.OPEN && it.expiryTime == candleOpenTime }
        if (idx < 0) return null
        val t = trades[idx]
        val entry = t.entryPrice ?: return null
        val result = when {
            exitPrice == entry -> PaperResult.DRAW
            t.side == Side.CALL && exitPrice > entry -> PaperResult.WIN
            t.side == Side.PUT && exitPrice < entry -> PaperResult.WIN
            else -> PaperResult.LOSS
        }
        val updated = t.copy(exitPrice = exitPrice, result = result)
        trades[idx] = updated; persist(); return updated
    }

    @Synchronized
    fun cancelOpen(reason: String = "Сессия остановлена") {
        for (i in trades.indices) if (trades[i].result == PaperResult.OPEN) {
            trades[i] = trades[i].copy(result = PaperResult.CANCELLED, reason = "${trades[i].reason}; $reason")
        }
        persist()
    }

    @Synchronized fun clear() { trades.clear(); persist() }

    @Synchronized
    fun stats(): Stats {
        val closed = trades.filter { it.result == PaperResult.WIN || it.result == PaperResult.LOSS || it.result == PaperResult.DRAW }
        val wins = closed.count { it.result == PaperResult.WIN }
        val losses = closed.count { it.result == PaperResult.LOSS }
        val decisive = wins + losses
        return Stats(trades.size, wins, losses, closed.count { it.result == PaperResult.DRAW },
            trades.count { it.result == PaperResult.OPEN },
            if (decisive == 0) 0.0 else wins * 100.0 / decisive)
    }

    data class Stats(val total: Int, val wins: Int, val losses: Int, val draws: Int, val open: Int, val winRate: Double)

    fun exportTxt(): String = buildString {
        appendLine("TRADERAI PAPER TRADING"); appendLine("Export: ${System.currentTimeMillis()}"); appendLine("==================")
        all().forEach {
            val ts = java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(it.entryTime))
            appendLine("$ts | ${it.pair} | ${it.side} | ${it.result} | score=${it.score} | ${it.reason}")
        }
        val s = stats()
        appendLine("TOTAL=${s.total} WINS=${s.wins} LOSSES=${s.losses} DRAWS=${s.draws} OPEN=${s.open} WINRATE=${"%.2f".format(s.winRate)}%")
    }

    private fun persist() {
        val arr = JSONArray()
        trades.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("pair", it.pair); put("side", it.side.name)
                put("signalTime", it.signalTime); put("entryTime", it.entryTime); put("expiryTime", it.expiryTime)
                put("entryPrice", it.entryPrice ?: JSONObject.NULL); put("exitPrice", it.exitPrice ?: JSONObject.NULL)
                put("payout", it.payout); put("result", it.result.name); put("score", it.score); put("reason", it.reason)
            })
        }
        prefs.edit().putString("trades", arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString("trades", null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                trades += PaperTrade(
                    o.getString("id"), o.getString("pair"), Side.valueOf(o.getString("side")),
                    o.getLong("signalTime"), o.getLong("entryTime"), o.getLong("expiryTime"),
                    o.optDouble("entryPrice").takeIf { it.isFinite() && it > 0.0 },
                    o.optDouble("exitPrice").takeIf { it.isFinite() && it > 0.0 },
                    o.getInt("payout"), PaperResult.valueOf(o.getString("result")),
                    o.getInt("score"), o.optString("reason")
                )
            }
        }.onFailure { trades.clear() }
    }
}
