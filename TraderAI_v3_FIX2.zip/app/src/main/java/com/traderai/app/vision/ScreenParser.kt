package com.traderai.app.vision

import android.graphics.Bitmap

data class ParsedFrame(
    val candles: List<Candle>,
    val context: ScreenContext,
    val confidence: Float,
    val note: String,
    val warnings: List<String> = emptyList()
)

class ScreenParser(
    private val ocr: ScreenOcr = ScreenOcr(),
    private val reconstructor: CandleReconstructor = CandleReconstructor()
) {
    suspend fun parse(bitmap: Bitmap, now: Long = System.currentTimeMillis()): ParsedFrame {
        if (bitmap.isRecycled || bitmap.width < 2) {
            return ParsedFrame(emptyList(), ScreenContext(null, null, null, null, false, "Некорректный кадр"), 0f, "Ошибка")
        }
        val o = ocr.read(bitmap)
        val validContext = o.pair != null && o.payout != null
        val context = ScreenContext(
            pair = o.pair, payout = o.payout,
            timeframeMins = 5, expiryMins = 5,
            valid = validContext,
            reason = "Пара=${o.pair ?: "?"}; выплата=${o.payout?.let { "$it%" } ?: "?"}"
        )
        val rec = if (validContext) reconstructor.reconstruct(bitmap, o, now) else ReconstructionResult(emptyList(), 0f, false, o.warnings)
        return ParsedFrame(
            candles = rec.candles,
            context = context,
            confidence = rec.confidence,
            note = if (rec.candles.isEmpty()) "OHLC не реконструирован: ${rec.warnings.joinToString("; ")}" else "Свечи реконструированы",
            warnings = o.warnings + rec.warnings
        )
    }
    fun close() = ocr.close()
}
