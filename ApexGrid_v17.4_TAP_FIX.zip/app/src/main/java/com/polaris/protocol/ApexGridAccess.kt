package com.polaris.protocol

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.MessageDigest
import java.util.Locale

object ApexGridAccess {
    const val APP_NAME = "ApexGrid"
    private const val PREFS_NAME = "apexgrid_offline_access"
    private const val KEY_UNLOCKED = "apexgrid_unlocked_v1"
    private const val KEY_CODE_HASH = "apexgrid_code_hash_v1"

    private const val MASTER_CODE = "ApexGrid_byBoroda13"
    private val masterCodeHash: String by lazy { hashCodeValue(MASTER_CODE) }

    fun isUnlocked(context: Context, expectedCertSha256: String = ""): Boolean {
        if (!SecurityGuard.verify(context, expectedCertSha256).allowed) return false
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val unlocked = sp.getBoolean(KEY_UNLOCKED, false)
        val savedHash = sp.getString(KEY_CODE_HASH, null)
        return unlocked && !savedHash.isNullOrBlank() && savedHash == masterCodeHash
    }

    fun unlock(context: Context, rawCode: String): Result<Unit> {
        val cleaned = rawCode.trim()
        if (cleaned.isEmpty()) {
            return Result.failure(IllegalArgumentException("[$APP_NAME] Введите код доступа"))
        }
        val inputHash = hashCodeValue(cleaned)
        if (inputHash != masterCodeHash) {
            return Result.failure(IllegalArgumentException("[$APP_NAME] Неверный код активации"))
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_UNLOCKED, true)
            .putString(KEY_CODE_HASH, inputHash)
            .apply()
        LogRepository.addLog("$APP_NAME: офлайн-доступ разблокирован")
        return Result.success(Unit)
    }

    fun lock(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().clear().apply()
        LogRepository.addLog("$APP_NAME: доступ заблокирован")
    }

    private fun hashCodeValue(code: String): String {
        val canonical = "APEXGRID_SALT_V1:${code.trim().uppercase(Locale.US)}"
        return MessageDigest.getInstance("SHA-256").digest(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02X".format(Locale.US, it) }
    }
}

@Composable
fun ApexGridActivationScreen(context: Context, onUnlocked: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    ApexGlassBackdrop(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(20.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LiquidGlassCard(Modifier.fillMaxWidth(), accentBorder = true) {
                Text(
                    ApexGridAccess.APP_NAME.uppercase(Locale.US),
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp
                    )
                )
                Text(
                    "Офлайн-активация ${ApexGridAccess.APP_NAME}. Введите код доступа для запуска терминала.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(4.dp))
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it; error = null },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = {
                        Text(
                            "Введите код доступа",
                            style = MaterialTheme.typography.labelMedium,
                            color = ApexGlassColors.TextMuted
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ApexGlassColors.IceCyan,
                        unfocusedBorderColor = ApexGlassColors.RimSubtle,
                        focusedTextColor = ApexGlassColors.TextPrimary,
                        unfocusedTextColor = ApexGlassColors.TextPrimary,
                        cursorColor = ApexGlassColors.IceCyan
                    )
                )
                if (error != null) {
                    Text(error!!, style = MaterialTheme.typography.bodyMedium,
                        color = ApexGlassColors.SignalCrimson)
                }
                Spacer(Modifier.height(6.dp))
                LiquidGlassActionButton(
                    text = "Войти в ${ApexGridAccess.APP_NAME}",
                    active = true,
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        ApexGridAccess.unlock(context, code)
                            .onSuccess { error = null; onUnlocked() }
                            .onFailure { err ->
                                error = err.message ?: "Ошибка активации ${ApexGridAccess.APP_NAME}"
                            }
                    }
                )
            }
        }
    }
}
