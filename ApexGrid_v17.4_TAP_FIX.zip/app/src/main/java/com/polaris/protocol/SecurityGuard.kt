package com.polaris.protocol

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import java.util.Locale

object SecurityGuard {

    data class IntegrityStatus(
        val signatureValid: Boolean,
        val debuggable: Boolean,
        val certSha256: String,
        val expectedConfigured: Boolean = false
    ) {
        /**
         * В GitHub Actions собирается debug APK — флаг DEBUGGABLE там выставлен всегда.
         * Поэтому debuggable блокирует доступ только когда задан APEX_EXPECTED_SHA256.
         */
        val allowed: Boolean
            get() = signatureValid && (!expectedConfigured || !debuggable)
    }

    fun verify(context: Context, expectedSha256: String): IntegrityStatus {
        val debuggable = (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        val actual = currentCertSha256(context)
        val normalized = expectedSha256.replace(":", "").trim().uppercase(Locale.US)
        val signatureValid = if (normalized.isEmpty()) {
            true
        } else {
            actual != null && actual.equals(normalized, ignoreCase = true)
        }
        return IntegrityStatus(
            signatureValid = signatureValid,
            debuggable = debuggable,
            certSha256 = actual ?: "UNKNOWN",
            expectedConfigured = normalized.isNotEmpty()
        )
    }

    private fun currentCertSha256(context: Context): String? {
        return try {
            val pkg = context.packageName
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                context.packageManager.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(pkg, PackageManager.GET_SIGNATURES)
            }
            val raw: ByteArray? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val si = info.signingInfo ?: return null
                val signers = if (si.hasMultipleSigners()) si.apkContentsSigners else si.signingCertificateHistory
                signers?.firstOrNull()?.toByteArray()
            } else {
                @Suppress("DEPRECATION")
                info.signatures?.firstOrNull()?.toByteArray()
            }
            raw?.let { sha256Hex(it) }
        } catch (_: Throwable) {
            null
        }
    }

    private fun sha256Hex(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02X".format(Locale.US, it) }
}
