package com.polaris.protocol

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LogRepository {
    private const val MAX_ENTRIES = 400
    private val entries = ArrayList<String>(MAX_ENTRIES)
    private val _logs = MutableStateFlow<List<String>>(emptyList())
    val logs: StateFlow<List<String>> = _logs

    @Synchronized
    fun addLog(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "[$stamp] $message"
        if (entries.size >= MAX_ENTRIES) entries.removeAt(0)
        entries.add(line)
        _logs.value = entries.toList()
    }

    @Synchronized
    fun clear() {
        entries.clear()
        _logs.value = emptyList()
    }
}
