package com.polaris.protocol

/**
 * Предохранитель по частоте: лимит сделок и cooldown.
 * Банк, размер ставки, дневные SL/TP задаёт оператор в Pocket Option — приложение
 * деньги не считает и ставку не меняет (мартингейл исключён полностью).
 */
class SessionRiskGate(
    private val maxTrades: Int = 30,
    private val cooldownMs: Long = 60_000L
) {
    private var trades = 0
    private var lastTradeAt = 0L

    fun allow(now: Long): String? = when {
        trades >= maxTrades -> "max_trades"
        now - lastTradeAt < cooldownMs -> "cooldown"
        else -> null
    }

    fun onSignal() {
        trades++
        lastTradeAt = System.currentTimeMillis()
    }

    fun snapshot(): String = "trades=$trades"
}
