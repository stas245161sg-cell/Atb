package com.polaris.protocol

/**
 * Взвешенное голосование: минимум 2 стратегии, суммарный score > порога,
 * плюс фильтр выплаты. Возвращает направление и строку для журнала.
 */
class VoteEngine(
    private val strategies: List<Strategy> = listOf(ScalpStrategy(), TrendStrategy(), VolatilityStrategy())
) {
    companion object {
        /** Фильтр выплаты жёстко задан алгоритмом и не меняется из UI. */
        const val MIN_PAYOUT = DecisionEngine.MIN_PAYOUT
        const val MIN_SCORE = 0.65f
    }

    fun decide(s: Snapshot, f: FiboLevels?, payout: Int): Pair<Direction?, String> {
        if (f == null) return null to "no_levels"
        if (payout < MIN_PAYOUT) return null to "payout_filter"

        val votes = strategies.filter { it.enabled }
            .map { it to it.evaluate(s, f) }
            .filter { it.second.dir != SignalDir.NONE }
        if (votes.isEmpty()) return null to "no_votes"

        val byDir = votes.groupBy { it.second.dir }
        val bestDir = byDir.maxByOrNull { (_, list) ->
            list.fold(0f) { acc, (st, sig) -> acc + sig.confidence * st.weight }
        }!!.key
        val group = votes.filter { it.second.dir == bestDir }
        val score = group.fold(0f) { acc, (st, sig) -> acc + sig.confidence * st.weight }
        val bonus = confirmBonus(s, bestDir)
        val total = (score + bonus).coerceAtMost(1f)

        if (group.size < 2 || total <= MIN_SCORE) {
            return null to "weak_vote($bestDir n=${group.size} score=${String.format("%.2f", total)} bonus=${String.format("%.2f", bonus)})"
        }

        // EV при текущей выплате: p ≈ total, безубыточность 1/(1+payout)
        val p = payout / 100f
        val ev = total * p - (1f - total)
        if (ev <= 0f) return null to "negative_ev(${String.format("%.3f", ev)})"

        val dir = if (bestDir == SignalDir.CALL) Direction.CALL else Direction.PUT
        return dir to "vote=$bestDir n=${group.size} score=${String.format("%.2f", total)} bonus=${String.format("%.2f", bonus)} ev=${String.format("%.3f", ev)}"
    }

    /** SuperTrend + Stochastic + AO добавляют уверенности, если согласны с направлением. */
    private fun confirmBonus(s: Snapshot, dir: SignalDir): Float {
        var b = 0f
        if (s.superTrend != Trend.UNKNOWN) {
            val stDir = if (s.superTrend == Trend.GREEN) SignalDir.CALL else SignalDir.PUT
            if (stDir == dir) b += 0.10f
        }
        if (s.stochCross != Cross.NONE) {
            val scDir = if (s.stochCross == Cross.UP) SignalDir.CALL else SignalDir.PUT
            if (scDir == dir) b += 0.08f
        }
        if (s.ao != Trend.UNKNOWN) {
            val aoDir = if (s.ao == Trend.GREEN) SignalDir.CALL else SignalDir.PUT
            if (aoDir == dir) b += 0.07f
        }
        return b
    }
}
