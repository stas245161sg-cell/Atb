# Dark Grid

Версия `3.4-autotap` (`versionCode 7`). Пакет `com.traderai.app` сохранён для стабильности сборки; имя приложения, иконка и весь UI — **Dark Grid**.

## Новое в 3.4

- Accessibility-сервис `DarkGridAccessibilityService` + кнопка «Включить спец. возможности» (открывает системные настройки).
- Кнопка «Назад» из LOGS / PAPER / INFO (системная и в UI через BackHandler).
- Автонажатие: тумблер в «Управлении», реализация через `dispatchGesture`.
- Adaptive icon по мотиву стеклянного куба DG (foreground + background, все плотности).
- Launcher label «Dark Grid» и в `application`, и в `activity`.

## Безопасность автотапа

Тап выполняется **только** если одновременно:
- тумблер «Автонажатие» включён;
- Paper Trading выключен;
- калибровка OHLC подтверждена;
- Accessibility-сервис подключён;
- в foreground именно `com.pocketoption.broker`;
- сигнал новый (ключ = pair + side + signalCandleTime), кулдаун 60 с.

Координаты CALL/PUT по умолчанию: `(0.29, 0.65)` и `(0.71, 0.65)`, сохранены в DataStore.

## Сборка

GitHub Actions → **Dark Grid Build** → артефакт `DarkGrid-debug`.

## Важно

Если на рабочем столе телефона осталась старая иконка/имя `TraderAI` — удалите старое приложение перед установкой: кэш лаунчера может показывать старую метку.
