package com.traderai.app.trading

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object TradingGate {
    private val _approved = MutableStateFlow(false)
    val approved = _approved.asStateFlow()
    fun set(v: Boolean) { _approved.value = v }
}
