package com.traderai.app.trading

import android.content.Context
import com.traderai.app.vision.Side
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class PaperResult { OPEN, WIN, LOSS, DRAW, CANCELLED }

data class PaperTrade(
    val id: String, val pair: String, val side: Side,
    val signalTime: Long, val signalKey: String,
    val entryTime: Long, val expiryTime: Long,
    val entryPrice: Double?, val exitPrice: Double?,
    val payout: Int, val result: PaperResult,
    val score: Int, val reason: String
)

class PaperTrading(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("traderai_paper_v31", Context.MODE_PRIVATE)
    private val trades = mutableListOf<PaperTrade>()
    private var lastSignalKey = ""

    init { load() }

    @Synchronized fun all(): List<PaperTrade> = trades.toList().asReversed()
    @Synchronized fun lastKey(): String = lastSignalKey

    @Synchronized
    fun open(
        pair: String, side: Side, signalTime: Long, signalKey: String,
        entryPrice: Double, payout: Int, score: Int, reason: String,
        paperEnabled: Boolean
    ): PaperTrade? {
        if (!paperEnabled) return null
        if (side == Side.NONE || pair.isBlank()) return null
        if (!entryPrice.isFinite() || entryPrice <= 0.0 || payout !in 1..100) return null
        if (!PaperMath.gridAligned(signalTime)) return null
        if (lastSignalKey == signalKey) return null
        if (trades.any { it.result == PaperResult.OPEN }) return null

        val entry = signalTime + PaperMath.EXPIRY_MS
        val trade = PaperTrade(
            id = UUID.randomUUID().toString(), pair = pair, side = side,
            signalTime = signalTime, signalKey = signalKey,
            entryTime = entry, expiryTime = entry + PaperMath.EXPIRY_MS,
            entryPrice = entryPrice, exitPrice = null, payout = payout,
            result = PaperResult.OPEN, score = score, reason = reason
        )
        trades += trade
        lastSignalKey = signalKey
        persist()
        return trade
    }

    /** result по цене ОТКРЫТИЯ свечи с time == expiryTime. Если её нет — остаётся OPEN. */
    @Synchronized
    fun settle(expiryCandleTime: Long, expiryCandleOpen: Double?): PaperTrade? {
        val idx = trades.indexOfLast { it.result == PaperResult.OPEN && it.expiryTime == expiryCandleTime }
        if (idx < 0) return null
        val trade = trades[idx]
        val entry = trade.entryPrice ?: return null
        val result = PaperMath.result(trade.side, entry, expiryCandleOpen) ?: return null
        val updated = trade.copy(exitPrice = expiryCandleOpen, result = result)
        trades[idx] = updated
        persist()
        return updated
    }

    @Synchronized
    fun cancelOpen(reason: String) {
        for (i in trades.indices) if (trades[i].result == PaperResult.OPEN) {
            trades[i] = trades[i].copy(result = PaperResult.CANCELLED, reason = "${trades[i].reason}; $reason")
        }
        persist()
    }

    @Synchronized fun clear() { trades.clear(); lastSignalKey = ""; persist() }

    @Synchronized
    fun stats(): Stats {
        val closed = trades.filter { it.result == PaperResult.WIN || it.result == PaperResult.LOSS || it.result == PaperResult.DRAW }
        val wins = closed.count { it.result == PaperResult.WIN }
        val losses = closed.count { it.result == PaperResult.LOSS }
        val decisive = wins + losses
        return Stats(trades.size, wins, losses, closed.count { it.result == PaperResult.DRAW },
            trades.count { it.result == PaperResult.OPEN },
            if (decisive == 0) 0.0 else wins * 100.0 / decisive)
    }

    data class Stats(val total: Int, val wins: Int, val losses: Int, val draws: Int, val open: Int, val winRate: Double)

    fun exportTxt(): String = buildString {
        appendLine("TRADERAI v3.1 PAPER TRADING")
        all().forEach {
            val ts = java.text.SimpleDateFormat("dd.MM HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(it.entryTime))
            appendLine("$ts | ${it.pair} | ${it.side} | ${it.result} | score=${it.score} | key=${it.signalKey} | ${it.reason}")
        }
        val s = stats()
        appendLine("TOTAL=${s.total} WINS=${s.wins} LOSSES=${s.losses} DRAWS=${s.draws} OPEN=${s.open} WINRATE=${"%.2f".format(s.winRate)}%")
    }

    private fun persist() {
        val arr = JSONArray()
        trades.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("pair", it.pair); put("side", it.side.name)
                put("signalTime", it.signalTime); put("signalKey", it.signalKey)
                put("entryTime", it.entryTime); put("expiryTime", it.expiryTime)
                put("entryPrice", it.entryPrice ?: JSONObject.NULL); put("exitPrice", it.exitPrice ?: JSONObject.NULL)
                put("payout", it.payout); put("result", it.result.name); put("score", it.score); put("reason", it.reason)
            })
        }
        prefs.edit().putString("trades", arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString("trades", null) ?: return
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                trades += PaperTrade(
                    o.getString("id"), o.getString("pair"), Side.valueOf(o.getString("side")),
                    o.getLong("signalTime"), o.optString("signalKey"),
                    o.getLong("entryTime"), o.getLong("expiryTime"),
                    o.optDouble("entryPrice").takeIf { it.isFinite() && it > 0.0 },
                    o.optDouble("exitPrice").takeIf { it.isFinite() && it > 0.0 },
                    o.getInt("payout"), PaperResult.valueOf(o.getString("result")),
                    o.getInt("score"), o.optString("reason")
                )
            }
            trades.lastOrNull()?.signalKey?.let { lastSignalKey = it }
        }.onFailure { trades.clear() }
    }
}
