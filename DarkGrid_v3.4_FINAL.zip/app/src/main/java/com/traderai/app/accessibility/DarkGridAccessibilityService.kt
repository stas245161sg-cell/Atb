package com.traderai.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import com.traderai.app.capture.CaptureState
import com.traderai.app.data.SessionLog

class DarkGridAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: DarkGridAccessibilityService? = null
            private set

        @Volatile var foregroundPackage: String = ""
            private set

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        CaptureState.accessibility(true)
        SessionLog.add("A11Y", "Служба специальных возможностей подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrBlank()) foregroundPackage = pkg
    }

    override fun onInterrupt() {
        SessionLog.add("A11Y", "Служба прервана")
    }

    override fun onDestroy() {
        instance = null
        CaptureState.accessibility(false)
        SessionLog.add("A11Y", "Служба отключена")
        super.onDestroy()
    }

    fun tap(x: Float, y: Float, onResult: (Boolean) -> Unit) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 60L)
        val desc = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(desc, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onResult(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { onResult(false) }
        }, null)
    }
}
