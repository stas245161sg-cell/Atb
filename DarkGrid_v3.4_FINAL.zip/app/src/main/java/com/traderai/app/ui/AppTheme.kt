package com.traderai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object TraderColors {
    val Void = Color(0xFF040507)
    val GlassBase = Color(0xFF090D12)
    val GlassDeep = Color(0xFF06080B)

    // Грани в духе стеклянного куба DG
    val RimTopLight = Color(0x40DDF3F7)
    val RimSubtle = Color(0x14FFFFFF)
    val RimActive = Color(0x738FD3DC)
    val RimRedAccent = Color(0x40D9534F)

    val Text = Color(0xFFF3F6F9)
    val Muted = Color(0xFF8490A0)

    val IceSteel = Color(0xFF8FD3DC)
    val IceSteelSoft = Color(0x228FD3DC)
    val IceSteelDeep = Color(0xFF0D1D24)

    val Red = Color(0xFFE0524A)
    val RedSoft = Color(0x22E0524A)
    val RedDeep = Color(0xFF240F11)

    val Amber = Color(0xFFD9A441)
}

private val DarkCubeGlassScheme = darkColorScheme(
    primary = TraderColors.IceSteel,
    onPrimary = TraderColors.Void,
    secondary = TraderColors.Amber,
    onSecondary = TraderColors.Void,
    background = TraderColors.Void,
    onBackground = TraderColors.Text,
    surface = TraderColors.GlassBase,
    onSurface = TraderColors.Text,
    surfaceVariant = TraderColors.GlassDeep,
    onSurfaceVariant = TraderColors.Muted,
    outline = TraderColors.RimSubtle,
    error = TraderColors.Red,
    onError = TraderColors.Text
)

@Composable
fun TraderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkCubeGlassScheme, content = content)
}
