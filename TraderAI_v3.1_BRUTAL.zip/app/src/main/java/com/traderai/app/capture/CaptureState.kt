package com.traderai.app.capture

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

object CaptureState {
    private val _capturing = MutableStateFlow(false)
    val capturing = _capturing.asStateFlow()

    private val _status = MutableStateFlow("Ожидание разрешения")
    val status = _status.asStateFlow()

    private val _analysis = MutableStateFlow("Нет анализа")
    val analysis = _analysis.asStateFlow()

    private val _calibrationReady = MutableStateFlow(false)
    val calibrationReady = _calibrationReady.asStateFlow()

    fun capturing(v: Boolean) { _capturing.value = v }
    fun status(v: String) { _status.value = v }
    fun analysis(v: String) { _analysis.value = v }
    fun calibrationReady(v: Boolean) { _calibrationReady.value = v }
}
