package com.traderai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object TraderColors {
    val Background = Color(0xFF050505)
    val Surface = Color(0xFF0E0E10)
    val SurfaceElevated = Color(0xFF151518)
    val Border = Color(0xFF232629)
    val BorderActive = Color(0xFF00FFAA)

    val Text = Color(0xFFF3F5F7)
    val Muted = Color(0xFF7D8590)

    val Mint = Color(0xFF00FFAA)
    val MintDim = Color(0xFF0B2E23)
    val Red = Color(0xFFFF3B30)
    val RedDim = Color(0xFF2B0E10)
    val Amber = Color(0xFFFFB800)
}

private val BrutalDarkScheme = darkColorScheme(
    primary = TraderColors.Mint,
    onPrimary = TraderColors.Background,
    secondary = TraderColors.Amber,
    onSecondary = TraderColors.Background,
    background = TraderColors.Background,
    onBackground = TraderColors.Text,
    surface = TraderColors.Surface,
    onSurface = TraderColors.Text,
    surfaceVariant = TraderColors.SurfaceElevated,
    onSurfaceVariant = TraderColors.Muted,
    outline = TraderColors.Border,
    error = TraderColors.Red,
    onError = TraderColors.Text
)

@Composable
fun TraderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = BrutalDarkScheme, content = content)
}
