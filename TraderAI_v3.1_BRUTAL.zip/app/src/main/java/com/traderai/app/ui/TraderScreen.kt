package com.traderai.app.ui

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.traderai.app.capture.CaptureState
import com.traderai.app.capture.ScreenCaptureService
import com.traderai.app.data.AppSettings
import com.traderai.app.data.SettingsRepo
import com.traderai.app.trading.TradingGate
import com.traderai.app.vision.TradingMode
import kotlinx.coroutines.launch

private val CardShape = RoundedCornerShape(8.dp)
private val ControlShape = RoundedCornerShape(6.dp)

@Composable
fun TraderScreen(repo: SettingsRepo) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val settings by repo.flow.collectAsStateWithLifecycle(initialValue = AppSettings())
    val capturing by CaptureState.capturing.collectAsStateWithLifecycle()
    val status by CaptureState.status.collectAsStateWithLifecycle()
    val analysis by CaptureState.analysis.collectAsStateWithLifecycle()
    val calibrationReady by CaptureState.calibrationReady.collectAsStateWithLifecycle()
    val approved by TradingGate.approved.collectAsStateWithLifecycle()

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            CaptureState.capturing(true)
            CaptureState.status("ЗАХВАТ ЗАПУСКАЕТСЯ…")
        } else {
            CaptureState.capturing(false)
            CaptureState.status("РАЗРЕШЕНИЕ НЕ ПОЛУЧЕНО")
        }
    }

    fun requestCapture() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    fun stopCapture() {
        val intent = Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        context.startService(intent)
        CaptureState.capturing(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TraderColors.Background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = "TRADER AI // v3.1",
                    color = TraderColors.Text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "OBSERVER · HEIKIN ASHI M5 · EXP 5M",
                    color = TraderColors.Muted,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 0.6.sp
                )
            }
            BadgePill(text = if (capturing) "LIVE" else "IDLE", active = capturing)
        }

        TerminalCard(title = "| СОСТОЯНИЕ") {
            Text(
                text = status,
                color = if (capturing) TraderColors.Mint else TraderColors.Amber,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
            val isStop = capturing
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(ControlShape)
                    .background(if (isStop) TraderColors.RedDim else TraderColors.MintDim)
                    .border(1.dp, if (isStop) TraderColors.Red else TraderColors.Mint, ControlShape)
                    .clickable { if (isStop) stopCapture() else requestCapture() }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isStop) "ОСТАНОВИТЬ АНАЛИЗ" else "ЗАПУСТИТЬ АНАЛИЗ",
                    color = if (isStop) TraderColors.Red else TraderColors.Mint,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }

        TerminalCard(title = "| УПРАВЛЕНИЕ") {
            Text("РЕЖИМ", color = TraderColors.Muted, fontSize = 11.sp,
                fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TradingMode.entries.forEach { mode ->
                    val selected = settings.mode == mode
                    Box(
                        modifier = Modifier.weight(1f).clip(ControlShape)
                            .background(if (selected) TraderColors.MintDim else TraderColors.SurfaceElevated)
                            .border(1.dp, if (selected) TraderColors.Mint else TraderColors.Border, ControlShape)
                            .clickable { scope.launch { repo.setMode(mode) } }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(mode.name, color = if (selected) TraderColors.Mint else TraderColors.Muted,
                            fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center)
                    }
                }
            }
            HorizontalDivider(color = TraderColors.Border, thickness = 1.dp)
            CompactToggleRow("НАПРАВЛЕНИЕ CALL", settings.call) { scope.launch { repo.setCall(it) } }
            CompactToggleRow("НАПРАВЛЕНИЕ PUT", settings.put) { scope.launch { repo.setPut(it) } }
            CompactToggleRow("PAPER TRADING", settings.paper) { scope.launch { repo.setPaper(it) } }
            HorizontalDivider(color = TraderColors.Border, thickness = 1.dp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("МИН. ВЫПЛАТА", color = TraderColors.Muted, fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace)
                Text("${settings.minPayout}%", color = TraderColors.Amber, fontSize = 13.sp,
                    fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Slider(
                value = settings.minPayout.toFloat(),
                onValueChange = { scope.launch { repo.setPayout(it.toInt()) } },
                valueRange = 50f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = TraderColors.Mint,
                    activeTrackColor = TraderColors.Mint,
                    inactiveTrackColor = TraderColors.Border
                )
            )
        }

        TerminalCard(title = "| КАЛИБРОВКА OHLC") {
            Text(
                text = if (calibrationReady)
                    "ШКАЛА И СВЕЧИ ГОТОВЫ. СВЕРЬТЕ 10+ СВЕЧ С ЭКРАНОМ."
                else "СИГНАЛЫ ЗАБЛОКИРОВАНЫ ДО ПОЛУЧЕНИЯ ДАННЫХ КАЛИБРОВКИ.",
                color = if (calibrationReady) TraderColors.Text else TraderColors.Muted,
                fontSize = 11.sp, fontFamily = FontFamily.Monospace
            )
            val canToggleCal = calibrationReady || approved
            val calBg = when { approved -> TraderColors.MintDim; canToggleCal -> TraderColors.SurfaceElevated; else -> TraderColors.Background }
            val calBorder = when { approved -> TraderColors.Mint; canToggleCal -> TraderColors.Amber; else -> TraderColors.Border }
            val calText = when { approved -> TraderColors.Mint; canToggleCal -> TraderColors.Amber; else -> TraderColors.Muted }
            Box(
                modifier = Modifier.fillMaxWidth().clip(ControlShape).background(calBg)
                    .border(1.dp, calBorder, ControlShape)
                    .clickable(enabled = canToggleCal) { TradingGate.set(!approved) }
                    .padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(if (approved) "КАЛИБРОВКА ПОДТВЕРЖДЕНА" else "ПОДТВЕРДИТЬ КАЛИБРОВКУ",
                    color = calText, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace, letterSpacing = 0.8.sp)
            }
            if (!settings.paper) {
                Text("PAPER TRADING ВЫКЛЮЧЕН — СДЕЛКИ НЕ ФИКСИРУЮТСЯ",
                    color = TraderColors.Red, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }

        TerminalCard(title = "| ТЕЛЕМЕТРИЯ КАДРА") {
            Text(analysis, color = TraderColors.Text, fontSize = 11.sp,
                lineHeight = 16.sp, fontFamily = FontFamily.Monospace)
        }

        Text("OBSERVER ONLY · АВТОКЛИКИ CALL/PUT ОТКЛЮЧЕНЫ",
            color = TraderColors.Muted, fontSize = 10.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(bottom = 4.dp))
    }
}

@Composable
private fun TerminalCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(CardShape).background(TraderColors.Surface)
            .border(1.dp, TraderColors.Border, CardShape).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, color = TraderColors.Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace, letterSpacing = 1.sp)
        content()
    }
}

@Composable
private fun CompactToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TraderColors.Text, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(
            checkedThumbColor = TraderColors.Background,
            checkedTrackColor = TraderColors.Mint,
            uncheckedThumbColor = TraderColors.Muted,
            uncheckedTrackColor = TraderColors.Background,
            uncheckedBorderColor = TraderColors.Border
        ))
    }
}

@Composable
private fun BadgePill(text: String, active: Boolean) {
    val fg = if (active) TraderColors.Mint else TraderColors.Muted
    val bg = if (active) TraderColors.MintDim else TraderColors.Surface
    val bd = if (active) TraderColors.Mint else TraderColors.Border
    Box(Modifier.clip(ControlShape).background(bg).border(1.dp, bd, ControlShape)
        .padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(text, color = fg, fontSize = 10.sp, fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace, letterSpacing = 0.8.sp)
    }
}
