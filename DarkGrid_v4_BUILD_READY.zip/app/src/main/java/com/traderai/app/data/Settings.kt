package com.traderai.app.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.traderai.app.vision.TradingMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore("traderai_settings")

data class AppSettings(
    val mode: TradingMode = TradingMode.BALANCED,
    val call: Boolean = true,
    val put: Boolean = true,
    val paper: Boolean = true,
    val minPayout: Int = 80,
    val autoTap: Boolean = false,
    val callX: Float = 0.29f,
    val callY: Float = 0.65f,
    val putX: Float = 0.71f,
    val putY: Float = 0.65f
)

class SettingsRepo(context: Context) {
    private val store = context.applicationContext.settingsDataStore
    private object K {
        val mode = stringPreferencesKey("mode")
        val call = booleanPreferencesKey("call")
        val put = booleanPreferencesKey("put")
        val paper = booleanPreferencesKey("paper")
        val payout = intPreferencesKey("payout")
        val autoTap = booleanPreferencesKey("auto_tap")
        val callX = floatPreferencesKey("call_x")
        val callY = floatPreferencesKey("call_y")
        val putX = floatPreferencesKey("put_x")
        val putY = floatPreferencesKey("put_y")
    }
    val flow: Flow<AppSettings> = store.data.map { p ->
        AppSettings(
            mode = runCatching { TradingMode.valueOf(p[K.mode] ?: "BALANCED") }.getOrDefault(TradingMode.BALANCED),
            call = p[K.call] ?: true,
            put = p[K.put] ?: true,
            paper = p[K.paper] ?: true,
            minPayout = (p[K.payout] ?: 80).coerceIn(50, 100),
            autoTap = p[K.autoTap] ?: false,
            callX = p[K.callX] ?: 0.29f,
            callY = p[K.callY] ?: 0.65f,
            putX = p[K.putX] ?: 0.71f,
            putY = p[K.putY] ?: 0.65f
        )
    }
    suspend fun setMode(v: TradingMode) { store.edit { it[K.mode] = v.name } }
    suspend fun setCall(v: Boolean) { store.edit { it[K.call] = v } }
    suspend fun setPut(v: Boolean) { store.edit { it[K.put] = v } }
    suspend fun setPaper(v: Boolean) { store.edit { it[K.paper] = v } }
    suspend fun setPayout(v: Int) { store.edit { it[K.payout] = v.coerceIn(50, 100) } }
    suspend fun setAutoTap(v: Boolean) { store.edit { it[K.autoTap] = v } }
    suspend fun setCallX(v: Float) { store.edit { it[K.callX] = v.coerceIn(0.05f, 0.95f) } }
    suspend fun setCallY(v: Float) { store.edit { it[K.callY] = v.coerceIn(0.05f, 0.95f) } }
    suspend fun setPutX(v: Float) { store.edit { it[K.putX] = v.coerceIn(0.05f, 0.95f) } }
    suspend fun setPutY(v: Float) { store.edit { it[K.putY] = v.coerceIn(0.05f, 0.95f) } }
}

