package com.traderai.app.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await
import java.util.Locale

data class OcrItem(val text: String, val bounds: Rect)

data class PriceLabel(
    val price: Double,
    val centerY: Float,
    val centerX: Float
)

data class OcrResult(
    val pair: String?,
    val payout: Int?,
    val secondsRemaining: Int?,
    val timeframeMins: Int?,
    val expiryMins: Int?,
    val priceLabels: List<PriceLabel>,
    val warnings: List<String>,
    val timerOcrData: TimerOcrData? = null
)

class ScreenOcr {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    // Защита от мусорного OCR (например «TND/USD» вместо «AUD/USD»):
    // смена пары сбрасывает историю свечей в TraderPipeline, поэтому принимаем
    // только правдоподобные базовые валюты и кэшируем последнюю удачную пару.
    private val knownBases = setOf(
        "AUD", "EUR", "GBP", "USD", "NZD", "CHF", "CAD", "JPY",
        "CNY", "SGD", "SEK", "NOK", "TRY", "ZAR", "BTC", "ETH", "LTC", "XRP"
    )
    @Volatile private var lastPair: String? = null
    @Volatile private var lastPairAt = 0L

    suspend fun read(bitmap: Bitmap, now: Long = System.currentTimeMillis()): OcrResult {
        if (bitmap.isRecycled || bitmap.width < 2 || bitmap.height < 2) {
            return OcrResult(null, null, null, null, null, emptyList(), listOf("Некорректный кадр"))
        }
        val text = try {
            recognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
        } catch (t: Throwable) {
            return OcrResult(null, null, null, null, null, emptyList(), listOf("Ошибка OCR: ${t.message}"))
        }

        val items = mutableListOf<OcrItem>()
        for (block in text.textBlocks) for (line in block.lines) {
            val box = line.boundingBox ?: continue
            items += OcrItem(line.text.trim(), Rect(box))
        }
        val w = bitmap.width.toFloat(); val h = bitmap.height.toFloat()
        val warnings = mutableListOf<String>()

        val rawPair = findPair(items, w, h)
        val pair = when {
            rawPair != null && rawPair.substringBefore("/") in knownBases && rawPair.substringAfter("/").substringBefore(" ") in knownBases -> {
                lastPair = rawPair; lastPairAt = now; rawPair
            }
            lastPair != null && now - lastPairAt < 60_000L -> lastPair
            else -> null
        }
        val payout = findPayout(items, w, h)

        // Единственный источник таймера — OCR текущего кадра в размеченной зоне.
        // Системные часы телефона никогда не подменяют таймер Pocket Option.
        val timerData = findTimer(items, w, h)
        val timer = timerData?.secondsRemaining
        warnings += if (timer == null) "Таймер M5 не распознан в зоне x=0.69..0.85, y=0.16..0.54"
                    else "Таймер прочитан OCR: ${timerData?.sourceText ?: "?"} (${timer} с)"

        // Таймфрейм и экспирация зафиксированы стратегией (M5 / 5 мин).
        // На основном графике PO подписи «M5» нет, поэтому требовать её из OCR нельзя.
        val timeframeOcr = findTimeframe(items, w, h)
        val timeframe = timeframeOcr ?: 5
        if (timeframeOcr == null) warnings += "M5 не показан на экране — принят фиксированный фрейм"
        val expiryOcr = findExpiry(items, w, h)
        val expiry = expiryOcr ?: 5
        if (expiryOcr == null) warnings += "Экспирация не прочитана — принято 5 мин"

        val prices = findPriceLabels(items, w, h)

        if (pair == null) warnings += "Пара не распознана"
        if (payout == null) warnings += "Выплата не распознана"
        if (prices.size < 3) warnings += "Нужно минимум 3 ценовые отметки (${prices.size})"

        return OcrResult(pair, payout, timer, timeframe, expiry, prices, warnings, timerData)
    }

    private fun center(i: OcrItem, w: Float, h: Float) = i.bounds.exactCenterX() / w to i.bounds.exactCenterY() / h

    private fun findPair(items: List<OcrItem>, w: Float, h: Float): String? {
        val regex = Regex("""\b([A-Z]{3})\s*/\s*([A-Z]{3})(?:\s+OTC)?\b""", RegexOption.IGNORE_CASE)
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.04f..0.60f && y in 0.11f..0.20f }
            .mapNotNull { regex.find(it.text.uppercase(Locale.US)) }
            .map { "${it.groupValues[1]}/${it.groupValues[2]}" + if (it.groupValues.getOrNull(3).orEmpty().isNotBlank()) " OTC" else "" }
            .firstOrNull()
    }

    private fun findPayout(items: List<OcrItem>, w: Float, h: Float): Int? {
        return items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.62f..0.72f }
            .mapNotNull { Regex("""(\d{2,3})\s*%""").find(it.text)?.groupValues?.getOrNull(1)?.toIntOrNull() }
            .firstOrNull { it in 50..100 }
    }

    private fun findTimer(items: List<OcrItem>, w: Float, h: Float): TimerOcrData? {
        return items.asSequence()
            .filter { val (x, y) = center(it, w, h); x in 0.69f..0.85f && y in 0.16f..0.54f }
            .mapNotNull { TimerTextParser.parse(it.text) }
            .firstOrNull()
    }

    private fun findTimeframe(items: List<OcrItem>, w: Float, h: Float): Int? {
        val upper = items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.10f..0.58f }
            .joinToString(" ") { it.text.uppercase(Locale.US) }
        return if (Regex("""\bM\s*5\b""").containsMatchIn(upper)) 5 else null
    }

    private fun findExpiry(items: List<OcrItem>, w: Float, h: Float): Int? {
        val lower = items.asSequence()
            .filter { val (_, y) = center(it, w, h); y in 0.45f..0.90f }
            .joinToString(" ") { it.text.uppercase(Locale.US) }
        val five = Regex("""(00\s*:\s*05\s*:\s*00|00\s*:\s*05|5\s*MIN|5\s*M\b)""")
        return if (five.containsMatchIn(lower)) 5 else null
    }

    private fun findPriceLabels(items: List<OcrItem>, w: Float, h: Float): List<PriceLabel> {
        val priceRegex = Regex("""(?<!\d)(\d+\.\d{3,8})(?!\d)""")
        return items.mapNotNull { item ->
            val (x, y) = center(item, w, h)
            if (x !in 0.70f..1.0f || y !in 0.18f..0.56f) return@mapNotNull null
            val v = priceRegex.find(item.text)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: return@mapNotNull null
            if (!v.isFinite() || v <= 0.0) return@mapNotNull null
            PriceLabel(v, item.bounds.exactCenterY(), item.bounds.exactCenterX())
        }.distinctBy { (it.price * 100000.0).toLong() }.sortedBy { it.centerY }
    }

    fun close() { recognizer.close() }
}

