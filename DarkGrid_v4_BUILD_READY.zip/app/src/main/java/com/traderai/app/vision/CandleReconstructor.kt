package com.traderai.app.vision

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class ReconstructionResult(
    val candles: List<Candle>,
    val confidence: Float,
    val priceScaleValid: Boolean,
    val calibrationReady: Boolean,
    val warnings: List<String>
)

class CandleReconstructor {
    private data class Hsv(val h: Float, val s: Float, val v: Float)
    private data class Column(val x: Int, val top: Int, val bottom: Int, val bull: Boolean)
    private data class Group(val cols: List<Column>) {
        val left get() = cols.minOf { it.x }
        val right get() = cols.maxOf { it.x }
        val centerX get() = (left + right) / 2f
        val top get() = cols.minOf { it.top }
        val bottom get() = cols.maxOf { it.bottom }
        val bull get() = cols.count { it.bull } >= cols.size / 2
        val height get() = bottom - top
    }
    private data class Scale(
        val intercept: Double, val slope: Double,
        val r2: Double, val maxErrPct: Double
    ) {
        // Ошибка шкалы 0.2% вместо 0.05%: OCR ценовой оси иногда ошибается в последнем знаке.
        val ok get() = r2 >= 0.95 && maxErrPct <= 0.002
        fun priceAt(y: Double): Double = intercept + slope * y
    }

    private fun hsv(c: Int): Hsv {
        val r = Color.red(c) / 255f; val g = Color.green(c) / 255f; val b = Color.blue(c) / 255f
        val mx = max(r, max(g, b)); val mn = min(r, min(g, b)); val d = mx - mn
        var h = 0f
        if (d != 0f) h = when (mx) {
            r -> 60f * (((g - b) / d) % 6f)
            g -> 60f * (((b - r) / d) + 2f)
            else -> 60f * (((r - g) / d) + 4f)
        }
        if (h < 0f) h += 360f
        return Hsv(h, if (mx == 0f) 0f else d / mx, mx)
    }

    private fun colorMatches(c: Int, bull: Boolean): Boolean {
        val v = hsv(c)
        return if (bull) ColorProfile.CANDLE_BULL.contains(v.h, v.s, v.v)
        else ColorProfile.CANDLE_BEAR.contains(v.h, v.s, v.v)
    }

    private fun calibrate(labels: List<PriceLabel>): Scale? {
        val pts = labels.distinctBy { (it.centerY / 5).toInt() }.sortedBy { it.centerY }
        if (pts.size < 3) return null
        for (i in 1 until pts.size) if (pts[i].centerY - pts[i - 1].centerY < 10f) return null
        if (pts.last().centerY - pts.first().centerY < 40f) return null

        val ys = pts.map { it.centerY.toDouble() }
        val ps = pts.map { it.price }
        val my = ys.average(); val mp = ps.average()
        val den = ys.sumOf { (it - my) * (it - my) }
        if (den <= 0.0) return null
        val slope = ys.indices.sumOf { (ys[it] - my) * (ps[it] - mp) } / den
        if (!slope.isFinite() || abs(slope) < 1e-12) return null
        val intercept = mp - slope * my
        val errors = pts.indices.map { abs(ps[it] - (intercept + slope * ys[it])) }
        val maxErrPct = (errors.maxOrNull() ?: Double.MAX_VALUE) / mp.coerceAtLeast(0.000001)
        val total = ps.sumOf { (it - mp) * (it - mp) }
        val residual = errors.sumOf { it * it }
        val r2 = if (total <= 1e-18) 0.0 else 1.0 - residual / total
        if (!r2.isFinite() || maxErrPct.isNaN()) return null
        return Scale(intercept, slope, r2, maxErrPct)
    }

    private fun columns(bitmap: Bitmap, rect: IntRect): List<Column> {
        val out = mutableListOf<Column>()
        for (x in rect.left until rect.right) {
            var best: Column? = null
            var start = -1; var bull: Boolean? = null
            for (y in rect.top until rect.bottom) {
                val px = bitmap.getPixel(x, y)
                val isBull = ColorProfile.CANDLE_BULL.let { val v = hsv(px); it.contains(v.h, v.s, v.v) }
                val isBear = ColorProfile.CANDLE_BEAR.let { val v = hsv(px); it.contains(v.h, v.s, v.v) }
                val cur = when { isBull && !isBear -> true; isBear && !isBull -> false; else -> null }
                if (cur == null) {
                    if (start >= 0 && bull != null && y - start >= 3) {
                        val c = Column(x, start, y - 1, bull)
                        if (best == null || c.bottom - c.top > best.bottom - best.top) best = c
                    }
                    start = -1; bull = null; continue
                }
                if (bull == null) { start = y; bull = cur }
            }
            if (start >= 0 && bull != null && rect.bottom - start >= 3) {
                val c = Column(x, start, rect.bottom - 1, bull)
                if (best == null || c.bottom - c.top > best.bottom - best.top) best = c
            }
            best?.let { out += it }
        }
        return out
    }

    private fun groupColumns(cols: List<Column>, width: Int): List<Group> {
        val maxGap = max(2, width / 180)
        val sorted = cols.sortedBy { it.x }
        val out = mutableListOf<Group>()
        var cur = mutableListOf<Column>()
        for (c in sorted) {
            if (cur.isEmpty()) { cur += c; continue }
            val p = cur.last()
            if (c.x - p.x <= maxGap + 1 && c.bull == p.bull) cur += c
            else { out += Group(cur); cur = mutableListOf(c) }
        }
        if (cur.isNotEmpty()) out += Group(cur)
        return out.filter { (it.right - it.left + 1) in 3..32 && it.height >= 4 }
    }

    /** Непрерывный фитиль строго от центра свечи, того же цвета, с ограничением длины. */
    private fun findWick(
        bmp: Bitmap, g: Group, direction: Int, rect: IntRect
    ): Int? {
        val cx = g.centerX.toInt()
        val radius = max(1, min(3, ((g.right - g.left + 1) / 2)))
        val start = if (direction < 0) g.top - 1 else g.bottom + 1
        val end = if (direction < 0) rect.top else rect.bottom - 1
        val step = direction
        var y = start
        var lastGood = start
        var gap = 0
        var found = false
        while (if (direction < 0) y >= end else y <= end) {
            var any = false
            for (x in (cx - radius)..(cx + radius)) {
                if (x in rect.left until rect.right && colorMatches(bmp.getPixel(x, y), g.bull)) { any = true; break }
            }
            if (any) {
                found = true; gap = 0; lastGood = y
            } else {
                gap++
                if (gap > 1) break
            }
            y += step
        }
        if (!found) return null
        val extended = abs(lastGood - start) + 1
        if (extended > g.height * 2 + 6) return null
        return lastGood
    }

    fun reconstruct(bmp: Bitmap, ocr: OcrResult, now: Long = System.currentTimeMillis()): ReconstructionResult {
        val warnings = mutableListOf<String>()
        val scale = calibrate(ocr.priceLabels)
        if (scale == null) {
            return ReconstructionResult(emptyList(), 0f, false, false,
                listOf("Ценовая шкала: минимум 3 отметки, R²>=0.95 и ошибка<=0.20%"))
        }
        val timer = ocr.secondsRemaining
            ?: return ReconstructionResult(emptyList(), 0f, true, false, listOf("Нет таймера M5"))
        if (ocr.timeframeMins != 5 || ocr.expiryMins != 5) {
            return ReconstructionResult(emptyList(), 0f, true, false, listOf("M5/5 мин не подтверждены OCR"))
        }

        val chart = ScreenZones.CHART.toPixels(bmp.width, bmp.height)
        val occ = ScreenZones.LEFT_OCCLUSION.toPixels(bmp.width, bmp.height)
        val marker = ScreenZones.TRADE_MARKER.toPixels(bmp.width, bmp.height)
        val scan = IntRect(max(chart.left, occ.right), chart.top, chart.right, chart.bottom)

        val groups = groupColumns(columns(bmp, scan), scan.width)
            .filter { g ->
                // плашка «Купить» — залитый прямоугольник 40..180 px шириной и 20..70 px высотой
                val w = g.right - g.left + 1
                !(g.centerX >= marker.left && g.centerX <= marker.right && w in 40..180 && g.height in 20..70)
            }
        if (groups.size < 10) warnings += "Мало тел свечей: ${groups.size}"
        if (groups.size > 80) warnings += "Слишком много групп: ${groups.size}"

        val estimated = now - ((300 - timer).coerceIn(0, 300) * 1000L)
        val currentOpen = (estimated / 300_000L) * 300_000L
        val ordered = groups.sortedBy { it.centerX }
        val candles = mutableListOf<Candle>()

        ordered.forEachIndexed { idx, g ->
            val upper = findWick(bmp, g, -1, scan)
            val lower = findWick(bmp, g, 1, scan)
            val wickKnown = upper != null && lower != null
            val yHigh = upper ?: g.top
            val yLow = lower ?: g.bottom
            val openY = if (g.bull) g.bottom else g.top
            val closeY = if (g.bull) g.top else g.bottom
            val open = scale.priceAt(openY.toDouble())
            val close = scale.priceAt(closeY.toDouble())
            val high = max(scale.priceAt(yHigh.toDouble()), max(open, close))
            val low = min(scale.priceAt(yLow.toDouble()), min(open, close))
            if (!high.isFinite() || !low.isFinite() || low <= 0.0 || high < low) return@forEachIndexed

            val gridOk = currentOpen % 300_000L == 0L
            val time = currentOpen - (ordered.lastIndex - idx) * 300_000L
            // Фитиль не обязателен для «проверенности»: на PO они часто тонкие
            // и не попадают в цветовой фильтр. Достаточно тела + шкалы + сетки.
            val verified = scale.ok && g.cols.size >= 3 && gridOk
            candles += Candle(
                time = time, open = open, high = high, low = low, close = close,
                closed = idx != ordered.lastIndex,
                confidence = if (verified) 0.92f else 0.60f,
                verified = verified
            )
            // Фитиль не обязателен для verified, поэтому не заспамываем логи.
            if (!wickKnown && warnings.count { it.contains("фитиль") } < 3) {
                warnings += "Свеча ${idx + 1}: фитиль не подтверждён"
            }
        }

        val countConf = when {
            candles.size >= 50 -> 1f
            candles.size >= 30 -> 0.85f
            candles.size >= 20 -> 0.70f
            else -> 0.5f
        }
        val verifiedRatio = if (candles.isEmpty()) 0f else candles.count { it.verified }.toFloat() / candles.size
        val confidence = (countConf * 0.2f + minOf(scale.r2, 1.0).toFloat() * 0.3f + verifiedRatio * 0.5f).coerceIn(0f, 1f)
        // Готовность калибровки здесь — по одному кадру; накопленная история
        // дополнительно проверяется TraderPipeline на непрерывный хвост из 30 свеч.
        val ready = scale.ok && verifiedRatio >= 0.80f && candles.size >= 20
        if (!gridOkLocal(currentOpen)) warnings += "Временная сетка не выровнена"
        return ReconstructionResult(candles, confidence, true, ready, warnings)
    }

    private fun gridOkLocal(t: Long) = t % 300_000L == 0L
}

