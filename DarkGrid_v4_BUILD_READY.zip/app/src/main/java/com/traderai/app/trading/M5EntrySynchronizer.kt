package com.traderai.app.trading

/** Detects a broker timer rollover from the final seconds of one M5 candle to the next.
 * No phone-clock fallback is used. A missed rollover is not reconstructed retroactively.
 */
class M5EntrySynchronizer(
    private val rolloverBeforeSeconds: Int = 2,
    private val rolloverAfterSeconds: Int = 298,
    private val maxObservationGapMs: Long = 2_500L
) {
    data class EntryWindow(val candleOpenTimeMs: Long, val observedAtMs: Long)
    private var previousSeconds: Int? = null
    private var previousAtMs: Long? = null
    private var lastEmittedOpen: Long = Long.MIN_VALUE

    @Synchronized
    fun observe(secondsRemaining: Int?, observedAtMs: Long): EntryWindow? {
        if (secondsRemaining == null || secondsRemaining !in 1..300 || observedAtMs <= 0L) {
            resetObservation(); return null
        }
        val prev = previousSeconds
        val prevAt = previousAtMs
        previousSeconds = secondsRemaining
        previousAtMs = observedAtMs
        if (prev == null || prevAt == null) return null
        if (observedAtMs <= prevAt || observedAtMs - prevAt > maxObservationGapMs) return null
        if (prev <= rolloverBeforeSeconds && secondsRemaining >= rolloverAfterSeconds) {
            val elapsedIntoNewCandle = (300 - secondsRemaining).coerceAtLeast(0) * 1000L
            val estimatedOpen = observedAtMs - elapsedIntoNewCandle
            val alignedOpen = (estimatedOpen / 300_000L) * 300_000L
            if (alignedOpen > 0L && alignedOpen != lastEmittedOpen) {
                lastEmittedOpen = alignedOpen
                return EntryWindow(alignedOpen, observedAtMs)
            }
        }
        return null
    }

    @Synchronized fun resetObservation() { previousSeconds = null; previousAtMs = null }
    @Synchronized fun resetAll() { resetObservation(); lastEmittedOpen = Long.MIN_VALUE }
}
