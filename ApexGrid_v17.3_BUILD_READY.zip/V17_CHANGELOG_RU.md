# ApexGrid V17.3 — unified Liquid Glass + офлайн-доступ + адаптивный OCR

V17.3:
- Удалён последний мёртвый `SignalSettings.kt` (переключатель MAX_WIN/BALANCED/MORE_SIGNALS) и оба вызова `SignalSettings.load(...)`. Единственный источник режимов — `TradingProfile` (Поток 0.45 / Баланс 0.55 / Снайпер 0.68).
- Payout OCR стал адаптивным: при стабильной выплате ≥80% опрос реже (2500 мс), у порога (80–84) или после `resetChartTracking()` — чаще (400 мс), иначе 600 мс. Поле `apexgrid_prefs` не используется — калибровка остаётся в прежнем хранилище.
- Иконка ApexGrid пока не заменена: ждём генерацию изображения.

---

# ApexGrid V17.2 — unified Liquid Glass + офлайн-доступ

Добавлены `SecurityGuard.kt` и `ApexGridAccess.kt`: офлайн-активация по коду `ApexGrid_byBoroda13` (хеш SHA-256 с солью, состояние в SharedPreferences). Экран активации в холодном Liquid Glass стиле показывается до основного терминала.

Отклонения от присланного «финального» комплекта (причины — конфликты и работоспособность):
- **Не добавлены** `ApexGridTheme.kt` и `ApexTopBarAndModes.kt` дословно: они дублировали `ApexGlassColors`, `ApexGridTheme`, `TradingProfile` и `LiquidGlassCard`. Вместо этого недостающие composable-функции (`ApexGlassBackdrop`, `LiquidGlassCard`, `LiquidGlassActionButton`, `GlassMetricRow`) добавлены в `ApexGridUI.kt`, старая карточка удалена из `Theme.kt`.
- **Не заменён `MainActivity.kt` заглушкой**: присланный вариант удалял весь рабочий интерфейс (START/STOP, логи, калибровка, маркеры). Вместо этого экран активации встроен в существующий `MainActivity` перед `PolarisScreen`.
- **Не использован присланный `ScreenCaptureService.kt`**: он ссылался на несуществующие `VoteEngine`, `DecisionEngine.MIN_PAYOUT`, `TradingAccessibilityService.isRunning()`, DROP-нул `SessionRiskGate.onExecutedGesture()` и хардкодил профиль `BALANCE`. Сохранён сервис V17 с единым движком и рабочим риск-гейтом.
- **Не использован присланный `ImageAnalyzer.kt` / `UnifiedStrategyEngine.kt`**: в них отсутствовали `dropLast(1)` и требование `candleClosed`, то есть вход шёл по формирующейся свече. Сохранены версии V17 с этими защитами.
- `SecurityGuard.allowed` изменён: `debuggable` блокирует доступ **только если задан `APEX_EXPECTED_SHA256`**.debug-сборка GitHub Actions иначе навсегда оставалась бы на экране активации.

Пороги профилей приведены к присланным: FLOW 0.45 / BALANCE 0.55 / SNIPER 0.68.

---

# ApexGrid V17.1 — unified Liquid Glass (бесконфликтный движок)

Ребрендинг: Polaris Protocol → **ApexGrid**. Новая палитра: ледяной циан `#5CE1E6`, сапфир `#4EA8DE`, коралловый сигнал `#FF4D6D`, глубокий фон `#04060A`. Мятный `#00FFAA` полностью убран. Моноширинная типографика для заголовка и метрик.

Три переключателя «Поток / Баланс / Снайпер» управляют **только порогом confidence** единого движка (0.44 / 0.52 / 0.62). Конфликтные стратегии не возвращались: `TradingProfile` не включает/не выключает стратегии и не создаёт `direction_conflict`.

Иконка и drawable `polaris_logo` пока сохранены — генерация новой иконки ApexGrid отложена.

База: Polaris Protocol V16. Сборка через GitHub Actions (Gradle 8.7, Kotlin 1.9.22).

## Удалено полностью

- OCR названия пары (`RoiZone.ASSET`, зона калибровки «Название пары`, `requestAssetOcr`, `AssetParser`).
- Конфликтное голосование: `VoteEngine.kt`, `Strategies.kt`, `DecisionEngine.kt` удалены.
- `direction_conflict`, `conflicting_votes`, `weak_vote`, `no_strategy_vote` больше не существуют.

## Ядро: UnifiedStrategyEngine.kt

- Единое направление выбирается один раз по EMA(5/13), наклону последних баров и цвету закрытой свечи.
- Остальные модули только **усиливают** выбранное направление (reinforcement), нейтральные индикаторы не режут сигнал:
  - форма свечи (чистое тело 0.25–0.82 — плюс, кульминация ≥0.90 — минус);
  - тень отскока (upper/lowerWickRatio);
  - зона края диапазона FIBO 14.6% (середина не мешает);
  - SuperTrend 10 3 / Stochastic 5 3 3 / AO 5 34 — только бонус при совпадении;
  - волатильность (сжатие/расширение).
- **Порог выплаты статичен: 80%.** Порог Confidence 0.52. Подтверждение: 2 разных состояния за ≥1.2 с.
- Вход строго по закрытой свече: `s.candleClosed == true` обязателен.
- Cooldown из BotPrefs (минимум 15 с); `SessionRiskGate` (30 жестов, 60 с) сохраняется.
- `onChartSwitched()` сбрасывает подтверждения и cooldown.

## Зрение: ImageAnalyzer.kt

- X-grid фильтрация свечей: берутся только компоненты с равным шагом по X; широкие горизонтальные плашки («Купить»/«Продать», меню) отсекаются.
- `labels.get(0,0,...)` вызывается один раз за кадр вместо 30 раз.
- Добавлены `upperWickRatio` / `lowerWickRatio`.
- Закрытие свечи фиксируется по появлению нового столбца справа (сдвиг правого края ≥0.7 pitch), окно 8 с.
- Защита от открытого меню вместо удалённого OCR: если X-сетка даёт 1–5 свечей или `pitch == 0`, кадр помечается невалидным.
- `resetChartTracking()` сбрасывает X-сетку и кэш выплаты при смене графика.
- SuperTrend / Stochastic / AO остаются по тем же HSV-маскам; новых индикаторов нет.

## Сервис и UI

- `ScreenCaptureService` переведён на `UnifiedStrategyEngine`; VOTE-логирование удалено (спам исчез).
- `ACTION_CHART_SWITCHED` сбрасывает и движок, и анализатор.
- EVAL теперь печатает `conf`, `reason`, `candle=CLOSED/FORMING`, ST/Stoch/AO и RISK-блок.
- Вкладка калибровки «Название пары» удалена из UI и из `RoiZone`.
- `BotState/BotPrefs/UiState` вынесены в отдельный `BotState.kt`.

## Известные ограничения

- Старый переключатель режимов в «Инфо» (Максимальный винрейт/Баланс/Больше сигналов) теперь **не влияет** на движок — удалён из логики, будет убран из UI в следующей версии.
- Payout OCR по-прежнему опрашивает зону каждые 600 мс; экономия достигается только ранним выходом по `!live` и невалидной сетке.
- Порог выплаты не различает CALL/PUT (один процент с экрана).
- Heikin Ashi и обычные свечи обрабатываются одним и тем же детектором; таймфрейм не привязан.
