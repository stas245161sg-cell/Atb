package com.example.tradebot

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.Closeable
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

enum class Trend { GREEN, RED, UNKNOWN }
enum class Cross { UP, DOWN, NONE }

/**
 * Результат анализа одного кадра. NaN / -1 / UNKNOWN означает «не удалось определить».
 * live = false, когда график прокручен (данные уходят за правый край) — входить нельзя.
 */
data class Snapshot(
    val superTrend: Trend,
    val stochCross: Cross,
    val stochValue: Float,
    val ao: Trend,
    val body: Float,
    val payout: Int,
    val live: Boolean = true,
    val aoSlope: Float = Float.NaN,      // изменение AO за последние 2 столбца (px): > 0 растёт, < 0 падает
    val chartNote: String = ""           // почему не распознаны свеча / SuperTrend (для строки EVAL)
)

// ======================= Зоны интереса (ROI) =======================

/** Четыре зоны, которые пользователь выставляет на экране калибровки. */
enum class RoiZone(val key: String, val title: String) {
    CHART("chart", "График"),
    STOCH("stoch", "Stochastic"),
    AO("ao", "AO"),
    PAYOUT("payout", "Выплата")
}

/** Прямоугольник в долях экрана: 0.0 = левый/верхний край, 1.0 = правый/нижний. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Хранение зон в SharedPreferences: roi_chart_left, roi_chart_top, roi_chart_right, roi_chart_bottom,
 * далее roi_stoch_*, roi_ao_*, roi_payout_*. Значения по умолчанию — раскладка Pocket Option 1080x2400.
 */
object RoiPrefs {
    private const val FILE = "tradebot"
    private const val MIN_SIZE = 0.01f

    fun default(zone: RoiZone): NormRect = when (zone) {
        RoiZone.CHART -> NormRect(0.00f, 0.110f, 1.00f, 0.530f)
        RoiZone.STOCH -> NormRect(0.00f, 0.693f, 0.94f, 0.782f)
        RoiZone.AO -> NormRect(0.00f, 0.785f, 0.94f, 0.873f)
        RoiZone.PAYOUT -> NormRect(0.20f, 0.646f, 0.37f, 0.672f)
    }

    fun load(ctx: Context, zone: RoiZone): NormRect {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = default(zone)
        val p = "roi_${zone.key}_"
        val r = NormRect(
            sp.getFloat(p + "left", d.left),
            sp.getFloat(p + "top", d.top),
            sp.getFloat(p + "right", d.right),
            sp.getFloat(p + "bottom", d.bottom)
        )
        return if (isValid(r)) r else d
    }

    fun save(ctx: Context, zone: RoiZone, r: NormRect) {
        val fixed = if (isValid(r)) r else default(zone)
        val p = "roi_${zone.key}_"
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(p + "left", fixed.left)
            .putFloat(p + "top", fixed.top)
            .putFloat(p + "right", fixed.right)
            .putFloat(p + "bottom", fixed.bottom)
            .apply()
    }

    private fun isValid(r: NormRect): Boolean =
        r.left >= 0f && r.top >= 0f && r.right <= 1f && r.bottom <= 1f &&
            r.right - r.left >= MIN_SIZE && r.bottom - r.top >= MIN_SIZE
}

/** Прочие константы анализа (сами зоны вынесены в RoiPrefs). */
object Roi {
    const val POCKET_PACKAGE = "com.pocketoption.broker"
    const val LAST_FRAME_FILE = "last_frame.jpg"   // последний кадр с графиком — фон экрана калибровки

    const val LIVE_EDGE_MAX = 0.95f     // данные дошли до правого края → график прокручен («>» внизу справа)
    const val STOCH_RECENT = 0.04f      // «свежесть» пересечения (доля ширины кадра, ≈2–3 свечи)

    // Запасное положение уровней 80 и 20 (доли высоты экрана), если линии на панели не найдены
    const val STOCH_Y80_ABS = 0.7163f
    const val STOCH_Y20_ABS = 0.7577f

    // Метки SuperTrend «Купить» / «Продать»: крупные залитые блоки с белым текстом, не свечи
    const val TAG_MIN_W = 0.06f         // минимальная ширина блока (доля ширины кадра)
    const val TAG_MIN_H = 0.008f        // минимальная высота блока (доля высоты кадра)
    const val TAG_MIN_WHITE = 0.02f     // доля белых пикселей (текст) внутри блока
    const val MAX_CANDLE_W = 0.025f     // шире — это линия или склейка, не свеча
}

/** Цвета в HSV OpenCV (H 0..179, S/V 0..255), замеры по скриншотам. */
object Hsv {
    // свеча вверх (70,183,52) H≈56; лаймовая линия SuperTrend и столбцы AO (113,181,20) H≈43
    val GREEN_LO = Scalar(30.0, 80.0, 80.0)
    val GREEN_HI = Scalar(90.0, 255.0, 255.0)
    // красная свеча (255,62,31) H≈4; линия SuperTrend и столбцы AO (205,8,12) H≈0/179
    val RED1_LO = Scalar(0.0, 80.0, 80.0)
    val RED1_HI = Scalar(10.0, 255.0, 255.0)
    val RED2_LO = Scalar(170.0, 80.0, 80.0)
    val RED2_HI = Scalar(180.0, 255.0, 255.0)

    // %K — синяя (39,72,178) H≈110; %D — оранжевая H≈10–15.
    val STOCH_K_LO = Scalar(100.0, 110.0, 110.0)
    val STOCH_K_HI = Scalar(128.0, 255.0, 255.0)
    val STOCH_D_LO = Scalar(5.0, 110.0, 110.0)
    val STOCH_D_HI = Scalar(18.0, 255.0, 255.0)

    // Белый текст внутри меток SuperTrend
    val WHITE_LO = Scalar(0.0, 0.0, 190.0)
    val WHITE_HI = Scalar(180.0, 60.0, 255.0)

    // Линии уровней Stochastic: 80 — бирюзовая (H≈86), 20 — жёлтая (H≈24)
    val LEVEL80_LO = Scalar(80.0, 100.0, 60.0)
    val LEVEL80_HI = Scalar(92.0, 255.0, 255.0)
    val LEVEL20_LO = Scalar(20.0, 100.0, 60.0)
    val LEVEL20_HI = Scalar(28.0, 255.0, 255.0)
}

/** Собирает все временные Mat и освобождает их разом (важно на 30 FPS). */
private class Mats : Closeable {
    private val list = ArrayList<Mat>()
    fun <T : Mat> keep(m: T): T {
        list.add(m)
        return m
    }
    fun mat(): Mat = keep(Mat())
    override fun close() {
        list.forEach { it.release() }
        list.clear()
    }
}

/** Пиксельные границы зоны внутри кадра. */
private class Box(val r0: Int, val r1: Int, val c0: Int, val c1: Int)

private class ChartResult(val live: Boolean, val superTrend: Trend, val body: Float, val note: String = "")

class ImageAnalyzer(context: Context) : Closeable {

    private companion object {
        const val TAG = "ImageAnalyzer"
        const val MIN_ST_PIXELS = 3
        const val DOMINANCE = 1.25f
        const val OCR_INTERVAL_MS = 600L
        const val PAYOUT_TTL_MS = 5000L
        const val OCR_UPSCALE = 3
        const val OCR_LOG_HEARTBEAT_MS = 30_000L
        const val OCR_ERR_LOG_MS = 10_000L
        const val ROI_RELOAD_MS = 2_000L

        // Строгий разбор payout: берём 2–3 цифры подряд, число должно быть в диапазоне 50..99
        val PAYOUT_REGEX = Regex("(\\d{2,3})")
        const val PAYOUT_MIN = 50
        const val PAYOUT_MAX = 99
    }

    private val appContext: Context = context.applicationContext

    private val cvReady: Boolean = try {
        OpenCVLoader.initDebug()
    } catch (t: Throwable) {
        Log.e(TAG, "OpenCV init failed", t)
        false
    }
    val ready: Boolean get() = cvReady

    /** Причина последней ошибки анализа кадра (для журнала). */
    @Volatile var lastError: String? = null
        private set

    // Зоны читаются из SharedPreferences при создании анализатора (каждый запуск захвата)
    // и затем перечитываются раз в 2 секунды — калибровка действует без перезапуска.
    private var rois: Map<RoiZone, NormRect> = loadRois()
    private var roisLoadedAt = SystemClock.elapsedRealtime()

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val ocrBusy = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastOcrLogKey = ""
    private var lastOcrLogAt = 0L
    private var lastOcrErrAt = 0L
    @Volatile private var payout = -1
    @Volatile private var payoutAt = 0L

    init {
        LogRepository.addLog("ROI: ${describeRois(rois)}")
    }

    private fun loadRois(): Map<RoiZone, NormRect> =
        RoiZone.values().associateWith { RoiPrefs.load(appContext, it) }

    private fun refreshRois(now: Long) {
        if (now - roisLoadedAt < ROI_RELOAD_MS) return
        roisLoadedAt = now
        val fresh = loadRois()
        if (fresh != rois) {
            rois = fresh
            LogRepository.addLog("ROI обновлены: ${describeRois(fresh)}")
        }
    }

    private fun describeRois(map: Map<RoiZone, NormRect>): String =
        map.entries.joinToString(" ") { (zone, r) ->
            "${zone.key}=x${pct(r.left)}-${pct(r.right)} y${pct(r.top)}-${pct(r.bottom)}"
        }

    private fun pct(v: Float): Int = (v * 100).roundToInt()

    fun analyze(bmp: Bitmap): Snapshot? {
        if (!cvReady) return null
        return try {
            refreshRois(SystemClock.elapsedRealtime())
            requestPayoutOcr(bmp)
            Mats().use { m ->
                val rgba = m.mat()
                Utils.bitmapToMat(bmp, rgba)
                val rgb = m.mat()
                Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
                val hsv = m.mat()
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
                val frameW = hsv.cols()
                val frameH = hsv.rows()

                val chart = chart(hsv, frameW, frameH, m)
                if (!chart.live) {
                    return@use Snapshot(
                        Trend.UNKNOWN, Cross.NONE, Float.NaN, Trend.UNKNOWN,
                        Float.NaN, currentPayout(), live = false
                    )
                }
                val (cross, crossValue) = stochastic(hsv, frameW, m)
                val (aoColor, aoSlope) = awesome(hsv, m)

                Snapshot(
                    chart.superTrend, cross, crossValue, aoColor, chart.body, currentPayout(),
                    aoSlope = aoSlope, chartNote = chart.note
                )
            }
        } catch (t: Throwable) {
            Log.e(TAG, "analyze failed", t)
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            null
        }
    }

    // ---------- вспомогательные ----------

    /** Пиксельные границы зоны; доли берутся из сохранённой калибровки. */
    private fun box(hsv: Mat, r: NormRect): Box {
        val r0 = (hsv.rows() * r.top).toInt().coerceIn(0, hsv.rows() - 1)
        val r1 = (hsv.rows() * r.bottom).toInt().coerceIn(r0 + 1, hsv.rows())
        val c0 = (hsv.cols() * r.left).toInt().coerceIn(0, hsv.cols() - 1)
        val c1 = (hsv.cols() * r.right).toInt().coerceIn(c0 + 1, hsv.cols())
        return Box(r0, r1, c0, c1)
    }

    private fun Mat.crop(b: Box): Mat = submat(b.r0, b.r1, b.c0, b.c1)

    private fun greenMask(src: Mat, m: Mats): Mat {
        val out = m.mat()
        Core.inRange(src, Hsv.GREEN_LO, Hsv.GREEN_HI, out)
        return out
    }

    private fun redMask(src: Mat, m: Mats): Mat {
        val a = m.mat()
        val b = m.mat()
        Core.inRange(src, Hsv.RED1_LO, Hsv.RED1_HI, a)
        Core.inRange(src, Hsv.RED2_LO, Hsv.RED2_HI, b)
        Core.bitwise_or(a, b, a)
        return a
    }

    /** Индекс самой правой колонки, где есть хотя бы [minPixels] пикселей маски; -1 если пусто. */
    private fun lastColoredColumn(mask: Mat, m: Mats, minPixels: Int = 2): Int {
        val sums = m.mat()
        Core.reduce(mask, sums, 0, Core.REDUCE_SUM, CvType.CV_32S)
        val arr = IntArray(mask.cols())
        sums.get(0, 0, arr)
        var x = arr.size - 1
        while (x >= 0 && arr[x] < 255 * minPixels) x--
        return x
    }

    // ---------- 1. График: метки, SuperTrend, тело последней свечи ----------

    private fun chart(hsv: Mat, frameW: Int, frameH: Int, m: Mats): ChartResult {
        val b = box(hsv, rois.getValue(RoiZone.CHART))
        val roi = hsv.crop(b)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        removeTags(roi, g, r, all, frameW, frameH, m)

        // Правый край данных = правый край последней свечи (индекс внутри зоны + сдвиг зоны)
        val end = lastColoredColumn(all, m)
        if (end < 0) return ChartResult(true, Trend.UNKNOWN, Float.NaN, "no_colored_pixels_in_chart_roi")
        if (b.c0 + end >= frameW * Roi.LIVE_EDGE_MAX) return ChartResult(false, Trend.UNKNOWN, Float.NaN)

        return lastCandle(g, r, all, end + 1, frameW, m)
    }

    /**
     * Метки SuperTrend «Купить»/«Продать» — крупные залитые прямоугольники с белым текстом того же цвета,
     * что свечи и линия. Они опасны тем, что после недавнего разворота выступают правее последней свечи
     * и могут касаться линии. Поэтому:
     *  1) берём «толстую» часть маски (открытие 5x5): тонкая линия SuperTrend и фитили отпадают,
     *     метка перестаёт быть связанной с линией;
     *  2) меткой считаем крупный блок, внутри которого есть белый текст (у свечей белого нет);
     *  3) заливаем «дырки» (буквы), расширяем и вырезаем блок из масок;
     *  4) убираем мелкие остатки краёв.
     */
    private fun removeTags(roi: Mat, g: Mat, r: Mat, all: Mat, frameW: Int, frameH: Int, m: Mats) {
        val k = (5f * frameW / 540f).roundToInt().coerceAtLeast(3)
        val kernel = m.keep(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(k.toDouble(), k.toDouble())))

        val thick = m.mat()
        Imgproc.morphologyEx(all, thick, Imgproc.MORPH_OPEN, kernel)

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(thick, labels, stats, centroids, 8, CvType.CV_32S)
        if (n >= 2) {
            val st = IntArray(n * 5)
            stats.get(0, 0, st)
            val white = m.mat()
            Core.inRange(roi, Hsv.WHITE_LO, Hsv.WHITE_HI, white)

            val tagMask = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
            val one = m.mat()
            var found = false
            for (i in 1 until n) {
                val x = st[i * 5]
                val y = st[i * 5 + 1]
                val w = st[i * 5 + 2]
                val h = st[i * 5 + 3]
                if (w < Roi.TAG_MIN_W * frameW || h < Roi.TAG_MIN_H * frameH) continue
                val whiteCount = Core.countNonZero(white.submat(y, y + h, x, x + w))
                if (whiteCount >= Roi.TAG_MIN_WHITE * w * h) {
                    Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                    Core.bitwise_or(tagMask, one, tagMask)
                    found = true
                }
            }
            if (found) {
                val work = m.mat()
                tagMask.copyTo(work)
                val contours = ArrayList<MatOfPoint>()
                val hierarchy = m.mat()
                Imgproc.findContours(work, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
                Imgproc.drawContours(tagMask, contours, -1, Scalar(255.0), -1)   // -1 = залить
                contours.forEach { it.release() }

                val grown = m.mat()
                Imgproc.dilate(tagMask, grown, kernel)
                val inverse = m.mat()
                Core.bitwise_not(grown, inverse)
                Core.bitwise_and(g, inverse, g)
                Core.bitwise_and(r, inverse, r)
                Core.bitwise_or(g, r, all)
            }
        }
        removeSpecks(g, r, all, frameW, m)
    }

    /** Мелкий мусор (остатки краёв меток): компоненты уже ~3 px и ниже ~6 px в масштабе кадра 540 px. */
    private fun removeSpecks(g: Mat, r: Mat, all: Mat, frameW: Int, m: Mats) {
        val s = frameW / 540f
        val minW = maxOf(2, (3f * s).roundToInt())
        val minH = maxOf(3, (6f * s).roundToInt())

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val junk = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            if (st[i * 5 + 2] < minW && st[i * 5 + 3] < minH) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(junk, one, junk)
                found = true
            }
        }
        if (!found) return
        val inverse = m.mat()
        Core.bitwise_not(junk, inverse)
        Core.bitwise_and(g, inverse, g)
        Core.bitwise_and(r, inverse, r)
        Core.bitwise_or(g, r, all)
    }

    /**
     * Последняя свеча = связная компонента (тело + фитили) у правого края данных.
     * body = высота тела / полная высота: строки, где ширина компоненты ≥ половины максимальной, — тело.
     * Цвет SuperTrend = цвет линии в колонках центра последней свечи вне вертикального диапазона самой свечи
     * (линия проходит через центр каждой свечи) — так флип виден сразу, без запаздывания.
     */
    private fun lastCandle(g: Mat, r: Mat, all: Mat, x1: Int, frameW: Int, m: Mats): ChartResult {
        fun unknown(note: String) = ChartResult(true, Trend.UNKNOWN, Float.NaN, note)
        val win = maxOf(10, (0.02f * frameW).toInt()) * 2
        val cx0 = (x1 - win).coerceAtLeast(0)
        if (x1 - cx0 < 4) return unknown("window_too_small")
        val sub = all.colRange(cx0, x1)

        // Горизонтальная синяя линия текущей цены режет свечи по вертикали — склеиваем разрыв
        val closeH = (5f * frameW / 540f).roundToInt().coerceAtLeast(3)
        val vk = m.keep(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(1.0, closeH.toDouble())))
        val closed = m.mat()
        Imgproc.morphologyEx(sub, closed, Imgproc.MORPH_CLOSE, vk)

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(closed, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return unknown("no_components")

        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        val cols = closed.cols()
        val maxW = Roi.MAX_CANDLE_W * frameW

        var best = -1
        var widest = 0
        for (i in 1 until n) {
            val left = st[i * 5]
            val w = st[i * 5 + 2]
            val area = st[i * 5 + 4]
            if (w > maxW) {                                         // линия SuperTrend или склейка свечей
                if (left + w >= cols - 1 && w > widest) widest = w
                continue
            }
            if (left + w >= cols - 1 && (best < 0 || area > st[best * 5 + 4])) best = i
        }
        if (best < 0) {
            return unknown(
                if (widest > 0) "candle_too_wide(w=${widest}px>max=${maxW.toInt()}px)"
                else "no_component_at_right_edge"
            )
        }

        val bx = st[best * 5]
        val by = st[best * 5 + 1]
        val bw = st[best * 5 + 2]
        val bh = st[best * 5 + 3]
        if (bh < 2) return unknown("candle_too_short")

        // --- тело свечи ---
        val lab = IntArray(closed.rows() * cols)
        labels.get(0, 0, lab)
        val rowCounts = IntArray(bh)
        var maxRow = 0
        for (yy in 0 until bh) {
            var c = 0
            val base = (by + yy) * cols
            for (xx in bx until bx + bw) if (lab[base + xx] == best) c++
            rowCounts[yy] = c
            if (c > maxRow) maxRow = c
        }
        val threshold = maxOf(3f, 0.5f * maxRow)
        var bodyRows = 0
        for (c in rowCounts) if (c >= threshold) bodyRows++
        // bodyRows == 0: ни одна строка свечи не шире 3 px — это сбой измерения (слишком мелкий масштаб графика),
        // а не «идеально маленькое тело»; помечаем как неизвестное, чтобы фильтр тела не пропустил такой кадр
        val body = if (bodyRows == 0) Float.NaN else (bodyRows.toFloat() / bh).coerceIn(0f, 1f)

        // --- цвет SuperTrend в колонках центра свечи вне её диапазона по высоте ---
        val xc = cx0 + bx + bw / 2
        val rad = (2f * frameW / 540f).roundToInt().coerceAtLeast(2)
        val c0 = (xc - rad).coerceAtLeast(0)
        val c1 = (xc + rad).coerceAtMost(g.cols())
        val ya = (by - 2).coerceAtLeast(0)
        val yb = (by + bh + 2).coerceAtMost(g.rows())
        if (c1 - c0 < 1 || yb <= ya) return ChartResult(true, Trend.UNKNOWN, body)

        val gc = Core.countNonZero(g.colRange(c0, c1)) - Core.countNonZero(g.submat(ya, yb, c0, c1))
        val rc = Core.countNonZero(r.colRange(c0, c1)) - Core.countNonZero(r.submat(ya, yb, c0, c1))
        val trend = when {
            gc + rc < MIN_ST_PIXELS -> Trend.UNKNOWN
            gc > rc * DOMINANCE -> Trend.GREEN
            rc > gc * DOMINANCE -> Trend.RED
            else -> Trend.UNKNOWN
        }
        val note = when {
            body.isNaN() -> "body_not_measured(maxRowWidth=${maxRow}px<3)"
            gc + rc < MIN_ST_PIXELS -> "st_line_not_found(g=$gc,r=$rc)"
            trend == Trend.UNKNOWN -> "st_ambiguous(g=$gc,r=$rc)"
            else -> ""
        }
        return ChartResult(true, trend, body, note)
    }

    // ---------- 2. Stochastic (5,3,3) ----------

    private fun stochastic(hsv: Mat, frameW: Int, m: Mats): Pair<Cross, Float> {
        val b = box(hsv, rois.getValue(RoiZone.STOCH))
        val roi = hsv.crop(b)
        val k = m.mat()
        val d = m.mat()
        Core.inRange(roi, Hsv.STOCH_K_LO, Hsv.STOCH_K_HI, k)
        Core.inRange(roi, Hsv.STOCH_D_LO, Hsv.STOCH_D_HI, d)

        val rows = k.rows()
        val cols = k.cols()
        val kb = ByteArray(rows * cols)
        val db = ByteArray(rows * cols)
        k.get(0, 0, kb)
        d.get(0, 0, db)

        // Шкала 0..100 привязана к линиям уровней 80 и 20 на самой панели, а не к границам рамки,
        // поэтому значение не зависит от того, как пользователь нарисовал зону
        val (y80, y20) = stochLevels(roi, b.r0, hsv.rows(), m)

        val sumK = LongArray(cols)
        val cntK = IntArray(cols)
        val sumD = LongArray(cols)
        val cntD = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (kb[base + x].toInt() != 0) { sumK[x] += y.toLong(); cntK[x]++ }
                if (db[base + x].toInt() != 0) { sumD[x] += y.toLong(); cntD[x]++ }
            }
        }

        // Конец данных: последняя колонка, где видны обе линии (правее — пустое поле графика)
        var lastX = -1
        for (x in cols - 1 downTo 0) {
            if (cntK[x] > 0 && cntD[x] > 0) { lastX = x; break }
        }
        if (lastX < 0) return Pair(Cross.NONE, Float.NaN)

        val deadzone = 0.5f * frameW / 540f
        var prevSign = 0
        var crossX = -1
        var crossDir = Cross.NONE
        var crossVal = Float.NaN
        for (x in 0..lastX) {
            if (cntK[x] == 0 || cntD[x] == 0) continue
            val yK = sumK[x].toFloat() / cntK[x]
            val yD = sumD[x].toFloat() / cntD[x]
            val diff = yD - yK                      // > 0  →  %K выше %D (меньший y = выше)
            val sign = when {
                diff > deadzone -> 1
                diff < -deadzone -> -1
                else -> 0
            }
            if (sign == 0) continue
            if (prevSign != 0 && sign != prevSign) {
                crossX = x
                crossDir = if (sign > 0) Cross.UP else Cross.DOWN
                crossVal = toStochValue((yK + yD) / 2f, y80, y20)
            }
            prevSign = sign
        }

        val recentCols = (frameW * Roi.STOCH_RECENT).toInt().coerceAtLeast(4)
        if (crossX < 0 || lastX - crossX > recentCols) return Pair(Cross.NONE, Float.NaN)
        return Pair(crossDir, crossVal)
    }

    /**
     * Строки (внутри зоны) линий уровней 80 и 20. Ищем длинные горизонтальные линии бирюзового и жёлтого цвета;
     * если не нашли — берём запасные доли высоты экрана.
     */
    private fun stochLevels(roi: Mat, roiTop: Int, frameH: Int, m: Mats): Pair<Float, Float> {
        val teal = m.mat()
        val yellow = m.mat()
        Core.inRange(roi, Hsv.LEVEL80_LO, Hsv.LEVEL80_HI, teal)
        Core.inRange(roi, Hsv.LEVEL20_LO, Hsv.LEVEL20_HI, yellow)
        val a = lineCenter(teal, m)
        val b = lineCenter(yellow, m)
        if (a != null && b != null && b - a >= frameH * 0.02f) return Pair(a, b)
        return Pair(Roi.STOCH_Y80_ABS * frameH - roiTop, Roi.STOCH_Y20_ABS * frameH - roiTop)
    }

    /** Вертикальный центр самой «насыщенной» горизонтальной линии маски; null, если линии нет. */
    private fun lineCenter(mask: Mat, m: Mats): Float? {
        val sums = m.mat()
        Core.reduce(mask, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = mask.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var max = 0
        for (v in arr) if (v > max) max = v
        if (max < 255 * 0.25f * mask.cols()) return null
        var wSum = 0.0
        var ySum = 0.0
        for (y in 0 until rows) {
            if (arr[y] >= max / 2) {
                wSum += arr[y]
                ySum += arr[y].toDouble() * y
            }
        }
        return (ySum / wSum).toFloat()
    }

    /** Линейная шкала по двум опорным линиям: y80 → 80, y20 → 20. */
    private fun toStochValue(y: Float, y80: Float, y20: Float): Float {
        val v = 80f - (y - y80) * 60f / (y20 - y80)
        return v.coerceIn(0f, 100f)
    }

    // ---------- 3. Awesome Oscillator (5,34) ----------

    private fun awesome(hsv: Mat, m: Mats): Pair<Trend, Float> {
        val b = box(hsv, rois.getValue(RoiZone.AO))
        val roi = hsv.crop(b)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        val x = lastColoredColumn(all, m)
        if (x < 0) return Pair(Trend.UNKNOWN, Float.NaN)

        val x0 = (x - 2).coerceAtLeast(0)
        val gc = Core.countNonZero(g.colRange(x0, x + 1))
        val rc = Core.countNonZero(r.colRange(x0, x + 1))
        val color = when {
            gc > rc -> Trend.GREEN
            rc > gc -> Trend.RED
            else -> Trend.UNKNOWN
        }
        return Pair(color, aoSlope(all))
    }

    /**
     * Изменение AO за последние два столбца: value[последний] − value[третий с конца], в пикселях зоны.
     * Значение столбца считается от базовой линии (нуля): над ней — плюс, под ней — минус.
     * > 0 — AO растёт, < 0 — падает, NaN — определить не удалось.
     * Цвет столбца в Pocket Option — это знак изменения к предыдущему столбцу, поэтому «красный, но растёт»
     * для одного последнего столбца невозможен; растущий наклон за два столбца ловит одиночный красный «провал».
     */
    private fun aoSlope(all: Mat): Float {
        val rows = all.rows()
        val cols = all.cols()
        val buf = ByteArray(rows * cols)
        all.get(0, 0, buf)

        val top = IntArray(cols) { -1 }
        val bot = IntArray(cols) { -1 }
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (buf[base + x].toInt() != 0) {
                    if (top[x] < 0) top[x] = y
                    bot[x] = y
                }
            }
        }

        // Столбцы гистограммы = группы подряд идущих непустых колонок шириной от 2 px
        val bars = ArrayList<IntArray>()
        var x = 0
        while (x < cols) {
            if (top[x] < 0) { x++; continue }
            var t = top[x]
            var bt = bot[x]
            var xx = x
            while (xx < cols && top[xx] >= 0) {
                if (top[xx] < t) t = top[xx]
                if (bot[xx] > bt) bt = bot[xx]
                xx++
            }
            if (xx - x >= 2) bars.add(intArrayOf(t, bt))
            x = xx
        }
        if (bars.size < 4) return Float.NaN

        // Базовая линия — самая частая граница столбцов (все столбцы «растут» от неё)
        val freq = HashMap<Int, Int>()
        for (bar in bars) {
            freq[bar[0]] = (freq[bar[0]] ?: 0) + 1
            freq[bar[1]] = (freq[bar[1]] ?: 0) + 1
        }
        var baseline = bars[0][0]
        var bestScore = -1
        for (v in freq.keys) {
            val score = (freq[v - 1] ?: 0) + (freq[v] ?: 0) + (freq[v + 1] ?: 0)
            if (score > bestScore) {
                bestScore = score
                baseline = v
            }
        }
        val zero = baseline

        fun value(bar: IntArray): Int {
            val up = zero - bar[0]
            val down = bar[1] - zero
            return if (up >= down) up else -down
        }
        val last = value(bars[bars.size - 1])
        val third = value(bars[bars.size - 3])
        return (last - third).toFloat()
    }

    // ---------- 4. Payout через ML Kit OCR + строгая регулярка ----------

    private fun requestPayoutOcr(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOcrAt < OCR_INTERVAL_MS) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now
        try {
            val zone = rois.getValue(RoiZone.PAYOUT)
            val x0 = (bmp.width * zone.left).toInt().coerceIn(0, bmp.width - 2)
            val x1 = (bmp.width * zone.right).toInt().coerceIn(x0 + 1, bmp.width)
            val y0 = (bmp.height * zone.top).toInt().coerceIn(0, bmp.height - 2)
            val y1 = (bmp.height * zone.bottom).toInt().coerceIn(y0 + 1, bmp.height)
            val crop = Bitmap.createBitmap(bmp, x0, y0, x1 - x0, y1 - y0)
            val scaled = Bitmap.createScaledBitmap(
                crop, crop.width * OCR_UPSCALE, crop.height * OCR_UPSCALE, true
            )
            if (scaled !== crop) crop.recycle()

            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val raw = text.text.replace('\n', ' ').trim().take(40)
                    val extracted = extractPayout(raw)
                    val nowMs = SystemClock.elapsedRealtime()
                    if (extracted != null) {
                        payout = extracted
                        payoutAt = nowMs
                    }
                    // В журнал — при изменении результата и раз в 30 с, чтобы не засорять его (OCR идёт ~2 раза в секунду)
                    val key = "$raw|$extracted"
                    if (key != lastOcrLogKey || nowMs - lastOcrLogAt >= OCR_LOG_HEARTBEAT_MS) {
                        lastOcrLogKey = key
                        lastOcrLogAt = nowMs
                        LogRepository.addLog("OCR RAW: '$raw' -> EXTRACTED: ${extracted ?: "null"}")
                    }
                }
                .addOnFailureListener { err ->
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastOcrErrAt >= OCR_ERR_LOG_MS) {
                        lastOcrErrAt = nowMs
                        LogRepository.addLog("OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    ocrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "ocr failed", t)
            ocrBusy.set(false)
        }
    }

    /**
     * Строгий разбор: из сырой строки ('YOTC +92', '92%', 'SD OTC +9;') берём числа из 2–3 цифр
     * и возвращаем первое в диапазоне 50..99; иначе null.
     */
    private fun extractPayout(raw: String): Int? {
        for (match in PAYOUT_REGEX.findAll(raw)) {
            val v = match.groupValues[1].toIntOrNull() ?: continue
            if (v in PAYOUT_MIN..PAYOUT_MAX) return v
        }
        return null
    }

    private fun currentPayout(): Int =
        if (SystemClock.elapsedRealtime() - payoutAt > PAYOUT_TTL_MS) -1 else payout

    override fun close() {
        try { recognizer.close() } catch (ignored: Throwable) {}
    }
}
