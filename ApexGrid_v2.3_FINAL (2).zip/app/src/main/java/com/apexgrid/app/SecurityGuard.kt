package com.apexgrid.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest
import java.util.Locale

object SecurityGuard {
    fun signingCertSha256(context: Context): String {
        return try {
            val pm = context.packageManager
            val pkg = context.packageName
            val sigs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                info.signingInfo?.apkContentsSigners
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES).signatures
            } ?: return ""
            val first = sigs.firstOrNull() ?: return ""
            val digest = MessageDigest.getInstance("SHA-256").digest(first.toByteArray())
            digest.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
        } catch (_: Throwable) {
            ""
        }
    }
}
