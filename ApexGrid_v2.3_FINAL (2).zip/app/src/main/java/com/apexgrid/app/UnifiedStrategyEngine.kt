package com.apexgrid.app

import kotlin.math.roundToInt

data class FiboLevels(
    val maxHigh: Float,
    val minLow: Float,
    val range: Float,
    val putLevel: Float,
    val callLevel: Float,
    val anchorY: Float
)

fun priceOf(y: Float, f: FiboLevels): Float = f.anchorY - y

fun fiboLevels(s: Snapshot): FiboLevels? {
    if (s.highs.isEmpty() || s.lows.isEmpty() || s.highs.size != s.lows.size) return null
    if (s.highs.any { !it.isFinite() } || s.lows.any { !it.isFinite() }) return null
    if (s.highs.indices.any { s.highs[it] > s.lows[it] }) return null
    val highY = s.highs.min()
    val lowY = s.lows.max()
    val range = lowY - highY
    if (!range.isFinite() || range <= 4f) return null
    return FiboLevels(
        maxHigh = highY,
        minLow = lowY,
        range = range,
        putLevel = highY + 0.146f * range,
        callLevel = lowY - 0.146f * range,
        anchorY = lowY
    )
}

class UnifiedStrategyEngine(
    private val cooldownMs: () -> Long,
    private val minConfidenceProvider: () -> Float,
    private val minPayout: Int = 80
) {
    var state: EngineState = EngineState.SCANNING
        private set

    var lastConfidence: Float = 0f
        private set

    var lastReason: String = ""
        private set

    private var pending: Direction? = null
    private var confirmCount = 0
    private var confirmingSince = 0L
    private var lastConfirmTickMs = 0L
    private var activeCandleKey: String? = null
    private var cooldownUntil = 0L
    private var lastFiredCandleKey: String? = null

    fun onChartSwitched() {
        resetConfirmation()
        cooldownUntil = 0L
        lastFiredCandleKey = null
        state = EngineState.SCANNING
        lastReason = "pair_switched_reset"
    }

    fun evaluate(s: Snapshot, now: Long, allowSignal: Boolean = true): Direction? {
        val minConf = minConfidenceProvider()

        if (state == EngineState.COOLDOWN && now >= cooldownUntil) {
            resetConfirmation()
            state = EngineState.SCANNING
        }

        if (!s.live) {
            lastConfidence = 0f
            lastReason = "chart_scrolled"
            resetIfConfirming()
            return null
        }
        if (s.payout < minPayout) {
            lastConfidence = 0f
            lastReason = "low_payout(${s.payout}<$minPayout)"
            resetIfConfirming()
            return null
        }
        if (s.highs.size < 6 || s.lows.size < 6) {
            lastConfidence = 0f
            lastReason = "not_enough_candles(${s.highs.size})"
            resetIfConfirming()
            return null
        }
        if (!s.candleClosed) {
            lastConfidence = 0f
            lastReason = "candle_not_closed"
            resetIfConfirming()
            return null
        }

        val closedHighs = s.highs.dropLast(1).toFloatArray()
        val closedLows = s.lows.dropLast(1).toFloatArray()
        val closedCloses = if (s.closes.size == s.highs.size) {
            s.closes.dropLast(1).toFloatArray()
        } else {
            closedLows
        }
        if (closedHighs.size < 5) {
            lastConfidence = 0f
            lastReason = "short_closed_history"
            resetIfConfirming()
            return null
        }

        val closedSnap = s.copy(highs = closedHighs, lows = closedLows, closes = closedCloses)
        val f = fiboLevels(closedSnap) ?: run {
            lastConfidence = 0f
            lastReason = "no_levels"
            resetIfConfirming()
            return null
        }

        val (dir, score, reason) = scoreCoherentSetup(closedSnap, f)
        lastConfidence = score
        lastReason = reason

        val candleKey = candleIdentity(closedSnap)
        if (lastFiredCandleKey != null && candleKey == lastFiredCandleKey) {
            resetIfConfirming()
            lastReason = "$reason+same_candle_lock"
            return null
        }

        if (state == EngineState.COOLDOWN) return null

        val candidate = if (allowSignal && dir != null && score >= minConf) dir else null

        when (state) {
            EngineState.COOLDOWN -> Unit
            EngineState.SCANNING -> {
                if (candidate != null) {
                    pending = candidate
                    confirmCount = 1
                    confirmingSince = now
                    lastConfirmTickMs = now
                    activeCandleKey = candleKey
                    state = EngineState.CONFIRMING
                }
            }
            EngineState.CONFIRMING -> {
                if (candidate != null && candidate == pending) {
                    if (candleKey != activeCandleKey) {
                        activeCandleKey = candleKey
                        confirmCount = 1
                        confirmingSince = now
                        lastConfirmTickMs = now
                    } else if (now - lastConfirmTickMs >= 250L) {
                        confirmCount++
                        lastConfirmTickMs = now
                    }
                    if (confirmCount >= 2 && now - confirmingSince >= 900L) {
                        val fired = pending
                        if (fired != null) lastFiredCandleKey = candleKey
                        state = EngineState.COOLDOWN
                        cooldownUntil = now + cooldownMs().coerceIn(15_000L, 30_000L)
                        resetConfirmation()
                        return fired
                    }
                } else {
                    resetConfirmation()
                    state = EngineState.SCANNING
                }
            }
        }
        return null
    }

    private fun scoreCoherentSetup(s: Snapshot, f: FiboLevels): Triple<Direction?, Float, String> {
        if (s.body.isFinite() && s.body >= 0.90f) {
            return Triple(null, 0f, "exhaustion_block")
        }

        val n = minOf(s.highs.size, s.lows.size)
        val closes = if (s.closes.size == n) s.closes else FloatArray(n) { s.lows[it] }
        val pCloses = FloatArray(n) { priceOf(closes[it], f) }
        val pHighs = FloatArray(n) { priceOf(s.highs[it], f) }
        val pLows = FloatArray(n) { priceOf(s.lows[it], f) }

        // 1) Единственный источник направления — SuperTrend (10,3).
        //    Остальные индикаторы не спорят, а только добавляют вес к уже выбранному направлению.
        val leadDir = when (s.superTrend) {
            Trend.GREEN -> Direction.CALL
            Trend.RED -> Direction.PUT
            Trend.UNKNOWN -> return Triple(null, 0f, "st_no_direction")
        }
        val dirSign = if (leadDir == Direction.CALL) 1f else -1f
        var total = 0.30f
        val notes = ArrayList<String>()

        // 2) Heikin Ashi / EMA: совпали — усиливаем, не совпали — просто не даём бонус.
        val emaFast = emaLast(pCloses, 5)
        val emaSlow = emaLast(pCloses, 13)
        val recentMove = pCloses[n - 1] - pCloses[(n - 4).coerceAtLeast(0)]
        val candleAlign = if (leadDir == Direction.CALL) s.isGreen else !s.isGreen
        val haAlign = ((emaFast - emaSlow) * dirSign > 0f) ||
            (recentMove * dirSign > 0f) || candleAlign
        if (haAlign) {
            total += 0.20f
            notes.add("ha_ok")
        } else {
            notes.add("ha_neutral")
        }

        if (s.body.isFinite() && s.body in 0.25f..0.82f) {
            total += 0.10f
            notes.add("clean_body")
        }
        // Тень против сделки — отсутствие бонуса, а не штраф.
        val adverseWick = if (leadDir == Direction.CALL) s.upperWickRatio else s.lowerWickRatio
        if (adverseWick <= 0.35f) {
            total += 0.05f
            notes.add("wick_clean")
        }

        // 3) AO: зелёный усиливает CALL, красный усиливает PUT.
        //    Противоречие — не конфликт, а отсутствие подтверждения.
        when (s.ao) {
            Trend.GREEN -> {
                if (leadDir == Direction.CALL) {
                    total += 0.15f
                    notes.add("ao_ok")
                } else {
                    return Triple(null, 0f, "ao_no_confirm")
                }
            }
            Trend.RED -> {
                if (leadDir == Direction.PUT) {
                    total += 0.15f
                    notes.add("ao_ok")
                } else {
                    return Triple(null, 0f, "ao_no_confirm")
                }
            }
            Trend.UNKNOWN -> notes.add("ao_neutral")
        }

        // 4) Stochastic только отсекает экстремум, не голосует за направление.
        if (s.stochValue.isFinite()) {
            if (leadDir == Direction.CALL && s.stochValue >= 88f && s.stochCross == Cross.DOWN) {
                return Triple(null, 0f, "stoch_overbought_block")
            }
            if (leadDir == Direction.PUT && s.stochValue <= 12f && s.stochCross == Cross.UP) {
                return Triple(null, 0f, "stoch_oversold_block")
            }
        }

        // 5) FIBO только добавляет бонус зоны, без штрафов против тренда.
        val curHigh = s.highs[n - 1]
        val curLow = s.lows[n - 1]
        val tol = f.range * 0.05f
        if (leadDir == Direction.CALL && curLow >= f.callLevel - tol) {
            total += 0.10f
            notes.add("fibo_call_zone")
        }
        if (leadDir == Direction.PUT && curHigh <= f.putLevel + tol) {
            total += 0.10f
            notes.add("fibo_put_zone")
        }

        val atrShort = avgRange(pHighs, pLows, 3)
        val atrLong = avgRange(pHighs, pLows, minOf(12, n))
        if (atrLong > 0f && atrShort >= atrLong) {
            total += 0.05f
            notes.add("vol_ok")
        }

        return Triple(leadDir, total.coerceIn(0f, 1f), notes.joinToString("+").ifEmpty { "base" })
    }

    private fun emaLast(src: FloatArray, period: Int): Float {
        if (src.isEmpty()) return 0f
        val p = period.coerceIn(1, src.size)
        val k = 2f / (p + 1)
        var acc = src[0]
        for (i in 1 until src.size) acc = src[i] * k + acc * (1f - k)
        return acc
    }

    private fun avgRange(h: FloatArray, l: FloatArray, len: Int): Float {
        if (h.isEmpty() || len <= 0) return 0f
        val start = (h.size - len).coerceAtLeast(0)
        var sum = 0f
        var cnt = 0
        for (i in start until h.size) {
            val d = h[i] - l[i]
            if (d > 0f) { sum += d; cnt++ }
        }
        return if (cnt == 0) 0f else sum / cnt
    }

    private fun candleIdentity(s: Snapshot): String {
        val i = s.highs.lastIndex
        val h = if (i >= 0) s.highs[i].roundToInt() / 3 else 0
        val l = if (i >= 0) s.lows[i].roundToInt() / 3 else 0
        val c = if (s.closeY.isFinite()) s.closeY.roundToInt() / 3 else 0
        val b = if (s.body.isFinite()) (s.body * 20f).roundToInt() else 0
        val prevH = if (i - 1 >= 0) s.highs[i - 1].roundToInt() / 3 else 0
        return "${s.highs.size}:$prevH:$h:$l:$c:$b:${s.isGreen}"
    }

    private fun resetIfConfirming() {
        if (state == EngineState.CONFIRMING) {
            resetConfirmation()
            state = EngineState.SCANNING
        }
    }

    private fun resetConfirmation() {
        pending = null
        confirmCount = 0
        confirmingSince = 0L
        lastConfirmTickMs = 0L
        activeCandleKey = null
    }
}
