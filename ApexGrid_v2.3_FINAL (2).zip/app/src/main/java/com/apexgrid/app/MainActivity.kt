package com.apexgrid.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale
import kotlin.math.roundToInt

private fun appVersion(context: Context): String = try {
    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
} catch (_: Throwable) {
    "?"
}

@Composable
private fun AutoTapControlRow(
    enabled: Boolean,
    accessibilityConnected: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(ApexGlassColors.GlassPill)
            .border(1.dp, ApexGlassColors.RimSubtle, RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                "Автонажатие",
                style = MaterialTheme.typography.titleMedium.copy(color = ApexGlassColors.TextPrimary)
            )
            Text(
                when {
                    enabled && accessibilityConnected -> "Вкл — автоматические тапы по сигналу"
                    enabled && !accessibilityConnected -> "Вкл — ждёт службу спец. возможностей"
                    else -> "Выкл — только сигналы и логи"
                },
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = when {
                        enabled && accessibilityConnected -> ApexGlassColors.IceCyan
                        enabled && !accessibilityConnected -> ApexGlassColors.AmberHold
                        else -> ApexGlassColors.TextSecondary
                    }
                )
            )
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = enabled, onCheckedChange = onToggle)
    }
}

private enum class ScreenRoute { TERMINAL, LOGS, INFO }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val expectedSha256 = try {
            val buildConfigClass = Class.forName("$packageName.BuildConfig")
            buildConfigClass.getField("APEX_EXPECTED_SHA256").get(null) as? String ?: ""
        } catch (_: Throwable) {
            ""
        }

        setContent {
            var isUnlocked by remember {
                mutableStateOf(
                    ApexGridAccess.isUnlocked(context = this, expectedCertSha256 = expectedSha256)
                )
            }

            ApexGridTheme {
                if (!isUnlocked) {
                    ApexGridActivationScreen(context = this, onUnlocked = { isUnlocked = true })
                } else {
                    ApexGridScreen(onLockAccess = {
                        ApexGridAccess.lock(this)
                        isUnlocked = false
                    })
                }
            }
        }
    }

    private fun toggleMarkers() {
        val acc = TradingAccessibilityService.instance
        if (acc == null) {
            LogRepository.addLog("Маркеры: служба спец. возможностей не подключена")
            return
        }
        if (acc.markersVisible) {
            acc.hideMarkers()
            LogRepository.addLog("Маркеры скрыты")
        } else {
            acc.showMarkers()
            LogRepository.addLog("Маркеры отображены")
        }
    }

    @Composable
    private fun ApexGridScreen(onLockAccess: () -> Unit) {
        val context = LocalContext.current
        val uiState by BotState.state.collectAsState()
        val logs by LogRepository.logs.collectAsState()

        var route by remember { mutableStateOf(ScreenRoute.TERMINAL) }
        var showCalibration by remember { mutableStateOf(false) }
        var cooldownSec by remember { mutableStateOf(BotPrefs.cooldownSec(context)) }

        LaunchedEffect(Unit) {
            BotPrefs.syncFromPrefs(context)
            BotState.setAccessibility(TradingAccessibilityService.isRunning())
        }

        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    BotPrefs.syncFromPrefs(context)
                    BotState.setAccessibility(TradingAccessibilityService.isRunning())
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        val projectionManager = remember { context.getSystemService(MediaProjectionManager::class.java) }

        val captureLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(context, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(context, intent)
            } else {
                LogRepository.addLog("Захват экрана отменён пользователем")
            }
        }

        if (showCalibration) {
            CalibrationScreen(onClose = { showCalibration = false })
            return
        }

        when (route) {
            ScreenRoute.LOGS -> ApexLogsScreen(
                logs = logs,
                onCopy = {
                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE)
                        as? android.content.ClipboardManager
                    val clip = android.content.ClipData.newPlainText(
                        "ApexGrid Logs",
                        logs.joinToString("\n")
                    )
                    clipboard?.setPrimaryClip(clip)
                    LogRepository.addLog("Лог скопирован в буфер обмена (${logs.size} строк)")
                },
                onClear = { LogRepository.clear() },
                onBack = { route = ScreenRoute.TERMINAL }
            )
            ScreenRoute.INFO -> ApexInfoScreen(
                cooldownSec = cooldownSec,
                onChangeCooldown = { sec ->
                    cooldownSec = sec
                    BotPrefs.setCooldownSec(context, sec)
                },
                onBack = { route = ScreenRoute.TERMINAL }
            )
            ScreenRoute.TERMINAL -> ApexTerminalScreen(
                uiState = uiState,
                autoTapEnabled = uiState.autoTap,
                cooldownSec = cooldownSec,
                onSelectProfile = { profile ->
                    BotPrefs.setProfile(context, profile)
                    LogRepository.addLog(
                        "Профиль: ${profile.title} (conf >= ${String.format(Locale.US, "%.2f", profile.minConfidence)})"
                    )
                },
                onStartCapture = { captureLauncher.launch(projectionManager.createScreenCaptureIntent()) },
                onStopCapture = {
                    context.startService(
                        Intent(context, ScreenCaptureService::class.java).apply {
                            action = ScreenCaptureService.ACTION_STOP
                        }
                    )
                },
                onOpenLogs = { route = ScreenRoute.LOGS },
                onOpenInfo = { route = ScreenRoute.INFO },
                onOpenCalibration = { showCalibration = true },
                onToggleMarkers = { toggleMarkers() },
                onOpenAccessibility = {
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                },
                onOpenPocketOption = {
                    val launch = context.packageManager.getLaunchIntentForPackage(Roi.POCKET_PACKAGE)
                    if (launch != null) {
                        context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } else {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${Roi.POCKET_PACKAGE}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                onToggleAutoTap = { enabled ->
                    BotPrefs.setAutoTapEnabled(context, enabled)
                    LogRepository.addLog(
                        if (enabled) "AUTO_TAP: включено пользователем"
                        else "AUTO_TAP: выключено пользователем"
                    )
                },
                onResetSessionCounter = {
                    SessionRiskGate.reset()
                    BotState.state.value = BotState.state.value.copy(sessionTrades = 0)
                    LogRepository.addLog("Счётчик сделок и риск-гейт сброшены")
                },
                onLockAccess = onLockAccess
            )
        }
    }

    @Composable
    private fun ApexTerminalScreen(
        uiState: UiState,
        autoTapEnabled: Boolean,
        cooldownSec: Int,
        onSelectProfile: (TradingProfile) -> Unit,
        onStartCapture: () -> Unit,
        onStopCapture: () -> Unit,
        onOpenLogs: () -> Unit,
        onOpenInfo: () -> Unit,
        onOpenCalibration: () -> Unit,
        onToggleMarkers: () -> Unit,
        onOpenAccessibility: () -> Unit,
        onOpenPocketOption: () -> Unit,
        onToggleAutoTap: (Boolean) -> Unit,
        onResetSessionCounter: () -> Unit,
        onLockAccess: () -> Unit
    ) {
        val scroll = rememberScrollState()
        val context = LocalContext.current
        ApexGlassBackdrop(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 16.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ApexBrandIcon(size = 44.dp)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            "APEXGRID",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.4.sp,
                                color = ApexGlassColors.TextPrimary
                            )
                        )
                        Text(
                            "LIQUID GLASS · V${appVersion(context)} · ${uiState.profile.title.uppercase(Locale.US)}",
                            style = MaterialTheme.typography.labelMedium.copy(fontSize = 11.sp, color = ApexGlassColors.IceCyan)
                        )
                    }
                }

                TradingProfileSelector(selected = uiState.profile, onSelect = onSelectProfile)

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LiquidGlassActionButton("START", active = uiState.running, modifier = Modifier.weight(1f), onClick = onStartCapture)
                    LiquidGlassActionButton("STOP", destructive = uiState.running, modifier = Modifier.weight(1f), onClick = onStopCapture)
                    LiquidGlassActionButton("LOGS", modifier = Modifier.weight(1f), onClick = onOpenLogs)
                    LiquidGlassActionButton("INFO", modifier = Modifier.weight(1f), onClick = onOpenInfo)
                }

                LiquidGlassCard(Modifier.fillMaxWidth(), accentBorder = true, contentPadding = PaddingValues(16.dp)) {
                    Text("| Статус", style = MaterialTheme.typography.titleMedium.copy(color = ApexGlassColors.IceCyan))
                    GlassMetricRow("Захват экрана", if (uiState.running) "ВКЛ" else "ВЫКЛ",
                        if (uiState.running) ApexGlassColors.IceCyan else ApexGlassColors.TextSecondary)
                    GlassMetricRow("Активная пара", uiState.activePair, ApexGlassColors.SapphireGlow)
                    GlassMetricRow("Выплата (OCR)", if (uiState.payout >= 0) "${uiState.payout}%" else "—",
                        if (uiState.payout >= 80) ApexGlassColors.IceCyan else ApexGlassColors.AmberHold)
                    GlassMetricRow("Свечей в истории", "${uiState.candles}/${Roi.CANDLES_TO_COLLECT}")
                    GlassMetricRow("Кадров/с", String.format(Locale.US, "%.1f", uiState.fps))
                    GlassMetricRow("Сделок в сессии", "${uiState.sessionTrades}/30")
                    GlassMetricRow("График", if (uiState.live) "на последней свече" else "прокручен",
                        if (uiState.live) ApexGlassColors.IceCyan else ApexGlassColors.AmberHold)
                    GlassMetricRow("OpenCV", if (uiState.cvReady) "готов" else "ошибка",
                        if (uiState.cvReady) ApexGlassColors.IceCyan else ApexGlassColors.SignalCrimson)
                    GlassMetricRow("Спец. возможности", if (uiState.accessibility) "подключены" else "не подключены",
                        if (uiState.accessibility) ApexGlassColors.IceCyan else ApexGlassColors.SignalCrimson)
                    GlassMetricRow("Маркеры", if (uiState.markers) "активны" else "скрыты",
                        if (uiState.markers) ApexGlassColors.IceCyan else ApexGlassColors.TextSecondary)
                }

                LiquidGlassCard(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
                    Text("| Управление", style = MaterialTheme.typography.titleMedium.copy(color = ApexGlassColors.IceCyan))
                    Text(
                        "Единый движок: вход по закрытой свече, выплата ≥ 80%, порог conf ≥ ${String.format(Locale.US, "%.2f", uiState.profile.minConfidence)}, кулдаун ${cooldownSec}s, автосброс при смене пары.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        LiquidGlassActionButton("Калибровка зон", modifier = Modifier.weight(1f), onClick = onOpenCalibration)
                        LiquidGlassActionButton(
                            if (uiState.markers) "Скрыть маркеры" else "Маркеры CALL/PUT",
                            active = uiState.markers, modifier = Modifier.weight(1f), onClick = onToggleMarkers
                        )
                    }
                    LiquidGlassActionButton("Включить службу спец. возможностей", modifier = Modifier.fillMaxWidth(), onClick = onOpenAccessibility)
                    LiquidGlassActionButton("Сбросить счётчик сделок (${uiState.sessionTrades}/30)", modifier = Modifier.fillMaxWidth(), onClick = onResetSessionCounter)
                    AutoTapControlRow(
                        enabled = autoTapEnabled,
                        accessibilityConnected = uiState.accessibility,
                        onToggle = onToggleAutoTap
                    )
                    Spacer(Modifier.height(2.dp))
                    HighContrastCyanButton("Открыть Pocket Option", onOpenPocketOption)
                    LiquidGlassActionButton("Заблокировать доступ", destructive = true, modifier = Modifier.fillMaxWidth(), onClick = onLockAccess)
                }
            }
        }
    }

    @Composable
    private fun ApexInfoScreen(cooldownSec: Int, onChangeCooldown: (Int) -> Unit, onBack: () -> Unit) {
        val scroll = rememberScrollState()
        val options = listOf(15, 20, 30)
        ApexGlassBackdrop(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().verticalScroll(scroll).padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Индикаторы и настройки", style = MaterialTheme.typography.headlineSmall.copy(
                        fontSize = 21.sp, fontWeight = FontWeight.Bold, color = ApexGlassColors.TextPrimary))
                    Text("APEXGRID V17.4 · UNIFIED REINFORCEMENT", style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 11.sp, color = ApexGlassColors.IceCyan))
                }
                LiquidGlassCard(Modifier.fillMaxWidth()) {
                    InfoLine("Окна OCR", "«Выплата» и «Пара»")
                    InfoLine("Смена пары", "Автосброс без ручной кнопки")
                    InfoLine("Вход", "Только закрытая свеча, ≥ 80%")
                    InfoLine("Профили", "Поток 0.45 · Баланс 0.55 · Снайпер 0.68")
                }
                LiquidGlassCard(Modifier.fillMaxWidth(), accentBorder = true) {
                    Text("Пауза после сигнала", style = MaterialTheme.typography.titleMedium.copy(color = ApexGlassColors.IceCyan))
                    Text("Короткий кулдаун защищает от повторного входа на одном импульсе без 60-секундной задержки:",
                        style = MaterialTheme.typography.bodyMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        options.forEach { sec ->
                            LiquidGlassActionButton("${sec} сек", active = cooldownSec == sec,
                                modifier = Modifier.weight(1f), onClick = { onChangeCooldown(sec) })
                        }
                    }
                }
                HighContrastCyanButton("Назад в терминал", onBack)
            }
        }
    }

    @Composable
    private fun InfoLine(label: String, value: String) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
            Text(label, modifier = Modifier.weight(0.35f), style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Medium, color = ApexGlassColors.TextMuted), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(value, modifier = Modifier.weight(0.65f), style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold, color = ApexGlassColors.TextPrimary))
        }
    }

    @Composable
    private fun ApexLogsScreen(
        logs: List<String>,
        onCopy: () -> Unit,
        onClear: () -> Unit,
        onBack: () -> Unit
    ) {
        androidx.activity.compose.BackHandler(onBack = onBack)

        ApexGlassBackdrop(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Журнал",
                        maxLines = 1,
                        softWrap = false,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontSize = 18.sp,
                            color = ApexGlassColors.TextPrimary
                        ),
                        modifier = Modifier.weight(1f).padding(end = 6.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LiquidGlassActionButton("Копировать", compact = true, onClick = onCopy)
                        LiquidGlassActionButton("Очистить", compact = true, onClick = onClear)
                        LiquidGlassActionButton("Назад", active = true, compact = true, onClick = onBack)
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(ApexGlassColors.GlassSurface)
                    .border(1.dp, ApexGlassColors.RimSubtle, RoundedCornerShape(20.dp))
                    .padding(12.dp)) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        items(logs.asReversed()) { line ->
                            Text(line, style = MaterialTheme.typography.labelMedium.copy(
                                fontSize = 11.sp, lineHeight = 15.sp,
                                color = when {
                                    "PAIR_SWITCHED" in line -> ApexGlassColors.IceCyan
                                    "ERROR" in line || "заблокирован" in line -> ApexGlassColors.SignalCrimson
                                    else -> ApexGlassColors.TextPrimary
                                }))
                        }
                    }
                }
            }
        }
    }

    private fun zoneColor(z: RoiZone): Color = when (z) {
        RoiZone.CHART -> ApexGlassColors.IceCyan
        RoiZone.STOCH -> ApexGlassColors.SapphireGlow
        RoiZone.AO -> ApexGlassColors.AmberHold
        RoiZone.PAYOUT -> Color(0xFF7CE8A8)
        RoiZone.PAIR -> Color(0xFFB388FF)
    }

    private fun loadLastFrame(ctx: Context): Bitmap? = try {
        val f = File(ctx.filesDir, Roi.LAST_FRAME_FILE)
        if (!f.exists()) null else BitmapFactory.decodeFile(f.absolutePath)
    } catch (_: Throwable) {
        null
    }

    private fun pct(v: Float): Int = (v * 100f).roundToInt()

    @Composable
    private fun CalibrationScreen(onClose: () -> Unit) {
        val ctx = LocalContext.current
        val zones = remember { RoiZone.values() }
        var selected by remember { mutableStateOf(RoiZone.PAIR) }
        val rects = remember {
            mutableStateMapOf<RoiZone, NormRect>().apply {
                for (z in zones) put(z, RoiPrefs.load(ctx, z))
            }
        }
        val frameBmp = remember { loadLastFrame(ctx) }
        DisposableEffect(frameBmp) {
            onDispose { frameBmp?.recycle() }
        }
        val activeRect = rects[selected] ?: RoiPrefs.default(selected)

        ApexGlassBackdrop(Modifier.fillMaxSize()) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Калибровка зон OCR и графика", style = MaterialTheme.typography.headlineSmall.copy(
                    fontSize = 19.sp, color = ApexGlassColors.TextPrimary))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (z in zones) {
                        LiquidGlassActionButton(z.title, active = selected == z, modifier = Modifier.weight(1f),
                            onClick = { selected = z })
                    }
                }
                Text(
                    "${selected.title}: x ${pct(activeRect.left)}-${pct(activeRect.right)}%, y ${pct(activeRect.top)}-${pct(activeRect.bottom)}%",
                    style = MaterialTheme.typography.labelMedium.copy(color = zoneColor(selected))
                )
                Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp))
                    .background(ApexGlassColors.VoidBlack)
                    .border(1.dp, ApexGlassColors.RimSubtle, RoundedCornerShape(18.dp))) {
                    if (frameBmp != null) {
                        Image(frameBmp.asImageBitmap(), "Последний кадр", modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.FillBounds)
                    }
                    ZoneCanvas(zones, selected, rects, { z, r -> rects[z] = r }, Modifier.fillMaxSize())
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    LiquidGlassActionButton("Сброс зоны", modifier = Modifier.weight(1f), onClick = {
                        val def = RoiPrefs.default(selected)
                        rects[selected] = def
                        RoiPrefs.save(ctx, selected, def)
                    })
                    LiquidGlassActionButton("Закрыть", modifier = Modifier.weight(1f), onClick = onClose)
                }
                LiquidGlassActionButton("Сбросить все зоны", modifier = Modifier.fillMaxWidth(), onClick = {
                    RoiPrefs.resetAll(ctx)
                    for (z in zones) rects[z] = RoiPrefs.default(z)
                    LogRepository.addLog("ROI сброшены: пара x6-44%, y13-17%, график y20-53%")
                })
                HighContrastCyanButton("Сохранить все зоны", onClick = {
                    for (z in zones) RoiPrefs.save(ctx, z, rects[z] ?: RoiPrefs.default(z))
                    LogRepository.addLog("Калибровка зон сохранена (включая Пара и Выплата)")
                    onClose()
                })
            }
        }
    }

    @Composable
    private fun ZoneCanvas(
        zones: Array<RoiZone>,
        selected: RoiZone,
        rects: Map<RoiZone, NormRect>,
        onUpdateRect: (RoiZone, NormRect) -> Unit,
        modifier: Modifier = Modifier
    ) {
        Canvas(modifier.pointerInput(selected, rects[selected]) {
            detectDragGestures { change, dragAmount ->
                change.consume()
                val w = size.width.toFloat().coerceAtLeast(1f)
                val h = size.height.toFloat().coerceAtLeast(1f)
                val cur = rects[selected] ?: RoiPrefs.default(selected)
                val dx = dragAmount.x / w
                val dy = dragAmount.y / h
                val width = (cur.right - cur.left).coerceIn(0.03f, 1f)
                val height = (cur.bottom - cur.top).coerceIn(0.02f, 1f)
                val newLeft = (cur.left + dx).coerceIn(0f, 1f - width)
                val newTop = (cur.top + dy).coerceIn(0f, 1f - height)
                onUpdateRect(selected, NormRect(
                    left = newLeft, top = newTop,
                    right = (newLeft + width).coerceAtMost(1f),
                    bottom = (newTop + height).coerceAtMost(1f)
                ))
            }
        }) {
            for (z in zones) {
                val r = rects[z] ?: RoiPrefs.default(z)
                val isSel = z == selected
                val col = zoneColor(z)
                val topLeft = Offset(r.left * size.width, r.top * size.height)
                val boxSize = Size(
                    ((r.right - r.left) * size.width).coerceAtLeast(4f),
                    ((r.bottom - r.top) * size.height).coerceAtLeast(4f)
                )
                drawRect(col.copy(alpha = if (isSel) 0.24f else 0.10f), topLeft = topLeft, size = boxSize)
                drawRect(col, topLeft = topLeft, size = boxSize, style = Stroke(width = if (isSel) 4f else 2f))
            }
        }
    }
}
