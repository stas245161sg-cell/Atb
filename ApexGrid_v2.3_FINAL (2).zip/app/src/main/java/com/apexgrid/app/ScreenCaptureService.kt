package com.apexgrid.app

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.apexgrid.app.START_CAPTURE"
        const val ACTION_STOP = "com.apexgrid.app.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val TAG = "ScreenCaptureService"
        private const val CHANNEL_ID = "apexgrid_capture_channel"
        private const val NOTIFICATION_ID = 1001
        private const val TARGET_FPS = 30
        private const val FRAME_INTERVAL_MS = 1000L / TARGET_FPS
        private const val STATS_INTERVAL_MS = 300_000L
        private const val EVAL_MIN_INTERVAL_MS = 2_000L
        private const val UI_MIN_INTERVAL_MS = 100L
        private const val TAP_MIN_GAP_MS = 350L
    }

    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var captureJob: Job? = null

    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var analyzer: ImageAnalyzer? = null
    private var engine: UnifiedStrategyEngine? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private val processing = AtomicBoolean(false)
    private var fpsStartMs = 0L
    private var fpsFrames = 0
    private var currentFps = 0f
    private var lastUiUpdateMs = 0L
    private var lastStatsLogMs = 0L
    private var lastEvalLogMs = 0L
    private var lastTapMs = 0L
    private var sessionTrades = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            LogRepository.addLog("Захват остановлен: MediaProjection завершён")
            stopCaptureInternal()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        workerThread = HandlerThread("ApexGridWorkerThread").apply { start() }
        workerHandler = Handler(workerThread!!.looper)

        val currentProfile = BotPrefs.profile(this)
        val eng = UnifiedStrategyEngine(
            cooldownMs = { BotPrefs.cooldownMs(this) },
            minConfidenceProvider = { BotPrefs.profile(this).minConfidence },
            minPayout = 80
        )
        engine = eng

        val an = ImageAnalyzer(this).apply {
            setOnPairChangedListener { _, newPair ->
                eng.onChartSwitched()
                BotState.state.value = BotState.state.value.copy(
                    activePair = newPair,
                    engine = EngineState.SCANNING,
                    lastSignal = null
                )
            }
        }
        analyzer = an

        BotState.state.value = BotState.state.value.copy(
            cvReady = an.ready,
            accessibility = TradingAccessibilityService.isRunning(),
            markers = TradingAccessibilityService.instance?.markersVisible == true,
            profile = currentProfile
        )
        LogRepository.addLog(
            "INIT: APEXGRID V${try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Throwable) { "?" }} " +
                "profile=${currentProfile.title} (${currentProfile.minConfidence}), " +
                "ST(10,3)+Stoch(5,3,3)+AO(5,34), автосброс по паре"
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                LogRepository.addLog("Захват остановлен")
                stopCaptureInternal()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                if (resultCode != Activity.RESULT_OK || resultData == null) {
                    LogRepository.addLog("ERROR: невалидные данные разрешения захвата экрана")
                    stopSelf()
                    return START_NOT_STICKY
                }
                startForeground(NOTIFICATION_ID, buildNotification())
                startProjection(resultCode, resultData)
                return START_STICKY
            }
        }
        return START_NOT_STICKY
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        stopProjectionOnly()
        updateScreenMetrics()

        val pm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = pm.getMediaProjection(resultCode, resultData)
        if (mp == null) {
            LogRepository.addLog("ERROR: не удалось получить MediaProjection")
            stopSelf()
            return
        }

        mp.registerCallback(projectionCallback, workerHandler)
        mediaProjection = mp

        val reader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 3)
        imageReader = reader

        virtualDisplay = mp.createVirtualDisplay(
            "ApexGridCaptureDisplay", screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, workerHandler
        )

        analyzer?.resetChartTracking(clearDetectedPair = true)
        engine?.onChartSwitched()

        val now = SystemClock.elapsedRealtime()
        fpsStartMs = now
        fpsFrames = 0
        currentFps = 0f
        lastStatsLogMs = now
        sessionTrades = 0

        val prof = BotPrefs.profile(this)
        BotState.state.value = BotState.state.value.copy(
            running = true,
            profile = prof,
            activePair = "—",
            sessionTrades = 0,
            lastSignal = null,
            engine = EngineState.SCANNING
        )
        LogRepository.addLog(
            "START: APEXGRID V17.4 profile=${prof.name} conf>=${String.format(Locale.US, "%.2f", prof.minConfidence)}, " +
                "autoTap=${if (BotPrefs.autoTap(this)) "ON" else "OFF"}, pause=${BotPrefs.cooldownSec(this)}s"
        )

        captureJob?.cancel()
        captureJob = scope.launch {
            while (isActive) {
                val loopStart = SystemClock.elapsedRealtime()
                pollLatestFrame()
                val elapsed = SystemClock.elapsedRealtime() - loopStart
                delay((FRAME_INTERVAL_MS - elapsed).coerceAtLeast(1L))
            }
        }
    }

    private fun pollLatestFrame() {
        val reader = imageReader ?: return
        if (!processing.compareAndSet(false, true)) return

        var latestImage: android.media.Image? = null
        try {
            while (true) {
                val next = reader.acquireLatestImage() ?: break
                latestImage?.close()
                latestImage = next
            }
            val img = latestImage ?: run {
                processing.set(false)
                return
            }
            val bmp = imageToBitmap(img)
            img.close()
            latestImage = null
            if (bmp == null) {
                processing.set(false)
                return
            }
            val handler = workerHandler
            if (handler == null) {
                bmp.recycle()
                processing.set(false)
                return
            }
            handler.post {
                try {
                    processBitmap(bmp)
                } finally {
                    bmp.recycle()
                    processing.set(false)
                }
            }
        } catch (t: Throwable) {
            latestImage?.close()
            processing.set(false)
            Log.e(TAG, "pollLatestFrame failed", t)
        }
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val width = image.width
        val height = image.height
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val rowPadding = rowStride - pixelStride * width
        val buffer = plane.buffer
        buffer.rewind()
        val rawBmp = Bitmap.createBitmap(
            width + rowPadding / pixelStride.coerceAtLeast(1),
            height,
            Bitmap.Config.ARGB_8888
        )
        rawBmp.copyPixelsFromBuffer(buffer)
        return if (rowPadding == 0) {
            rawBmp
        } else {
            val cropped = Bitmap.createBitmap(rawBmp, 0, 0, width, height)
            rawBmp.recycle()
            cropped
        }
    }

    private fun processBitmap(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        fpsFrames++
        val dt = now - fpsStartMs
        if (dt >= 1_000L) {
            currentFps = fpsFrames * 1000f / dt.toFloat()
            fpsFrames = 0
            fpsStartMs = now
        }

        val an = analyzer ?: return
        val eng = engine ?: return

        val snap = an.analyze(bmp) ?: return
        val fibo = fiboLevels(snap)

        if (now - lastStatsLogMs >= STATS_INTERVAL_MS) {
            val periodSec = ((now - lastStatsLogMs) / 1000L).coerceAtLeast(1L)
            lastStatsLogMs = now
            LogRepository.addLog(
                "STATS ${periodSec}s: fps=${String.format(Locale.US, "%.1f", currentFps)} " +
                    "state=${eng.state} conf=${String.format(Locale.US, "%.2f", eng.lastConfidence)} " +
                    "pair=${snap.pairName} reason=${eng.lastReason}"
            )
        }

        val riskBlock = SessionRiskGate.allow(now)
        val fired = eng.evaluate(snap, now, allowSignal = riskBlock == null)

        if (now - lastEvalLogMs >= EVAL_MIN_INTERVAL_MS || fired != null) {
            lastEvalLogMs = now
            val bodyStr = if (snap.body.isFinite()) String.format(Locale.US, "%.2f", snap.body) else "?"
            val confStr = String.format(Locale.US, "%.2f", eng.lastConfidence)
            val candleTag = if (snap.candleClosed) "CLOSED" else "FORMING"
            val sigTag = fired?.name ?: "NONE"
            LogRepository.addLog(
                "EVAL: dir=$sigTag conf=$confStr body=$bodyStr payout=${snap.payout} " +
                    "pair=${snap.pairName} candle=$candleTag ST=${snap.superTrend.name} " +
                    "Stoch=${snap.stochCross.name} AO=${snap.ao.name} GRID=${snap.chartNote} " +
                    "(${eng.lastReason})${riskBlock?.let { " RISK=$it" } ?: ""}"
            )
        }

        if (fired != null) {
            an.consumeCandleClosedWindow()
            saveLastFrame(bmp)
            sessionTrades++
            BotState.state.value = BotState.state.value.copy(lastSignal = fired, sessionTrades = sessionTrades)
            maybeExecuteAutoTap(fired, now)
        }

        if (now - lastUiUpdateMs >= UI_MIN_INTERVAL_MS) {
            lastUiUpdateMs = now
            val prevPair = BotState.state.value.activePair
            val resolvedPair = if (snap.pairName == "—" && prevPair != "—") prevPair else snap.pairName
            BotState.state.value = BotState.state.value.copy(
                running = true,
                cvReady = an.ready,
                live = snap.live,
                accessibility = TradingAccessibilityService.isRunning(),
                markers = TradingAccessibilityService.instance?.markersVisible == true,
                profile = BotPrefs.profile(this),
                activePair = resolvedPair,
                fps = currentFps,
                candles = snap.highs.size,
                sessionTrades = sessionTrades,
                body = snap.body,
                payout = snap.payout,
                fiboHigh = fibo?.maxHigh ?: Float.NaN,
                fiboLow = fibo?.minLow ?: Float.NaN,
                putLevel = fibo?.putLevel ?: Float.NaN,
                callLevel = fibo?.callLevel ?: Float.NaN,
                curHigh = snap.highs.lastOrNull() ?: Float.NaN,
                curLow = snap.lows.lastOrNull() ?: Float.NaN,
                lastGreen = snap.isGreen,
                superTrend = snap.superTrend,
                stochCross = snap.stochCross,
                stochValue = snap.stochValue,
                ao = snap.ao,
                engine = eng.state
            )
        }
    }

    private fun maybeExecuteAutoTap(dir: Direction, now: Long) {
        if (!BotPrefs.isAutoTapEnabled(this)) {
            LogRepository.addLog("TAP ${dir.name}: пропущен — тумблер Автонажатие выключен")
            return
        }
        val acc = TradingAccessibilityService.instance
        if (acc == null || !TradingAccessibilityService.isRunning()) {
            BotState.setAccessibility(false)
            LogRepository.addLog("TAP ${dir.name}: заблокирован — служба спец. возможностей не активна")
            return
        }
        BotState.setAccessibility(true)
        dispatchTradeTap(dir, now)
    }

    private fun dispatchTradeTap(dir: Direction, now: Long) {
        if (now - lastTapMs < TAP_MIN_GAP_MS) return
        val acc = TradingAccessibilityService.instance
        if (acc == null) {
            LogRepository.addLog("TAP ${dir.name}: заблокирован — служба спец. возможностей не активна")
            return
        }
        val fgPkg = TradingAccessibilityService.currentForegroundPackage()
        if (fgPkg != Roi.POCKET_PACKAGE) {
            LogRepository.addLog(
                "TAP ${dir.name}: заблокирован — активный пакет '${fgPkg.ifEmpty { "unknown" }}', нужен ${Roi.POCKET_PACKAGE}"
            )
            return
        }
        val xNorm = if (dir == Direction.CALL) BotPrefs.get(this, BotPrefs.CALL_X) else BotPrefs.get(this, BotPrefs.PUT_X)
        val yNorm = if (dir == Direction.CALL) BotPrefs.get(this, BotPrefs.CALL_Y) else BotPrefs.get(this, BotPrefs.PUT_Y)
        val tapX = (xNorm * screenWidth).coerceIn(0f, (screenWidth - 1).coerceAtLeast(0).toFloat())
        val tapY = (yNorm * screenHeight).coerceIn(0f, (screenHeight - 1).coerceAtLeast(0).toFloat())
        lastTapMs = now
        SessionRiskGate.onExecutedGesture(now)
        acc.tap(tapX, tapY) { ok ->
            LogRepository.addLog("TAP ${dir.name} (${tapX.toInt()},${tapY.toInt()}): ok=$ok")
        }
    }

    private fun saveLastFrame(bmp: Bitmap) {
        try {
            val outFile = File(filesDir, Roi.LAST_FRAME_FILE)
            FileOutputStream(outFile).use { bmp.compress(Bitmap.CompressFormat.JPEG, 85, it) }
        } catch (t: Throwable) {
            Log.w(TAG, "saveLastFrame failed", t)
        }
    }

    private fun updateScreenMetrics() {
        val (w, h) = realScreenSize(this)
        screenWidth = w
        screenHeight = h
        screenDensity = resources.displayMetrics.densityDpi
    }

    private fun stopProjectionOnly() {
        captureJob?.cancel()
        captureJob = null
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Throwable) {}
        imageReader = null
        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Throwable) {}
        mediaProjection = null
    }

    private fun stopCaptureInternal() {
        stopProjectionOnly()
        BotState.state.value = BotState.state.value.copy(running = false, fps = 0f, engine = EngineState.SCANNING)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "ApexGrid Capture", NotificationManager.IMPORTANCE_LOW
            )
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        return builder
            .setContentTitle("ApexGrid")
            .setContentText("Автономный анализ графика и индикаторов")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopCaptureInternal()
        scope.cancel()
        try { analyzer?.close() } catch (_: Throwable) {}
        analyzer = null
        workerThread?.quitSafely()
        workerThread = null
        super.onDestroy()
    }
}
