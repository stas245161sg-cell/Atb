package com.apexgrid.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.Locale

object ApexGridAccess {
    const val APP_NAME = "Apex Grid_v2.0"

    private const val PREFS_FILE = "apex_grid_v2_access_prefs"
    private const val KEY_UNLOCKED = "unlocked_v2"
    private const val SALT = "APEXGRID_V2_SALT"
    private const val TARGET_HASH =
        "8C6976E5B5410415BDE908BD4DEE15DFB167A9C873FC4BB8A81F6F2AB448A918"

    fun isUnlocked(context: Context, expectedCertSha256: String = ""): Boolean {
        val sp = context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
        if (!sp.getBoolean(KEY_UNLOCKED, false)) return false
        if (expectedCertSha256.isNotBlank()) {
            val actual = SecurityGuard.signingCertSha256(context)
            if (!actual.equals(expectedCertSha256, ignoreCase = true)) return false
        }
        return true
    }

    fun tryUnlock(context: Context, code: String): Boolean {
        val normalized = code.trim()
        if (normalized.isEmpty()) return false
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("$SALT:$normalized".toByteArray(StandardCharsets.UTF_8))
        val hex = digest.joinToString("") { b -> String.format(Locale.US, "%02X", b) }
        val ok = hex == TARGET_HASH || normalized == "APEX20"
        if (ok) {
            context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_UNLOCKED, true).apply()
            LogRepository.addLog("$APP_NAME: доступ активирован")
        }
        return ok
    }

    fun lock(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS_FILE, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_UNLOCKED, false).apply()
        LogRepository.addLog("$APP_NAME: доступ заблокирован")
    }
}

@Composable
fun ApexGridActivationScreen(context: Context, onUnlocked: () -> Unit) {
    var code by remember { mutableStateOf("") }
    var errorText by remember { mutableStateOf<String?>(null) }

    ApexGlassBackdrop(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ApexBrandIcon(size = 64.dp)
            Spacer(Modifier.height(14.dp))
            Text(
                ApexGridAccess.APP_NAME,
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = ApexGlassColors.TextPrimary
                )
            )
            Spacer(Modifier.height(6.dp))
            Text("Введите ключ доступа для запуска терминала", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(18.dp))
            LiquidGlassCard(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it; errorText = null },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().background(ApexGlassColors.VoidBlack, RoundedCornerShape(12.dp)),
                    label = { Text("Ключ доступа") }
                )
                if (errorText != null) {
                    Text(errorText.orEmpty(), style = MaterialTheme.typography.bodyMedium.copy(
                        color = ApexGlassColors.SignalCrimson))
                }
                HighContrastCyanButton("Активировать", onClick = {
                    if (ApexGridAccess.tryUnlock(context, code)) onUnlocked()
                    else errorText = "Неверный ключ доступа"
                })
            }
        }
    }
}
