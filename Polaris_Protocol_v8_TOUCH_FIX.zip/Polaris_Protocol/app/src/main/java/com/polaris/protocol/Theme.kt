package com.polaris.protocol

import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ======================= Палитра «HyperOS 4 · Liquid Glass / Neon Cyber» =======================
// Тёмный карбон, матовое стекло сDepth и преломлением света, ледяной циан
// и точечный неоново-красный акцент для активных состояний и сигналов.

/** Карбоновый фон. */
val BgTop = Color(0xFF0A0A0C)
val BgBottom = Color(0xFF121A22)

/** Ледяной циан — основной акцент интерфейса. */
val IceCyan = Color(0xFF6CE6FF)
val DeepCyan = Color(0xFF0B5F73)

/** Неоновый красный — активные состояния, сигналы, FIBO-метрики. */
val NeonRed = Color(0xFFFF2A2A)
val DeepRed = Color(0xFF7A0A0A)

/** Морозный голубой — вторичный акцент. */
val FrostBlue = Color(0xFF8FC2FF)

/** Текст. */
val TextPrimary = Color(0xFFF2F8FB)
val TextSecondary = Color(0xFF9FB2BE)

/** Стекло HyperOS: полупрозрачная поверхность и обводка с ледяным оттенком. */
val GlassFill = Color.White.copy(alpha = 0.055f)
val GlassBorder = IceCyan.copy(alpha = 0.16f)
/** Вертикальный градиент с бликом сверху и мягким отражением снизу — эффект преломления. */
val GlassBrush: Brush = Brush.verticalGradient(
    listOf(
        Color.White.copy(alpha = 0.12f),
        Color.White.copy(alpha = 0.03f),
        Color.White.copy(alpha = 0.07f)
    )
)
/** Тонкий блик по верхней кромке карточки. */
val GlassSpecular: Brush = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.22f), Color.Transparent)
)

/** Смысловые цвета: рост/падение + отдельный цвет сигнала. */
val Positive = Color(0xFF63E6C4)
val Negative = Color(0xFF8FA9FF)
val SignalRed = NeonRed

/** Текст журнала. */
val LogText = Color(0xFFD6E6EF)

val AppBackgroundBrush: Brush = Brush.verticalGradient(listOf(BgTop, BgBottom))

private val PolarisColorScheme = darkColorScheme(
    primary = IceCyan,
    onPrimary = BgTop,
    secondary = FrostBlue,
    onSecondary = BgTop,
    background = BgTop,
    onBackground = TextPrimary,
    surface = BgTop,
    onSurface = TextPrimary,
    surfaceVariant = BgBottom,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = NeonRed
)

private val PolarisTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 14.sp,
        color = TextSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 12.sp,
        color = TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = TextPrimary
    )
)

@Composable
fun PolarisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PolarisColorScheme,
        typography = PolarisTypography,
        content = content
    )
}

/**
 * Фон: карбоновый градиент и три мягких свечения — циан сверху справа,
 * морозный голубой снизу слева, слабый неоновый красный снизу справа.
 */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(AppBackgroundBrush)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(IceCyan.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.92f, size.height * 0.04f),
                        radius = size.width * 0.95f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(FrostBlue.copy(alpha = 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.05f, size.height * 0.96f),
                        radius = size.width * 1.05f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(NeonRed.copy(alpha = 0.06f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.88f),
                        radius = size.width * 0.7f
                    )
                )
            },
        content = content
    )
}
