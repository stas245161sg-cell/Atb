package com.example.tradebot

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.roundToInt

private val Bg = Color(0xFF0F1115)
private val Accent = Color(0xFF4C8DFF)
private val Up = Color(0xFF34D399)
private val Down = Color(0xFFF87171)
private val TextMain = Color(0xFFF2F4F8)
private val TextDim = Color(0xFF9AA3B2)
private val LogText = Color(0xFFD0D5DD)
private val GlassFill = Color(0x33FFFFFF)

class MainActivity : ComponentActivity() {

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            val data = res.data
            if (res.resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_CODE, res.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_DATA, data)
                }
                ContextCompat.startForegroundService(this, i)
            }
        }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0F1115.toInt()
        window.navigationBarColor = 0xFF0F1115.toInt()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            TradeBotTheme {
                TradeBotScreen(
                    onStart = {
                        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        projectionLauncher.launch(mpm.createScreenCaptureIntent())
                    },
                    onStop = {
                        startService(
                            Intent(this, ScreenCaptureService::class.java)
                                .setAction(ScreenCaptureService.ACTION_STOP)
                        )
                    },
                    onOpenAccessibility = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    },
                    onToggleMarkers = { toggleMarkers() }
                )
            }
        }
    }

    private fun toggleMarkers() {
        val svc = TradingAccessibilityService.instance
        if (svc == null) {
            Toast.makeText(this, "Сначала включите службу спец. возможностей", Toast.LENGTH_LONG).show()
            return
        }
        if (svc.markersVisible) {
            svc.hideMarkers()
            return
        }
        svc.showMarkers()
        val launch = packageManager.getLaunchIntentForPackage(Roi.POCKET_PACKAGE)
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Pocket Option не найден — откройте его вручную", Toast.LENGTH_LONG).show()
        }
    }
}

@Composable
private fun TradeBotTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Bg,
            surface = Bg,
            onBackground = TextMain,
            onSurface = TextMain
        ),
        content = content
    )
}

@Composable
private fun TradeBotScreen(
    onStart: () -> Unit,
    onStop: () -> Unit,
    onOpenAccessibility: () -> Unit,
    onToggleMarkers: () -> Unit
) {
    val ctx = LocalContext.current
    val ui by BotState.state.collectAsState()

    var showLogDialog by remember { mutableStateOf(false) }
    var showCalibration by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(BotPrefs.tradingMode(ctx)) }
    var autoTap by remember { mutableStateOf(BotPrefs.autoTap(ctx)) }
    var cooldown by remember { mutableFloatStateOf(BotPrefs.cooldownSec(ctx).toFloat()) }
    val callPos = remember(ui.markers) { posText(ctx, BotPrefs.CALL_X, BotPrefs.CALL_Y) }
    val putPos = remember(ui.markers) { posText(ctx, BotPrefs.PUT_X, BotPrefs.PUT_Y) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(Color(0x334C8DFF), Color.Transparent),
                    center = Offset(150f, 150f),
                    radius = 900f
                )
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(
                    colors = listOf(Color(0x2234D399), Color.Transparent),
                    center = Offset(900f, 1800f),
                    radius = 1100f
                )
            )
        )

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("TradeBot", color = TextMain, fontSize = 28.sp, fontWeight = FontWeight.Bold)

            GlassCard {
                SectionTitle("Статус")
                InfoRow("Захват экрана", if (ui.running) "ВКЛ" else "ВЫКЛ", if (ui.running) Up else TextDim)
                InfoRow("Режим", mode.title, Accent)
                InfoRow("Кадров/с", ui.fps.fmt(0), TextMain)
                InfoRow(
                    "График",
                    if (ui.live) "на последней свече" else "прокручен — нажмите «>»",
                    if (ui.live) Up else Down
                )
                InfoRow("OpenCV", if (ui.cvReady) "готов" else "ошибка", if (ui.cvReady) Up else Down)
                InfoRow(
                    "Спец. возможности",
                    if (ui.accessibility) "подключены" else "не подключены",
                    if (ui.accessibility) Up else Down
                )
            }

            GlassCard {
                SectionTitle("Индикаторы")
                InfoRow("SuperTrend", trendText(ui.superTrend), trendColor(ui.superTrend))
                InfoRow("Stochastic 5,3,3", crossText(ui.stochCross, ui.stochValue), crossColor(ui.stochCross))
                InfoRow("AO 5,34", trendText(ui.ao), trendColor(ui.ao))
                InfoRow("Тело свечи", ui.body.fmt(2), if (ui.body < mode.maxBody) Up else Down)
                InfoRow(
                    "Payout",
                    if (ui.payout >= 0) "${ui.payout}%" else "—",
                    if (ui.payout >= mode.minPayout) Up else Down
                )
                InfoRow("Автомат", ui.engine.name, Accent)
                InfoRow(
                    "Последний сигнал",
                    ui.lastSignal?.name ?: "—",
                    when (ui.lastSignal) {
                        Direction.CALL -> Up
                        Direction.PUT -> Down
                        null -> TextDim
                    }
                )
            }

            GlassCard {
                SectionTitle("Управление")

                // Режим торговли (сохраняется в SharedPreferences, действует сразу, без перезапуска)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TradingMode.values().forEach { m ->
                        ModeChip(
                            text = m.title,
                            selected = mode == m,
                            onClick = {
                                mode = m
                                BotPrefs.setTradingMode(ctx, m)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
                Text(
                    mode.hint,
                    color = if (mode == TradingMode.TEST) Down else TextDim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
                )

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    GlassButton(
                        text = if (ui.running) "Остановить" else "Запросить захват и старт",
                        color = if (ui.running) Down else Accent,
                        onClick = if (ui.running) onStop else onStart,
                        modifier = Modifier.weight(1f).height(60.dp),
                        fontSize = 12.sp
                    )
                    GlassButton(
                        text = "Показать логи",
                        color = GlassFill,
                        onClick = { showLogDialog = true },
                        modifier = Modifier.weight(1f).height(60.dp),
                        fontSize = 12.sp
                    )
                    GlassButton(
                        text = "Калибровка зон",
                        color = GlassFill,
                        onClick = { showCalibration = true },
                        modifier = Modifier.weight(1f).height(60.dp),
                        fontSize = 12.sp
                    )
                }
                Box(Modifier.padding(top = 10.dp))
                GlassButton("Включить службу спец. возможностей", GlassFill, onOpenAccessibility)
                Row(
                    Modifier.fillMaxWidth().padding(top = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Автонажатие", color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text("Только демо-счёт. Выкл — только сигналы.", color = TextDim, fontSize = 12.sp)
                    }
                    Switch(
                        checked = autoTap,
                        onCheckedChange = { autoTap = it; BotPrefs.setAutoTap(ctx, it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Accent)
                    )
                }
            }

            GlassCard {
                SectionTitle("Маркеры нажатия")
                Text(
                    "Перетащите зелёный ▲ на кнопку КУПИТЬ, красный ▼ — на ПРОДАТЬ, затем нажмите синюю ✓. " +
                        "Бот будет нажимать в точках, где вы оставили маркеры.",
                    color = TextDim,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                InfoRow("CALL (КУПИТЬ)", callPos, Up)
                InfoRow("PUT (ПРОДАТЬ)", putPos, Down)
                Box(Modifier.padding(top = 10.dp))
                GlassButton(
                    text = if (ui.markers) "Скрыть маркеры и сохранить" else "Показать маркеры и открыть Pocket Option",
                    color = if (ui.markers) Down else Accent,
                    onClick = onToggleMarkers
                )
            }

            GlassCard {
                SectionTitle("Параметры")
                LabeledSlider("Пауза после сигнала", cooldown, 10f..300f, "${cooldown.toInt()} с") {
                    cooldown = it; BotPrefs.setCooldownSec(ctx, it.toInt())
                }
            }
        }

        // Полноэкранный оверлей калибровки зон поверх всего интерфейса
        if (showCalibration) {
            CalibrationScreen(onClose = { showCalibration = false })
        }
    }

    if (showLogDialog) {
        LogDialog(onDismiss = { showLogDialog = false })
    }
}

// ---------- окно журнала ----------

@Composable
private fun LogDialog(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val logs by LogRepository.logs.collectAsState()
    val listState = rememberLazyListState()

    // Авто-скролл вниз при каждом обновлении (размер списка упирается в лимит, поэтому следим и за последней строкой)
    LaunchedEffect(logs.size, logs.lastOrNull()) {
        if (logs.isNotEmpty()) listState.scrollToItem(logs.lastIndex)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(24.dp)
        Column(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.82f)
                .clip(shape)
                .background(Bg.copy(alpha = 0.9f))
                .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
                .padding(16.dp)
        ) {
            Text(
                "Журнал анализа",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            if (logs.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    Text("Журнал пуст", color = TextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth()
                ) {
                    items(logs) { line ->
                        Text(
                            text = line,
                            color = LogText,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GlassButton(
                    text = "Скопировать",
                    color = Accent,
                    onClick = {
                        clipboardManager.setText(AnnotatedString(LogRepository.logs.value.joinToString("\n")))
                        Toast.makeText(ctx, "Логи скопированы", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(1f)
                )
                GlassButton(
                    text = "Закрыть",
                    color = GlassFill,
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

// ---------- компоненты Glassmorphism ----------

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.04f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.14f), shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
private fun ModeChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = Accent
) {
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier = modifier
            .height(52.dp)
            .clip(shape)
            .background(if (selected) color.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.08f))
            .border(
                1.dp,
                if (selected) Color.White.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.14f),
                shape
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) Color.White else TextDim,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        color = TextMain,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(bottom = 8.dp)
    )
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextDim, fontSize = 14.sp)
        Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun GlassButton(
    text: String,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth(),
    fontSize: TextUnit = 14.sp
) {
    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = TextMain)
    ) {
        Text(text, fontSize = fontSize, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun LabeledSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    valueText: String,
    onChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = TextDim, fontSize = 13.sp)
            Text(valueText, color = TextMain, fontSize = 13.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
        )
    }
}

private fun trendText(t: Trend) = when (t) {
    Trend.GREEN -> "ЗЕЛЁНЫЙ"
    Trend.RED -> "КРАСНЫЙ"
    Trend.UNKNOWN -> "—"
}

private fun trendColor(t: Trend) = when (t) {
    Trend.GREEN -> Up
    Trend.RED -> Down
    Trend.UNKNOWN -> TextDim
}

private fun crossText(c: Cross, v: Float) = when (c) {
    Cross.UP -> "вверх (${v.fmt()})"
    Cross.DOWN -> "вниз (${v.fmt()})"
    Cross.NONE -> "нет"
}

private fun crossColor(c: Cross) = when (c) {
    Cross.UP -> Up
    Cross.DOWN -> Down
    Cross.NONE -> TextDim
}

private fun posText(ctx: Context, kx: String, ky: String): String =
    "${(BotPrefs.get(ctx, kx) * 100).roundToInt()}% × ${(BotPrefs.get(ctx, ky) * 100).roundToInt()}%"

// ======================= Калибровка зон (ROI) =======================

private enum class DragMode { NONE, MOVE, CORNER, DRAW }

private fun zoneColor(z: RoiZone): Color = when (z) {
    RoiZone.CHART -> Accent
    RoiZone.STOCH -> Color(0xFFF59E0B)
    RoiZone.AO -> Up
    RoiZone.PAYOUT -> Color(0xFFE879F9)
}

/** Последний кадр, сохранённый сервисом захвата, пока на экране был Pocket Option. */
private fun loadLastFrame(ctx: Context): Pair<ImageBitmap?, Long> {
    val f = File(ctx.filesDir, Roi.LAST_FRAME_FILE)
    if (!f.exists()) return Pair(null, 0L)
    return try {
        Pair(BitmapFactory.decodeFile(f.path)?.asImageBitmap(), f.lastModified())
    } catch (e: Exception) {
        Pair(null, 0L)
    }
}

private fun pct(v: Float): Int = (v * 100).roundToInt()

@Composable
private fun CalibrationScreen(onClose: () -> Unit) {
    val ctx = LocalContext.current
    BackHandler(onBack = onClose)

    // Рамки хранятся в долях экрана (0.0–1.0): пиксели касаний пересчитываются при каждом жесте,
    // поэтому «Сохранить» просто записывает готовые проценты в SharedPreferences
    val rects = remember {
        mutableStateMapOf<RoiZone, NormRect>().apply {
            RoiZone.values().forEach { put(it, RoiPrefs.load(ctx, it)) }
        }
    }
    var active by remember { mutableStateOf(RoiZone.CHART) }
    val (frame, frameTime) = remember { loadLastFrame(ctx) }
    val (screenW, screenH) = remember { realScreenSize(ctx) }
    val ratio = screenW.toFloat() / screenH.toFloat()

    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        // Вкладки зон
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            RoiZone.values().forEach { z ->
                ModeChip(
                    text = z.title,
                    selected = active == z,
                    onClick = { active = z },
                    modifier = Modifier.weight(1f),
                    color = zoneColor(z)
                )
            }
        }

        val r = rects.getValue(active)
        Text(
            "${active.title}: x ${pct(r.left)}–${pct(r.right)}%, y ${pct(r.top)}–${pct(r.bottom)}%. " +
                "Тяните за углы, двигайте рамку или обведите зону пальцем заново.",
            color = TextDim,
            fontSize = 11.sp,
            modifier = Modifier.padding(vertical = 6.dp)
        )

        // Картинка размером с экран телефона (с сохранением пропорций) и рамки поверх неё
        BoxWithConstraints(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            val wDp = minOf(maxWidth, maxHeight * ratio)
            val hDp = wDp / ratio
            ZoneCanvas(
                widthDp = wDp,
                heightDp = hDp,
                frame = frame,
                rects = rects,
                active = active
            )
        }

        if (frame == null) {
            Text(
                "Скриншота пока нет: запустите захват, откройте Pocket Option на несколько секунд " +
                    "и вернитесь сюда — на фоне появится последний кадр.",
                color = Down,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 6.dp)
            )
        } else if (frameTime > 0L) {
            val time = remember(frameTime) {
                java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date(frameTime))
            }
            Text("Скриншот от $time", color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            GlassButton(
                text = "Сбросить зону",
                color = GlassFill,
                onClick = { rects[active] = RoiPrefs.default(active) },
                modifier = Modifier.weight(1f).height(52.dp),
                fontSize = 12.sp
            )
            GlassButton(
                text = "Отмена",
                color = GlassFill,
                onClick = onClose,
                modifier = Modifier.weight(1f).height(52.dp),
                fontSize = 12.sp
            )
            GlassButton(
                text = "Сохранить",
                color = Accent,
                onClick = {
                    RoiZone.values().forEach { z -> RoiPrefs.save(ctx, z, rects.getValue(z)) }
                    LogRepository.addLog("ROI сохранены (калибровка)")
                    Toast.makeText(ctx, "Зоны сохранены", Toast.LENGTH_SHORT).show()
                    onClose()
                },
                modifier = Modifier.weight(1f).height(52.dp),
                fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun ZoneCanvas(
    widthDp: Dp,
    heightDp: Dp,
    frame: ImageBitmap?,
    rects: MutableMap<RoiZone, NormRect>,
    active: RoiZone
) {
    val density = LocalDensity.current
    val widthPx = with(density) { widthDp.toPx() }
    val heightPx = with(density) { heightDp.toPx() }
    val hitRadius = with(density) { 32.dp.toPx() }
    val handleRadius = with(density) { 10.dp.toPx() }
    val minSize = 0.02f

    Box(
        Modifier
            .size(widthDp, heightDp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF14171D))
    ) {
        if (frame != null) {
            Image(
                bitmap = frame,
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Заглушка: сетка через каждые 10% экрана
            Canvas(Modifier.fillMaxSize()) {
                for (i in 1..9) {
                    val x = size.width * i / 10f
                    val y = size.height * i / 10f
                    drawLine(Color.White.copy(alpha = 0.07f), Offset(x, 0f), Offset(x, size.height))
                    drawLine(Color.White.copy(alpha = 0.07f), Offset(0f, y), Offset(size.width, y))
                }
            }
        }

        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(active) {
                    val w = size.width.toFloat()
                    val h = size.height.toFloat()
                    var mode = DragMode.NONE
                    var corner = 0
                    var anchorX = 0f
                    var anchorY = 0f

                    detectDragGestures(
                        onDragStart = { p ->
                            val r = rects.getValue(active)
                            val corners = arrayOf(
                                Offset(r.left * w, r.top * h),
                                Offset(r.right * w, r.top * h),
                                Offset(r.left * w, r.bottom * h),
                                Offset(r.right * w, r.bottom * h)
                            )
                            var best = -1
                            var bestDist = hitRadius
                            for (i in 0..3) {
                                val dist = (corners[i] - p).getDistance()
                                if (dist <= bestDist) {
                                    bestDist = dist
                                    best = i
                                }
                            }
                            if (best >= 0) {
                                mode = DragMode.CORNER
                                corner = best
                            } else if (p.x in (r.left * w)..(r.right * w) && p.y in (r.top * h)..(r.bottom * h)) {
                                mode = DragMode.MOVE
                            } else {
                                mode = DragMode.DRAW
                                anchorX = (p.x / w).coerceIn(0f, 1f)
                                anchorY = (p.y / h).coerceIn(0f, 1f)
                            }
                        },
                        onDrag = { change, drag ->
                            change.consume()
                            val r = rects.getValue(active)
                            val fx = (change.position.x / w).coerceIn(0f, 1f)
                            val fy = (change.position.y / h).coerceIn(0f, 1f)
                            when (mode) {
                                DragMode.CORNER -> {
                                    var l = r.left
                                    var t = r.top
                                    var rr = r.right
                                    var b = r.bottom
                                    // углы: 0 = левый верхний, 1 = правый верхний, 2 = левый нижний, 3 = правый нижний
                                    if (corner == 0 || corner == 2) l = fx.coerceAtMost(rr - minSize)
                                    else rr = fx.coerceAtLeast(l + minSize)
                                    if (corner == 0 || corner == 1) t = fy.coerceAtMost(b - minSize)
                                    else b = fy.coerceAtLeast(t + minSize)
                                    rects[active] = NormRect(l, t, rr, b)
                                }
                                DragMode.MOVE -> {
                                    val wd = r.right - r.left
                                    val ht = r.bottom - r.top
                                    val nl = (r.left + drag.x / w).coerceIn(0f, 1f - wd)
                                    val nt = (r.top + drag.y / h).coerceIn(0f, 1f - ht)
                                    rects[active] = NormRect(nl, nt, nl + wd, nt + ht)
                                }
                                DragMode.DRAW -> {
                                    var l = minOf(anchorX, fx)
                                    var rr = maxOf(anchorX, fx)
                                    var t = minOf(anchorY, fy)
                                    var b = maxOf(anchorY, fy)
                                    if (rr - l < minSize) { rr = (l + minSize).coerceAtMost(1f); l = rr - minSize }
                                    if (b - t < minSize) { b = (t + minSize).coerceAtMost(1f); t = b - minSize }
                                    rects[active] = NormRect(l, t, rr, b)
                                }
                                DragMode.NONE -> Unit
                            }
                        },
                        onDragEnd = { mode = DragMode.NONE },
                        onDragCancel = { mode = DragMode.NONE }
                    )
                }
        ) {
            // Сначала неактивные зоны, активная — сверху
            RoiZone.values().sortedBy { it == active }.forEach { z ->
                val r = rects.getValue(z)
                val color = zoneColor(z)
                val isActive = z == active
                val topLeft = Offset(r.left * size.width, r.top * size.height)
                val rectSize = Size((r.right - r.left) * size.width, (r.bottom - r.top) * size.height)
                drawRect(color.copy(alpha = if (isActive) 0.28f else 0.10f), topLeft, rectSize)
                drawRect(
                    color.copy(alpha = if (isActive) 1f else 0.6f),
                    topLeft,
                    rectSize,
                    style = Stroke(width = (if (isActive) 3.dp else 1.5.dp).toPx())
                )
                if (isActive) {
                    listOf(
                        topLeft,
                        Offset(topLeft.x + rectSize.width, topLeft.y),
                        Offset(topLeft.x, topLeft.y + rectSize.height),
                        Offset(topLeft.x + rectSize.width, topLeft.y + rectSize.height)
                    ).forEach { c ->
                        drawCircle(Color.White, handleRadius, c)
                        drawCircle(color, handleRadius * 0.6f, c)
                    }
                }
            }
        }

        // Подписи зон
        RoiZone.values().forEach { z ->
            val r = rects.getValue(z)
            Text(
                z.title,
                color = zoneColor(z),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.offset {
                    IntOffset((r.left * widthPx).roundToInt() + 6, (r.top * heightPx).roundToInt() + 4)
                }
            )
        }
    }
}
