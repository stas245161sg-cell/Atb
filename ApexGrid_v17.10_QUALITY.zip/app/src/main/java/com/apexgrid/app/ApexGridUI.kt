package com.apexgrid.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ApexGlassBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.background(
            brush = Brush.verticalGradient(
                listOf(Color(0xFF0A1120), ApexGlassColors.VoidBlack, Color(0xFF060911))
            )
        )
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0x245CE1E6), Color(0x124EA8DE), Color.Transparent),
                        radius = 900f
                    )
                )
        )
        content()
    }
}

@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    accentBorder: Boolean = false,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (accentBorder) ApexGlassColors.RimAccent else ApexGlassColors.RimSubtle
    val glassBrush = Brush.linearGradient(
        listOf(Color(0xE0172238), Color(0xC40D1320), Color(0xD40A0F1A))
    )
    val sheenBrush = Brush.verticalGradient(
        listOf(Color(0x24FFFFFF), Color(0x08FFFFFF), Color.Transparent)
    )
    Box(
        modifier
            .shadow(12.dp, shape, ambientColor = Color(0x40000000), spotColor = Color(0x335CE1E6))
            .clip(shape)
            .background(glassBrush)
            .background(sheenBrush)
            .border(BorderStroke(1.dp, borderColor), shape)
    ) {
        Column(
            Modifier.padding(contentPadding),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun LiquidGlassActionButton(
    text: String,
    active: Boolean = false,
    destructive: Boolean = false,
    modifier: Modifier = Modifier,
    minHeight: Dp = 46.dp,
    compact: Boolean = false,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    val bg = when {
        destructive -> Brush.horizontalGradient(listOf(Color(0x66FF4D6D), Color(0x339E1B32)))
        active -> Brush.horizontalGradient(listOf(Color(0x525CE1E6), Color(0x384EA8DE)))
        else -> Brush.verticalGradient(listOf(Color(0x38FFFFFF), Color(0x16FFFFFF)))
    }
    val stroke = when {
        destructive -> Color(0x99FF4D6D)
        active -> ApexGlassColors.RimAccent
        else -> ApexGlassColors.RimSubtle
    }
    val textColor = when {
        destructive -> Color(0xFFFF9BB0)
        active -> ApexGlassColors.IceCyan
        else -> ApexGlassColors.TextPrimary
    }
    Box(
        modifier
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.dp, stroke), shape)
            .clickable(onClick = onClick)
            .padding(
                horizontal = if (compact) 7.dp else 10.dp,
                vertical = 10.dp
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = if (compact) 12.sp else 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            ),
            textAlign = TextAlign.Center,
            maxLines = if (compact) 1 else 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun HighContrastCyanButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(ApexGlassColors.IceCyan, Color(0xFF4CD2DC))))
            .border(BorderStroke(1.dp, Color(0x99FFFFFF)), shape)
            .clickable(onClick = onClick)
            .padding(vertical = 13.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = MaterialTheme.typography.titleMedium.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ApexGlassColors.VoidBlack
            ),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GlassMetricRow(
    label: String,
    value: String,
    valueColor: Color = ApexGlassColors.TextPrimary,
    modifier: Modifier = Modifier
) {
    Row(
        modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium.copy(color = ApexGlassColors.TextSecondary))
        Text(
            value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = valueColor
            )
        )
    }
}

@Composable
fun TradingProfileSelector(
    selected: TradingProfile,
    onSelect: (TradingProfile) -> Unit,
    modifier: Modifier = Modifier
) {
    val containerShape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(containerShape)
            .background(ApexGlassColors.GlassPill)
            .border(1.dp, ApexGlassColors.RimSubtle, containerShape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        TradingProfile.entries.forEach { profile ->
            val isSelected = profile == selected
            val itemShape = RoundedCornerShape(16.dp)
            Box(
                Modifier
                    .weight(1f)
                    .clip(itemShape)
                    .background(
                        if (isSelected) Brush.horizontalGradient(
                            listOf(Color(0x525CE1E6), Color(0x384EA8DE))
                        ) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .border(
                        1.dp,
                        if (isSelected) ApexGlassColors.RimAccent else Color.Transparent,
                        itemShape
                    )
                    .clickable { onSelect(profile) }
                    .padding(vertical = 10.dp, horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    profile.title,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) ApexGlassColors.IceCyan else ApexGlassColors.TextSecondary
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

/** Иконка бренда внутри Compose (тот же исходник, что и адаптивная иконка лаунчера). */
@Composable
fun ApexBrandIcon(modifier: Modifier = Modifier, size: Dp = 48.dp) {
    Image(
        painter = painterResource(id = R.drawable.apexgrid_icon_raw),
        contentDescription = "ApexGrid",
        contentScale = ContentScale.Crop,
        modifier = modifier.size(size).clip(RoundedCornerShape(14.dp))
    )
}
