package com.apexgrid.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

class TradingAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instanceRef: WeakReference<TradingAccessibilityService>? = null

        @Volatile
        var foregroundPackage: String = ""
            private set

        val instance: TradingAccessibilityService?
            get() = instanceRef?.get()

        fun isRunning(): Boolean = instanceRef?.get() != null

        fun currentForegroundPackage(): String {
            val svc = instanceRef?.get() ?: return foregroundPackage
            val rootPkg = try {
                svc.rootInActiveWindow?.packageName?.toString().orEmpty()
            } catch (_: Throwable) {
                ""
            }
            if (rootPkg.isNotEmpty()) {
                foregroundPackage = rootPkg
                return rootPkg
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val winPkg = svc.windows
                        ?.firstOrNull { it.isActive }
                        ?.root
                        ?.packageName
                        ?.toString()
                        .orEmpty()
                    if (winPkg.isNotEmpty()) {
                        foregroundPackage = winPkg
                        return winPkg
                    }
                } catch (_: Throwable) {}
            }
            return foregroundPackage
        }

        fun isPocketOptionForeground(): Boolean =
            currentForegroundPackage() == Roi.POCKET_PACKAGE
    }

    private var markers: OverlayMarkers? = null

    val markersVisible: Boolean
        get() = markers?.isShown == true

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        markers = OverlayMarkers(this)
        BotState.state.value = BotState.state.value.copy(accessibility = true, markers = false)
        LogRepository.addLog("Служба спец. возможностей подключена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val pkg = event?.packageName?.toString()
        if (!pkg.isNullOrEmpty()) foregroundPackage = pkg
    }

    override fun onInterrupt() {
        LogRepository.addLog("Служба спец. возможностей прервана")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        markers?.hide()
        markers = null
        if (instanceRef?.get() === this) instanceRef = null
        BotState.state.value = BotState.state.value.copy(accessibility = false, markers = false)
        LogRepository.addLog("Служба спец. возможностей отключена")
        return super.onUnbind(intent)
    }

    fun showMarkers() {
        (markers ?: OverlayMarkers(this).also { markers = it }).show()
    }

    fun hideMarkers() {
        markers?.hide()
    }

    fun tap(x: Float, y: Float, onResult: ((Boolean) -> Unit)? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            onResult?.invoke(false)
            return
        }
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        mainHandler.post {
            val dispatched = dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        onResult?.invoke(true)
                    }
                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        onResult?.invoke(false)
                    }
                },
                null
            )
            if (!dispatched) onResult?.invoke(false)
        }
    }
}
