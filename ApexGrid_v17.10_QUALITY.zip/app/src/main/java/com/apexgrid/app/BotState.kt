package com.apexgrid.app

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.ArrayDeque

enum class TradingProfile(val title: String, val minConfidence: Float) {
    FLOW("Поток", 0.45f),
    BALANCE("Баланс", 0.55f),
    SNIPER("Снайпер", 0.68f)
}

data class UiState(
    val running: Boolean = false,
    val cvReady: Boolean = false,
    val live: Boolean = true,
    val accessibility: Boolean = false,
    val autoTap: Boolean = true,
    val markers: Boolean = false,
    val profile: TradingProfile = TradingProfile.FLOW,
    val activePair: String = "—",
    val fps: Float = 0f,
    val candles: Int = 0,
    val sessionTrades: Int = 0,
    val body: Float = Float.NaN,
    val payout: Int = -1,
    val fiboHigh: Float = Float.NaN,
    val fiboLow: Float = Float.NaN,
    val putLevel: Float = Float.NaN,
    val callLevel: Float = Float.NaN,
    val curHigh: Float = Float.NaN,
    val curLow: Float = Float.NaN,
    val lastGreen: Boolean = false,
    val superTrend: Trend = Trend.UNKNOWN,
    val stochCross: Cross = Cross.NONE,
    val stochValue: Float = Float.NaN,
    val ao: Trend = Trend.UNKNOWN,
    val engine: EngineState = EngineState.SCANNING,
    val lastSignal: Direction? = null
)

object BotState {
    val state: MutableStateFlow<UiState> = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> get() = state

    fun setAutoTap(enabled: Boolean) {
        state.value = state.value.copy(autoTap = enabled)
    }

    fun setAccessibility(connected: Boolean) {
        state.value = state.value.copy(accessibility = connected)
    }

    fun update(transform: (UiState) -> UiState) {
        state.value = transform(state.value)
    }
}

object BotPrefs {
    private const val FILE = "apexgrid_bot_prefs"
    private const val KEY_AUTO_TAP = "auto_tap"
    private const val KEY_COOLDOWN_SEC = "cooldown_sec"
    private const val KEY_PROFILE = "trading_profile"
    private const val KEY_CALL_X = "call_x"
    private const val KEY_CALL_Y = "call_y"
    private const val KEY_PUT_X = "put_x"
    private const val KEY_PUT_Y = "put_y"

    const val CALL_X = KEY_CALL_X
    const val CALL_Y = KEY_CALL_Y
    const val PUT_X = KEY_PUT_X
    const val PUT_Y = KEY_PUT_Y

    fun isAutoTapEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getBoolean(KEY_AUTO_TAP, true)

    fun autoTap(context: Context): Boolean = isAutoTapEnabled(context)

    fun setAutoTapEnabled(context: Context, enabled: Boolean) {
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_AUTO_TAP, enabled).apply()
        BotState.setAutoTap(enabled)
    }

    fun setAutoTap(context: Context, enabled: Boolean) = setAutoTapEnabled(context, enabled)

    fun syncFromPrefs(context: Context) {
        BotState.setAutoTap(isAutoTapEnabled(context))
    }

    fun cooldownSec(context: Context): Int =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).getInt(KEY_COOLDOWN_SEC, 20)
            .coerceIn(15, 30)

    fun cooldownMs(context: Context): Long = cooldownSec(context) * 1_000L

    fun setCooldownSec(context: Context, sec: Int) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt(KEY_COOLDOWN_SEC, sec.coerceIn(15, 30)).apply()
    }

    fun profile(context: Context): TradingProfile {
        val raw = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_PROFILE, TradingProfile.FLOW.name)
        return TradingProfile.entries.firstOrNull { it.name == raw } ?: TradingProfile.FLOW
    }

    fun setProfile(context: Context, profile: TradingProfile) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putString(KEY_PROFILE, profile.name).apply()
        BotState.state.value = BotState.state.value.copy(profile = profile)
    }

    fun get(context: Context, key: String): Float {
        val defaultVal = when (key) {
            KEY_CALL_X -> 0.29f
            KEY_CALL_Y -> 0.65f
            KEY_PUT_X -> 0.71f
            KEY_PUT_Y -> 0.65f
            else -> 0.50f
        }
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getFloat(key, defaultVal).coerceIn(0.02f, 0.98f)
    }

    fun set(context: Context, key: String, value: Float) {
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(key, value.coerceIn(0.02f, 0.98f)).apply()
    }

    fun put(context: Context, key: String, value: Float) = set(context, key, value)
}

object SessionRiskGate {
    private const val MAX_GESTURES_PER_MINUTE = 30
    private const val WINDOW_MS = 60_000L
    private val gestureTimestamps = ArrayDeque<Long>()

    @Synchronized
    fun allow(nowMs: Long): String? {
        while (gestureTimestamps.isNotEmpty() && nowMs - gestureTimestamps.peekFirst() > WINDOW_MS) {
            gestureTimestamps.removeFirst()
        }
        if (gestureTimestamps.size >= MAX_GESTURES_PER_MINUTE) return "rate_limit_30_60s"
        return null
    }

    @Synchronized
    fun onExecutedGesture(nowMs: Long = SystemClock.elapsedRealtime()) {
        while (gestureTimestamps.isNotEmpty() && nowMs - gestureTimestamps.peekFirst() > WINDOW_MS) {
            gestureTimestamps.removeFirst()
        }
        gestureTimestamps.addLast(nowMs)
    }

    @Synchronized
    fun reset() {
        gestureTimestamps.clear()
    }
}
