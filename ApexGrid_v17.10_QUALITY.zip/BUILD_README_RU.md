# ApexGrid V17.7 — сборка APK

Локальная сборка в текущей среде невозможна: нет JDK, Gradle и Android SDK. APK собирается в GitHub Actions.

## Шаг 1 — репозиторий

1. Создайте **private** репозиторий на GitHub (например `apexgrid`).
2. Загрузите **содержимое корня архива** `ApexGrid_v17.7_FINAL.zip` в корень ветки `main`.

   В корне ветки обязательно должны лежать:

   ```
   app/
   build.gradle
   settings.gradle
   gradle.properties
   gradle/
   .github/workflows/build.yml
   ```

   **Важно:** нельзя загружать в корень саму папку `ApexGrid_V17/` — иначе `settings.gradle` и `app/build.gradle` окажутся на уровень ниже и workflow не найдёт проект, а путь `app/build/outputs/apk/debug/*.apk` в шаге Upload APK не совпадёт.

3. Альтернатива: распакуйте `ApexGrid_v17.7_ALL_CODE.txt` — это единый текстовый файл со всеми 33 исходными файлами (каждый с заголовком `FILE: ...`).

## Шаг 2 — сборка

Workflow `.github/workflows/build.yml`: checkout v4, JDK 17 Temurin, `android-actions/setup-android@v3`, `gradle/actions/setup-gradle@v3` (Gradle 8.7), сборка:

```
gradle assembleDebug --no-daemon --stacktrace
```

- при `push` в `main`/`master` сборка запускается сама;
- или вручную: **Actions → Build APK → Run workflow**.

Артефакт: **ApexGrid-debug-apk** (`app/build/outputs/apk/debug/*.apk`).

## Шаг 3 — установка

1. Перенесите APK на устройство и разрешите установку из неизвестных источников.
2. При первом запуске введите код доступа: `ApexGrid_byBoroda13`.
3. Включите службу спец. возможностей ApexGrid в настройках Android.
4. Нажмите START и разрешите захват экрана.
5. В Pocket Option выставьте SuperTrend 10/3, Stochastic 5/3/3, AO 5/34; уберите лишние индикаторы.
6. Откалите зоны «График», «Выплата», «Пара», Stochastic и AO. Новые дефолты V17.7: график верх 19.5%, пара x0.14–0.52, индикаторы ниже подписей.
7. Выплата ≥80%; график должен быть на последней свече (кнопка «>»).

**Важно:** `applicationId` изменён на `com.apexgrid.app`. Android сочтёт это новым приложением — старые настройки и калибровка не перенесутся. Ключ ROI тоже новый (`apexgrid_roi_prefs`), поэтому зоны нужно откалибровать заново.

## Что прислать после первого запуска

Первые 30–50 строк журнала (кнопка LOGS → «Копировать»). Проверяю:

- `START: APEXGRID profile=... conf>=...`
- `OCR PAIR RAW: '<сырое>' -> '<нормализованное>'` — должно быть `CAD/JPY OTC` без `8`, `O`, `CI`
- `PAIR_SWITCHED` — не должен сыпаться на одной паре
- `OCR PAYOUT: ...`
- `EVAL: ... candle=CLOSED ...`, `ST=GREEN/RED` (не сплошной UNKNOWN)
- `TAP CALL/PUT: ok=true` — и что `SessionRiskGate` инкрементирует счётчик

## Иконка

Иконка ApexGrid подключена: `res/drawable-nodpi/apexgrid_icon_raw.jpg` (1024×1024), адаптивные слои `mipmap-anydpi-v26/ic_launcher*.xml`, фон `#060B12`, `inset 16%`. Старые растровые mipmap удалены. Если лаунчер показывает старую иконку — очистите кэш лаунчера или переустановите APK.

## Известное

- Сборка debug, поэтому `debuggable=true`; доступ не блокируется, пока не задан `APEX_EXPECTED_SHA256`.
- WARNING про `Unable to strip ... .so` и `SDK XML version 4` на сборку не влияют.
