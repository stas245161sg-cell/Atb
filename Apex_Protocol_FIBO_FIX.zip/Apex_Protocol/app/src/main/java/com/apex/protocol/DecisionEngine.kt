package com.apex.protocol

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

enum class Direction { CALL, PUT }
enum class EngineState { SCANNING, CONFIRMING, COOLDOWN }

/** Коэффициент Фибоначчи 14.6% для расчёта уровней отката. */
const val FIBO_RATIO = 0.146f

/**
 * Уровни стратегии в Y-координатах КАДРА (Y растёт вниз!).
 *
 *  minHighY — верхняя граница свинга (самый высокий High = МИНИМАЛЬНЫЙ Y);
 *  maxLowY  — нижняя граница свинга (самый низкий Low = МАКСИМАЛЬНЫЙ Y);
 *  range    = maxLowY - minHighY > 0;
 *  putLevelY  = minHighY + 0.146·range  (ближе к верху, цена откатывает вниз от High);
 *  callLevelY = maxLowY  - 0.146·range  (ближе к низу, цена откатывает вверх от Low).
 *
 * Раньше в логах было `Low=0.0`, потому что minLow жёстко равнялся нулю — теперь Low это
 * реальная Y-координата нижней границы свинга.
 */
data class FiboLevels(
    val maxHigh: Float,   // = minHighY
    val minLow: Float,    // = maxLowY  (НЕ ноль!)
    val range: Float,
    val putLevel: Float,  // = putLevelY
    val callLevel: Float, // = callLevelY
    val anchorY: Float    // = maxLowY
)

fun fiboLevels(s: Snapshot): FiboLevels? {
    if (s.highs.isEmpty() || s.lows.isEmpty() || s.highs.size != s.lows.size) return null
    val highY = s.highs.min()   // High цены = минимальный Y
    val lowY = s.lows.max()     // Low цены = максимальный Y
    val range = lowY - highY
    if (range <= 0f) return null
    return FiboLevels(
        maxHigh = highY,
        minLow = lowY,
        range = range,
        putLevel = highY + FIBO_RATIO * range,
        callLevel = lowY - FIBO_RATIO * range,
        anchorY = lowY
    )
}

fun Float.fmt(digits: Int = 0, nan: String = "—"): String =
    if (isNaN()) nan else String.format(Locale.US, "%.${digits}f", this)

/** Итог оценки одного кадра. direction не null, только если выполнены ВСЕ условия входа. */
data class Verdict(
    val direction: Direction?,
    val failures: List<String>,
    val intended: String
)

/** EVAL: mode=FIBO ... FIBO: High=..., Low=..., PutLevel=..., CallLevel=... -> SIGNAL(PUT) */
fun evalLine(s: Snapshot, v: Verdict): String {
    val f = fiboLevels(s)
    val fibo = if (f != null) {
        "FIBO: HighY=${f.maxHigh.fmt(1)}, LowY=${f.minLow.fmt(1)}, " +
            "PutLevelY=${f.putLevel.fmt(1)}, CallLevelY=${f.callLevel.fmt(1)}, RangeY=${f.range.fmt(1)}"
    } else {
        "FIBO: n/a"
    }
    val touch = if (f != null && s.highs.isNotEmpty() && s.lows.isNotEmpty()) {
        "curHighY=${s.highs.last().fmt(1)}, curLowY=${s.lows.last().fmt(1)}, " +
            "closeY=${s.closeY.fmt(1, "?")}, ${if (s.isGreen) "GREEN" else "RED"}"
    } else {
        "cur=n/a"
    }
    val payout = if (s.payout >= 0) "${s.payout}" else "?"
    val verdict = if (v.direction != null) "SIGNAL(${v.direction.name})" else "NO_TRADE(${v.failures.joinToString(",")})"
    return "EVAL: mode=FIBO, dir=${v.intended}, body=${s.body.fmt(2, "?")}, payout=$payout, " +
        "$fibo, $touch -> $verdict"
}

/**
 * State Machine: SCANNING → CONFIRMING (N кадров подряд) → COOLDOWN → SCANNING.
 * Сигнал выдаётся один раз; после паузы бот ждёт, пока сетап исчезнет.
 * ENTRY_LOCK_MS защищает от повторного входа в ту же сторону на одном пересечении.
 */
class DecisionEngine(
    private val cooldownMs: () -> Long
) {

    companion object {
        const val CONFIRM_FRAMES = 3
        const val ENTRY_LOCK_MS = 300_000L

        /** Фильтры входа. */
        const val MIN_PAYOUT = 82
        const val MAX_BODY = 0.85f
    }

    var state: EngineState = EngineState.SCANNING
        private set

    /** Результат последней оценки (читается сервисом для строки EVAL). */
    var lastVerdict: Verdict = Verdict(null, emptyList(), "NONE")
        private set

    private var pending: Direction? = null
    private var count = 0
    private var cooldownUntil = 0L
    private var callLockUntil = 0L
    private var putLockUntil = 0L

    // Статистика причин отказа за период — показывает, какое условие чаще всего «не пускает» сделку
    private val failCounts = HashMap<String, Int>()
    private var framesTotal = 0
    private var framesLive = 0
    private var signals = 0

    fun evaluate(s: Snapshot, now: Long): Direction? {
        val v = applyEntryLock(verdict(s), now)
        lastVerdict = v

        framesTotal++
        if (s.live) framesLive++
        // entry_locked — не причина Market-условия, а служебный статус, STATS не засорят
        for (f in v.failures) {
            if (f.startsWith("entry_locked")) continue
            failCounts[f] = (failCounts[f] ?: 0) + 1
        }

        val raw = v.direction
        when (state) {
            EngineState.COOLDOWN -> {
                // После паузы ждём, пока сетап пропадёт — иначе вход повторится по тому же сигналу
                if (now >= cooldownUntil && raw == null) {
                    reset()
                    LogRepository.addLog("STATE: COOLDOWN -> SCANNING")
                }
            }
            EngineState.SCANNING -> {
                if (raw != null) {
                    pending = raw
                    count = 1
                    state = EngineState.CONFIRMING
                    LogRepository.addLog("STATE: SCANNING -> CONFIRMING (${raw.name} 1/$CONFIRM_FRAMES)")
                    // Сигнал выдаётся только из CONFIRMING, когда подтверждено CONFIRM_FRAMES кадров подряд.
                }
            }
            EngineState.CONFIRMING -> {
                if (raw != null && raw == pending) {
                    count++
                    if (count >= CONFIRM_FRAMES) return fire(now)
                } else {
                    val why = v.failures.joinToString(",").ifEmpty { "direction_changed" }
                    LogRepository.addLog("STATE: CONFIRMING -> SCANNING (setup lost: $why)")
                    reset()
                }
            }
        }
        return null
    }

    /**
     * Вход строго по закрытию, всё в Y-координатах кадра (Y растёт вниз!).
     *
     * PutLevelY лежит у ВЕРХА графика. Цена приходит к нему СНИЗУ (цена растёт → Y убывает):
     *   касание: high последней свечи дошёл до уровня → curHighY <= PutLevelY;
     *   отскок вниз: закрытие опустилось ниже уровня → closeY > PutLevelY;
     *   дополнительно свеча должна быть КРАСНОЙ (!isGreen).
     *
     * CallLevelY лежит у НИЗА графика. Цена приходит к нему СВЕРХУ (цена падает → Y растёт):
     *   касание: low последней свечи дошёл до уровня → curLowY >= CallLevelY;
     *   отскок вверх: закрытие поднялось выше уровня → closeY < CallLevelY;
     *   дополнительно свеча должна быть ЗЕЛЁНОЙ (isGreen).
     *
     * Важно: писать `curLowY >= PutLevelY` / `curHighY <= CallLevelY` НЕЛЬЗЯ — эти условия
     * истинны почти всегда и дают вечный entry_locked.
     */
    fun verdict(s: Snapshot): Verdict {
        if (!s.live) return Verdict(null, listOf("chart_scrolled"), "NONE")
        val f = fiboLevels(s) ?: return Verdict(null, listOf("fibo_no_data"), "NONE")

        val fails = ArrayList<String>()
        if (s.payout < 0) {
            fails.add("payout_unreadable")
        } else if (s.payout < MIN_PAYOUT) {
            fails.add("low_payout(<$MIN_PAYOUT)")
        }
        if (s.body.isNaN()) {
            fails.add("body_unknown")
        } else if (s.body >= MAX_BODY) {
            fails.add("big_body(>=${MAX_BODY.fmt(2)})")
        }

        val curHighY = s.highs.last()
        val curLowY = s.lows.last()
        val closeY = s.closeY
        val tol = f.range * 0.02f

        val putTouch = curHighY <= f.putLevel + tol
        val putReject = closeY > f.putLevel - tol
        val callTouch = curLowY >= f.callLevel - tol
        val callReject = closeY < f.callLevel + tol

        val direction: Direction?
        when {
            putTouch && putReject && !s.isGreen -> direction = Direction.PUT
            callTouch && callReject && s.isGreen -> direction = Direction.CALL
            putTouch || callTouch -> {
                fails.add("fibo_wrong_color")
                direction = null
            }
            else -> {
                fails.add("fibo_no_touch")
                direction = null
            }
        }

        val intended = when {
            putTouch -> "DOWN"
            callTouch -> "UP"
            else -> "NONE"
        }
        return Verdict(if (fails.isEmpty()) direction else null, fails, intended)
    }

    /** Один вход на одно касание уровня: повтор в ту же сторону блокируется на ENTRY_LOCK_MS. */
    private fun applyEntryLock(v: Verdict, now: Long): Verdict {
        val dir = v.direction ?: return v
        if (ENTRY_LOCK_MS <= 0L) return v
        val until = if (dir == Direction.CALL) callLockUntil else putLockUntil
        if (now >= until) return v
        return Verdict(null, v.failures + "entry_locked(${ENTRY_LOCK_MS / 60_000L}m)", v.intended)
    }

    /** Итоговая строка статистики за период; счётчики обнуляются. */
    fun statsLine(periodSec: Long): String {
        val fails = failCounts.entries
            .sortedByDescending { it.value }
            .joinToString(" ") { "${it.key}=${it.value}" }
            .ifEmpty { "none" }
        val line = "STATS ${periodSec}s: mode=FIBO frames=$framesTotal " +
            "live=$framesLive signals=$signals | $fails"
        failCounts.clear()
        framesTotal = 0
        framesLive = 0
        signals = 0
        return line
    }

    private fun fire(now: Long): Direction? {
        val dir = pending
        val pauseMs = cooldownMs()
        state = EngineState.COOLDOWN
        cooldownUntil = now + pauseMs
        pending = null
        count = 0
        signals++
        if (ENTRY_LOCK_MS > 0L) {
            if (dir == Direction.CALL) callLockUntil = now + ENTRY_LOCK_MS else putLockUntil = now + ENTRY_LOCK_MS
        }
        LogRepository.addLog(
            "STATE: CONFIRMING -> COOLDOWN (signal ${dir?.name}, mode=FIBO, pause ${pauseMs / 1000}s)"
        )
        return dir
    }

    private fun reset() {
        state = EngineState.SCANNING
        pending = null
        count = 0
    }
}

/** Состояние для UI. Журнал вынесен в LogRepository. */
data class UiState(
    val running: Boolean = false,
    val cvReady: Boolean = true,
    val live: Boolean = true,
    val markers: Boolean = false,
    val accessibility: Boolean = false,
    val fps: Float = 0f,
    val candles: Int = 0,
    val body: Float = Float.NaN,
    val payout: Int = -1,
    val fiboHigh: Float = Float.NaN,
    val fiboLow: Float = Float.NaN,
    val putLevel: Float = Float.NaN,
    val callLevel: Float = Float.NaN,
    val curHigh: Float = Float.NaN,
    val curLow: Float = Float.NaN,
    val lastGreen: Boolean = false,
    val engine: EngineState = EngineState.SCANNING,
    val lastSignal: Direction? = null
)

object BotState {
    val state = MutableStateFlow(UiState())
}

/** Настройки (SharedPreferences). Координаты кнопок — доли ширины/высоты экрана. */
object BotPrefs {
    const val CALL_X = "call_x"
    const val CALL_Y = "call_y"
    const val PUT_X = "put_x"
    const val PUT_Y = "put_y"
    private const val AUTO = "auto_tap"
    private const val COOLDOWN = "cooldown_s"

    // Центры кнопок КУПИТЬ / ПРОДАТЬ на скриншоте 1080x2400: (308,1553) и (771,1553)
    private val defaults = mapOf(
        CALL_X to 0.285f, CALL_Y to 0.647f,
        PUT_X to 0.714f, PUT_Y to 0.647f
    )

    private fun sp(c: Context) = c.getSharedPreferences("apex_protocol", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float = sp(c).getFloat(key, defaults[key] ?: 0.5f)
    fun put(c: Context, key: String, v: Float) { sp(c).edit().putFloat(key, v).apply() }

    fun autoTap(c: Context): Boolean = sp(c).getBoolean(AUTO, false)
    fun setAutoTap(c: Context, v: Boolean) { sp(c).edit().putBoolean(AUTO, v).apply() }

    fun cooldownSec(c: Context): Int = sp(c).getInt(COOLDOWN, 60)
    fun setCooldownSec(c: Context, v: Int) { sp(c).edit().putInt(COOLDOWN, v).apply() }
    fun cooldownMs(c: Context): Long = cooldownSec(c) * 1000L
}
