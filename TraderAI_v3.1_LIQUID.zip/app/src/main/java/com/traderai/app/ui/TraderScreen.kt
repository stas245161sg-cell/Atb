package com.traderai.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.traderai.app.capture.CaptureState
import com.traderai.app.capture.ScreenCaptureService
import com.traderai.app.data.AppSettings
import com.traderai.app.data.SettingsRepo
import com.traderai.app.trading.TradingGate
import com.traderai.app.vision.TradingMode
import kotlinx.coroutines.launch

private val GlassCardShape = RoundedCornerShape(22.dp)
private val GlassButtonShape = RoundedCornerShape(14.dp)
private val GlassSegmentShape = RoundedCornerShape(12.dp)

@Composable
fun TraderScreen(repo: SettingsRepo) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val settings by repo.flow.collectAsStateWithLifecycle(initialValue = AppSettings())
    val capturing by CaptureState.capturing.collectAsStateWithLifecycle()
    val status by CaptureState.status.collectAsStateWithLifecycle()
    val analysis by CaptureState.analysis.collectAsStateWithLifecycle()
    val calibrationReady by CaptureState.calibrationReady.collectAsStateWithLifecycle()
    val approved by TradingGate.approved.collectAsStateWithLifecycle()

    val projectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(context, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_START
                putExtra(ScreenCaptureService.EXTRA_CODE, result.resultCode)
                putExtra(ScreenCaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, serviceIntent)
            CaptureState.capturing(true)
            CaptureState.status("Захват запускается…")
        } else {
            CaptureState.capturing(false)
            CaptureState.status("Разрешение не получено")
        }
    }

    fun requestCapture() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    fun stopCapture() {
        val intent = Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        context.startService(intent)
        CaptureState.capturing(false)
    }

    val ambientBg = Brush.radialGradient(
        colors = listOf(
            Color(0xFF0E1B24),
            Color(0xFF07090D),
            TraderColors.Void
        ),
        center = Offset(450f, 180f),
        radius = 1250f
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ambientBg)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                    text = "Dark Grid",
                    color = TraderColors.Text,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "Observer · Heikin Ashi M5 · 5m",
                    color = TraderColors.Muted,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            GlassStatusPill(active = capturing)
        }

        LiquidGlassCard(accentGlow = capturing) {
            Text("СОСТОЯНИЕ", color = TraderColors.Muted, fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            Text(
                text = status,
                color = if (capturing) TraderColors.Mint else TraderColors.Amber,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(Modifier.height(2.dp))

            val isStop = capturing
            val btnFill = Brush.horizontalGradient(
                colors = if (isStop) {
                    listOf(TraderColors.RedGlow, TraderColors.RedDeep.copy(alpha = 0.85f))
                } else {
                    listOf(TraderColors.MintGlow, TraderColors.MintDeep.copy(alpha = 0.85f))
                }
            )
            val btnBorder = if (isStop) TraderColors.Red.copy(alpha = 0.55f)
                            else TraderColors.Mint.copy(alpha = 0.55f)
            val btnTextColor = if (isStop) TraderColors.Red else TraderColors.Mint

            Box(
                modifier = Modifier.fillMaxWidth().clip(GlassButtonShape)
                    .background(btnFill).border(1.dp, btnBorder, GlassButtonShape)
                    .clickable { if (isStop) stopCapture() else requestCapture() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isStop) "Остановить анализ" else "Запустить анализ",
                    color = btnTextColor,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 0.2.sp
                )
            }
        }

        LiquidGlassCard {
            Text("УПРАВЛЕНИЕ", color = TraderColors.Muted, fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)

            Row(
                modifier = Modifier.fillMaxWidth().clip(GlassSegmentShape)
                    .background(Color.White.copy(alpha = 0.04f))
                    .border(1.dp, TraderColors.GlassBorderSubtle, GlassSegmentShape)
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                TradingMode.entries.forEach { mode ->
                    val selected = settings.mode == mode
                    Box(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(9.dp))
                            .background(
                                if (selected) Brush.verticalGradient(
                                    listOf(TraderColors.Mint.copy(alpha = 0.22f),
                                        TraderColors.MintDeep.copy(alpha = 0.65f))
                                ) else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
                            )
                            .border(1.dp,
                                if (selected) TraderColors.Mint.copy(alpha = 0.45f) else Color.Transparent,
                                RoundedCornerShape(9.dp))
                            .clickable { scope.launch { repo.setMode(mode) } }
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = mode.name.lowercase().replaceFirstChar { it.uppercase() },
                            color = if (selected) TraderColors.Mint else TraderColors.Muted,
                            fontSize = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            GlassDivider()

            GlassToggleRow("Разрешить CALL", settings.call) { scope.launch { repo.setCall(it) } }
            GlassToggleRow("Разрешить PUT", settings.put) { scope.launch { repo.setPut(it) } }
            GlassToggleRow("Paper Trading", settings.paper) { scope.launch { repo.setPaper(it) } }

            GlassDivider()

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("Мин. выплата", color = TraderColors.Text, fontSize = 13.sp)
                Text("${settings.minPayout}%", color = TraderColors.Amber, fontSize = 14.sp,
                    fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Slider(
                value = settings.minPayout.toFloat(),
                onValueChange = { scope.launch { repo.setPayout(it.toInt()) } },
                valueRange = 50f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = TraderColors.Mint,
                    activeTrackColor = TraderColors.Mint,
                    inactiveTrackColor = Color.White.copy(alpha = 0.10f)
                )
            )
        }

        LiquidGlassCard(accentGlow = approved) {
            Text("КАЛИБРОВКА OHLC", color = TraderColors.Muted, fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            Text(
                text = if (calibrationReady)
                    "Шкала и свечи готовы. Сверьте 10+ свеч с экраном перед подтверждением."
                else "Сигналы заблокированы до получения данных калибровки.",
                color = if (calibrationReady) TraderColors.Text else TraderColors.Muted,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            val canToggleCal = calibrationReady || approved
            val calBg = when {
                approved -> Brush.horizontalGradient(
                    listOf(TraderColors.MintGlow, TraderColors.MintDeep.copy(alpha = 0.75f)))
                canToggleCal -> Brush.horizontalGradient(
                    listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f)))
                else -> Brush.horizontalGradient(
                    listOf(Color.White.copy(alpha = 0.03f), Color.Transparent))
            }
            val calBorder = when {
                approved -> TraderColors.Mint.copy(alpha = 0.5f)
                canToggleCal -> TraderColors.Amber.copy(alpha = 0.45f)
                else -> TraderColors.GlassBorderSubtle
            }
            val calText = when {
                approved -> TraderColors.Mint
                canToggleCal -> TraderColors.Amber
                else -> TraderColors.Muted
            }

            Box(
                modifier = Modifier.fillMaxWidth().clip(GlassButtonShape)
                    .background(calBg).border(1.dp, calBorder, GlassButtonShape)
                    .clickable(enabled = canToggleCal) { TradingGate.set(!approved) }
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (approved) "Калибровка подтверждена" else "Подтвердить калибровку",
                    color = calText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                )
            }

            if (!settings.paper) {
                Text("Paper Trading выключен — виртуальные сделки не фиксируются.",
                    color = TraderColors.Red, fontSize = 12.sp)
            }
        }

        LiquidGlassCard {
            Text("ТЕЛЕМЕТРИЯ КАДРА", color = TraderColors.Muted, fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
            Text(analysis, color = TraderColors.Text.copy(alpha = 0.92f), fontSize = 12.sp,
                lineHeight = 17.sp, fontFamily = FontFamily.Monospace)
        }

        Text("Observer · Автоклики CALL/PUT отключены",
            color = TraderColors.Muted, fontSize = 11.sp, fontFamily = FontFamily.Monospace,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
    }
}

@Composable
private fun LiquidGlassCard(
    accentGlow: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val surfaceBrush = Brush.verticalGradient(
        colors = listOf(
            Color.White.copy(alpha = if (accentGlow) 0.08f else 0.06f),
            TraderColors.GlassBase.copy(alpha = 0.92f),
            TraderColors.Void.copy(alpha = 0.96f)
        )
    )
    val borderBrush = Brush.verticalGradient(
        colors = listOf(
            if (accentGlow) TraderColors.GlassBorderMint else TraderColors.GlassBorderTop,
            TraderColors.GlassBorderSubtle,
            Color.White.copy(alpha = 0.02f)
        )
    )
    Column(
        modifier = Modifier.fillMaxWidth().clip(GlassCardShape)
            .background(surfaceBrush).border(1.dp, borderBrush, GlassCardShape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
private fun GlassDivider() {
    HorizontalDivider(color = Color.White.copy(alpha = 0.07f), thickness = 1.dp)
}

@Composable
private fun GlassToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TraderColors.Text, fontSize = 13.sp)
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(
            checkedThumbColor = TraderColors.Void,
            checkedTrackColor = TraderColors.Mint,
            uncheckedThumbColor = TraderColors.Muted,
            uncheckedTrackColor = Color.White.copy(alpha = 0.06f),
            uncheckedBorderColor = TraderColors.GlassBorderSubtle
        ))
    }
}

@Composable
private fun GlassStatusPill(active: Boolean) {
    val fg = if (active) TraderColors.Mint else TraderColors.Muted
    val bg = if (active) TraderColors.MintGlow else Color.White.copy(alpha = 0.05f)
    val bd = if (active) TraderColors.Mint.copy(alpha = 0.45f) else TraderColors.GlassBorderSubtle
    Row(
        modifier = Modifier.clip(CircleShape).background(bg).border(1.dp, bd, CircleShape)
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(fg))
        Text(if (active) "Active" else "Idle", color = fg, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, fontFamily = FontFamily.Monospace)
    }
}
