package com.traderai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object TraderColors {
    val Void = Color(0xFF040507)
    val GlassBase = Color(0xFF0C1015)
    val GlassHighlight = Color(0xFF161C24)

    val GlassBorderTop = Color(0x33FFFFFF)
    val GlassBorderSubtle = Color(0x12FFFFFF)
    val GlassBorderMint = Color(0x6600FFAA)

    val Text = Color(0xFFF5F7FA)
    val Muted = Color(0xFF8C96A6)

    val Mint = Color(0xFF00FFAA)
    val MintGlow = Color(0x2600FFAA)
    val MintDeep = Color(0xFF07261D)

    val Red = Color(0xFFFF453A)
    val RedGlow = Color(0x26FF453A)
    val RedDeep = Color(0xFF280B0D)

    val Amber = Color(0xFFFFB800)
}

private val LiquidGlassScheme = darkColorScheme(
    primary = TraderColors.Mint,
    onPrimary = TraderColors.Void,
    secondary = TraderColors.Amber,
    onSecondary = TraderColors.Void,
    background = TraderColors.Void,
    onBackground = TraderColors.Text,
    surface = TraderColors.GlassBase,
    onSurface = TraderColors.Text,
    surfaceVariant = TraderColors.GlassHighlight,
    onSurfaceVariant = TraderColors.Muted,
    outline = TraderColors.GlassBorderSubtle,
    error = TraderColors.Red,
    onError = TraderColors.Text
)

@Composable
fun TraderTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LiquidGlassScheme, content = content)
}
