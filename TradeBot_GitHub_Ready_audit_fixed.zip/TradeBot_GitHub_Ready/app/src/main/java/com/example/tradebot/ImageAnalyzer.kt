package com.example.tradebot

import android.content.Context
import android.graphics.Bitmap
import android.os.SystemClock
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.OpenCVLoader
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.io.Closeable
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.roundToInt

enum class Trend { GREEN, RED, UNKNOWN }
enum class Cross { UP, DOWN, NONE }

/**
 * Результат анализа одного кадра. NaN / -1 / UNKNOWN означает «не удалось определить».
 * live = false, когда график прокручен (данные уходят за правый край) — входить нельзя.
 */
data class Snapshot(
    val superTrend: Trend,
    val stochCross: Cross,
    val stochValue: Float,
    val ao: Trend,
    val body: Float,
    val payout: Int,
    val live: Boolean = true,
    val aoSlope: Float = Float.NaN,      // изменение AO за последние 2 столбца (px): > 0 растёт, < 0 падает
    val chartNote: String = ""           // почему не распознаны свеча / SuperTrend (для строки EVAL)
)

// ======================= Зоны интереса (ROI) =======================

/** Четыре зоны, которые пользователь выставляет на экране калибровки. */
enum class RoiZone(val key: String, val title: String) {
    CHART("chart", "График"),
    STOCH("stoch", "Stochastic"),
    AO("ao", "AO"),
    PAYOUT("payout", "Выплата")
}

/** Прямоугольник в долях экрана: 0.0 = левый/верхний край, 1.0 = правый/нижний. */
data class NormRect(val left: Float, val top: Float, val right: Float, val bottom: Float)

/**
 * Хранение зон в SharedPreferences: roi_chart_left, roi_chart_top, roi_chart_right, roi_chart_bottom,
 * далее roi_stoch_*, roi_ao_*, roi_payout_*. Значения по умолчанию — раскладка Pocket Option 1080x2400.
 */
object RoiPrefs {
    private const val FILE = "tradebot"
    private const val MIN_SIZE = 0.01f

    fun default(zone: RoiZone): NormRect = when (zone) {
        RoiZone.CHART -> NormRect(0.00f, 0.110f, 1.00f, 0.530f)
        RoiZone.STOCH -> NormRect(0.00f, 0.693f, 0.94f, 0.782f)
        RoiZone.AO -> NormRect(0.00f, 0.785f, 0.94f, 0.873f)
        RoiZone.PAYOUT -> NormRect(0.20f, 0.646f, 0.37f, 0.672f)
    }

    fun load(ctx: Context, zone: RoiZone): NormRect {
        val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        val d = default(zone)
        val p = "roi_${zone.key}_"
        val r = NormRect(
            sp.getFloat(p + "left", d.left),
            sp.getFloat(p + "top", d.top),
            sp.getFloat(p + "right", d.right),
            sp.getFloat(p + "bottom", d.bottom)
        )
        return if (isValid(r)) r else d
    }

    fun save(ctx: Context, zone: RoiZone, r: NormRect) {
        val fixed = if (isValid(r)) r else default(zone)
        val p = "roi_${zone.key}_"
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putFloat(p + "left", fixed.left)
            .putFloat(p + "top", fixed.top)
            .putFloat(p + "right", fixed.right)
            .putFloat(p + "bottom", fixed.bottom)
            .apply()
    }

    private fun isValid(r: NormRect): Boolean =
        r.left >= 0f && r.top >= 0f && r.right <= 1f && r.bottom <= 1f &&
            r.right - r.left >= MIN_SIZE && r.bottom - r.top >= MIN_SIZE
}

/** Прочие константы анализа (сами зоны вынесены в RoiPrefs). */
object Roi {
    const val POCKET_PACKAGE = "com.pocketoption.broker"
    const val LAST_FRAME_FILE = "last_frame.jpg"   // последний кадр с графиком — фон экрана калибровки

    // Данные дошли до правой границы калибровочной зоны графика (доля её ширины) → график прокручен.
    // Сравнение идёт именно с зоной ROI, а не с шириной экрана: зона может быть уже экрана.
    const val LIVE_EDGE_MAX = 0.95f
    const val STOCH_RECENT = 0.04f      // «свежесть» пересечения (доля ширины кадра, ≈2–3 свечи)

    // Запасное положение уровней 80 и 20 (доли высоты экрана), если линии на панели не найдены
    const val STOCH_Y80_ABS = 0.7163f
    const val STOCH_Y20_ABS = 0.7577f

    // Метки SuperTrend «Купить» / «Продать»: крупные залитые блоки с белым текстом, не свечи
    const val TAG_MIN_W = 0.06f         // минимальная ширина блока (доля ширины кадра)
    const val TAG_MIN_H = 0.008f        // минимальная высота блока (доля высоты кадра)
    const val TAG_MIN_WHITE = 0.02f     // доля белых пикселей (текст) внутри блока
    // Свеча: максимальная ширина — доля ширины кадра (для 1080 px ≈ 43 px). Лимит относится ТОЛЬКО к свечам:
    // линия SuperTrend читается по колонкам центра свечи и по ширине не ограничивается.
    const val CANDLE_MAX_WIDTH = 0.04f
    const val MAX_SKIP_SHIFT = 0.10f    // насколько левее самого правого края можно искать свечу, если правая слишком широкая
    const val MAX_ANALYSIS_WIDTH = 1080 // кадры шире уменьшаются до этой ширины перед анализом
}

/** Цвета в HSV OpenCV (H 0..179, S/V 0..255), замеры по скриншотам. */
object Hsv {
    // Общие маски: свечи и столбцы AO. Свеча вверх (70,183,52) H≈56; лаймовый столбец AO (113,181,20) H≈43
    val GREEN_LO = Scalar(30.0, 80.0, 80.0)
    val GREEN_HI = Scalar(90.0, 255.0, 255.0)
    // красная свеча (255,62,31) H≈4; красный столбец AO (205,8,12) H≈0/179
    val RED1_LO = Scalar(0.0, 80.0, 80.0)
    val RED1_HI = Scalar(10.0, 255.0, 255.0)
    val RED2_LO = Scalar(170.0, 80.0, 80.0)
    val RED2_HI = Scalar(180.0, 255.0, 255.0)

    // SuperTrend: линия и метки «Купить/Продать» окрашены в бирюзовый/голубой (Hue ≈ 84–90) и пурпурный (Hue ≈ 150).
    // Нижняя граница бирюзового — 78, а не 85: на реальном кадре оттенок линии 84–85, и при 85 теряется половина пикселей.
    // Направление тренда определяется не цветом, а положением линии относительно цены (см. superTrend()).
    val ST_CYAN_LO = Scalar(78.0, 100.0, 100.0)
    val ST_CYAN_HI = Scalar(105.0, 255.0, 255.0)
    val ST_MAGENTA_LO = Scalar(140.0, 100.0, 100.0)
    val ST_MAGENTA_HI = Scalar(165.0, 255.0, 255.0)

    // Синяя линия текущей цены (H≈102–108) задевает хвост голубого диапазона, поэтому её строки вырезаются.
    // Диапазон начинается с 106, чтобы не совпасть с самой голубой линией SuperTrend.
    val PRICE_LINE_LO = Scalar(106.0, 80.0, 80.0)
    val PRICE_LINE_HI = Scalar(125.0, 255.0, 255.0)

    // %K — синяя (39,72,178) H≈110; %D — оранжевая H≈10–15.
    val STOCH_K_LO = Scalar(100.0, 110.0, 110.0)
    val STOCH_K_HI = Scalar(128.0, 255.0, 255.0)
    val STOCH_D_LO = Scalar(5.0, 110.0, 110.0)
    val STOCH_D_HI = Scalar(18.0, 255.0, 255.0)

    // Белый текст внутри меток SuperTrend
    val WHITE_LO = Scalar(0.0, 0.0, 190.0)
    val WHITE_HI = Scalar(180.0, 60.0, 255.0)

    // Линии уровней Stochastic: 80 — бирюзовая (H≈86), 20 — жёлтая (H≈24)
    val LEVEL80_LO = Scalar(80.0, 100.0, 60.0)
    val LEVEL80_HI = Scalar(92.0, 255.0, 255.0)
    val LEVEL20_LO = Scalar(20.0, 100.0, 60.0)
    val LEVEL20_HI = Scalar(28.0, 255.0, 255.0)
}

/** Собирает все временные Mat и освобождает их разом (важно на 30 FPS). */
private class Mats : Closeable {
    private val list = ArrayList<Mat>()
    fun <T : Mat> keep(m: T): T {
        list.add(m)
        return m
    }
    fun mat(): Mat = keep(Mat())
    override fun close() {
        list.forEach { it.release() }
        list.clear()
    }
}

/** Пиксельные границы зоны внутри кадра. */
private class Box(val r0: Int, val r1: Int, val c0: Int, val c1: Int)

/** Найденная свеча: границы (в кадре анализа) и отношение тела к полной высоте. */
private class CandleShape(val x: Int, val y: Int, val w: Int, val h: Int, val body: Float)

/** Результат поиска последней свечи: отношение тела к высоте и пометка (например, candle_skipped). */
private class CandleResult(val body: Float, val note: String, val centerY: Int = -1)

private class ChartResult(val live: Boolean, val superTrend: Trend, val body: Float, val note: String = "")

class ImageAnalyzer(context: Context) : Closeable {

    private companion object {
        const val TAG = "ImageAnalyzer"
        const val MIN_ST_PIXELS = 3
        const val DOMINANCE = 1.25f
        const val OCR_INTERVAL_MS = 600L
        const val PAYOUT_TTL_MS = 5000L
        const val OCR_UPSCALE = 3
        const val OCR_LOG_HEARTBEAT_MS = 30_000L
        const val OCR_ERR_LOG_MS = 10_000L
        const val ROI_RELOAD_MS = 2_000L

        // Строгий разбор payout: берём 2–3 цифры подряд, число должно быть в диапазоне 50..99
        val PAYOUT_REGEX = Regex("(\\d{2,3})")
        const val PAYOUT_MIN = 50
        const val PAYOUT_MAX = 99
    }

    private val appContext: Context = context.applicationContext

    private val cvReady: Boolean = try {
        OpenCVLoader.initDebug()
    } catch (t: Throwable) {
        Log.e(TAG, "OpenCV init failed", t)
        false
    }
    val ready: Boolean get() = cvReady

    /** Причина последней ошибки анализа кадра (для журнала). */
    @Volatile var lastError: String? = null
        private set

    // Зоны читаются из SharedPreferences при создании анализатора (каждый запуск захвата)
    // и затем перечитываются раз в 2 секунды — калибровка действует без перезапуска.
    private var rois: Map<RoiZone, NormRect> = loadRois()
    private var roisLoadedAt = SystemClock.elapsedRealtime()
    private var lastResizeScale = 1f

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val ocrBusy = AtomicBoolean(false)
    private var lastOcrAt = 0L
    private var lastOcrLogKey = ""
    private var lastOcrLogAt = 0L
    private var lastOcrErrAt = 0L
    @Volatile private var payout = -1
    @Volatile private var payoutAt = 0L

    init {
        LogRepository.addLog("ROI: ${describeRois(rois)}")
    }

    private fun loadRois(): Map<RoiZone, NormRect> =
        RoiZone.values().associateWith { RoiPrefs.load(appContext, it) }

    private fun refreshRois(now: Long) {
        if (now - roisLoadedAt < ROI_RELOAD_MS) return
        roisLoadedAt = now
        val fresh = loadRois()
        if (fresh != rois) {
            rois = fresh
            LogRepository.addLog("ROI обновлены: ${describeRois(fresh)}")
        }
    }

    private fun describeRois(map: Map<RoiZone, NormRect>): String =
        map.entries.joinToString(" ") { (zone, r) ->
            "${zone.key}=x${pct(r.left)}-${pct(r.right)} y${pct(r.top)}-${pct(r.bottom)}"
        }

    private fun pct(v: Float): Int = (v * 100).roundToInt()

    fun analyze(bmp: Bitmap): Snapshot? {
        if (!cvReady) return null
        var scaled: Bitmap? = null
        return try {
            refreshRois(SystemClock.elapsedRealtime())
            requestPayoutOcr(bmp)                 // OCR — по исходному кадру (качество выше)

            // Все вычисления OpenCV — на копии шириной не больше 1080 px. Координаты тапов не затрагиваются:
            // они хранятся в долях реального экрана и применяются сервисом, а не анализатором.
            scaled = downscaleIfNeeded(bmp)
            val work = scaled ?: bmp

            Mats().use { m ->
                val rgba = m.mat()
                Utils.bitmapToMat(work, rgba)
                val rgb = m.mat()
                Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
                val hsv = m.mat()
                Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
                val frameW = hsv.cols()
                val frameH = hsv.rows()

                val chart = chart(hsv, frameW, frameH, m)
                if (!chart.live) {
                    return@use Snapshot(
                        Trend.UNKNOWN, Cross.NONE, Float.NaN, Trend.UNKNOWN,
                        Float.NaN, currentPayout(), live = false
                    )
                }
                val (cross, crossValue) = stochastic(hsv, frameW, m)
                val (aoColor, aoSlope) = awesome(hsv, m)

                Snapshot(
                    chart.superTrend, cross, crossValue, aoColor, chart.body, currentPayout(),
                    aoSlope = aoSlope, chartNote = chart.note
                )
            }
        } catch (t: Throwable) {
            Log.e(TAG, "analyze failed", t)
            lastError = "${t.javaClass.simpleName}: ${t.message}"
            null
        } finally {
            scaled?.recycle()
        }
    }

    /** Кадр шире 1080 px уменьшается до ровно 1080 px по ширине (высота пропорционально); иначе null. */
    private fun downscaleIfNeeded(bmp: Bitmap): Bitmap? {
        if (bmp.width <= Roi.MAX_ANALYSIS_WIDTH) {
            lastResizeScale = 1f
            return null
        }
        val scale = Roi.MAX_ANALYSIS_WIDTH.toFloat() / bmp.width
        val height = (bmp.height * scale).roundToInt().coerceAtLeast(1)
        if (abs(scale - lastResizeScale) > 0.001f) {
            lastResizeScale = scale
            LogRepository.addLog("image_resized(scale=${String.format(Locale.US, "%.2f", scale)})")
        }
        return Bitmap.createScaledBitmap(bmp, Roi.MAX_ANALYSIS_WIDTH, height, true)
    }

    // ---------- вспомогательные ----------

    /** Пиксельные границы зоны; доли берутся из сохранённой калибровки. */
    private fun box(hsv: Mat, r: NormRect): Box {
        val r0 = (hsv.rows() * r.top).toInt().coerceIn(0, hsv.rows() - 1)
        val r1 = (hsv.rows() * r.bottom).toInt().coerceIn(r0 + 1, hsv.rows())
        val c0 = (hsv.cols() * r.left).toInt().coerceIn(0, hsv.cols() - 1)
        val c1 = (hsv.cols() * r.right).toInt().coerceIn(c0 + 1, hsv.cols())
        return Box(r0, r1, c0, c1)
    }

    /**
     * submat()/colRange()/rowRange() создают новый Mat-хендлер с общими данными.
     * Регистрируем его в пуле кадра: без этого на 30 FPS хендлер живёт до GC.
     */
    private fun Mat.crop(b: Box, m: Mats): Mat = m.keep(submat(b.r0, b.r1, b.c0, b.c1))

    private fun greenMask(src: Mat, m: Mats): Mat {
        val out = m.mat()
        Core.inRange(src, Hsv.GREEN_LO, Hsv.GREEN_HI, out)
        return out
    }

    private fun redMask(src: Mat, m: Mats): Mat {
        val a = m.mat()
        val b = m.mat()
        Core.inRange(src, Hsv.RED1_LO, Hsv.RED1_HI, a)
        Core.inRange(src, Hsv.RED2_LO, Hsv.RED2_HI, b)
        Core.bitwise_or(a, b, a)
        return a
    }

    /** Индекс самой правой колонки, где есть хотя бы [minPixels] пикселей маски; -1 если пусто. */
    private fun lastColoredColumn(mask: Mat, m: Mats, minPixels: Int = 2): Int {
        val sums = m.mat()
        Core.reduce(mask, sums, 0, Core.REDUCE_SUM, CvType.CV_32S)
        val arr = IntArray(mask.cols())
        sums.get(0, 0, arr)
        var x = arr.size - 1
        while (x >= 0 && arr[x] < 255 * minPixels) x--
        return x
    }

    // ---------- 1. График: метки, SuperTrend, тело последней свечи ----------

    private fun chart(hsv: Mat, frameW: Int, frameH: Int, m: Mats): ChartResult {
        val b = box(hsv, rois.getValue(RoiZone.CHART))
        val roi = hsv.crop(b, m)
        // Зелёная/красная маски — только для свечей; SuperTrend ищется отдельно по бирюзовому/пурпурному
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        removeTags(roi, g, r, all, frameW, frameH, m)

        // Правый край данных сравнивается с правой границей калибровочной зоны графика,
        // а не с шириной всего экрана: пользователь мог нарисовать зону уже экрана.
        val end = lastColoredColumn(all, m)
        if (end < 0) return ChartResult(true, Trend.UNKNOWN, Float.NaN, "no_colored_pixels_in_chart_roi")
        val roiW = b.c1 - b.c0
        if (end >= roiW * Roi.LIVE_EDGE_MAX) return ChartResult(false, Trend.UNKNOWN, Float.NaN)

        val candle = lastCandle(all, frameW, m)
        val (trend, stNote) = superTrend(roi, end + 1, frameW, frameH, candle.centerY, m)
        val note = listOf(candle.note, stNote).filter { it.isNotEmpty() }.joinToString(",")
        return ChartResult(true, trend, candle.body, note)
    }

    /**
     * SuperTrend. Линия ищется по бирюзовому (Hue 78–105) и пурпурному (Hue 140–165) цветам, а направление тренда
     * определяется ГЕОМЕТРИЕЙ, а не цветом: линия под ценой — восходящий тренд (Trend.GREEN), над ценой — нисходящий
     * (Trend.RED). Так бот не зависит от того, какой цвет назначен тренду: на реальном кадре пурпурная линия ниже цены
     * с меткой «Купить» — это восходящий тренд, а бирюзовая выше цены с меткой «Продать» — нисходящий.
     *
     * Линия заканчивается в центре последней свечи, поэтому берутся последние колонки перед правым краем данных [x1].
     * Метки «Купить/Продать» окрашены в те же цвета, что и линия, — крупные блоки с белым текстом вырезаются.
     * Строки синей линии текущей цены вырезаются, а сама цена служит опорной точкой для сравнения.
     */
    private fun superTrend(
        roi: Mat, x1: Int, frameW: Int, frameH: Int, candleCenterY: Int, m: Mats
    ): Pair<Trend, String> {
        val cyan = m.mat()
        val magenta = m.mat()
        Core.inRange(roi, Hsv.ST_CYAN_LO, Hsv.ST_CYAN_HI, cyan)
        Core.inRange(roi, Hsv.ST_MAGENTA_LO, Hsv.ST_MAGENTA_HI, magenta)
        val line = m.mat()
        Core.bitwise_or(cyan, magenta, line)

        val keep = tagKeepMask(roi, line, frameW, frameH, m)
        if (keep != null) Core.bitwise_and(line, keep, line)

        val band = priceLineBand(roi, m)
        if (band != null) {
            val priceBand = m.keep(line.submat(band[0], band[1], 0, line.cols()))
            priceBand.setTo(Scalar(0.0))
        }

        val s = frameW / 540f
        val rad = (2f * s).roundToInt().coerceAtLeast(2)
        val c1 = x1.coerceAtMost(line.cols())
        val c0 = (c1 - 6 * rad).coerceAtLeast(0)
        if (c1 - c0 < 2) return Pair(Trend.UNKNOWN, "st_line_not_found(window_too_small)")

        val region = m.mat()
        m.keep(line.colRange(c0, c1)).copyTo(region)
        val count = Core.countNonZero(region)
        if (count < MIN_ST_PIXELS) return Pair(Trend.UNKNOWN, "st_line_not_found(px=$count)")

        val cols = region.cols()
        val rows = region.rows()
        val bytes = ByteArray(rows * cols)
        region.get(0, 0, bytes)
        val colCount = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) if (bytes[base + x].toInt() != 0) colCount[x]++
        }

        // Правый конец линии: последняя колонка с ≥2 пикселями (иначе ≥1); берём 3 последние колонки
        var xe = -1
        for (x in cols - 1 downTo 0) if (colCount[x] >= 2) { xe = x; break }
        if (xe < 0) for (x in cols - 1 downTo 0) if (colCount[x] >= 1) { xe = x; break }
        if (xe < 0) return Pair(Trend.UNKNOWN, "st_line_not_found(px=0)")
        val lo = (xe - 2).coerceAtLeast(0)
        var ySum = 0L
        var yCount = 0
        for (y in 0 until rows) {
            val base = y * cols
            for (x in lo..xe) if (bytes[base + x].toInt() != 0) { ySum += y; yCount++ }
        }
        val lineY = ySum.toFloat() / yCount

        val priceY: Float = when {
            band != null -> band[2].toFloat()
            candleCenterY >= 0 -> candleCenterY.toFloat()
            else -> return Pair(Trend.UNKNOWN, "st_no_price_reference")
        }

        // y растёт вниз: линия ниже цены → восходящий тренд
        val margin = maxOf(2f, 2f * s)
        val trend = when {
            lineY > priceY + margin -> Trend.GREEN
            lineY < priceY - margin -> Trend.RED
            else -> Trend.UNKNOWN
        }
        val note = if (trend == Trend.UNKNOWN) {
            "st_line_at_price(lineY=${lineY.roundToInt()},priceY=${priceY.roundToInt()})"
        } else {
            ""
        }
        return Pair(trend, note)
    }

    /** Строки (от, до, центр) длинной горизонтальной синей линии текущей цены; null, если её нет. */
    private fun priceLineBand(roi: Mat, m: Mats): IntArray? {
        val blue = m.mat()
        Core.inRange(roi, Hsv.PRICE_LINE_LO, Hsv.PRICE_LINE_HI, blue)
        val sums = m.mat()
        Core.reduce(blue, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = blue.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var best = 0
        for (y in 1 until rows) if (arr[y] > arr[best]) best = y
        if (arr[best] < 255 * 0.25f * blue.cols()) return null
        return intArrayOf((best - 3).coerceAtLeast(0), (best + 4).coerceAtMost(rows), best)
    }

    /**
     * Метки SuperTrend «Купить»/«Продать» — крупные залитые прямоугольники с белым текстом. Они выступают правее
     * последней свечи после недавнего разворота и могут касаться линии. Поэтому:
     *  1) берём «толстую» часть маски (открытие 5x5): тонкая линия и фитили отпадают, метка отделяется от линии;
     *  2) меткой считаем крупный блок, внутри которого есть белый текст (у свечей белого нет);
     *  3) заливаем «дырки» (буквы) и расширяем.
     * Возвращает маску «оставить» (255 — оставить) или null, если меток нет.
     */
    private fun tagKeepMask(roi: Mat, union: Mat, frameW: Int, frameH: Int, m: Mats): Mat? {
        val k = (5f * frameW / 540f).roundToInt().coerceAtLeast(3)
        val kernel = m.keep(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(k.toDouble(), k.toDouble())))

        val thick = m.mat()
        Imgproc.morphologyEx(union, thick, Imgproc.MORPH_OPEN, kernel)

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(thick, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return null
        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        val white = m.mat()
        Core.inRange(roi, Hsv.WHITE_LO, Hsv.WHITE_HI, white)

        val tagMask = m.keep(Mat.zeros(union.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            val x = st[i * 5]
            val y = st[i * 5 + 1]
            val w = st[i * 5 + 2]
            val h = st[i * 5 + 3]
            if (w < Roi.TAG_MIN_W * frameW || h < Roi.TAG_MIN_H * frameH) continue
            val whiteCount = Core.countNonZero(m.keep(white.submat(y, y + h, x, x + w)))
            if (whiteCount >= Roi.TAG_MIN_WHITE * w * h) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(tagMask, one, tagMask)
                found = true
            }
        }
        if (!found) return null

        val work = m.mat()
        tagMask.copyTo(work)
        val contours = ArrayList<MatOfPoint>()
        val hierarchy = m.mat()
        Imgproc.findContours(work, contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        Imgproc.drawContours(tagMask, contours, -1, Scalar(255.0), -1)   // -1 = залить
        contours.forEach { it.release() }

        val grown = m.mat()
        Imgproc.dilate(tagMask, grown, kernel)
        val inverse = m.mat()
        Core.bitwise_not(grown, inverse)
        return inverse
    }

    /** Вырезает метки из зелёной/красной масок графика (свечи) и убирает мелкие остатки. */
    private fun removeTags(roi: Mat, g: Mat, r: Mat, all: Mat, frameW: Int, frameH: Int, m: Mats) {
        val keep = tagKeepMask(roi, all, frameW, frameH, m)
        if (keep != null) {
            Core.bitwise_and(g, keep, g)
            Core.bitwise_and(r, keep, r)
            Core.bitwise_or(g, r, all)
        }
        removeSpecks(g, r, all, frameW, m)
    }

    /** Мелкий мусор (остатки краёв меток): компоненты уже ~3 px и ниже ~6 px в масштабе кадра 540 px. */
    private fun removeSpecks(g: Mat, r: Mat, all: Mat, frameW: Int, m: Mats) {
        val s = frameW / 540f
        val minW = maxOf(2, (3f * s).roundToInt())
        val minH = maxOf(3, (6f * s).roundToInt())

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        val junk = m.keep(Mat.zeros(all.size(), CvType.CV_8UC1))
        val one = m.mat()
        var found = false
        for (i in 1 until n) {
            if (st[i * 5 + 2] < minW && st[i * 5 + 3] < minH) {
                Core.compare(labels, Scalar(i.toDouble()), one, Core.CMP_EQ)
                Core.bitwise_or(junk, one, junk)
                found = true
            }
        }
        if (!found) return
        val inverse = m.mat()
        Core.bitwise_not(junk, inverse)
        Core.bitwise_and(g, inverse, g)
        Core.bitwise_and(r, inverse, r)
        Core.bitwise_or(g, r, all)
    }

    /**
     * Последняя свеча — самая правая связная компонента (тело + фитили) шириной не больше
     * maxAllowedWidth = 4% ширины кадра (для 1080 px ≈ 43 px). Если самая правая слишком широкая
     * (зум графика, склейка соседних свечей), она пропускается и берётся предыдущая закрытая свеча —
     * не дальше MAX_SKIP_SHIFT влево. Причина пропуска пишется как candle_skipped(w=..px,max=..px)
     * (значения приведены к ширине кадра 1080 px). Возвращает body = высота тела / полная высота.
     */
    private fun lastCandle(all: Mat, frameW: Int, m: Mats): CandleResult {
        fun unknown(note: String) = CandleResult(Float.NaN, note)
        fun px1080(v: Int) = (v * 1080f / frameW).roundToInt()

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(all, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return unknown("no_components")
        val st = IntArray(n * 5)
        stats.get(0, 0, st)

        var rightmost = 0
        for (i in 1 until n) rightmost = maxOf(rightmost, st[i * 5] + st[i * 5 + 2])

        val s = frameW / 540f
        val maxAllowedWidth = (frameW * Roi.CANDLE_MAX_WIDTH).toInt()
        val maxShift = (frameW * Roi.MAX_SKIP_SHIFT).toInt()
        val minWideHeight = maxOf(3, (6f * s).roundToInt())

        var skippedWidth = 0
        var tooFarLeft = false
        var shape: CandleShape? = null
        // Перебор справа налево по правому краю компоненты
        for (i in (1 until n).sortedByDescending { st[it * 5] + st[it * 5 + 2] }) {
            val x = st[i * 5]
            val w = st[i * 5 + 2]
            val h = st[i * 5 + 3]
            val area = st[i * 5 + 4]
            if (h < 3) continue
            if (rightmost - (x + w) > maxShift) {
                tooFarLeft = true
                break
            }
            if (w > maxAllowedWidth) {
                // широкая «свеча»: запоминаем для лога и сдвигаемся влево
                if (skippedWidth == 0 && h >= minWideHeight && area.toFloat() / (w * h) >= 0.3f) skippedWidth = w
                continue
            }
            val measured = measureCandle(all, x, w, frameW, m)
            if (measured != null) {
                shape = measured
                break
            }
        }

        val skippedNote = if (skippedWidth > 0) {
            "candle_skipped(w=${px1080(skippedWidth)}px,max=${px1080(maxAllowedWidth)}px)"
        } else {
            ""
        }
        val c = shape ?: return unknown(
            when {
                skippedNote.isNotEmpty() && tooFarLeft -> "$skippedNote,no_candle_within_shift"
                skippedNote.isNotEmpty() -> skippedNote
                else -> "no_candle_found"
            }
        )
        return CandleResult(c.body, skippedNote, c.y + c.h / 2)
    }

    /**
     * Измеряет свечу в колонках [x-1, x+w+1]: вертикальное замыкание склеивает тело и фитили, разрезанные
     * горизонтальной линией цены; тело — строки шире половины максимальной ширины. null — не свеча
     * (ни одна строка не шире 3 px: фитиль, линия, остаток).
     */
    private fun measureCandle(all: Mat, x: Int, w: Int, frameW: Int, m: Mats): CandleShape? {
        val x0 = (x - 1).coerceAtLeast(0)
        val x1 = (x + w + 1).coerceAtMost(all.cols())
        if (x1 - x0 < 2) return null
        val sub = m.keep(all.colRange(x0, x1))

        val closeH = (5f * frameW / 540f).roundToInt().coerceAtLeast(3)
        val vk = m.keep(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(1.0, closeH.toDouble())))
        val closed = m.mat()
        Imgproc.morphologyEx(sub, closed, Imgproc.MORPH_CLOSE, vk)

        val labels = m.mat()
        val stats = m.mat()
        val centroids = m.mat()
        val n = Imgproc.connectedComponentsWithStats(closed, labels, stats, centroids, 8, CvType.CV_32S)
        if (n < 2) return null
        val st = IntArray(n * 5)
        stats.get(0, 0, st)
        val cols = closed.cols()

        // Компонента, пересекающая центральную колонку свечи (самая крупная)
        val center = (x + w / 2) - x0
        var best = -1
        for (j in 1 until n) {
            val left = st[j * 5]
            val wj = st[j * 5 + 2]
            val area = st[j * 5 + 4]
            if (center >= left && center < left + wj && (best < 0 || area > st[best * 5 + 4])) best = j
        }
        if (best < 0) return null

        val bx = st[best * 5]
        val by = st[best * 5 + 1]
        val bw = st[best * 5 + 2]
        val bh = st[best * 5 + 3]
        if (bh < 2) return null

        val lab = IntArray(closed.rows() * cols)
        labels.get(0, 0, lab)
        val rowCounts = IntArray(bh)
        var maxRow = 0
        for (yy in 0 until bh) {
            var c = 0
            val base = (by + yy) * cols
            for (xx in bx until bx + bw) if (lab[base + xx] == best) c++
            rowCounts[yy] = c
            if (c > maxRow) maxRow = c
        }
        if (maxRow < 3) return null

        val threshold = maxOf(3f, 0.5f * maxRow)
        var bodyRows = 0
        for (c in rowCounts) if (c >= threshold) bodyRows++
        return CandleShape(x0 + bx, by, bw, bh, (bodyRows.toFloat() / bh).coerceIn(0f, 1f))
    }

    // ---------- 2. Stochastic (5,3,3) ----------

    private fun stochastic(hsv: Mat, frameW: Int, m: Mats): Pair<Cross, Float> {
        val b = box(hsv, rois.getValue(RoiZone.STOCH))
        val roi = hsv.crop(b, m)
        val k = m.mat()
        val d = m.mat()
        Core.inRange(roi, Hsv.STOCH_K_LO, Hsv.STOCH_K_HI, k)
        Core.inRange(roi, Hsv.STOCH_D_LO, Hsv.STOCH_D_HI, d)

        val rows = k.rows()
        val cols = k.cols()
        val kb = ByteArray(rows * cols)
        val db = ByteArray(rows * cols)
        k.get(0, 0, kb)
        d.get(0, 0, db)

        // Шкала 0..100 привязана к линиям уровней 80 и 20 на самой панели, а не к границам рамки,
        // поэтому значение не зависит от того, как пользователь нарисовал зону
        val (y80, y20) = stochLevels(roi, b.r0, hsv.rows(), m)

        val sumK = LongArray(cols)
        val cntK = IntArray(cols)
        val sumD = LongArray(cols)
        val cntD = IntArray(cols)
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (kb[base + x].toInt() != 0) { sumK[x] += y.toLong(); cntK[x]++ }
                if (db[base + x].toInt() != 0) { sumD[x] += y.toLong(); cntD[x]++ }
            }
        }

        // Конец данных: последняя колонка, где видны обе линии (правее — пустое поле графика)
        var lastX = -1
        for (x in cols - 1 downTo 0) {
            if (cntK[x] > 0 && cntD[x] > 0) { lastX = x; break }
        }
        if (lastX < 0) return Pair(Cross.NONE, Float.NaN)

        val deadzone = 0.5f * frameW / 540f
        var prevSign = 0
        var crossX = -1
        var crossDir = Cross.NONE
        var crossVal = Float.NaN
        for (x in 0..lastX) {
            if (cntK[x] == 0 || cntD[x] == 0) continue
            val yK = sumK[x].toFloat() / cntK[x]
            val yD = sumD[x].toFloat() / cntD[x]
            val diff = yD - yK                      // > 0  →  %K выше %D (меньший y = выше)
            val sign = when {
                diff > deadzone -> 1
                diff < -deadzone -> -1
                else -> 0
            }
            if (sign == 0) continue
            if (prevSign != 0 && sign != prevSign) {
                crossX = x
                crossDir = if (sign > 0) Cross.UP else Cross.DOWN
                crossVal = toStochValue((yK + yD) / 2f, y80, y20)
            }
            prevSign = sign
        }

        val recentCols = (frameW * Roi.STOCH_RECENT).toInt().coerceAtLeast(4)
        if (crossX < 0 || lastX - crossX > recentCols) return Pair(Cross.NONE, Float.NaN)
        return Pair(crossDir, crossVal)
    }

    /**
     * Строки (внутри зоны) линий уровней 80 и 20. Ищем длинные горизонтальные линии бирюзового и жёлтого цвета;
     * если не нашли — берём запасные доли высоты экрана.
     */
    private fun stochLevels(roi: Mat, roiTop: Int, frameH: Int, m: Mats): Pair<Float, Float> {
        val teal = m.mat()
        val yellow = m.mat()
        Core.inRange(roi, Hsv.LEVEL80_LO, Hsv.LEVEL80_HI, teal)
        Core.inRange(roi, Hsv.LEVEL20_LO, Hsv.LEVEL20_HI, yellow)
        val a = lineCenter(teal, m)
        val b = lineCenter(yellow, m)
        if (a != null && b != null && b - a >= frameH * 0.02f) return Pair(a, b)
        return Pair(Roi.STOCH_Y80_ABS * frameH - roiTop, Roi.STOCH_Y20_ABS * frameH - roiTop)
    }

    /** Вертикальный центр самой «насыщенной» горизонтальной линии маски; null, если линии нет. */
    private fun lineCenter(mask: Mat, m: Mats): Float? {
        val sums = m.mat()
        Core.reduce(mask, sums, 1, Core.REDUCE_SUM, CvType.CV_32S)
        val rows = mask.rows()
        val arr = IntArray(rows)
        sums.get(0, 0, arr)
        var max = 0
        for (v in arr) if (v > max) max = v
        if (max < 255 * 0.25f * mask.cols()) return null
        var wSum = 0.0
        var ySum = 0.0
        for (y in 0 until rows) {
            if (arr[y] >= max / 2) {
                wSum += arr[y]
                ySum += arr[y].toDouble() * y
            }
        }
        return (ySum / wSum).toFloat()
    }

    /** Линейная шкала по двум опорным линиям: y80 → 80, y20 → 20. */
    private fun toStochValue(y: Float, y80: Float, y20: Float): Float {
        val v = 80f - (y - y80) * 60f / (y20 - y80)
        return v.coerceIn(0f, 100f)
    }

    // ---------- 3. Awesome Oscillator (5,34) ----------

    private fun awesome(hsv: Mat, m: Mats): Pair<Trend, Float> {
        val b = box(hsv, rois.getValue(RoiZone.AO))
        val roi = hsv.crop(b, m)
        val g = greenMask(roi, m)
        val r = redMask(roi, m)
        val all = m.mat()
        Core.bitwise_or(g, r, all)

        val x = lastColoredColumn(all, m)
        if (x < 0) return Pair(Trend.UNKNOWN, Float.NaN)

        val x0 = (x - 2).coerceAtLeast(0)
        val gc = Core.countNonZero(m.keep(g.colRange(x0, x + 1)))
        val rc = Core.countNonZero(m.keep(r.colRange(x0, x + 1)))
        val color = when {
            gc > rc -> Trend.GREEN
            rc > gc -> Trend.RED
            else -> Trend.UNKNOWN
        }
        return Pair(color, aoSlope(all))
    }

    /**
     * Изменение AO за последние два столбца: value[последний] − value[третий с конца], в пикселях зоны.
     * Значение столбца считается от базовой линии (нуля): над ней — плюс, под ней — минус.
     * > 0 — AO растёт, < 0 — падает, NaN — определить не удалось.
     * Цвет столбца в Pocket Option — это знак изменения к предыдущему столбцу, поэтому «красный, но растёт»
     * для одного последнего столбца невозможен; растущий наклон за два столбца ловит одиночный красный «провал».
     */
    private fun aoSlope(all: Mat): Float {
        val rows = all.rows()
        val cols = all.cols()
        val buf = ByteArray(rows * cols)
        all.get(0, 0, buf)

        val top = IntArray(cols) { -1 }
        val bot = IntArray(cols) { -1 }
        for (y in 0 until rows) {
            val base = y * cols
            for (x in 0 until cols) {
                if (buf[base + x].toInt() != 0) {
                    if (top[x] < 0) top[x] = y
                    bot[x] = y
                }
            }
        }

        // Столбцы гистограммы = группы подряд идущих непустых колонок шириной от 2 px
        val bars = ArrayList<IntArray>()
        var x = 0
        while (x < cols) {
            if (top[x] < 0) { x++; continue }
            var t = top[x]
            var bt = bot[x]
            var xx = x
            while (xx < cols && top[xx] >= 0) {
                if (top[xx] < t) t = top[xx]
                if (bot[xx] > bt) bt = bot[xx]
                xx++
            }
            if (xx - x >= 2) bars.add(intArrayOf(t, bt))
            x = xx
        }
        if (bars.size < 4) return Float.NaN

        // Базовая линия — самая частая граница столбцов (все столбцы «растут» от неё)
        val freq = HashMap<Int, Int>()
        for (bar in bars) {
            freq[bar[0]] = (freq[bar[0]] ?: 0) + 1
            freq[bar[1]] = (freq[bar[1]] ?: 0) + 1
        }
        var baseline = bars[0][0]
        var bestScore = -1
        for (v in freq.keys) {
            val score = (freq[v - 1] ?: 0) + (freq[v] ?: 0) + (freq[v + 1] ?: 0)
            if (score > bestScore) {
                bestScore = score
                baseline = v
            }
        }
        val zero = baseline

        fun value(bar: IntArray): Int {
            val up = zero - bar[0]
            val down = bar[1] - zero
            return if (up >= down) up else -down
        }
        val last = value(bars[bars.size - 1])
        val third = value(bars[bars.size - 3])
        return (last - third).toFloat()
    }

    // ---------- 4. Payout через ML Kit OCR + строгая регулярка ----------

    private fun requestPayoutOcr(bmp: Bitmap) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOcrAt < OCR_INTERVAL_MS) return
        if (!ocrBusy.compareAndSet(false, true)) return
        lastOcrAt = now
        try {
            val zone = rois.getValue(RoiZone.PAYOUT)
            val x0 = (bmp.width * zone.left).toInt().coerceIn(0, bmp.width - 2)
            val x1 = (bmp.width * zone.right).toInt().coerceIn(x0 + 1, bmp.width)
            val y0 = (bmp.height * zone.top).toInt().coerceIn(0, bmp.height - 2)
            val y1 = (bmp.height * zone.bottom).toInt().coerceIn(y0 + 1, bmp.height)
            val crop = Bitmap.createBitmap(bmp, x0, y0, x1 - x0, y1 - y0)
            val scaled = Bitmap.createScaledBitmap(
                crop, crop.width * OCR_UPSCALE, crop.height * OCR_UPSCALE, true
            )
            if (scaled !== crop) crop.recycle()

            recognizer.process(InputImage.fromBitmap(scaled, 0))
                .addOnSuccessListener { text ->
                    val raw = text.text.replace('\n', ' ').trim().take(40)
                    val extracted = extractPayout(raw)
                    val nowMs = SystemClock.elapsedRealtime()
                    if (extracted != null) {
                        payout = extracted
                        payoutAt = nowMs
                    }
                    // В журнал — при изменении результата и раз в 30 с, чтобы не засорять его (OCR идёт ~2 раза в секунду)
                    val key = "$raw|$extracted"
                    if (key != lastOcrLogKey || nowMs - lastOcrLogAt >= OCR_LOG_HEARTBEAT_MS) {
                        lastOcrLogKey = key
                        lastOcrLogAt = nowMs
                        LogRepository.addLog("OCR RAW: '$raw' -> EXTRACTED: ${extracted ?: "null"}")
                    }
                }
                .addOnFailureListener { err ->
                    val nowMs = SystemClock.elapsedRealtime()
                    if (nowMs - lastOcrErrAt >= OCR_ERR_LOG_MS) {
                        lastOcrErrAt = nowMs
                        LogRepository.addLog("OCR: ошибка ${err.message}")
                    }
                }
                .addOnCompleteListener {
                    scaled.recycle()
                    ocrBusy.set(false)
                }
        } catch (t: Throwable) {
            Log.e(TAG, "ocr failed", t)
            ocrBusy.set(false)
        }
    }

    /**
     * Строгий разбор: из сырой строки ('YOTC +92', '92%', 'SD OTC +9;') берём числа из 2–3 цифр
     * и возвращаем первое в диапазоне 50..99; иначе null.
     */
    private fun extractPayout(raw: String): Int? {
        for (match in PAYOUT_REGEX.findAll(raw)) {
            val v = match.groupValues[1].toIntOrNull() ?: continue
            if (v in PAYOUT_MIN..PAYOUT_MAX) return v
        }
        return null
    }

    private fun currentPayout(): Int =
        if (SystemClock.elapsedRealtime() - payoutAt > PAYOUT_TTL_MS) -1 else payout

    override fun close() {
        try { recognizer.close() } catch (ignored: Throwable) {}
    }
}
