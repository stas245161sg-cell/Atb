package com.example.tradebot

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.Locale

enum class Direction { CALL, PUT }
enum class EngineState { SCANNING, CONFIRMING, COOLDOWN }

/**
 * Режим торговли. У каждого режима своя независимая функция проверки (checkTest / checkBase / checkSafe),
 * общие только мелкие проверки payout и тела свечи.
 *
 *  ТЕСТ     — только SuperTrend (Stochastic и AO игнорируются); payout ≥ 70, тело < 0.85. Для проверки нажатий.
 *  БАЗОВЫЙ  — SuperTrend + свежее пересечение Stochastic в сторону тренда (любая зона); AO не учитывается;
 *             payout ≥ 82, тело < 0.85.
 *  АККУРАТНЫЙ — SuperTrend + пересечение Stochastic строго ниже 30 (CALL) / выше 70 (PUT) + AO того же цвета;
 *             payout ≥ 85, тело < 0.70.
 */
enum class TradingMode(
    val title: String,
    val minPayout: Int,
    val maxBody: Float,
    val hint: String
) {
    TEST(
        "ТЕСТ (50%)", 70, 0.85f,
        "Только SuperTrend: вход по цвету линии, Stochastic и AO не учитываются. Payout ≥ 70, тело < 0.85. " +
            "Только для проверки нажатий — демо-счёт!"
    ),
    BASE(
        "БАЗОВЫЙ (60%)", 82, 0.85f,
        "SuperTrend + свежее пересечение Stochastic в сторону тренда (в любой зоне). AO не учитывается. " +
            "Payout ≥ 82, тело < 0.85."
    ),
    SAFE(
        "АККУРАТНЫЙ (70%)", 85, 0.70f,
        "SuperTrend + пересечение Stochastic строго ниже 30 (вверх) / выше 70 (вниз) + AO того же цвета. " +
            "Payout ≥ 85, тело < 0.70."
    )
}

fun Float.fmt(digits: Int = 0, nan: String = "—"): String =
    if (isNaN()) nan else String.format(Locale.US, "%.${digits}f", this)

/**
 * Итог оценки одного кадра в заданном режиме.
 * direction — не null, только если выполнены ВСЕ условия режима; failures — коды невыполненных условий;
 * notes — пометки (например, проигнорированное противоречие Stoch в режиме ТЕСТ);
 * intended — направление, которое «хочет» SuperTrend (UP / DOWN / NONE).
 */
data class Verdict(
    val direction: Direction?,
    val failures: List<String>,
    val intended: String,
    val mode: TradingMode,
    val notes: List<String> = emptyList()
)

/** EVAL: mode=BASE, dir=DOWN, st=RED, stoch=DOWN@73, ao=GREEN(d+6), body=0.50, payout=86 -> SIGNAL(PUT) (ao — только для информации) */
fun evalLine(s: Snapshot, v: Verdict): String {
    val stoch = if (s.stochCross == Cross.NONE) "NONE" else "${s.stochCross.name}@${s.stochValue.fmt(0, "?")}"
    val payout = if (s.payout >= 0) "${s.payout}" else "?"
    val d = v.direction
    val verdict = if (d != null) "SIGNAL(${d.name})" else "NO_TRADE(${v.failures.joinToString(",")})"
    val notes = if (v.notes.isEmpty()) "" else " [${v.notes.joinToString(",")}]"
    val slope = if (s.aoSlope.isNaN()) "" else "(d${if (s.aoSlope > 0f) "+" else ""}${s.aoSlope.toInt()})"
    val chart = if (s.chartNote.isNotEmpty()) {
        ", chart=${s.chartNote}"
    } else {
        ""
    }
    return "EVAL: mode=${v.mode.name}, dir=${v.intended}, st=${s.superTrend.name}, stoch=$stoch, " +
        "ao=${s.ao.name}$slope, body=${s.body.fmt(2, "?")}, payout=$payout$chart -> $verdict$notes"
}

/**
 * State Machine: SCANNING → CONFIRMING (N кадров подряд) → COOLDOWN → SCANNING.
 * Сигнал выдаётся один раз; после паузы бот ждёт, пока сетап исчезнет, и только потом снова готов к входу.
 * Режим читается на каждом кадре через [modeProvider], поэтому переключение в UI действует сразу.
 */
class DecisionEngine(
    private val cooldownMs: () -> Long,
    private val modeProvider: () -> TradingMode = { TradingMode.TEST }
) {

    companion object {
        const val CONFIRM_FRAMES = 3

        // АККУРАТНЫЙ: пересечение Stochastic строго ниже 30 (CALL) / строго выше 70 (PUT)
        const val SAFE_CALL_BELOW = 30f
        const val SAFE_PUT_ABOVE = 70f

        /**
         * «Свежее пересечение» Stochastic в БАЗОВОМ и АККУРАТНОМ режимах считается свежим ещё несколько свечей
         * (на M5 это 10–15 минут), поэтому после входа новый вход в ту же сторону блокируется на это время:
         * один вход на одно пересечение. 0 — отключить блокировку. ТЕСТ блокировкой не затрагивается.
         */
        const val ENTRY_LOCK_MS = 300_000L
    }

    var state: EngineState = EngineState.SCANNING
        private set

    /** Результат последней оценки (читается сервисом для строки EVAL). */
    var lastVerdict: Verdict = Verdict(null, emptyList(), "NONE", TradingMode.TEST)
        private set

    private var lastMode: TradingMode? = null
    private var pending: Direction? = null
    private var count = 0
    private var cooldownUntil = 0L
    private var callLockUntil = 0L
    private var putLockUntil = 0L

    // Статистика причин отказа за период — показывает, какое условие чаще всего «не пускает» сделку
    private val failCounts = HashMap<String, Int>()
    private var framesTotal = 0
    private var framesLive = 0
    private var signals = 0

    fun evaluate(s: Snapshot, now: Long): Direction? {
        val mode = modeProvider()
        val previous = lastMode
        if (previous != null && previous != mode) {
            LogRepository.addLog("MODE: ${previous.name} -> ${mode.title}")
            if (state == EngineState.CONFIRMING) reset()     // условия другие — подтверждение начинаем заново
        }
        lastMode = mode

        val v = applyEntryLock(verdict(s, mode), now)
        lastVerdict = v

        framesTotal++
        if (s.live) framesLive++
        for (f in v.failures) failCounts[f] = (failCounts[f] ?: 0) + 1

        val raw = v.direction
        when (state) {
            EngineState.COOLDOWN -> {
                // После паузы ждём, пока сетап пропадёт — иначе вход повторится по тому же сигналу
                if (now >= cooldownUntil && raw == null) {
                    reset()
                    LogRepository.addLog("STATE: COOLDOWN -> SCANNING")
                }
            }
            EngineState.SCANNING -> {
                if (raw != null) {
                    pending = raw
                    count = 1
                    state = EngineState.CONFIRMING
                    LogRepository.addLog("STATE: SCANNING -> CONFIRMING (${raw.name} 1/$CONFIRM_FRAMES)")
                    // Сигнал выдаётся только из CONFIRMING, когда подтверждено CONFIRM_FRAMES кадров подряд.
                }
            }
            EngineState.CONFIRMING -> {
                if (raw != null && raw == pending) {
                    count++
                    if (count >= CONFIRM_FRAMES) return fire(now, mode)
                } else {
                    val why = v.failures.joinToString(",").ifEmpty { "direction_changed" }
                    LogRepository.addLog("STATE: CONFIRMING -> SCANNING (setup lost: $why)")
                    reset()
                }
            }
        }
        return null
    }

    /** Проверка условий входа выбранного режима с перечислением невыполненных. Режимы не пересекаются. */
    fun verdict(s: Snapshot, mode: TradingMode): Verdict {
        if (!s.live) return Verdict(null, listOf("chart_scrolled"), "NONE", mode)
        return when (mode) {
            TradingMode.TEST -> checkTest(s)
            TradingMode.BASE -> checkBase(s)
            TradingMode.SAFE -> checkSafe(s)
        }
    }

    // ---------- ТЕСТ: только SuperTrend ----------
    private fun checkTest(s: Snapshot): Verdict {
        val mode = TradingMode.TEST
        val fails = ArrayList<String>()
        payoutFailure(s, mode.minPayout)?.let { fails.add(it) }
        bodyFailure(s, mode.maxBody)?.let { fails.add(it) }
        val (dir, intended) = trendDirection(s)
        if (dir == null) fails.add("st_unknown")
        return Verdict(if (fails.isEmpty()) dir else null, fails, intended, mode)
    }

    // ---------- БАЗОВЫЙ: SuperTrend + свежее пересечение Stochastic (любая зона), AO не учитывается ----------
    private fun checkBase(s: Snapshot): Verdict {
        val mode = TradingMode.BASE
        val fails = ArrayList<String>()
        payoutFailure(s, mode.minPayout)?.let { fails.add(it) }
        bodyFailure(s, mode.maxBody)?.let { fails.add(it) }
        val (dir, intended) = trendDirection(s)
        if (dir == null) {
            fails.add("st_unknown")
        } else {
            crossDirectionFailure(s, dir)?.let { fails.add(it) }
        }
        return Verdict(if (fails.isEmpty()) dir else null, fails, intended, mode)
    }

    // ---------- АККУРАТНЫЙ: SuperTrend + Stochastic строго в зоне + AO, тело < 0.70, payout ≥ 85 ----------
    private fun checkSafe(s: Snapshot): Verdict {
        val mode = TradingMode.SAFE
        val fails = ArrayList<String>()
        payoutFailure(s, mode.minPayout)?.let { fails.add(it) }
        bodyFailure(s, mode.maxBody)?.let { fails.add(it) }
        val (dir, intended) = trendDirection(s)
        if (dir == null) {
            fails.add("st_unknown")
        } else {
            val crossFailure = crossDirectionFailure(s, dir)
            if (crossFailure != null) {
                fails.add(crossFailure)
            } else {
                zoneFailure(s, dir)?.let { fails.add(it) }
            }
            aoFailure(s, dir)?.let { fails.add(it) }
        }
        return Verdict(if (fails.isEmpty()) dir else null, fails, intended, mode)
    }

    // ---------- общие мелкие проверки (без логики режимов) ----------

    private fun payoutFailure(s: Snapshot, min: Int): String? = when {
        s.payout < 0 -> "payout_unreadable"
        s.payout < min -> "low_payout(<$min)"
        else -> null
    }

    private fun bodyFailure(s: Snapshot, max: Float): String? = when {
        s.body.isNaN() -> "body_unknown"
        s.body >= max -> "big_body(>=${max.fmt(2)})"
        else -> null
    }

    /** Направление по SuperTrend: GREEN → CALL ("UP"), RED → PUT ("DOWN"), иначе null ("NONE"). */
    private fun trendDirection(s: Snapshot): Pair<Direction?, String> = when (s.superTrend) {
        Trend.GREEN -> Pair(Direction.CALL, "UP")
        Trend.RED -> Pair(Direction.PUT, "DOWN")
        Trend.UNKNOWN -> Pair(null, "NONE")
    }

    /** Свежее пересечение Stochastic в сторону тренда (зона не проверяется). */
    private fun crossDirectionFailure(s: Snapshot, dir: Direction): String? {
        val want = if (dir == Direction.CALL) Cross.UP else Cross.DOWN
        return when {
            s.stochCross == Cross.NONE -> if (dir == Direction.CALL) "no_stoch_cross_up" else "no_stoch_cross_down"
            s.stochCross != want -> "stoch_cross_opposite"
            else -> null
        }
    }

    /** АККУРАТНЫЙ: значение пересечения строго ниже 30 (CALL) / строго выше 70 (PUT); NaN не проходит. */
    private fun zoneFailure(s: Snapshot, dir: Direction): String? = when (dir) {
        Direction.CALL ->
            if (s.stochValue < SAFE_CALL_BELOW) null else "stoch_cross_not_below_${SAFE_CALL_BELOW.toInt()}"
        Direction.PUT ->
            if (s.stochValue > SAFE_PUT_ABOVE) null else "stoch_cross_not_above_${SAFE_PUT_ABOVE.toInt()}"
    }

    /** АККУРАТНЫЙ: цвет последнего столбца AO должен совпасть с направлением (CALL — зелёный, PUT — красный). */
    private fun aoFailure(s: Snapshot, dir: Direction): String? = when (dir) {
        Direction.CALL -> if (s.ao == Trend.GREEN) null else "ao_not_green"
        Direction.PUT -> if (s.ao == Trend.RED) null else "ao_not_red"
    }

    /** БАЗОВЫЙ и АККУРАТНЫЙ: один вход на одно пересечение — повторный вход в ту же сторону блокируется. */
    private fun applyEntryLock(v: Verdict, now: Long): Verdict {
        val dir = v.direction ?: return v
        if (v.mode == TradingMode.TEST || ENTRY_LOCK_MS <= 0L) return v
        val until = if (dir == Direction.CALL) callLockUntil else putLockUntil
        if (now >= until) return v
        return Verdict(null, v.failures + "entry_locked(${ENTRY_LOCK_MS / 60_000L}m)", v.intended, v.mode, v.notes)
    }

    /** Итоговая строка статистики за период; счётчики обнуляются. */
    fun statsLine(periodSec: Long): String {
        val fails = failCounts.entries
            .sortedByDescending { it.value }
            .joinToString(" ") { "${it.key}=${it.value}" }
            .ifEmpty { "none" }
        val line = "STATS ${periodSec}s: mode=${lastMode?.name ?: "?"} frames=$framesTotal " +
            "live=$framesLive signals=$signals | $fails"
        failCounts.clear()
        framesTotal = 0
        framesLive = 0
        signals = 0
        return line
    }

    private fun fire(now: Long, mode: TradingMode): Direction? {
        val dir = pending
        val pauseMs = cooldownMs()
        state = EngineState.COOLDOWN
        cooldownUntil = now + pauseMs
        pending = null
        count = 0
        signals++
        if (mode != TradingMode.TEST && ENTRY_LOCK_MS > 0L) {
            if (dir == Direction.CALL) callLockUntil = now + ENTRY_LOCK_MS else putLockUntil = now + ENTRY_LOCK_MS
        }
        LogRepository.addLog(
            "STATE: CONFIRMING -> COOLDOWN (signal ${dir?.name}, mode=${mode.name}, pause ${pauseMs / 1000}s)"
        )
        return dir
    }

    private fun reset() {
        state = EngineState.SCANNING
        pending = null
        count = 0
    }
}

/** Состояние для UI. Журнал вынесен в LogRepository. */
data class UiState(
    val running: Boolean = false,
    val cvReady: Boolean = true,
    val live: Boolean = true,
    val markers: Boolean = false,
    val accessibility: Boolean = false,
    val fps: Float = 0f,
    val superTrend: Trend = Trend.UNKNOWN,
    val stochCross: Cross = Cross.NONE,
    val stochValue: Float = Float.NaN,
    val ao: Trend = Trend.UNKNOWN,
    val body: Float = Float.NaN,
    val payout: Int = -1,
    val engine: EngineState = EngineState.SCANNING,
    val lastSignal: Direction? = null
)

object BotState {
    val state = MutableStateFlow(UiState())
}

/** Настройки (SharedPreferences). Координаты кнопок — доли ширины/высоты экрана. */
object BotPrefs {
    const val CALL_X = "call_x"
    const val CALL_Y = "call_y"
    const val PUT_X = "put_x"
    const val PUT_Y = "put_y"
    private const val AUTO = "auto_tap"
    private const val COOLDOWN = "cooldown_s"
    private const val MODE = "trading_mode"

    // Центры кнопок КУПИТЬ / ПРОДАТЬ на скриншоте 1080x2400: (308,1553) и (771,1553)
    private val defaults = mapOf(
        CALL_X to 0.285f, CALL_Y to 0.647f,
        PUT_X to 0.714f, PUT_Y to 0.647f
    )

    private fun sp(c: Context) = c.getSharedPreferences("tradebot", Context.MODE_PRIVATE)

    fun get(c: Context, key: String): Float = sp(c).getFloat(key, defaults[key] ?: 0.5f)
    fun put(c: Context, key: String, v: Float) { sp(c).edit().putFloat(key, v).apply() }

    fun autoTap(c: Context): Boolean = sp(c).getBoolean(AUTO, false)
    fun setAutoTap(c: Context, v: Boolean) { sp(c).edit().putBoolean(AUTO, v).apply() }

    fun cooldownSec(c: Context): Int = sp(c).getInt(COOLDOWN, 60)
    fun setCooldownSec(c: Context, v: Int) { sp(c).edit().putInt(COOLDOWN, v).apply() }
    fun cooldownMs(c: Context): Long = cooldownSec(c) * 1000L

    /** Режим торговли; по умолчанию ТЕСТ. */
    fun tradingMode(c: Context): TradingMode {
        val name = sp(c).getString(MODE, null) ?: return TradingMode.TEST
        return try {
            TradingMode.valueOf(name)
        } catch (e: IllegalArgumentException) {
            TradingMode.TEST
        }
    }

    fun setTradingMode(c: Context, m: TradingMode) { sp(c).edit().putString(MODE, m.name).apply() }
}
