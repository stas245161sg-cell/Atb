package com.polaris.protocol

import kotlin.math.abs

/** Параметры индикаторов зафиксированы в алгоритме — оператор их не настраивает. */
private const val EMA_FAST = 9
private const val EMA_SLOW = 21
private const val RSI_PERIOD = 14
private const val ADX_PERIOD = 14
private const val ADX_MIN = 20f
private const val ATR_PERIOD = 14
private const val ATR_EXPANSION = 1.08f

enum class SignalDir { CALL, PUT, NONE }

data class Signal(val dir: SignalDir, val confidence: Float, val note: String)

interface Strategy {
    val name: String
    val weight: Float
    val enabled: Boolean
    fun evaluate(s: Snapshot, f: FiboLevels): Signal
}

/** Y→ценовая ось: чем больше значение, тем выше цена. */
private fun prices(s: Snapshot, f: FiboLevels): Triple<FloatArray, FloatArray, FloatArray> {
    val n = minOf(s.highs.size, s.lows.size, s.closes.size)
    return Triple(
        FloatArray(n) { priceOf(s.highs[it], f) },
        FloatArray(n) { priceOf(s.lows[it], f) },
        FloatArray(n) { priceOf(s.closes[it], f) }
    )
}

private fun ema(src: FloatArray, p: Int): FloatArray {
    val out = FloatArray(src.size)
    if (src.isEmpty() || p < 1) return out
    val k = 2f / (p + 1)
    var seed = 0f
    for (i in 0 until minOf(p, src.size)) seed += src[i]
    out[0] = seed / minOf(p, src.size)
    for (i in 1 until src.size) out[i] = src[i] * k + out[i - 1] * (1 - k)
    return out
}

private fun rsi(c: FloatArray, p: Int): Float {
    if (c.size <= p || p < 1) return 50f
    var gain = 0f
    var loss = 0f
    for (i in c.size - p until c.size) {
        val d = c[i] - c[i - 1]
        if (d >= 0f) gain += d else loss -= d
    }
    if (loss == 0f) return 100f
    return 100f - 100f / (1f + gain / loss)
}

private fun adx(h: FloatArray, l: FloatArray, c: FloatArray, p: Int): Float {
    if (c.size < p + 1 || p < 1) return 0f
    val tr = FloatArray(c.size)
    val pdm = FloatArray(c.size)
    val ndm = FloatArray(c.size)
    for (i in 1 until c.size) {
        tr[i] = maxOf(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1]))
        val up = h[i] - h[i - 1]
        val down = l[i - 1] - l[i]
        pdm[i] = if (up > down && up > 0f) up else 0f
        ndm[i] = if (down > up && down > 0f) down else 0f
    }
    var trS = 0f
    var pS = 0f
    var nS = 0f
    for (i in 1..p) { trS += tr[i]; pS += pdm[i]; nS += ndm[i] }
    var sum = 0f
    var cnt = 0
    for (i in p + 1 until c.size) {
        trS = trS - trS / p + tr[i]
        pS = pS - pS / p + pdm[i]
        nS = nS - nS / p + ndm[i]
        val pdi = 100f * pS / trS
        val ndi = 100f * nS / trS
        sum += 100f * abs(pdi - ndi) / (pdi + ndi + 1e-6f)
        cnt++
    }
    return if (cnt == 0) 0f else sum / cnt
}

/** Скальпинг: пробой 3-барного микрофрактала + импульс (на M5 = 15-минутный фрактал). */
class ScalpStrategy : Strategy {
    override val name = "SCALP"
    override val weight = 0.30f
    override val enabled get() = SignalSettings.scalpEnabled

    override fun evaluate(s: Snapshot, f: FiboLevels): Signal {
        val (h, l, c) = prices(s, f)
        val n = c.size
        if (n < 6) return Signal(SignalDir.NONE, 0f, "short_history")
        // Фрактал берём по ПРЕДЫДУЩИМ 3 свечам. Включать текущую нельзя:
        // её close физически не может быть выше её собственного high → стратегия никогда не голосовала.
        val fractalHigh = maxOf(h[n - 4], h[n - 3], h[n - 2])
        val fractalLow = minOf(l[n - 4], l[n - 3], l[n - 2])
        val span = fractalHigh - fractalLow
        if (span <= 0f) return Signal(SignalDir.NONE, 0f, "no_range")
        val impulse = (c[n - 1] - c[n - 4]) / span
        return when {
            c[n - 1] > fractalHigh && s.isGreen ->
                Signal(SignalDir.CALL, minOf(1f, abs(impulse)), "fractal_break_up")
            c[n - 1] < fractalLow && !s.isGreen ->
                Signal(SignalDir.PUT, minOf(1f, abs(impulse)), "fractal_break_dn")
            else -> Signal(SignalDir.NONE, 0f, "no_break")
        }
    }
}

/** Тренд: EMA(fast/slow) + RSI + фильтр ADX. */
class TrendStrategy : Strategy {
    override val name = "TREND"
    override val weight = 0.45f
    override val enabled get() = SignalSettings.trendEnabled

    override fun evaluate(s: Snapshot, f: FiboLevels): Signal {
        val (h, l, c) = prices(s, f)
        if (c.size <= EMA_SLOW + 1) return Signal(SignalDir.NONE, 0f, "need_${EMA_SLOW + 2}_bars")
        val fast = ema(c, EMA_FAST).last()
        val slowV = ema(c, EMA_SLOW).last()
        val r = rsi(c, RSI_PERIOD)
        val a = adx(h, l, c, ADX_PERIOD)
        if (a < ADX_MIN) return Signal(SignalDir.NONE, 0f, "adx_low")
        return when {
            fast > slowV && r in 45f..70f ->
                Signal(SignalDir.CALL, minOf(1f, a / 50f), "ema_up rsi=${r.toInt()} adx=${a.toInt()}")
            fast < slowV && r in 30f..55f ->
                Signal(SignalDir.PUT, minOf(1f, a / 50f), "ema_dn rsi=${r.toInt()} adx=${a.toInt()}")
            else -> Signal(SignalDir.NONE, 0f, "no_alignment")
        }
    }
}

/** OTC: сжатие ATR → расширение. */
class VolatilityStrategy : Strategy {
    override val name = "VOL"
    override val weight = 0.25f
    override val enabled get() = SignalSettings.volEnabled

    override fun evaluate(s: Snapshot, f: FiboLevels): Signal {
        val (h, l, c) = prices(s, f)
        if (c.size < 12) return Signal(SignalDir.NONE, 0f, "short")
        val p = ATR_PERIOD.coerceIn(2, c.size - 1)
        fun atr(len: Int): Float {
            var sum = 0f
            for (i in c.size - len until c.size) sum += h[i] - l[i]
            return sum / len
        }
        val base = atr(c.size - 1)
        if (base <= 0f) return Signal(SignalDir.NONE, 0f, "no_range")
        val ratio = atr(p) / base   // обе величины — средний диапазон на бар
        if (ratio <= ATR_EXPANSION) return Signal(SignalDir.NONE, 0f, "no_expansion")
        val conf = minOf(1f, ratio - 1f)
        return if (c.last() > c[c.size - 6])
            Signal(SignalDir.CALL, conf, "expansion_up")
        else
            Signal(SignalDir.PUT, conf, "expansion_dn")
    }
}
