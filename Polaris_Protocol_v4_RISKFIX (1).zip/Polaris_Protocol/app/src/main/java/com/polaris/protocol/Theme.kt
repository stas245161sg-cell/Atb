package com.polaris.protocol

import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ======================= Палитра «HyperOS 4 · Cold Glass» =======================
// Холодная ледяная гамма в тон иконке Polaris Protocol: ледяной циан, стальной тёмный фон,
// ничего горячего/красного — даже сигнальные цвета переведены в холодную часть спектра.

/** Глубокий ледяной чёрный → холодный стальной. */
val BgTop = Color(0xFF050A0E)
val BgBottom = Color(0xFF0D1A22)

/** Основной акцент: ледяной циан из свечения иконки; DeepCyan — тёмный конец градиента кнопок. */
val IceCyan = Color(0xFF6CE6FF)
val DeepCyan = Color(0xFF0B5F73)

/** Вторичный акцент: морозный голубой. */
val FrostBlue = Color(0xFF8FC2FF)

/** Текст: светлый ледяной белый для заголовков, приглушённый стальной для подписей. */
val TextPrimary = Color(0xFFEAF6FA)
val TextSecondary = Color(0xFF93AAB6)

/** Стекло HyperOS: полупрозрачная поверхность и обводка с ледяным оттенком. */
val GlassFill = Color.White.copy(alpha = 0.06f)
val GlassBorder = IceCyan.copy(alpha = 0.18f)
val GlassBrush: Brush = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.025f))
)

/**
 * Смысловые цвета статусов без «горячих» оттенков:
 * рост — ледяная мята, падение — холодный василёк.
 */
val Positive = Color(0xFF63E6C4)
val Negative = Color(0xFF8FA9FF)

/** Текст журнала. */
val LogText = Color(0xFFCFE6EF)

val AppBackgroundBrush: Brush = Brush.verticalGradient(listOf(BgTop, BgBottom))

private val PolarisColorScheme = darkColorScheme(
    primary = IceCyan,
    onPrimary = BgTop,
    secondary = FrostBlue,
    onSecondary = BgTop,
    background = BgTop,
    onBackground = TextPrimary,
    surface = BgTop,
    onSurface = TextPrimary,
    surfaceVariant = BgBottom,
    onSurfaceVariant = TextSecondary,
    outline = GlassBorder,
    error = Negative
)

private val PolarisTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 28.sp,
        color = TextPrimary
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        color = TextPrimary
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 14.sp,
        color = TextSecondary
    ),
    bodySmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Light,
        fontSize = 12.sp,
        color = TextSecondary
    ),
    labelLarge = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 14.sp,
        color = TextPrimary
    )
)

@Composable
fun PolarisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = PolarisColorScheme,
        typography = PolarisTypography,
        content = content
    )
}

/**
 * Фон экрана: вертикальный ледяной градиент и два мягких свечения —
 * циан справа сверху и морозный голубой слева снизу (как подсветка в иконке).
 */
@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(AppBackgroundBrush)
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(IceCyan.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width * 0.92f, size.height * 0.04f),
                        radius = size.width * 0.95f
                    )
                )
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(FrostBlue.copy(alpha = 0.14f), Color.Transparent),
                        center = Offset(size.width * 0.05f, size.height * 0.96f),
                        radius = size.width * 1.05f
                    )
                )
            },
        content = content
    )
}
