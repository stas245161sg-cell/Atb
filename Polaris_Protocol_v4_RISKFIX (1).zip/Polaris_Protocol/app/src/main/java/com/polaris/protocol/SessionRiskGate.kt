package com.polaris.protocol

import android.os.SystemClock

/**
 * Предохранитель по частоте: лимит сделок и cooldown.
 * Банк, размер ставки, дневные SL/TP задаёт оператор в Pocket Option — приложение
 * деньги не считает и ставку не меняет (мартингейл исключён полностью).
 *
 * ВАЖНО: все времена — только [SystemClock.elapsedRealtime]. Раньше allow() получал
 * elapsedRealtime, а onSignal() писал currentTimeMillis — разница в "~1.7 триллиона" мс
 * давала вечный BLOCK=cooldown после первой сделки.
 */
class SessionRiskGate(
    private val maxTrades: Int = 30,
    private val cooldownMs: Long = 60_000L
) {
    private var trades = 0
    private var lastTradeAt = 0L

    /** [now] сохраняем для совместимости вызова, но используем единые часы внутри. */
    fun allow(@Suppress("UNUSED_PARAMETER") now: Long): String? {
        val t = SystemClock.elapsedRealtime()
        return when {
            trades >= maxTrades -> "max_trades"
            t - lastTradeAt < cooldownMs -> "cooldown"
            else -> null
        }
    }

    fun onSignal() {
        trades++
        lastTradeAt = SystemClock.elapsedRealtime()
    }

    fun snapshot(): String = "trades=$trades"
}
